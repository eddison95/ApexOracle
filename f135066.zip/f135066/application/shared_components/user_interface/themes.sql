prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 135066
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_theme(
 p_id=>wwv_flow_api.id(13960856040450591937)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_api.id(13960764248818591902)
,p_default_dialog_template=>wwv_flow_api.id(13960759914229591901)
,p_error_template=>wwv_flow_api.id(13960753491289591898)
,p_printer_friendly_template=>wwv_flow_api.id(13960764248818591902)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_api.id(13960753491289591898)
,p_default_button_template=>wwv_flow_api.id(13960853193765591935)
,p_default_region_template=>wwv_flow_api.id(13960797068045591914)
,p_default_chart_template=>wwv_flow_api.id(13960797068045591914)
,p_default_form_template=>wwv_flow_api.id(13960797068045591914)
,p_default_reportr_template=>wwv_flow_api.id(13960797068045591914)
,p_default_tabform_template=>wwv_flow_api.id(13960797068045591914)
,p_default_wizard_template=>wwv_flow_api.id(13960797068045591914)
,p_default_menur_template=>wwv_flow_api.id(13960806470235591917)
,p_default_listr_template=>wwv_flow_api.id(13960797068045591914)
,p_default_irr_template=>wwv_flow_api.id(13960796002249591914)
,p_default_report_template=>wwv_flow_api.id(13960822795309591924)
,p_default_label_template=>wwv_flow_api.id(13960852129143591935)
,p_default_menu_template=>wwv_flow_api.id(13960854582670591936)
,p_default_calendar_template=>wwv_flow_api.id(13960854718018591936)
,p_default_list_template=>wwv_flow_api.id(13960839216371591930)
,p_default_nav_list_template=>wwv_flow_api.id(13960847832309591933)
,p_default_top_nav_list_temp=>wwv_flow_api.id(13960847832309591933)
,p_default_side_nav_list_temp=>wwv_flow_api.id(13960845252050591932)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_api.id(13960772933603591906)
,p_default_dialogr_template=>wwv_flow_api.id(13960771903852591905)
,p_default_option_label=>wwv_flow_api.id(13960852129143591935)
,p_default_required_label=>wwv_flow_api.id(13960852464671591935)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_api.id(13960845006762591932)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/1.3/')
,p_files_version=>67
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_api.component_end;
end;
/
