prompt --application/shared_components/user_interface/lovs/lov_moneda
begin
--   Manifest
--     LOV_MONEDA
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(13966336081955007059)
,p_lov_name=>'LOV_MONEDA'
,p_lov_query=>'.'||wwv_flow_api.id(13966336081955007059)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13966336388000007061)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'No Definida'
,p_lov_return_value=>'ND'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13966336774916007063)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Local'
,p_lov_return_value=>'L'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13966354692075268993)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Alterna'
,p_lov_return_value=>'A'
);
wwv_flow_api.component_end;
end;
/
