prompt --application/shared_components/security/authorizations/gip
begin
--   Manifest
--     SECURITY SCHEME: GIP
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_security_scheme(
 p_id=>wwv_flow_api.id(14000867207679915099)
,p_name=>'GIP'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM nss_autorizacion_usuario_tb_nx a, gnl_usuario_empresa_tb_nx b',
'WHERE a.use_id = b.use_id',
'AND use_usu_user_id = gnl_id_usuario_n_nx(:APP_USER)',
'AND subsistema = ''APX''',
'AND autorizacion = ''GIP'''))
,p_error_message=>'Usuario no tiene autorizacion GIP'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_api.component_end;
end;
/
