prompt --application/shared_components/security/authentications/mbacase
begin
--   Manifest
--     AUTHENTICATION: MBACASE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_authentication(
 p_id=>wwv_flow_api.id(14082218275716767554)
,p_name=>'MBACASE'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'my_authentication'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function my_authentication (',
'    p_username in varchar2,',
'    p_password in varchar2 )',
'    return boolean',
'is',
'    l_user GNL_USUARIOS_TB_NX.username%type := upper(p_username);',
'    l_pwd  GNL_USUARIOS_TB_NX.password%type;',
'    l_id   GNL_USUARIOS_TB_NX.user_id%type;',
'begin',
'    select user_id  , password',
'      into l_id, l_pwd',
'      from GNL_USUARIOS_TB_NX',
'     where username = l_user',
'     AND status in (''A'',''I'');',
'',
'    return l_pwd = nss_user_nx.hash_pw_pr(p_password);',
'exception',
'    when NO_DATA_FOUND then return false;',
'end;'))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_api.component_end;
end;
/
