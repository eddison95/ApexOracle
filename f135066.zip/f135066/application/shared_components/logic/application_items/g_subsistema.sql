prompt --application/shared_components/logic/application_items/g_subsistema
begin
--   Manifest
--     APPLICATION ITEM: G_SUBSISTEMA
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_flow_item(
 p_id=>wwv_flow_api.id(14193430979533872852)
,p_name=>'G_SUBSISTEMA'
,p_scope=>'GLOBAL'
,p_protection_level=>'N'
,p_escape_on_http_output=>'N'
);
wwv_flow_api.component_end;
end;
/
