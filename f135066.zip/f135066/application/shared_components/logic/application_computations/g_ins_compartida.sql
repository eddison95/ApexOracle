prompt --application/shared_components/logic/application_computations/g_ins_compartida
begin
--   Manifest
--     APPLICATION COMPUTATION: G_INS_COMPARTIDA
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_flow_computation(
 p_id=>wwv_flow_api.id(14003541997621707842)
,p_computation_sequence=>10
,p_computation_item=>'G_INS_COMPARTIDA'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'select valor from gnl_parametro_general_tb_nx where PARAMETRO =''INSTANCIA COMPARTIDA''and subsistema = ''GNL'';'
);
wwv_flow_api.component_end;
end;
/
