prompt --application/pages/page_00074
begin
--   Manifest
--     PAGE: 00074
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>74
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'TAL - Citas'
,p_step_title=>'Citas Taller'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164432'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094378861149906995)
,p_plug_name=>'Citas Taller'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094317409526420530)
,p_plug_name=>'Citas Taller'
,p_parent_plug_id=>wwv_flow_api.id(14094378861149906995)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 23/02/2017 06:30:48 p.m. (QP5 v5.115.810.9015) */',
'SELECT   c.CIT_EMP_EMPRESA,',
'         c.CIT_CITA,',
'         c.CIT_VEH_CONSECUTIVO,',
'         VEH_PLACA,',
'         cxc_nombre_cli_v_nx(VEH_CLI_EMP_EMPRESA, VEH_CLI_CLIENTE, VEH_CLI_MON_MONEDA) CLI_NOMBRE,',
'         TRUNC (c.CIT_FECHA),',
'         c.CIT_EMP_USERNAME,',
'         DECODE (c.CIT_ESTADO,',
'                 ''P'',',
'                 ''Pendiente'',',
'                 ''A'',',
'                 ''Agendada'',',
'                 ''C'',',
'                 ''Cancelada'',',
'                 ''O'',',
'                 ''Confirmada'',',
'                 ''I'',',
'                 ''Incumplida'',',
'                 ''U'',',
'                 ''Cumplida'')',
'            estado,',
'         c.CIT_DESCRIPCION,',
'         c.CIT_ANOTACIONES,',
'         c.CIT_DIST_RECORRIDA,',
'         c.CIT_MOTIVO motivo,',
'         c.CIT_FORMA_SOLICITUD,',
'         c.CIT_PRF_PROFORMA,',
'         c.CIT_PORC_DESC_SERV,',
'         c.CIT_PORC_DESC_REP,',
'         c.CIT_LPO_LISTA,',
'         c.CIT_CAT_CATEGORIA,',
'         TRUNC (c.CIT_INICIO_CITA) CIT_INICIO_CITA,',
'         TRUNC (c.CIT_FIN_CITA) CIT_FIN_CITA,',
'         c.CIT_ESTADO_REPUESTOS,',
'         c.CIT_LCN_LOCALIZACION,',
'         tal_ord_servi_cit_n_nx (c.CIT_EMP_EMPRESA, c.CIT_CITA) Orden#,',
'         c.CIT_VIS_CONSECUTIVO,',
'         TRUNC (TAL_FECHA_DE_LA_CITA_D_NX (c.CIT_EMP_EMPRESA, c.CIT_CITA))',
'            fechaCita,',
'         TRUNC (tal_bitacora_cit_d_nx (c.CIT_EMP_EMPRESA, c.CIT_CITA, ''P''))',
'            fechaP,',
'         TRUNC (tal_bitacora_cit_d_nx (c.CIT_EMP_EMPRESA, c.CIT_CITA, ''A''))',
'            fechaA,',
'         TRUNC (tal_bitacora_cit_d_nx (c.CIT_EMP_EMPRESA, c.CIT_CITA, ''C''))',
'            fechaC,',
'         TRUNC (tal_bitacora_cit_d_nx (c.CIT_EMP_EMPRESA, c.CIT_CITA, ''O''))',
'            fechaO,',
'         TRUNC (tal_bitacora_cit_d_nx (c.CIT_EMP_EMPRESA, c.CIT_CITA, ''I''))',
'            fechaI,',
'         TRUNC (',
'            tal_bitacora_cit_cumplida_d_nx (c.CIT_EMP_EMPRESA, c.CIT_CITA)',
'         )',
'            fechaU',
'  FROM   TAL_CITAS_TB_NX c, TAL_VEHICULOS_TB_NX v',
' WHERE   INSTR ('':'' || :P74_EMPRESA || '':'', '':'' || c.CIT_EMP_EMPRESA || '':'') >',
'            0',
'         AND cit_emp_empresa = veh_emp_empresa',
'         AND cit_veh_consecutivo = veh_consecutivo',
'         AND c.CIT_FECHA BETWEEN :P74_INICIO',
'                             AND  TO_DATE (:P74_FIN || '' 23:59'',',
'                                           ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P74_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14094317474686420531)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>6573749914531437
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094317578005420532)
,p_db_column_name=>'CIT_EMP_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094317644856420533)
,p_db_column_name=>'CIT_CITA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cita'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094317756519420534)
,p_db_column_name=>'CIT_VEH_CONSECUTIVO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Consecutivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094317978575420536)
,p_db_column_name=>'CIT_EMP_USERNAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Username'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094318077705420537)
,p_db_column_name=>'ESTADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094318147237420538)
,p_db_column_name=>'CIT_DESCRIPCION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094318237242420539)
,p_db_column_name=>'CIT_ANOTACIONES'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Anotaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094318393132420540)
,p_db_column_name=>'CIT_DIST_RECORRIDA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Dist Recorrida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094318448820420541)
,p_db_column_name=>'MOTIVO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094318574858420542)
,p_db_column_name=>'CIT_FORMA_SOLICITUD'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Solicitud'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094318718517420543)
,p_db_column_name=>'CIT_PRF_PROFORMA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Proforma'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094318824069420544)
,p_db_column_name=>'CIT_PORC_DESC_SERV'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Desc Serv'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094391756931958995)
,p_db_column_name=>'CIT_PORC_DESC_REP'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Desc Rep'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094391880542958996)
,p_db_column_name=>'CIT_LPO_LISTA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Lista Precio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094391988708958997)
,p_db_column_name=>'CIT_CAT_CATEGORIA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392111429958998)
,p_db_column_name=>'CIT_INICIO_CITA'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Inicio Cita'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392144953958999)
,p_db_column_name=>'CIT_FIN_CITA'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fin Cita'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392251423959000)
,p_db_column_name=>'CIT_ESTADO_REPUESTOS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Estado Repuestos'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392356477959001)
,p_db_column_name=>'CIT_LCN_LOCALIZACION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392449172959002)
,p_db_column_name=>'ORDEN#'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'# Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392537223959003)
,p_db_column_name=>'FECHAP'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'F. Pendiente'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392628557959004)
,p_db_column_name=>'FECHAA'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'F. Agregada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392767254959005)
,p_db_column_name=>'FECHAC'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'F. Cancelada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392845770959006)
,p_db_column_name=>'FECHAO'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'F. Confirmada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094392966826959007)
,p_db_column_name=>'FECHAI'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'F. Incumplida'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094393117327959008)
,p_db_column_name=>'FECHAU'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'F. Cumplida'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094393922759959016)
,p_db_column_name=>'CIT_VIS_CONSECUTIVO'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'# Visita'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569781041602514)
,p_db_column_name=>'FECHACITA'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'F. Cita'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095888309747530095)
,p_db_column_name=>'TRUNC(C.CIT_FECHA)'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'F. Cita'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086451398934262467)
,p_db_column_name=>'VEH_PLACA'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Placa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086451440598262468)
,p_db_column_name=>'CLI_NOMBRE'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14094427800775154516)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'66841'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CIT_EMP_EMPRESA:CIT_CITA:CIT_VEH_CONSECUTIVO:VEH_PLACA:CLI_NOMBRE:CIT_EMP_USERNAME:ESTADO:CIT_DESCRIPCION:CIT_ANOTACIONES:CIT_DIST_RECORRIDA:MOTIVO:CIT_FORMA_SOLICITUD:CIT_PRF_PROFORMA:CIT_PORC_DESC_SERV:CIT_PORC_DESC_REP:CIT_LPO_LISTA:CIT_CAT_CATEGO'
||'RIA:CIT_INICIO_CITA:CIT_FIN_CITA:CIT_ESTADO_REPUESTOS:CIT_LCN_LOCALIZACION:ORDEN#:CIT_VIS_CONSECUTIVO:FECHACITA:FECHAP:FECHAA:FECHAC:FECHAO:FECHAI:FECHAU:TRUNC(C.CIT_FECHA):'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14094379286798906996)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14094378861149906995)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094379683994906997)
,p_name=>'P74_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14094378861149906995)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094380091447906997)
,p_name=>'P74_INICIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14094378861149906995)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094380449113906998)
,p_name=>'P74_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14094378861149906995)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
