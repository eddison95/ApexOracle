prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('KJE \2013 Ventas Diarias')
,p_step_title=>'Ventas Diarias'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163106'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14192775270034263464)
,p_plug_name=>'Ventas Diarias'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14192884764658817410)
,p_plug_name=>'Ventas Diarias'
,p_parent_plug_id=>wwv_flow_api.id(14192775270034263464)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   KDM_EMPRESA,',
'         KDM_TRANSACCION,',
'         KDM_DOCUMENTO,',
'         KDM_DEPARTAMENTO,',
'         KDM_CAJA,',
'         KDM_ORIGEN,',
'         KDM_LOCALIZACION,',
'         TRUNC (KDM_FECHA),',
'         KDM_VENDEDOR,',
'         KDM_LISTA,',
'         KDM_MONEDA,',
'         KDM_CLIENTE_EMPRESA,',
'         KDM_CLIENTE,',
'         KDM_CLIENTE_MONEDA,',
'         KDM_NOMBRE,',
'         KDM_TIPO,',
'         KDM_STATUS,',
'         KDM_TT_TIPO,',
'         KDM_DOC_DOCUMENTO,',
'         KDM_PAGADA,',
'         KDM_SUBTOTAL,',
'         KDM_DESCUENTO,',
'         KDM_IMPUESTO_VENTAS,',
'         KDM_OTROS_IMPUESTOS,',
'         KDM_FLETE,',
'         KDM_OTROS_GASTOS,',
'         KDM_TOTAL,',
'         KDM_OBSERVACIONES,',
'         KDM_HOJA,',
'         KDM_ELETRONICO,',
'         CASE',
'          WHEN (fel_estado = 0 AND fel_batchid IS NULL) THEN ''SIN ENVIAR''',
'          WHEN fel_estado = 0 THEN ''ESPERANDO RESPUESTA''',
'          WHEN fel_estado = 1 THEN ''RECIBIDO SITIO WEB''',
'          WHEN fel_estado = 2 THEN ''ENVIADO''',
'          WHEN fel_estado = 3 THEN ''CON ERROR''',
'          WHEN fel_estado = 4 THEN ''APROBADO MH''',
'          WHEN fel_estado = 5 THEN ''CON ERROR''',
'          WHEN fel_estado = 6 THEN ''RECHAZADO''',
'          WHEN fel_estado = 7 THEN ''CON ERROR''',
'          ELSE ''OTRO''',
'       END ESTADO_HACIENDA,',
'       LIV_VENTAS_GRAVADAS GRAVADO,',
'       LIV_VENTAS_EXENTAS EXENTO',
'  FROM   KJE_DETALLE_MOVIMIENTOS_VW_NX, ',
'         FAC_FACTURA_ELECTRONICA_VW_NX,',
'         CGL_LIBRO_VENTAS_TB_NX',
' WHERE   INSTR ('':'' || :P2_EMPRESA || '':'', '':'' || KDM_EMPRESA || '':'') > 0',
'         AND FEL_EMPRESA = KDM_EMPRESA',
'         AND LIV_EMP_EMPRESA = FEL_EMPRESA',
'         AND FEL_TRANSACCION = KDM_TRANSACCION',
'         AND LIV_TRA_TRANSACCION = FEL_TRANSACCION',
'         AND KDM_FECHA BETWEEN :P2_FECHA_INICIO',
'                           AND  TO_DATE (:P2_FECHA_FIN || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P2_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14192884860505817410)
,p_name=>'Ventas Diarias'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>6885508386631733
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885064142817442)
,p_db_column_name=>'KDM_EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'KDM_EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885183325817444)
,p_db_column_name=>'KDM_TRANSACCION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('Transacci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'KDM_TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885277653817444)
,p_db_column_name=>'KDM_DOCUMENTO'
,p_display_order=>22
,p_column_identifier=>'C'
,p_column_label=>unistr('N\00FAmero Documento')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'KDM_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885354204817444)
,p_db_column_name=>'KDM_DEPARTAMENTO'
,p_display_order=>32
,p_column_identifier=>'D'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_static_id=>'KDM_DEPARTAMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885463713817445)
,p_db_column_name=>'KDM_CAJA'
,p_display_order=>42
,p_column_identifier=>'E'
,p_column_label=>'Caja'
,p_column_type=>'STRING'
,p_static_id=>'KDM_CAJA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885560048817447)
,p_db_column_name=>'KDM_ORIGEN'
,p_display_order=>52
,p_column_identifier=>'F'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_static_id=>'KDM_ORIGEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885670407817447)
,p_db_column_name=>'KDM_LOCALIZACION'
,p_display_order=>62
,p_column_identifier=>'G'
,p_column_label=>unistr('Localizaci\00F3n')
,p_column_type=>'STRING'
,p_static_id=>'KDM_LOCALIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885875250817448)
,p_db_column_name=>'KDM_VENDEDOR'
,p_display_order=>82
,p_column_identifier=>'I'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'KDM_VENDEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192885973175817448)
,p_db_column_name=>'KDM_LISTA'
,p_display_order=>92
,p_column_identifier=>'J'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
,p_static_id=>'KDM_LISTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886058591817448)
,p_db_column_name=>'KDM_MONEDA'
,p_display_order=>102
,p_column_identifier=>'K'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'KDM_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886172387817449)
,p_db_column_name=>'KDM_CLIENTE_EMPRESA'
,p_display_order=>112
,p_column_identifier=>'L'
,p_column_label=>'Cliente Empresa'
,p_column_type=>'STRING'
,p_static_id=>'KDM_CLIENTE_EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886257259817449)
,p_db_column_name=>'KDM_CLIENTE'
,p_display_order=>122
,p_column_identifier=>'M'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'KDM_CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886353708817449)
,p_db_column_name=>'KDM_CLIENTE_MONEDA'
,p_display_order=>132
,p_column_identifier=>'N'
,p_column_label=>'Cliente Moneda'
,p_column_type=>'STRING'
,p_static_id=>'KDM_CLIENTE_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886468453817450)
,p_db_column_name=>'KDM_NOMBRE'
,p_display_order=>142
,p_column_identifier=>'O'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'KDM_NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886583989817450)
,p_db_column_name=>'KDM_TIPO'
,p_display_order=>152
,p_column_identifier=>'P'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'KDM_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886668895817451)
,p_db_column_name=>'KDM_STATUS'
,p_display_order=>162
,p_column_identifier=>'Q'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_static_id=>'KDM_STATUS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886768696817451)
,p_db_column_name=>'KDM_TT_TIPO'
,p_display_order=>172
,p_column_identifier=>'R'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'KDM_TT_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886857264817452)
,p_db_column_name=>'KDM_DOC_DOCUMENTO'
,p_display_order=>182
,p_column_identifier=>'S'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_static_id=>'KDM_DOC_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192886976830817452)
,p_db_column_name=>'KDM_PAGADA'
,p_display_order=>192
,p_column_identifier=>'T'
,p_column_label=>'Pagada'
,p_column_type=>'STRING'
,p_static_id=>'KDM_PAGADA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887053289817452)
,p_db_column_name=>'KDM_SUBTOTAL'
,p_display_order=>202
,p_column_identifier=>'U'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KDM_SUBTOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887178887817453)
,p_db_column_name=>'KDM_DESCUENTO'
,p_display_order=>212
,p_column_identifier=>'V'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KDM_DESCUENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887254823817453)
,p_db_column_name=>'KDM_IMPUESTO_VENTAS'
,p_display_order=>222
,p_column_identifier=>'W'
,p_column_label=>'Impuesto Ventas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KDM_IMPUESTO_VENTAS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887372160817453)
,p_db_column_name=>'KDM_OTROS_IMPUESTOS'
,p_display_order=>232
,p_column_identifier=>'X'
,p_column_label=>'Otros Impuestos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KDM_OTROS_IMPUESTOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887452297817454)
,p_db_column_name=>'KDM_FLETE'
,p_display_order=>242
,p_column_identifier=>'Y'
,p_column_label=>'Flete'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KDM_FLETE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887582992817454)
,p_db_column_name=>'KDM_OTROS_GASTOS'
,p_display_order=>252
,p_column_identifier=>'Z'
,p_column_label=>'Otros Gastos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KDM_OTROS_GASTOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887653879817454)
,p_db_column_name=>'KDM_TOTAL'
,p_display_order=>262
,p_column_identifier=>'AA'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KDM_TOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887781931817455)
,p_db_column_name=>'KDM_OBSERVACIONES'
,p_display_order=>272
,p_column_identifier=>'AB'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_static_id=>'KDM_OBSERVACIONES'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192887865211817455)
,p_db_column_name=>'KDM_HOJA'
,p_display_order=>282
,p_column_identifier=>'AC'
,p_column_label=>'Hoja'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'KDM_HOJA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084690822094360960)
,p_db_column_name=>'KDM_ELETRONICO'
,p_display_order=>292
,p_column_identifier=>'AD'
,p_column_label=>unistr('Comprobante electr\00F3nico')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057097695367037113)
,p_db_column_name=>'ESTADO_HACIENDA'
,p_display_order=>302
,p_column_identifier=>'AE'
,p_column_label=>'Estado hacienda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049846394306900148)
,p_db_column_name=>'GRAVADO'
,p_display_order=>312
,p_column_identifier=>'AF'
,p_column_label=>'Gravado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049846488957900149)
,p_db_column_name=>'EXENTO'
,p_display_order=>322
,p_column_identifier=>'AG'
,p_column_label=>'Exento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049964704980260932)
,p_db_column_name=>'TRUNC(KDM_FECHA)'
,p_display_order=>332
,p_column_identifier=>'AH'
,p_column_label=>'Trunc(kdm fecha)'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14192887962496835773)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'68887'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'KDM_EMPRESA:KDM_TRANSACCION:KDM_DOCUMENTO:KDM_ELETRONICO:KDM_DEPARTAMENTO:KDM_CAJA:KDM_ORIGEN:KDM_LOCALIZACION:KDM_VENDEDOR:KDM_LISTA:KDM_MONEDA:KDM_CLIENTE_EMPRESA:KDM_CLIENTE:KDM_CLIENTE_MONEDA:KDM_NOMBRE:KDM_TIPO:KDM_STATUS:KDM_TT_TIPO:KDM_DOC_DOC'
||'UMENTO:KDM_PAGADA:KDM_SUBTOTAL:KDM_DESCUENTO:KDM_IMPUESTO_VENTAS:KDM_OTROS_IMPUESTOS:KDM_FLETE:KDM_OTROS_GASTOS:KDM_TOTAL:KDM_OBSERVACIONES:KDM_HOJA::ESTADO_HACIENDA:GRAVADO:EXENTO:TRUNC(KDM_FECHA)'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168172505407749472)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14192775270034263464)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096846938018423214)
,p_name=>'P2_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14192775270034263464)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14192775580030285295)
,p_name=>'P2_FECHA_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14192775270034263464)
,p_prompt=>'F. Inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14192800959252043392)
,p_name=>'P2_FECHA_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14192775270034263464)
,p_prompt=>'F. Final'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
