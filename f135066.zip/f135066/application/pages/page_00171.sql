prompt --application/pages/page_00171
begin
--   Manifest
--     PAGE: 00171
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>171
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'BCO - Carga Concliaciones'
,p_step_title=>'BCO - Carga Concliaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170110'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14138478089613989465)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14128289181521048053)
,p_plug_name=>'Archivo'
,p_parent_plug_id=>wwv_flow_api.id(14138478089613989465)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14128289388453048056)
,p_plug_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_api.id(14138478089613989465)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT seq_id, ',
'       c001, c002, c003, c004',
'FROM APEX_COLLECTIONS',
'WHERE COLLECTION_NAME = ''P171_CONCILIACION'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P171_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14128289520647048057)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>163179815070504012
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001189775915252121)
,p_db_column_name=>'C001'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001190157396252124)
,p_db_column_name=>'C002'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nro Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001190510201252124)
,p_db_column_name=>'C003'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001190965315252125)
,p_db_column_name=>'C004'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Monto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001194177629252128)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fila'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14128892789608935668)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'360848'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14128874594575892560)
,p_plug_name=>'Plantilla'
,p_parent_plug_id=>wwv_flow_api.id(14138478089613989465)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'bco_carga_nx.pla_conciliacion_pr;'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P171_PLANTILLA'
,p_plug_display_when_cond2=>'S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14001188616732252120)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14128289181521048053)
,p_button_name=>'CARGAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cargar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14001194930167252133)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14128289388453048056)
,p_button_name=>'PROCESAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Procesar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000849234968807378)
,p_name=>'P171_CONCILIACION'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14138478089613989465)
,p_prompt=>'Conciliacion'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (ccn_conciliacion ||'' ''||ccn_fecha) as d, ccn_conciliacion as r',
'FROM bco_conciliacion_tb_nx',
'WHERE ccn_ctb_bco_emp_empresa = :P171_EMPRESA',
'AND ccn_ctb_cuenta = :P171_CUENTA',
'AND ccn_status = ''C'''))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P171_CUENTA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'Solo conciliaciones en estado Creado y que pertenecen a la cuenta seleccionada'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14001182299860252070)
,p_name=>'P171_EMPRESA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14138478089613989465)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14001183042099252078)
,p_name=>'P171_CUENTA'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14138478089613989465)
,p_prompt=>'Cuenta'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (gnl_nombre_persona_v_nx(ctb_bco_per_persona)||''*''||ctb_mon_moneda||''* (''||ctb_cuenta||'')'') as d, ctb_cuenta as r ',
'FROM bco_cuenta_bancaria_tr_nx',
'WHERE ctb_bco_emp_empresa = :P171_EMPRESA'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P171_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14001183440394252080)
,p_name=>'P171_PLANTILLA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14138478089613989465)
,p_item_default=>'N'
,p_prompt=>'Plantilla'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:SI;S,NO;N'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14001189022789252120)
,p_name=>'P171_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14128289181521048053)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14001216296868589476)
,p_name=>'P171_ELIMINAR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14138478089613989465)
,p_item_default=>'S'
,p_prompt=>'Eliminar'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:SI;S,NO;N'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Indica si se deben eliminar las lineas existentes en la conciliacion'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14001196027238252150)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'cargar_pr'
,p_attribute_01=>'P171_ARCHIVO'
,p_attribute_02=>'P171_CONCILIACION'
,p_attribute_04=>';'
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14000755601524193963)
,p_process_success_message=>'Carga Completa'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14001196450170252151)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'procesar_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    det_con_v   bco_detalle_conciliacion_tb_nx%rowtype;',
'    persona_v   gnl_persona_tr_nx.persona%type;',
'    banco_v     bco_banco_tr_nx.bco_banco%type;',
'    id_v        bco_detalle_conciliacion_tb_nx.den_consecutivo%type;    ',
'BEGIN',
'    SELECT ctb_bco_per_persona, ctb_bco_banco',
'    INTO persona_v, banco_v',
'    FROM bco_cuenta_bancaria_tr_nx',
'    WHERE ctb_bco_emp_empresa = :P171_EMPRESA',
'    AND ctb_cuenta = :P171_CUENTA;',
'    ',
'    id_v := 1;',
'    ',
'    IF :P171_ELIMINAR = ''S'' THEN',
'       DELETE bco_detalle_conciliacion_tb_nx',
'       WHERE DEN_CCN_CONCILIACION = :P171_CONCILIACION',
'       AND DEN_CTB_BCO_EMP_EMPRESA = :P171_EMPRESA',
'       AND DEN_CTB_BCO_PER_PERSONA = persona_v',
'       AND DEN_CTB_BCO_BANCO = banco_v',
'       AND DEN_CTB_CUENTA = :P171_CUENTA;',
'       COMMIT;',
'    END IF;',
'    ',
'    FOR a IN (',
'        SELECT',
'            seq_id,',
'            SUBSTR(c001,1,10) c001, c002, c003, c004',
'        FROM',
'            apex_collections',
'        WHERE',
'            collection_name = ''P171_CONCILIACION''',
'        ORDER BY',
'            seq_id',
'    ) LOOP',
'        det_con_v.den_ccn_conciliacion := :P171_CONCILIACION;',
'        det_con_v.den_consecutivo := id_v;',
'        det_con_v.den_ctb_bco_emp_empresa := :p171_empresa;',
'        det_con_v.den_ctb_bco_per_persona := persona_v;',
'        det_con_v.den_ctb_bco_banco := banco_v;',
'        det_con_v.den_ctb_cuenta := :P171_CUENTA;',
'        det_con_v.den_fecha := TO_DATE(a.c001);',
'        det_con_v.den_monto := a.c004;',
'        det_con_v.den_conciliado := 2;',
'        det_con_v.den_ind_conciliacion := 2;',
'        det_con_v.den_numero_documento := a.c002;',
'        det_con_v.den_ind_seleccion := ''N'';',
'        det_con_v.den_observaciones := a.c003;',
'        det_con_v.den_status := ''C'';                ',
'        bco_carga_nx.det_conciliacion_pr(det_con_v);',
'        COMMIT;',
'        id_v := id_v + 1;',
'    END LOOP;',
'    ',
'    apex_collection.truncate_collection(''P171_CONCILIACION'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14001194930167252133)
,p_process_success_message=>'Proceso Terminado'
);
wwv_flow_api.component_end;
end;
/
