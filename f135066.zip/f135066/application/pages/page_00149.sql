prompt --application/pages/page_00149
begin
--   Manifest
--     PAGE: 00149
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>149
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'INV - Entrada por Compra'
,p_step_title=>'Entrada por Compra'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14074633162152556973)
,p_plug_name=>'Entrada por Compra'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14076650709477263167)
,p_plug_name=>'INV - Entrada por Compra'
,p_parent_plug_id=>wwv_flow_api.id(14074633162152556973)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   a.*,',
'         b.*,',
'         DECODE (tsn_status,',
'                 ''R'',',
'                 ''Registrado'',',
'                 ''C'',',
'                 ''Creado'',',
'                 ''P'',',
'                 ''Procesada'',',
'                 ''O'',',
'                 ''Confirmada'')',
'            estado,',
'         cxp_nombre_prov_v_nx (tsn_emp_empresa,',
'                               tsn_pro_proveedor,',
'                               tsn_pro_mon_moneda)',
'            nombre_proveedor,',
'         (SELECT   SUM(NVL (DTN_MONTO, 0))',
'            FROM   INV_DETALLE_TRANSACCION_TB_NX',
'           WHERE   dtn_tsn_transaccion = a.tsn_transaccion)',
'            subtotal,',
'         (  (SELECT   SUM(NVL (DTN_MONTO, 0))',
'               FROM   INV_DETALLE_TRANSACCION_TB_NX',
'              WHERE   dtn_tsn_transaccion = a.tsn_transaccion)',
'          - TSN_DESCUENTO',
'          + TSN_OTROS_IMPUESTOS',
'          + TSN_IMPUESTO_VENTAS)',
'            total,',
'cxp_cedula_prov_v_nx(',
'  tsn_emp_empresa',
' , tsn_pro_proveedor',
' , tsn_pro_mon_moneda',
') cedula_proveedor',
'  FROM   inv_transaccion_tb_nx a, INV_TRANS_GRAVAMEN_TB_NX b',
' WHERE   igr_tsn_transaccion = tsn_transaccion',
'         AND INSTR ('':'' || :P149_EMPRESA || '':'',',
'                    '':'' || tsn_emp_empresa || '':'') > 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14076650826377263167)
,p_name=>'INV - Entrada por Compra'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>20769728140848508
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062870413874467076)
,p_db_column_name=>'TSN_EMP_EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062870888684467077)
,p_db_column_name=>'TSN_TRANSACCION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062871265362467078)
,p_db_column_name=>'TSN_TTN_TIPO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062871676536467079)
,p_db_column_name=>'TSN_TIP_TIPO_CAMBIO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Tipo Cambio'
,p_sync_form_label=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062872069071467080)
,p_db_column_name=>'TSN_MON_MONEDA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Moneda'
,p_sync_form_label=>'N'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062872470360467081)
,p_db_column_name=>'TSN_DOC_DOCUMENTO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062872841047467081)
,p_db_column_name=>'TSN_NUMERO_DOCUMENTO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Numero Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062873275970467082)
,p_db_column_name=>'TSN_FECHA_DOCUMENTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062873676866467082)
,p_db_column_name=>'TSN_DEP_EMP_EMPRESA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Emp. Departamento'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062874094152467083)
,p_db_column_name=>'TSN_DEP_DEPARTAMENTO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062874439489467083)
,p_db_column_name=>'TSN_FECHA_TRANSACCION'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fecha Transaccion'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062874890527467083)
,p_db_column_name=>'TSN_STATUS'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062875251633467084)
,p_db_column_name=>'TSN_PRO_EMP_EMPRESA'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062875645421467084)
,p_db_column_name=>'TSN_PRO_PROVEEDOR'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062876072795467085)
,p_db_column_name=>'TSN_PRO_MON_MONEDA'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Moneda Prov'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062876415663467085)
,p_db_column_name=>'TSN_CLI_EMP_EMPRESA'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Empresa Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062876873450467086)
,p_db_column_name=>'TSN_CLI_CLIENTE'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062877280669467086)
,p_db_column_name=>'TSN_CLI_MON_MONEDA'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Moneda Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062877608669467086)
,p_db_column_name=>'TSN_DESCUENTO'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062878064695467087)
,p_db_column_name=>'TSN_IMPUESTO_VENTAS'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Impuesto Ventas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062878456536467087)
,p_db_column_name=>'TSN_OTROS_IMPUESTOS'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Otros Impuestos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062878872661467089)
,p_db_column_name=>'TSN_OTROS_CARGOS'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Otros Cargos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062879291433467090)
,p_db_column_name=>'TSN_INDICE_CORRECCION'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Indice Correccion'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062879686206467090)
,p_db_column_name=>'TSN_VALOR_CAMBIO'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Valor Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062880056783467091)
,p_db_column_name=>'TSN_OBSERVACIONES'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062880443408467091)
,p_db_column_name=>'TSN_LCN_EMP_EMPRESA'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Emp Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062880827217467092)
,p_db_column_name=>'TSN_LCN_LOCALIZACION'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062881231930467092)
,p_db_column_name=>'TSN_TRANSACCION_REF'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Transaccion Ref'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062881660073467092)
,p_db_column_name=>'TSN_TRA_TRANSACCION'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Transaccion Fact.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062882018423467093)
,p_db_column_name=>'TSN_NCD_TRANSACCION'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Transaccion Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062882486354467093)
,p_db_column_name=>'TSN_TSC_TRANSACCION'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Transaccion Tsc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062882808809467093)
,p_db_column_name=>'TSN_GENERAR_KERNEL'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Generar Kernel'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062883219648467094)
,p_db_column_name=>'TSN_GENERAR_CXC'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Generar Cxc'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062883629409467094)
,p_db_column_name=>'TSN_GENERAR_CXP'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Generar Cxp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062884056992467095)
,p_db_column_name=>'TSN_ESTADISTICA_GENERADA'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Estadistica Generada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062884494707467095)
,p_db_column_name=>'TSN_CREADO_POR'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Creado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062884802581467096)
,p_db_column_name=>'TSN_FECHA_CREACION'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Fecha Creacion'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062885250462467096)
,p_db_column_name=>'TSN_MODIFICADO_POR'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Modificado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062885696452467096)
,p_db_column_name=>'TSN_FECHA_MODIFICACION'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Fecha Modificacion'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062886079652467097)
,p_db_column_name=>'TSN_REGISTRADA_POR'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Registrada Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062886444664467097)
,p_db_column_name=>'TSN_FECHA_REGISTRO'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Fecha Registro'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062887198299467098)
,p_db_column_name=>'TSN_ESTAD_DIARIA_GENERADA'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Estad Diaria Generada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062886871288467098)
,p_db_column_name=>'TSN_TSN_TRANSACCION'
,p_display_order=>53
,p_column_identifier=>'AP'
,p_column_label=>'Transaccion Padre'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062887633979467099)
,p_db_column_name=>'TSN_ENC_CONSULTA'
,p_display_order=>63
,p_column_identifier=>'AR'
,p_column_label=>'Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062888021086467099)
,p_db_column_name=>'TSN_GRUPO'
,p_display_order=>73
,p_column_identifier=>'AS'
,p_column_label=>'Grupo'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062888475293467102)
,p_db_column_name=>'TSN_SELECCIONADO'
,p_display_order=>83
,p_column_identifier=>'AT'
,p_column_label=>'Seleccionado'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062888875466467102)
,p_db_column_name=>'TSN_SESION'
,p_display_order=>93
,p_column_identifier=>'AU'
,p_column_label=>'Sesion'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062889289874467103)
,p_db_column_name=>'TSN_IND_PSI'
,p_display_order=>103
,p_column_identifier=>'AV'
,p_column_label=>'Ind Psi'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062889627125467103)
,p_db_column_name=>'TSN_TIPO'
,p_display_order=>113
,p_column_identifier=>'AW'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062890024332467103)
,p_db_column_name=>'TSN_IND_PSI_B'
,p_display_order=>123
,p_column_identifier=>'AX'
,p_column_label=>'Psi B'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062890468091467103)
,p_db_column_name=>'TSN_PSI_EMP_EMPRESA'
,p_display_order=>133
,p_column_identifier=>'AY'
,p_column_label=>'Empresa Psi'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062890830126467104)
,p_db_column_name=>'TSN_PSI_PEDIDO_INT'
,p_display_order=>143
,p_column_identifier=>'AZ'
,p_column_label=>'Pedido Int Psi'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062891219357467104)
,p_db_column_name=>'TSN_COMPROBANTE_ELECTRONICO'
,p_display_order=>153
,p_column_identifier=>'BA'
,p_column_label=>'Comprobante Electronico'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062891632080467104)
,p_db_column_name=>'TSN_RETENCION'
,p_display_order=>163
,p_column_identifier=>'BB'
,p_column_label=>'Retencion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062892024163467105)
,p_db_column_name=>'TSN_ATV_ACTIVIDAD'
,p_display_order=>173
,p_column_identifier=>'BC'
,p_column_label=>'Actividad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062892485723467105)
,p_db_column_name=>'IGR_EMP_EMPRESA'
,p_display_order=>183
,p_column_identifier=>'BD'
,p_column_label=>'Empresa Base Gravable'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062892882901467105)
,p_db_column_name=>'IGR_TSN_TRANSACCION'
,p_display_order=>193
,p_column_identifier=>'BE'
,p_column_label=>'Transaccion Inv'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062893238819467106)
,p_db_column_name=>'IGR_ID_GRAV'
,p_display_order=>203
,p_column_identifier=>'BF'
,p_column_label=>'Id Gravable'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062893667209467106)
,p_db_column_name=>'IGR_BASE_IMPONIBLE'
,p_display_order=>213
,p_column_identifier=>'BG'
,p_column_label=>'Base Imponible'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062894026106467107)
,p_db_column_name=>'IGR_PORCENTAJE'
,p_display_order=>223
,p_column_identifier=>'BH'
,p_column_label=>'Porcentaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062894402263467107)
,p_db_column_name=>'IGR_MONTO'
,p_display_order=>233
,p_column_identifier=>'BI'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062894883401467108)
,p_db_column_name=>'IGR_PRORRATA'
,p_display_order=>243
,p_column_identifier=>'BJ'
,p_column_label=>'Prorrata'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062895239035467108)
,p_db_column_name=>'IGR_IVA_NODESCONTABLE_COSTO'
,p_display_order=>253
,p_column_identifier=>'BK'
,p_column_label=>'Iva No Descontable Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062895670982467109)
,p_db_column_name=>'IGR_IVA_NODESCONTABLE_GASTO'
,p_display_order=>263
,p_column_identifier=>'BL'
,p_column_label=>'Iva No Descontable Gasto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062896039222467109)
,p_db_column_name=>'IGR_IVA_SOPORTADO'
,p_display_order=>273
,p_column_identifier=>'BM'
,p_column_label=>'Iva Soportado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062869664630467073)
,p_db_column_name=>'ESTADO'
,p_display_order=>283
,p_column_identifier=>'BN'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14062870044437467076)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>293
,p_column_identifier=>'BO'
,p_column_label=>'Nombre proveedor'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14060725017764929087)
,p_db_column_name=>'TOTAL'
,p_display_order=>303
,p_column_identifier=>'BP'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14060725110406929088)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>313
,p_column_identifier=>'BQ'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14060725267033929089)
,p_db_column_name=>'CEDULA_PROVEEDOR'
,p_display_order=>323
,p_column_identifier=>'BR'
,p_column_label=>'Ced. Proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14076677914983280833)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'70153'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TSN_EMP_EMPRESA:TSN_TRANSACCION:TSN_TTN_TIPO:TSN_TIP_TIPO_CAMBIO:TSN_MON_MONEDA:TSN_DOC_DOCUMENTO:TSN_NUMERO_DOCUMENTO:TSN_FECHA_DOCUMENTO:TSN_DEP_EMP_EMPRESA:TSN_DEP_DEPARTAMENTO:TSN_FECHA_TRANSACCION:TSN_STATUS:TSN_PRO_EMP_EMPRESA:TSN_PRO_PROVEEDOR'
||':TSN_PRO_MON_MONEDA:TSN_CLI_EMP_EMPRESA:TSN_CLI_CLIENTE:TSN_CLI_MON_MONEDA:TSN_DESCUENTO:TSN_IMPUESTO_VENTAS:TSN_OTROS_IMPUESTOS:TSN_OTROS_CARGOS:TSN_INDICE_CORRECCION:TSN_VALOR_CAMBIO:TSN_OBSERVACIONES:TSN_LCN_EMP_EMPRESA:TSN_LCN_LOCALIZACION:TSN_TR'
||'ANSACCION_REF:TSN_TRA_TRANSACCION:TSN_NCD_TRANSACCION:TSN_TSC_TRANSACCION:TSN_GENERAR_KERNEL:TSN_GENERAR_CXC:TSN_GENERAR_CXP:TSN_ESTADISTICA_GENERADA:TSN_CREADO_POR:TSN_FECHA_CREACION:TSN_MODIFICADO_POR:TSN_FECHA_MODIFICACION:TSN_REGISTRADA_POR:TSN_F'
||'ECHA_REGISTRO:TSN_TSN_TRANSACCION:TSN_ESTAD_DIARIA_GENERADA:TSN_ENC_CONSULTA:TSN_GRUPO:TSN_SELECCIONADO:TSN_SESION:TSN_IND_PSI:TSN_TIPO:TSN_IND_PSI_B:TSN_PSI_EMP_EMPRESA:TSN_PSI_PEDIDO_INT:TSN_COMPROBANTE_ELECTRONICO:TSN_RETENCION:TSN_ATV_ACTIVIDAD:I'
||'GR_EMP_EMPRESA:IGR_TSN_TRANSACCION:IGR_ID_GRAV:IGR_BASE_IMPONIBLE:IGR_PORCENTAJE:IGR_MONTO:IGR_PRORRATA:IGR_IVA_NODESCONTABLE_COSTO:IGR_IVA_NODESCONTABLE_GASTO:IGR_IVA_SOPORTADO:ESTADO:NOMBRE_PROVEEDOR:TOTAL:SUBTOTAL:CEDULA_PROVEEDOR'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14062897089684467125)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14074633162152556973)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14062897432038467126)
,p_name=>'P149_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14074633162152556973)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
