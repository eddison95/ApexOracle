prompt --application/pages/page_00043
begin
--   Manifest
--     PAGE: 00043
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>43
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CGL \2013 Estado de Resultados')
,p_step_title=>'Estado de Resultados'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163931'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14168020924957658986)
,p_plug_name=>'Estado de Resultados'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14168020023090656395)
,p_plug_name=>'Estado de Resultados'
,p_parent_plug_id=>wwv_flow_api.id(14168020924957658986)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 23/02/2017 08:38:05 a.m. (QP5 v5.115.810.9015) */',
'SELECT   a.empresa,',
'         a.cuenta,',
'         b.descripcion,',
'         DECODE (tipo,',
'                 1,',
'                 ''Mayor'',',
'                 2,',
'                 ''Detalle'')',
'            tipo,',
'         a.inicial,',
'         a.debe,',
'         a.haber,',
'         a.final',
'  FROM   cgl_consulta_p_vw_nx a, cgl_cuenta_tr_nx b',
' WHERE       INSTR ('':'' || :p43_empresa || '':'', '':'' || a.empresa || '':'') > 0',
'         AND a.PERIODO_ID = :p43_periodo_mba',
'         AND a.moneda = :p43_moneda',
'         AND a.CONTABILIDAD = :p43_contabilidad',
'         AND b.emp_empresa = a.empresa',
'         AND b.cuenta = a.cuenta',
'         AND b.grupo IN (4, 5, 6, 7)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P43_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14168020104868656395)
,p_name=>'Reporte Estado de Resultados'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10906211457157095
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168020321451656418)
,p_db_column_name=>'CUENTA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168020410254656420)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168020515905656420)
,p_db_column_name=>'INICIAL'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Inicial'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'INICIAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168020603594656421)
,p_db_column_name=>'DEBE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Debe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DEBE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168020700995656421)
,p_db_column_name=>'HABER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Haber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'HABER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168020812663656421)
,p_db_column_name=>'FINAL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Final'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'FINAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14131158430622642088)
,p_db_column_name=>'TIPO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098671726490192139)
,p_db_column_name=>'EMPRESA'
,p_display_order=>17
,p_column_identifier=>'H'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14168022099115660924)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'109083'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CUENTA:DESCRIPCION:TIPO:INICIAL:DEBE:HABER:FINAL::EMPRESA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168170097693692261)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_api.id(14168020924957658986)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168021118965658994)
,p_name=>'P43_PERIODO_MBA'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(14168020924957658986)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (periodo||'' ''||ano||'' ''||fecha_inicio||'' ''||fecha_fin) descripcion, id',
'from cgl_periodo_tr_nx',
'where emp_empresa = :P43_EMPRESA',
'ORDER BY ano desc, periodo desc'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P43_EMPRESA'
,p_ajax_items_to_submit=>'P43_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168021303813658998)
,p_name=>'P43_CONTABILIDAD'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14168020924957658986)
,p_prompt=>'Contabilidad'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Fiscal;2,Corporativa;3'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168021522960658999)
,p_name=>'P43_MONEDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14168020924957658986)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Local;2,Alterna;3'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168021903341659000)
,p_name=>'P43_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14168020924957658986)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
