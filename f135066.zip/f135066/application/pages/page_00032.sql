prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>32
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CGL \2013 Anexos Saldos por Departamento')
,p_step_title=>'Anexos Saldos por Departamento'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170251'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14180422631969214457)
,p_plug_name=>'Anexos Saldos por Departamento'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14180421058011208581)
,p_plug_name=>'Anexos Saldos por Departamento'
,p_parent_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   sdp_emp_empresa,',
'			  sdp_cta_cuenta,',
'                          cgl_cuenta_reporte_v_nx (a.empresa, a.cuenta)||'' -  ''||c.descripcion cuenta_formato,',
'			  sdp_dep_departamento,',
'			  sdp_sac_peri_id,',
'			  sdp_moneda,',
'			  sdp_contabilidad,',
'			  sdp_inicial,',
'			  sdp_debe,',
'			  sdp_haber,',
'			  sdp_final,',
'			  NVL (sdp_debe, 0) - NVL (sdp_haber, 0) mes,',
'			  sdp_saldo_fasb,',
'			  cgl_nombre_depto_v_nx (sdp_emp_empresa, sdp_dep_departamento)',
'				  departamento',
'	 FROM   cgl_cons_saldo_dpto_todo_vw_nx b,',
'			  cgl_consulta_p_vw_nx a,',
'			  cgl_cuenta_tr_nx c',
'	WHERE 		a.empresa = :p32_empresa',
'			  AND a.moneda = :p32_moneda',
'			  AND a.contabilidad = :p32_contabilidad',
'			  AND a.empresa = b.sdp_emp_empresa',
'			  AND a.moneda = b.sdp_moneda',
'			  AND a.cuenta = b.sdp_cta_cuenta',
'			  AND a.periodo_id = b.sdp_sac_peri_id',
'			  AND a.contabilidad = b.sdp_contabilidad',
'			  AND c.emp_empresa = a.empresa',
'			  AND c.cuenta = a.cuenta',
'			  AND c.cuenta >= NVL (:p32_cuenta_ini, c.cuenta)',
'			  AND c.cuenta <= NVL (:p32_cuenta_fin, c.cuenta)',
'			  AND c.nivel <= NVL (:p32_nivel, c.nivel)',
'                          AND a.periodo_id= :p32_periodo_mba ',
'			  AND NVL (sdp_debe, 0) - NVL (sdp_haber, 0) > 0',
'			  AND NVL (sdp_final, 0) > 0',
'			  AND NVL(a.debe, 0) - NVL (a.haber, 0)> 0',
'			  AND NVL (a.final, 0) > 0',
'ORDER BY   a.empresa, a.moneda, a.contabilidad, a.cuenta'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P32_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14180421136288208581)
,p_name=>'Saldos por Departamento'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>3520107546649685
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180421338700208631)
,p_db_column_name=>'SDP_EMP_EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Sdp Emp Empresa'
,p_column_type=>'STRING'
,p_static_id=>'SDP_EMP_EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180421461069208638)
,p_db_column_name=>'SDP_CTA_CUENTA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Sdp Cta Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'SDP_CTA_CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180421555353208639)
,p_db_column_name=>'SDP_DEP_DEPARTAMENTO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('C\00F3digo de Departamento')
,p_column_type=>'STRING'
,p_static_id=>'SDP_DEP_DEPARTAMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180421641508208639)
,p_db_column_name=>'SDP_SAC_PERI_ID'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Sdp Sac Peri Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'SDP_SAC_PERI_ID'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180421738066208640)
,p_db_column_name=>'SDP_MONEDA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Sdp Moneda'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'SDP_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180421833975208640)
,p_db_column_name=>'SDP_CONTABILIDAD'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Sdp Contabilidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'SDP_CONTABILIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180421957012208641)
,p_db_column_name=>'SDP_INICIAL'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Sdp Inicial'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SDP_INICIAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180422055456208641)
,p_db_column_name=>'SDP_DEBE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Sdp Debe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SDP_DEBE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180422154374208642)
,p_db_column_name=>'SDP_HABER'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Sdp Haber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SDP_HABER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180422244704208642)
,p_db_column_name=>'SDP_FINAL'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Acumulado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SDP_FINAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180422449280208643)
,p_db_column_name=>'SDP_SALDO_FASB'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Sdp Saldo Fasb'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SDP_SALDO_FASB'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180422555567208644)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_static_id=>'DEPARTAMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180428738348395492)
,p_db_column_name=>'CUENTA_FORMATO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Cuenta Formato'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA_FORMATO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180430446917725814)
,p_db_column_name=>'MES'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'MES'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14180427333971309725)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'35264'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'CUENTA_FORMATO:SDP_DEP_DEPARTAMENTO:DEPARTAMENTO:MES:SDP_FINAL:'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'SDP_MES:SDP_FINAL:MES'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168170726135709460)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168023304384684758)
,p_name=>'P32_PERIODO_MBA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (periodo||'' ''||ano||'' ''||fecha_inicio||'' ''||fecha_fin) descripcion, id',
'from cgl_periodo_tr_nx',
'where emp_empresa = :P32_EMPRESA',
'ORDER BY ano desc, periodo desc'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P32_EMPRESA'
,p_ajax_items_to_submit=>'P32_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14180423160481218118)
,p_name=>'P32_CUENTA_INI'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_prompt=>'Cuenta Inicial'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14180423355737220261)
,p_name=>'P32_CUENTA_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_prompt=>'Cuenta Final'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14180423552070221940)
,p_name=>'P32_NIVEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_prompt=>'Nivel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14180424252274237044)
,p_name=>'P32_MONEDA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Local;2,Alterna;3'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14180424449470238431)
,p_name=>'P32_CONTABILIDAD'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_prompt=>'Contabilidad'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Fiscal;2,Corporativa;3'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14180424644726240627)
,p_name=>'P32_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14180422631969214457)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
