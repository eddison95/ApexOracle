prompt --application/pages/page_00063
begin
--   Manifest
--     PAGE: 00063
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>63
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CXP - Antiguedad de Saldos'
,p_step_title=>'CXP - Antiguedad de Saldos'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201210093217'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14138542843926378848)
,p_plug_name=>'Antiguedad de Saldos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14138541945277378769)
,p_plug_name=>'Antiguedad de Saldos'
,p_region_name=>'Reporte Antiguedad de Saldos'
,p_parent_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 19/11/2018 01:18:58 p.m. (QP5 v5.115.810.9015) */',
'SELECT   tsp_emp_empresa tsp_empresa,',
'         tsp_transaccion tsp_transaccion,',
'         (tsp_ttp_tipo || ''-'' || tsp_documento) tsp_documento,',
'         tsp_pro_proveedor tsp_proveedor,',
'         tsp_pro_mon_moneda tsp_moneda,',
'         cxp_nombre_prov_v_nx (tsp_emp_empresa,',
'                               tsp_pro_proveedor,',
'                               tsp_pro_mon_moneda)',
'            tsp_nombre,',
'         cxp_cedula_prov_v_nx (tsp_emp_empresa,',
'                               tsp_pro_proveedor,',
'                               tsp_pro_mon_moneda)',
'            tsp_cedula_prov,',
'         cxp_clase_prov_v_nx (tsp_emp_empresa,',
'                              tsp_pro_proveedor,',
'                              tsp_pro_mon_moneda)',
'            clase,',
'         CXP_TIPO_PROV_V_NX (tsp_emp_empresa,',
'                             tsp_pro_proveedor,',
'                             tsp_pro_mon_moneda)',
'            tipo,',
'         tsp_detalle_documento,',
'         TRUNC (tsp_fecha_transaccion) tsp_fecha_transaccion,',
'         TRUNC (tsp_fecha_vencimiento) tsp_fecha_vencimiento,',
'         ttp_aumenta_disminuye tsp_signo,',
'         tsp_monto tsp_monto,',
'         TRUNC (tsp_fecha_liquidacion) tsp_fecha_liquidacion,',
'         cxp_saldo_fecha_n_nx (tsp_transaccion, :P63_FIN) tsp_saldo,',
'         tsp_plazo,',
'         DECODE (tsp_status,',
'                 ''E'',',
'                 ''Entrada'',',
'                 ''V'',',
'                 ''Vigente'',',
'                 ''S'',',
'                 ''Solicitud'',',
'                 ''L'',',
'                 ''Liquidada'')',
'            tsp_estatus',
'  FROM   cxp_transaccion_tb_nx, cxp_tipo_transaccion_tb_nx',
' WHERE       tsp_status <> ''E''',
'         AND tsp_ind_referencia = ''N''',
'         AND tsp_tsp_transaccion IS NULL',
'         AND tsp_ind_referencia = ''N''',
'         AND tsp_emp_empresa = ttp_emp_empresa',
'         AND tsp_ttp_tipo = ttp_tipo',
'         AND tsp_fecha_transaccion BETWEEN :p63_inicio',
'                                       AND  TO_DATE (:p63_fin || '' 23:59'',',
'                                                     ''dd/mm/rrrr hh24:mi'')',
'         AND INSTR ('':'' || :P63_EMPRESA || '':'',',
'                    '':'' || TSP_EMP_EMPRESA || '':'') > 0',
'         AND tsp_pro_mon_moneda = :P63_MONEDA',
'         AND tsp_pro_proveedor = NVL (:P63_PROVEEDOR, tsp_pro_proveedor)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P63_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14138542126497378778)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>75522396057162519
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082478312300663658)
,p_db_column_name=>'TSP_EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'TSP_EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082478633662663659)
,p_db_column_name=>'TSP_TRANSACCION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TSP_TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082479090376663660)
,p_db_column_name=>'TSP_DOCUMENTO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_static_id=>'TSP_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082479435694663660)
,p_db_column_name=>'TSP_PROVEEDOR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'TSP_PROVEEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082479924825663662)
,p_db_column_name=>'TSP_MONEDA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'TSP_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082480294746663663)
,p_db_column_name=>'TSP_NOMBRE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'TSP_NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082480683621663664)
,p_db_column_name=>'TSP_DETALLE_DOCUMENTO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Detalle Documento'
,p_column_type=>'STRING'
,p_static_id=>'TSP_DETALLE_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082481085218663665)
,p_db_column_name=>'TSP_FECHA_TRANSACCION'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fecha Transaccion'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'TSP_FECHA_TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082481459765663665)
,p_db_column_name=>'TSP_FECHA_VENCIMIENTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fecha Vencimiento'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'TSP_FECHA_VENCIMIENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082481916542663666)
,p_db_column_name=>'TSP_SIGNO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Signo'
,p_column_type=>'STRING'
,p_static_id=>'TSP_SIGNO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082482305669663667)
,p_db_column_name=>'TSP_MONTO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'TSP_MONTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082482670627663668)
,p_db_column_name=>'TSP_FECHA_LIQUIDACION'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fecha Liquidacion'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'TSP_FECHA_LIQUIDACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082483103954663669)
,p_db_column_name=>'TSP_SALDO'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'TSP_SALDO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082483501016663669)
,p_db_column_name=>'TSP_PLAZO'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Plazo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TSP_PLAZO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082483849686663670)
,p_db_column_name=>'TSP_ESTATUS'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Estatus'
,p_column_type=>'STRING'
,p_static_id=>'TSP_ESTATUS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082477870092663657)
,p_db_column_name=>'CLASE'
,p_display_order=>27
,p_column_identifier=>'R'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082477563702663630)
,p_db_column_name=>'TIPO'
,p_display_order=>37
,p_column_identifier=>'S'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086909451987238881)
,p_db_column_name=>'TSP_CEDULA_PROV'
,p_display_order=>47
,p_column_identifier=>'T'
,p_column_label=>'Cedula Prov'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14138542629908378831)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'194645'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TSP_EMPRESA:TSP_TRANSACCION:TSP_FECHA_TRANSACCION:TSP_FECHA_VENCIMIENTO:TSP_DOCUMENTO:TSP_DETALLE_DOCUMENTO:TSP_PROVEEDOR:TSP_NOMBRE:TSP_CEDULA_PROV:CLASE:TIPO:TSP_MONEDA:TSP_SIGNO:TSP_MONTO:TSP_FECHA_LIQUIDACION:TSP_SALDO:TSP_PLAZO:TSP_ESTATUS:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14082456493705111864)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966310407389995423)
,p_name=>'P63_LOCAL'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P63_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   FROM DUAL',
'connect by regexp_substr(:P63_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966310581975995424)
,p_name=>'P63_ALTERNA'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P63_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )   FROM DUAL',
'connect by regexp_substr(:P63_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082485346223663719)
,p_name=>'P63_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082485725137663739)
,p_name=>'P63_MONEDA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT NOMBRE ||''(''||MONEDA||'')'' as d, moneda as r from gnl_moneda_tr_nx'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082486046217663740)
,p_name=>'P63_PROVEEDOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PRO_PROVEEDOR ||'' - ''|| CXP_NOMBRE_PROV_V_NX(PRO_EMP_EMPRESA, PRO_PROVEEDOR, PRO_MON_MONEDA), ',
'PRO_PROVEEDOR FROM CXP_PROVEEDOR_TB_NX',
'WHERE PRO_EMP_EMPRESA = :P63_EMPRESA',
'AND PRO_MON_MONEDA = :P63_MONEDA',
'ORDER BY PRO_PROVEEDOR'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P63_MONEDA'
,p_ajax_items_to_submit=>'P63_EMPRESA,P63_MONEDA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082486434752663741)
,p_name=>'P63_INICIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082486921327663742)
,p_name=>'P63_FIN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082487239852663742)
,p_name=>'P63_SALDO_INICIAL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saldo Inicial'
,p_source=>'return to_char(cxp_saldo_proveedor_n_nx (:P63_EMPRESA, :P63_PROVEEDOR, :P63_MONEDA, TO_DATE(:P63_INICIO) - 1), ''999G999G999G990D00'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P63_PROVEEDOR'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082487678075663745)
,p_name=>'P63_SALDO_FINAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14138542843926378848)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saldo Final'
,p_source=>'return to_char(cxp_saldo_proveedor_n_nx (:P63_EMPRESA, :P63_PROVEEDOR, :P63_MONEDA, :P63_FIN), ''999G999G999G990D00'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P63_PROVEEDOR'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966308402350995402)
,p_validation_name=>'MONEDA_EMPRESA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P63_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P63_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P63_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P63_EMPRESA,''[^:]+'', 1, level) is not null;',
'             ',
'IF (cantidad_local_v > 1 AND :P63_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
'',
'IF (cantidad_alt_v > 1 AND :P63_MONEDA = ''A'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
' ',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_api.id(14082456493705111864)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
