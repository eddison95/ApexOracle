prompt --application/pages/page_00124
begin
--   Manifest
--     PAGE: 00124
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>124
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Facturacion Neta Detallada'
,p_step_title=>'Facturacion Neta Detallada'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201208143146'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14082372709744752202)
,p_plug_name=>'Facturacion Neta Detallada'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14082346088845752132)
,p_plug_name=>'Facturacion Neta Detallada'
,p_parent_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 05/06/2017 10:23:41 a.m. (QP5 v5.115.810.9015) */',
'SELECT fac_empresa,',
'       fac_transaccion,',
'       fac_factura,',
'       fac_fecha,',
'       fac_departamento,',
'       fac_desc_dep,',
'       fac_dep_padre,',
'       fac_desc_dep_padre,',
'       fac_localizacion,',
'       fac_desc_loc,',
'       fac_loc_padre,',
'       fac_desc_loc_padre,',
'       fac_tipo,',
'       fac_vencimiento,',
'       fac_tipo_tra,',
'       fac_tipo_cambio,',
'       fac_vendedor,',
'       fac_desc_ven,',
'       fac_cliente,',
'       fac_cli_moneda,',
'       fac_cli_nombre,',
'       fac_cli_cedula,',
'       fac_cli_segmento,',
'       fac_gravado_cli,',
'       fac_desc_cli_seg,',
'       fac_lista,',
'       fac_moneda,',
'       fac_orden_taller,',
'       fac_reserva,',
'       fac_cliente_res,',
'       fac_cli_mon_res,',
'       fac_cli_nombre_res,',
'       fac_cli_cedula_res,',
'       fac_banco,',
'       fac_articulo,',
'       fac_desc_art,',
'       fac_gravado_art,',
'       fac_familia,',
'       fac_desc_fam,',
'       fac_fam_padre,',
'       fac_desc_fam_padre,',
'       fac_tipo_art,',
'       fac_clase,',
'       fac_cantidad,',
'       fac_costo_unitario,',
'       fac_costo_total,',
'       fac_precio_unitario,',
'       fac_precio_total,',
'       fac_descuento,',
'       fac_subtotal,',
'       fac_impuesto,',
'       fac_total,',
'       fac_itm_color,',
'       fac_itm_motor,',
'       fac_itm_chasis,',
'       fac_itm_anno,',
'       fac_mes,',
'       fac_ano,',
'       fac_origen,',
'       fac_comprobante_electronico,',
'fac_usuario,',
'fac_orden_compra,',
'fac_pedido',
'FROM fac_rep_facturacion_tb_nx',
'WHERE fac_usuario = V(''APP_USER'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P124_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14082346441741752135)
,p_name=>'Detalle de Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>12504931263913930
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14082415877702884313)
,p_name=>'Reserva'
,p_description=>'Reserva'
,p_display_sequence=>10
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14082415929619884314)
,p_name=>'Item'
,p_description=>'Item'
,p_display_sequence=>20
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082415731352884312)
,p_db_column_name=>'FAC_ORIGEN'
,p_display_order=>10
,p_column_identifier=>'EJ'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082258034561365854)
,p_db_column_name=>'FAC_EMPRESA'
,p_display_order=>20
,p_column_identifier=>'CD'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082258114497365855)
,p_db_column_name=>'FAC_TRANSACCION'
,p_display_order=>30
,p_column_identifier=>'CE'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410155653884206)
,p_db_column_name=>'FAC_FACTURA'
,p_display_order=>40
,p_column_identifier=>'CF'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410226058884207)
,p_db_column_name=>'FAC_FECHA'
,p_display_order=>50
,p_column_identifier=>'CG'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082415512097884310)
,p_db_column_name=>'FAC_MES'
,p_display_order=>60
,p_column_identifier=>'EH'
,p_column_label=>'Mes'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082415678860884311)
,p_db_column_name=>'FAC_ANO'
,p_display_order=>70
,p_column_identifier=>'EI'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410360568884208)
,p_db_column_name=>'FAC_DEPARTAMENTO'
,p_display_order=>80
,p_column_identifier=>'CH'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410435645884209)
,p_db_column_name=>'FAC_DESC_DEP'
,p_display_order=>90
,p_column_identifier=>'CI'
,p_column_label=>'Desc Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410557561884210)
,p_db_column_name=>'FAC_DEP_PADRE'
,p_display_order=>100
,p_column_identifier=>'CJ'
,p_column_label=>'Dep Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410685804884211)
,p_db_column_name=>'FAC_DESC_DEP_PADRE'
,p_display_order=>110
,p_column_identifier=>'CK'
,p_column_label=>'Desc Dep Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410790062884212)
,p_db_column_name=>'FAC_LOCALIZACION'
,p_display_order=>120
,p_column_identifier=>'CL'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410879944884213)
,p_db_column_name=>'FAC_DESC_LOC'
,p_display_order=>130
,p_column_identifier=>'CM'
,p_column_label=>'Desc Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082410951469884214)
,p_db_column_name=>'FAC_LOC_PADRE'
,p_display_order=>140
,p_column_identifier=>'CN'
,p_column_label=>'Loc Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411098442884215)
,p_db_column_name=>'FAC_DESC_LOC_PADRE'
,p_display_order=>150
,p_column_identifier=>'CO'
,p_column_label=>'Desc Loc Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411169662884216)
,p_db_column_name=>'FAC_TIPO'
,p_display_order=>160
,p_column_identifier=>'CP'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411263572884217)
,p_db_column_name=>'FAC_VENCIMIENTO'
,p_display_order=>170
,p_column_identifier=>'CQ'
,p_column_label=>'Vencimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411392863884218)
,p_db_column_name=>'FAC_TIPO_TRA'
,p_display_order=>180
,p_column_identifier=>'CR'
,p_column_label=>'Tipo Trn'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411445389884219)
,p_db_column_name=>'FAC_TIPO_CAMBIO'
,p_display_order=>190
,p_column_identifier=>'CS'
,p_column_label=>'Tipo Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411552004884220)
,p_db_column_name=>'FAC_VENDEDOR'
,p_display_order=>200
,p_column_identifier=>'CT'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411622471884221)
,p_db_column_name=>'FAC_DESC_VEN'
,p_display_order=>210
,p_column_identifier=>'CU'
,p_column_label=>'Nombre Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411734730884222)
,p_db_column_name=>'FAC_CLIENTE'
,p_display_order=>220
,p_column_identifier=>'CV'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411880254884223)
,p_db_column_name=>'FAC_CLI_MONEDA'
,p_display_order=>230
,p_column_identifier=>'CW'
,p_column_label=>'Mon Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082411922306884224)
,p_db_column_name=>'FAC_CLI_NOMBRE'
,p_display_order=>240
,p_column_identifier=>'CX'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412064714884225)
,p_db_column_name=>'FAC_CLI_CEDULA'
,p_display_order=>250
,p_column_identifier=>'CY'
,p_column_label=>'Cedula Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412165702884226)
,p_db_column_name=>'FAC_CLI_SEGMENTO'
,p_display_order=>260
,p_column_identifier=>'CZ'
,p_column_label=>'Segmento Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412401862884228)
,p_db_column_name=>'FAC_DESC_CLI_SEG'
,p_display_order=>270
,p_column_identifier=>'DB'
,p_column_label=>'Desc Segmento Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412292504884227)
,p_db_column_name=>'FAC_GRAVADO_CLI'
,p_display_order=>280
,p_column_identifier=>'DA'
,p_column_label=>'Gravado Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412481048884229)
,p_db_column_name=>'FAC_LISTA'
,p_display_order=>290
,p_column_identifier=>'DC'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412598834884230)
,p_db_column_name=>'FAC_MONEDA'
,p_display_order=>300
,p_column_identifier=>'DD'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412614929884231)
,p_db_column_name=>'FAC_ORDEN_TALLER'
,p_display_order=>310
,p_column_identifier=>'DE'
,p_column_label=>'Orden Taller'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412779086884232)
,p_db_column_name=>'FAC_RESERVA'
,p_display_order=>320
,p_group_id=>wwv_flow_api.id(14082415877702884313)
,p_column_identifier=>'DF'
,p_column_label=>'Reserva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412904168884233)
,p_db_column_name=>'FAC_CLIENTE_RES'
,p_display_order=>330
,p_group_id=>wwv_flow_api.id(14082415877702884313)
,p_column_identifier=>'DG'
,p_column_label=>'Cliente Res.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082412918455884234)
,p_db_column_name=>'FAC_CLI_MON_RES'
,p_display_order=>340
,p_group_id=>wwv_flow_api.id(14082415877702884313)
,p_column_identifier=>'DH'
,p_column_label=>'Moneda Res.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413098132884235)
,p_db_column_name=>'FAC_CLI_NOMBRE_RES'
,p_display_order=>350
,p_group_id=>wwv_flow_api.id(14082415877702884313)
,p_column_identifier=>'DI'
,p_column_label=>'Nombre Cliente Res.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413148469884236)
,p_db_column_name=>'FAC_CLI_CEDULA_RES'
,p_display_order=>360
,p_group_id=>wwv_flow_api.id(14082415877702884313)
,p_column_identifier=>'DJ'
,p_column_label=>'Cedula Cliente Res.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413283933884237)
,p_db_column_name=>'FAC_BANCO'
,p_display_order=>370
,p_column_identifier=>'DK'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413395108884238)
,p_db_column_name=>'FAC_ARTICULO'
,p_display_order=>380
,p_column_identifier=>'DL'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413445897884239)
,p_db_column_name=>'FAC_DESC_ART'
,p_display_order=>390
,p_column_identifier=>'DM'
,p_column_label=>'Desc Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413533849884240)
,p_db_column_name=>'FAC_GRAVADO_ART'
,p_display_order=>400
,p_column_identifier=>'DN'
,p_column_label=>'Gravado Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413709240884241)
,p_db_column_name=>'FAC_FAMILIA'
,p_display_order=>410
,p_column_identifier=>'DO'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413779988884242)
,p_db_column_name=>'FAC_DESC_FAM'
,p_display_order=>420
,p_column_identifier=>'DP'
,p_column_label=>'Desc Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413827385884243)
,p_db_column_name=>'FAC_FAM_PADRE'
,p_display_order=>430
,p_column_identifier=>'DQ'
,p_column_label=>'Fam Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082413947811884244)
,p_db_column_name=>'FAC_DESC_FAM_PADRE'
,p_display_order=>440
,p_column_identifier=>'DR'
,p_column_label=>'Desc Fam Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414109848884245)
,p_db_column_name=>'FAC_TIPO_ART'
,p_display_order=>450
,p_column_identifier=>'DS'
,p_column_label=>'Tipo Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414209768884246)
,p_db_column_name=>'FAC_CLASE'
,p_display_order=>460
,p_column_identifier=>'DT'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414262520884247)
,p_db_column_name=>'FAC_CANTIDAD'
,p_display_order=>470
,p_column_identifier=>'DU'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414365427884248)
,p_db_column_name=>'FAC_COSTO_UNITARIO'
,p_display_order=>480
,p_column_identifier=>'DV'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414440879884249)
,p_db_column_name=>'FAC_COSTO_TOTAL'
,p_display_order=>490
,p_column_identifier=>'DW'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414546467884250)
,p_db_column_name=>'FAC_PRECIO_UNITARIO'
,p_display_order=>500
,p_column_identifier=>'DX'
,p_column_label=>'Precio Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414620392884251)
,p_db_column_name=>'FAC_PRECIO_TOTAL'
,p_display_order=>510
,p_column_identifier=>'DY'
,p_column_label=>'Precio Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414801581884252)
,p_db_column_name=>'FAC_DESCUENTO'
,p_display_order=>520
,p_column_identifier=>'DZ'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414849643884253)
,p_db_column_name=>'FAC_SUBTOTAL'
,p_display_order=>530
,p_column_identifier=>'EA'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082414931413884254)
,p_db_column_name=>'FAC_IMPUESTO'
,p_display_order=>540
,p_column_identifier=>'EB'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082415019605884255)
,p_db_column_name=>'FAC_TOTAL'
,p_display_order=>550
,p_column_identifier=>'EC'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082415140403884306)
,p_db_column_name=>'FAC_ITM_COLOR'
,p_display_order=>560
,p_group_id=>wwv_flow_api.id(14082415929619884314)
,p_column_identifier=>'ED'
,p_column_label=>'Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082415265564884307)
,p_db_column_name=>'FAC_ITM_MOTOR'
,p_display_order=>570
,p_group_id=>wwv_flow_api.id(14082415929619884314)
,p_column_identifier=>'EE'
,p_column_label=>'Motor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082415390556884308)
,p_db_column_name=>'FAC_ITM_CHASIS'
,p_display_order=>580
,p_group_id=>wwv_flow_api.id(14082415929619884314)
,p_column_identifier=>'EF'
,p_column_label=>'Chasis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082415453755884309)
,p_db_column_name=>'FAC_ITM_ANNO'
,p_display_order=>590
,p_group_id=>wwv_flow_api.id(14082415929619884314)
,p_column_identifier=>'EG'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084691819575360970)
,p_db_column_name=>'FAC_COMPROBANTE_ELECTRONICO'
,p_display_order=>600
,p_column_identifier=>'EK'
,p_column_label=>unistr('Comprobante electr\00F3nico')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087235308746160900)
,p_db_column_name=>'FAC_USUARIO'
,p_display_order=>610
,p_column_identifier=>'EL'
,p_column_label=>'Fac usuario'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951987732530507408)
,p_db_column_name=>'FAC_ORDEN_COMPRA'
,p_display_order=>620
,p_column_identifier=>'EM'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951987878443507409)
,p_db_column_name=>'FAC_PEDIDO'
,p_display_order=>630
,p_column_identifier=>'EN'
,p_column_label=>'Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14082372185772752200)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'125307'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'FAC_ORIGEN:FAC_EMPRESA:FAC_TRANSACCION:FAC_FACTURA:FAC_COMPROBANTE_ELECTRONICO:FAC_FECHA:FAC_MES:FAC_ANO:FAC_DEPARTAMENTO:FAC_DESC_DEP:FAC_DEP_PADRE:FAC_DESC_DEP_PADRE:FAC_LOCALIZACION:FAC_DESC_LOC:FAC_LOC_PADRE:FAC_DESC_LOC_PADRE:FAC_TIPO:FAC_VENCIM'
||'IENTO:FAC_TIPO_TRA:FAC_TIPO_CAMBIO:FAC_VENDEDOR:FAC_DESC_VEN:FAC_CLIENTE:FAC_CLI_MONEDA:FAC_CLI_NOMBRE:FAC_CLI_CEDULA:FAC_CLI_SEGMENTO:FAC_GRAVADO_CLI:FAC_DESC_CLI_SEG:FAC_LISTA:FAC_MONEDA:FAC_ORDEN_TALLER:FAC_RESERVA:FAC_CLIENTE_RES:FAC_CLI_MON_RES:'
||'FAC_CLI_NOMBRE_RES:FAC_CLI_CEDULA_RES:FAC_BANCO:FAC_ARTICULO:FAC_DESC_ART:FAC_GRAVADO_ART:FAC_FAMILIA:FAC_DESC_FAM:FAC_FAM_PADRE:FAC_DESC_FAM_PADRE:FAC_TIPO_ART:FAC_CLASE:FAC_CANTIDAD:FAC_COSTO_UNITARIO:FAC_COSTO_TOTAL:FAC_PRECIO_UNITARIO:FAC_PRECIO_'
||'TOTAL:FAC_DESCUENTO:FAC_SUBTOTAL:FAC_IMPUESTO:FAC_TOTAL:FAC_ITM_COLOR:FAC_ITM_MOTOR:FAC_ITM_CHASIS:FAC_ITM_ANNO::FAC_USUARIO:FAC_ORDEN_COMPRA:FAC_PEDIDO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14082373087426752202)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13967055416268886879)
,p_name=>'P124_LOCAL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   FROM DUAL',
'connect by regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13967055592504886880)
,p_name=>'P124_ALTERNA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )   FROM DUAL',
'connect by regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082373474083752204)
,p_name=>'P124_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE   use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082374221779752206)
,p_name=>'P124_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082374523805752207)
,p_name=>'P124_MONEDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MONEDA'
,p_lov=>'.'||wwv_flow_api.id(13966336081955007059)||'.'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082374925852752208)
,p_name=>'P124_INICIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14082375390282752208)
,p_name=>'P124_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14082372709744752202)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14082376606166752217)
,p_computation_sequence=>10
,p_computation_item=>'P124_AUTO_CCA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE   use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966308784514995406)
,p_validation_name=>'MONEDA_EMPRESA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level) is not null;',
'             ',
'IF (cantidad_local_v > 1 AND :P124_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
'',
'IF (cantidad_alt_v > 1 AND :P124_MONEDA = ''L'' ) THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
'',
'',
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   INTO :P124_LOCAL FROM DUAL',
'connect by regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )  INTO :P124_ALTERNA   FROM DUAL',
'connect by regexp_substr(:P124_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_api.id(14082373087426752202)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14082376858603752220)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'llena_reporte_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   fac_rep_facturacion_pr_nx (:P124_EMPRESA,',
'                              CASE WHEN :P124_MONEDA= ''L'' THEN :P124_LOCAL WHEN :P124_MONEDA= ''A'' THEN :P124_ALTERNA ELSE :P124_MONEDA END,',
'                              :P124_INICIO,',
'                              :P124_FIN);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14082373087426752202)
);
wwv_flow_api.component_end;
end;
/
