prompt --application/pages/page_00165
begin
--   Manifest
--     PAGE: 00165
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>165
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CGL - D104 Auxiliar Compras'
,p_step_title=>'D104 Auxiliar Compras'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170000'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14155139407802327270)
,p_plug_name=>'D104 Auxiliar Compras'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14155112786903327200)
,p_plug_name=>'D104 Auxiliar Compras'
,p_parent_plug_id=>wwv_flow_api.id(14155139407802327270)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    c001   empresa,',
'    c002   origen,',
'    c003   actividad,',
'    c004   transaccion,',
'    c005   numero,',
'    TO_DATE(c006) fecha,',
'    c007   cedula,',
'    c008   nombre,',
'    to_number(c009) subtotal,',
'    to_number(c010) base,',
'    to_number(c011) porcentaje,',
'    to_number(c012) iva,',
'    to_number(c013) total,',
'    to_number(c014) exonerado,',
'    to_number(c015) exento,',
'    c016   codigo,',
'    c017   tarifa,',
'    c018   cod_base,',
'    c019   tipo,',
'    c020   desc_tipo,',
'    to_number(c021)   monto_retencion,',
'    to_number(c022)   prorrata,',
'    to_number(c023)   iva_nodescontable_costo,',
'    to_number(c024)   iva_nodescontable_gasto,',
'    to_number(c025)   iva_soportado,',
'    to_number(c026)   descuento,',
'    to_number(c027)   base_imponible,',
'    c028    codigo_declaracion,',
'    c029    descripcion_declaracion,',
'    c030    departamento',
'FROM',
'    apex_collections',
'WHERE',
'    collection_name = ''D104C'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P165_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14155113139799327203)
,p_name=>'Detalle de Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:160:&SESSION.::&DEBUG.:RP:P160_CEDULA,P160_CODIGO:#D_CEDULA#,#D_CODIGO#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_owner=>'ACAMPOS'
,p_internal_uid=>134320141904472175
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035412438860579885)
,p_db_column_name=>'EMPRESA'
,p_display_order=>10
,p_column_identifier=>'EY'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035412878056579885)
,p_db_column_name=>'ORIGEN'
,p_display_order=>20
,p_column_identifier=>'EZ'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035413243210579885)
,p_db_column_name=>'ACTIVIDAD'
,p_display_order=>30
,p_column_identifier=>'FA'
,p_column_label=>'Actividad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035413695793579886)
,p_db_column_name=>'TRANSACCION'
,p_display_order=>40
,p_column_identifier=>'FB'
,p_column_label=>'Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035414032940579886)
,p_db_column_name=>'NUMERO'
,p_display_order=>50
,p_column_identifier=>'FC'
,p_column_label=>'Numero'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035414417886579886)
,p_db_column_name=>'FECHA'
,p_display_order=>60
,p_column_identifier=>'FD'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035414864537579887)
,p_db_column_name=>'CEDULA'
,p_display_order=>70
,p_column_identifier=>'FE'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035415294618579887)
,p_db_column_name=>'NOMBRE'
,p_display_order=>80
,p_column_identifier=>'FF'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035415668748579887)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>90
,p_column_identifier=>'FG'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035416048227579887)
,p_db_column_name=>'BASE'
,p_display_order=>100
,p_column_identifier=>'FH'
,p_column_label=>'Base'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035416486600579888)
,p_db_column_name=>'PORCENTAJE'
,p_display_order=>110
,p_column_identifier=>'FI'
,p_column_label=>'Porcentaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035416868698579888)
,p_db_column_name=>'IVA'
,p_display_order=>120
,p_column_identifier=>'FJ'
,p_column_label=>'Iva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035417221712579889)
,p_db_column_name=>'TOTAL'
,p_display_order=>130
,p_column_identifier=>'FK'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035417609467579889)
,p_db_column_name=>'EXONERADO'
,p_display_order=>140
,p_column_identifier=>'FL'
,p_column_label=>'Exonerado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035418036342579889)
,p_db_column_name=>'EXENTO'
,p_display_order=>150
,p_column_identifier=>'FM'
,p_column_label=>'Exento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035418422068579890)
,p_db_column_name=>'CODIGO'
,p_display_order=>160
,p_column_identifier=>'FN'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035418840049579890)
,p_db_column_name=>'TARIFA'
,p_display_order=>170
,p_column_identifier=>'FO'
,p_column_label=>'Tarifa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035419098964579890)
,p_db_column_name=>'COD_BASE'
,p_display_order=>180
,p_column_identifier=>'FP'
,p_column_label=>'Cod base'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035419590058579891)
,p_db_column_name=>'TIPO'
,p_display_order=>190
,p_column_identifier=>'FQ'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035419965300579891)
,p_db_column_name=>'DESC_TIPO'
,p_display_order=>200
,p_column_identifier=>'FR'
,p_column_label=>'Desc tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14023998459706493078)
,p_db_column_name=>'MONTO_RETENCION'
,p_display_order=>210
,p_column_identifier=>'FY'
,p_column_label=>'Monto retencion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035508401283382129)
,p_db_column_name=>'PRORRATA'
,p_display_order=>220
,p_column_identifier=>'FZ'
,p_column_label=>'Prorrata'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035508512756382130)
,p_db_column_name=>'IVA_NODESCONTABLE_COSTO'
,p_display_order=>230
,p_column_identifier=>'GA'
,p_column_label=>'Iva nodescontable costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035508654283382131)
,p_db_column_name=>'IVA_NODESCONTABLE_GASTO'
,p_display_order=>240
,p_column_identifier=>'GB'
,p_column_label=>'Iva nodescontable gasto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035508786671382132)
,p_db_column_name=>'IVA_SOPORTADO'
,p_display_order=>250
,p_column_identifier=>'GC'
,p_column_label=>'Iva soportado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035508807083382133)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>260
,p_column_identifier=>'GD'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035509137361382136)
,p_db_column_name=>'BASE_IMPONIBLE'
,p_display_order=>270
,p_column_identifier=>'GE'
,p_column_label=>'Base imponible'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035509440151382139)
,p_db_column_name=>'CODIGO_DECLARACION'
,p_display_order=>280
,p_column_identifier=>'GF'
,p_column_label=>'Codigo declaracion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14035509532755382140)
,p_db_column_name=>'DESCRIPCION_DECLARACION'
,p_display_order=>290
,p_column_identifier=>'GG'
,p_column_label=>'Descripcion declaracion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049586556450902058)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>300
,p_column_identifier=>'GH'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14155138883830327268)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'146273'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_view_mode=>'REPORT'
,p_report_columns=>'ORIGEN:ACTIVIDAD:TRANSACCION:NUMERO:DEPARTAMENTO:FECHA:CEDULA:NOMBRE:PORCENTAJE:IVA:TOTAL:EXONERADO:EXENTO:CODIGO:TARIFA:COD_BASE:TIPO:DESC_TIPO:BASE_IMPONIBLE:CODIGO_DECLARACION:DESCRIPCION_DECLARACION:BASE:DESCUENTO:EMPRESA:IVA_NODESCONTABLE_COSTO:'
||'IVA_NODESCONTABLE_GASTO:IVA_SOPORTADO:MONTO_RETENCION:PRORRATA:SUBTOTAL:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14035421004812579892)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14155139407802327270)
,p_button_name=>'CONSULTAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14035421403313579893)
,p_name=>'P165_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14155139407802327270)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14035421830546579893)
,p_name=>'P165_INICIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14155139407802327270)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14035422291276579893)
,p_name=>'P165_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14155139407802327270)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(14035631058095409645)
,p_validation_name=>'valida_fecha_pr'
,p_validation_sequence=>10
,p_validation=>'(TO_DATE(:P165_FIN,''DD/MM/YYYY'') - TO_DATE(:P165_INICIO,''DD/MM/YYYY'')) <= 30'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('El rango de fechas es inv\00E1lido. Debe usar un rango de fechas menor a 30 d\00EDas')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(14035629491421409629)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(14035421004812579892)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(14035629790904409632)
,p_event_id=>wwv_flow_api.id(14035629491421409629)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(14035421004812579892)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(14035629890339409633)
,p_event_id=>wwv_flow_api.id(14035629491421409629)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14035630078959409635)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'procesar_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   cgl_d104_compras_pr_nx(:P165_EMPRESA, :P165_INICIO, :P165_FIN);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
