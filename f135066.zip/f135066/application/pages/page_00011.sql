prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>11
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('INV \2013 Valor de Inventario')
,p_step_title=>'Valor Inventario'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163308'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193509771210170781)
,p_plug_name=>'Valor Inventario'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193507759627170767)
,p_plug_name=>'Valor Inventario'
,p_parent_plug_id=>wwv_flow_api.id(14193509771210170781)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 05/06/2017 09:56:39 a.m. (QP5 v5.115.810.9015) */',
'SELECT ska_emp_empresa,',
'       ska_periodo,',
'       ska_ato_articulo,',
'       ska_ato_descripcion,',
'       ska_ato_familia,',
'       ska_ato_localizacion,',
'       inv_descrip_loca_v_nx (ska_emp_empresa, ska_ato_localizacion)',
'          ska_desc_loc,',
'       ska_cantidad_inicial,',
'       ska_costo_inicial,',
'       ska_cantidad_entrada,',
'       ska_costo_entrada,',
'       ska_cantidad_salida,',
'       ska_costo_salida,',
'       ska_costo_ajuste,',
'       ska_cantidad_final,',
'       ska_costo_final,',
'       DECODE (inv_itemizado_art_v_nx (ska_emp_empresa, ska_ato_articulo),',
'               ''N'',',
'               ''NO'',',
'               ''S'',',
'               ''SI''',
'       )',
'          itemizado,',
'       ska_transito_interno,',
'       ska_costo_unitario,',
'       ska_costo_transito_int',
'FROM rep_saldos_kardex_tb_nx',
'WHERE INSTR ('':'' || :P11_EMPRESA || '':'', '':'' || ska_emp_empresa || '':'') > 0',
'      AND ska_periodo = :p11_periodo;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P11_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14193507983502170770)
,p_name=>'Valor Inventario'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>7508631382985093
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508060585170770)
,p_db_column_name=>'SKA_EMP_EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'SKA_EMP_EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508176855170771)
,p_db_column_name=>'SKA_ATO_ARTICULO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
,p_static_id=>'SKA_ATO_ARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508267973170771)
,p_db_column_name=>'SKA_ATO_DESCRIPCION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'SKA_ATO_DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508370869170771)
,p_db_column_name=>'SKA_ATO_FAMILIA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
,p_static_id=>'SKA_ATO_FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508460952170773)
,p_db_column_name=>'SKA_ATO_LOCALIZACION'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
,p_static_id=>'SKA_ATO_LOCALIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508569051170773)
,p_db_column_name=>'SKA_CANTIDAD_INICIAL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Cantidad Inicial'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D99'
,p_static_id=>'SKA_CANTIDAD_INICIAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508671545170773)
,p_db_column_name=>'SKA_COSTO_INICIAL'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Costo Inicial'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SKA_COSTO_INICIAL'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P11_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508774741170774)
,p_db_column_name=>'SKA_CANTIDAD_ENTRADA'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Cantidad Entrada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SKA_CANTIDAD_ENTRADA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508872084170774)
,p_db_column_name=>'SKA_COSTO_ENTRADA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Costo Entrada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SKA_COSTO_ENTRADA'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P11_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193508978652170778)
,p_db_column_name=>'SKA_CANTIDAD_SALIDA'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Cantidad Salida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SKA_CANTIDAD_SALIDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193509076705170778)
,p_db_column_name=>'SKA_COSTO_SALIDA'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Costo Salida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SKA_COSTO_SALIDA'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P11_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193509156684170778)
,p_db_column_name=>'SKA_COSTO_AJUSTE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Costo Ajuste'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SKA_COSTO_AJUSTE'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P11_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193509280884170779)
,p_db_column_name=>'SKA_CANTIDAD_FINAL'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Cantidad Final'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SKA_CANTIDAD_FINAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193509378792170779)
,p_db_column_name=>'SKA_COSTO_FINAL'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Costo Final'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SKA_COSTO_FINAL'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P11_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098965729464251907)
,p_db_column_name=>'SKA_PERIODO'
,p_display_order=>24
,p_column_identifier=>'P'
,p_column_label=>'Periodo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098965946646251909)
,p_db_column_name=>'SKA_DESC_LOC'
,p_display_order=>34
,p_column_identifier=>'Q'
,p_column_label=>unistr('Desc. Localizaci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099123743655152603)
,p_db_column_name=>'ITEMIZADO'
,p_display_order=>44
,p_column_identifier=>'R'
,p_column_label=>'Itemizado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082255371700365827)
,p_db_column_name=>'SKA_TRANSITO_INTERNO'
,p_display_order=>54
,p_column_identifier=>'S'
,p_column_label=>'Transito Interno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D99'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082255510243365828)
,p_db_column_name=>'SKA_COSTO_UNITARIO'
,p_display_order=>64
,p_column_identifier=>'T'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D99'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001216871069589482)
,p_db_column_name=>'SKA_COSTO_TRANSITO_INT'
,p_display_order=>74
,p_column_identifier=>'U'
,p_column_label=>'Costo Transito Interno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D99'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14193509563191170780)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75103'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'SKA_EMP_EMPRESA:SKA_ATO_ARTICULO:SKA_ATO_DESCRIPCION:SKA_ATO_FAMILIA:SKA_ATO_LOCALIZACION:SKA_DESC_LOC:SKA_CANTIDAD_INICIAL:SKA_COSTO_INICIAL:SKA_CANTIDAD_ENTRADA:SKA_COSTO_ENTRADA:SKA_CANTIDAD_SALIDA:SKA_COSTO_SALIDA:SKA_COSTO_AJUSTE:SKA_CANTIDAD_FI'
||'NAL:SKA_COSTO_FINAL:ITEMIZADO:SKA_COSTO_UNITARIO:SKA_TRANSITO_INTERNO:SKA_COSTO_TRANSITO_INT:'
,p_sum_columns_on_break=>'SKA_COSTO_INICIAL:SKA_COSTO_ENTRADA:SKA_COSTO_SALIDA:SKA_COSTO_FINAL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168177525414801026)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14193509771210170781)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098463877364922703)
,p_name=>'P11_AUTO_CCA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14193509771210170781)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE       use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193509981374170781)
,p_name=>'P11_EMPRESA'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14193509771210170781)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193510781920170789)
,p_name=>'P11_PERIODO'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14193509771210170781)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    SELECT   ska_periodo periodo, ska_periodo',
'    FROM   rep_saldos_kardex_tb_nx',
'   WHERE   INSTR ('':'' || :P11_EMPRESA || '':'', '':'' || ska_emp_empresa || '':'') >',
'              0',
'GROUP BY   ska_periodo',
'ORDER BY   ska_periodo DESC;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_lov_cascade_parent_items=>'P11_EMPRESA'
,p_ajax_items_to_submit=>'P11_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
