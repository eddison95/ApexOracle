prompt --application/pages/page_00085
begin
--   Manifest
--     PAGE: 00085
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>85
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'PLA - Detalle Planillas'
,p_page_mode=>'MODAL'
,p_step_title=>'Detalle Planillas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170312'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095418149068430802)
,p_plug_name=>'Detalle Planillas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095410451004430697)
,p_plug_name=>'Detalle Planillas'
,p_parent_plug_id=>wwv_flow_api.id(14095418149068430802)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'rvh.RVH_DEV_ID,',
'PLA_NOMBRE_DEVENGO_V_NX(rvh.RVH_EMP_EMPRESA, rvh.RVH_DEV_ID) Descripcion,',
'rvh.RVH_CANTIDAD,',
'rvh.RVH_MONTO,',
'rvh.RVH_MONTO_TOTAL',
'FROM PLA_RESEMPDEV_HIST_TB_NX rvh, PLA_RESPLAN_HIST_TB_NX rph',
'WHERE rvh.RVH_RPH_ID = :P85_RPH_ID',
'AND rvh.RVH_RPH_ID = rph.RPH_ID',
'AND :P85_TIPO_DET = ''Dv''',
'UNION ALL',
'SELECT ',
'rdh.RDH_DED_ID,',
'PLA_NOMBRE_DEDUCCION_V_NX(rdh.RDH_DED_ID) Descripcion,',
'rdh.RDH_CANTIDAD,',
'rdh.RDH_MONTO,',
'rdh.RDH_MONTO_TOTAL',
'FROM PLA_RESEMPDED_HIST_TB_NX rdh, PLA_RESPLAN_HIST_TB_NX rph',
'WHERE rdh.RDH_RPH_ID = :P85_RPH_ID',
'AND rdh.RDH_RPH_ID = rph.RPH_ID',
'AND :P85_TIPO_DET = ''Dd''',
'UNION ALL',
'SELECT ',
'rch.RCH_ID,',
'PLA_NOMBRE_CARGA_SOCIAL_V_NX(rch.RCH_CRS_ID) Descripcion,',
'rch.RCH_CANTIDAD,',
'rch.RCH_MONTO,',
'rch.RCH_MONTO_TOTAL',
'FROM PLA_RESEMPCARGS_HIST_TB_NX rch, PLA_RESPLAN_HIST_TB_NX rph',
'WHERE rch.RCH_RPH_ID = :P85_RPH_ID',
'AND rch.RCH_RPH_ID = rph.RPH_ID',
'AND :P85_TIPO_DET = ''CS''',
'UNION ALL',
'SELECT rrh.RRH_ID,',
'pla_nombre_provision_v_nx(rrh.RRH_PRV_ID) Descripcion,',
'rrh.RRH_CANTIDAD,',
'rrh.RRH_MONTO,',
'rrh.RRH_MONTO_TOTAL',
'FROM PLA_RESEMPPROV_HIST_TB_NX rrh, PLA_RESPLAN_HIST_TB_NX rph',
'WHERE rrh.RRH_RPH_ID = :P85_RPH_ID',
'AND rrh.RRH_RPH_ID = rph.RPH_ID',
'AND :P85_TIPO_DET = ''P'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095410880331430724)
,p_name=>'Ventas Diarias'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>7667155559541630
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095363354772527316)
,p_db_column_name=>'RVH_DEV_ID'
,p_display_order=>10
,p_column_identifier=>'AU'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095363507158527317)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>20
,p_column_identifier=>'AV'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095363571903527318)
,p_db_column_name=>'RVH_CANTIDAD'
,p_display_order=>30
,p_column_identifier=>'AW'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095363625867527319)
,p_db_column_name=>'RVH_MONTO'
,p_display_order=>40
,p_column_identifier=>'AX'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095363731683527320)
,p_db_column_name=>'RVH_MONTO_TOTAL'
,p_display_order=>50
,p_column_identifier=>'AY'
,p_column_label=>'Monto Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095417715011430780)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'76740'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'KDM_KDM_TIPO:RVH_DEV_ID:DESCRIPCION:RVH_CANTIDAD:RVH_MONTO:RVH_MONTO_TOTAL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14095418596338430804)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14095418149068430802)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095362950325527312)
,p_name=>'P85_RPH_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14095418149068430802)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095363063609527313)
,p_name=>'P85_TPLA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14095418149068430802)
,p_prompt=>'Tipo Planilla'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095363170887527314)
,p_name=>'P85_NOMBRE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14095418149068430802)
,p_prompt=>'Persona'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095363283537527315)
,p_name=>'P85_TIPO_DET'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14095418149068430802)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
