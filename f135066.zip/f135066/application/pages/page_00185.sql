prompt --application/pages/page_00185
begin
--   Manifest
--     PAGE: 00185
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>185
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GAC - Informe de Programas por Estudiante'
,p_step_title=>'Informe de Programas por Estudiante'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20210601092353'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14106186559206008712)
,p_plug_name=>'Informe de Programas por Estudiante'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14106181106102008314)
,p_plug_name=>'Informe de Programar por Estudiante'
,p_region_name=>'Informe de cursos por estudiante'
,p_parent_plug_id=>wwv_flow_api.id(14106186559206008712)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>200
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 25/09/2017 03:59:25 p.m. (QP5 v5.115.810.9015) */',
'SELECT  distinct GAE_PERSONA ID_Persona,',
'         RAZON_SOCIAL AS Nombre,',
'         SEXO AS Sexo,',
'         GAE_CLI_CLIENTE AS Cliente,',
'         GAE_CLI_MON_MONEDA AS Moneda,',
'         DECODE (TIPO_DOCUMENTO,',
'                 1,',
'                 ''Identificacion Tributaria'',',
'                 2,',
'                 ''Cedula de Cuidadania'',',
'                 3,',
'                 ''Cedula de Residencia'',',
'                 4,',
'                 ''Tarjeta de Identidad'',',
'                 5,',
'                 ''Registro Unico Contribuyentes'',',
'                 6,',
'                 ''Pasaporte'',',
'                 7,',
'                 ''Cedula de Identidad'',',
'                 8,',
'                 ''Registro Federal de Causantes'')',
'            AS Tipo_Documento,',
'         PER.DOCUMENTO AS Documento,',
'         DECODE (PER_GRD_GRADO_ACADEMICO,',
'                 1,',
'                 ''PRIMARIA'',',
'                 2,',
'                 ''SECUNDARIA'',',
'                 3,',
'                 ''DIPLOMADO'',',
'                 4,',
'                 ''BACHILLERATO'',',
'                 5,',
'                 ''BACHILLERATO INCOMPLETO'',',
'                 6,',
'                 ''LICENCIATURA'',',
'                 7,',
'                 ''LICENCIATURA INCOMPLETA'',',
'                 8,',
'                 ''MAESTRIA'',',
'                 9,',
'                 ''MAESTRIA INCOMPLETA'',',
'                 10,',
'                 ''DOCTORADO'',',
'                 11,',
'                 ''DOCTORADO INCOMPLETO'',',
'                 12,',
'                 ''ESPECIALIDAD'',',
'                 NULL,',
'                 ''N/A'')',
'            AS Grado_Academico,',
'         DAE_OAC_LCN_LOCALIZACION AS Sede,',
'         DAE_OAC_SLO_SEGMENTO AS Decanatura,',
'         DAE_OAC_ULA_SLO_SEGMENTO AS Programa,',
'         DAE_OAC_ULA_ANTIGUEDAD AS Generacion,',
'         DAE_DOA_ATO_ARTICULO AS Materia,',
'                       (SELECT PAC_PERIODO',
'            FROM GAC_OFERTA_ACADEMICA_TB_NX,',
'                 GAC_DET_OFERTA_ACADEMICA_TB_NX,',
'                 GAC_OFERTA_HORA_LOCA_TB_NX,',
'                 GAC_PERIODOS_ACADEMICOS_TB_NX',
'           WHERE OAC_ID = DOA_OAC_ID --oferta con detalle oferta',
'           AND DOA_ID = OHL_DOA_ID --detalle oferta con oferta horario localizacion',
'           AND OHL_PAC_ID = PAC_ID --oferta hora localizacion con periodo       )',
'           AND OAC_ULA_SLO_SEGMENTO = DAE_OAC_ULA_SLO_SEGMENTO',
'           AND OAC_ULA_ANTIGUEDAD = DAE_OAC_ULA_ANTIGUEDAD',
'                        AND DOA_ATO_ARTICULO = dae_doa_ato_articulo',
'                       )',
'           periodo, ',
'         EMAIL email,',
'         TELEFONO1 || '' '' || TELEFONO2 telefono,',
'                  (SELECT   TCU_CUENTA',
'            FROM   CXC_TIPO_CUENTA_TB_NX',
'           WHERE   TCU_EMP_EMPRESA = per_emp_empresa',
'                   AND TCU_CUENTA = PER_TCU_CUENTA)',
'            condicion,',
'            (select ato_cantidad_maquina from INV_ARTICULO_TB_NX where ato_articulo = DAE_DOA_ATO_ARTICULO and ATO_EMP_EMPRESA=per_emp_empresa ) creditos',
'  FROM   GAC_ADMI_ESTUDIANTES_TB_NX,',
'         GNL_PERSONA_TR_NX PER,',
'         GAC_DET_ADMI_ESTUDIANTES_TB_NX',
' WHERE   INSTR ('':'' || :P185_EMPRESA || '':'',',
'                '':'' || GAE_CLI_EMP_EMPRESA || '':'') > 0',
'         AND GAE_FECHA_CREACION BETWEEN :P185_INICIO',
'                                    AND  TO_DATE (:P185_FIN || '' 23:59'',',
'                                                  ''dd/mm/rrrr hh24:mi'')',
'         AND GAE_PERSONA = PERSONA',
'         AND GAE_ID = DAE_GAE_ID',
'        AND inv_art_combo_v_nx (dae_emp_empresa, dae_doa_ato_articulo',
'															 ) = ''S'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P185_EMPRESA'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14106181347613008361)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>224406535379361046
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885228535474832263)
,p_db_column_name=>'ID_PERSONA'
,p_display_order=>110
,p_column_identifier=>'AK'
,p_column_label=>'Id Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885228983381832263)
,p_db_column_name=>'NOMBRE'
,p_display_order=>120
,p_column_identifier=>'AL'
,p_column_label=>'Nombre Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885229383763832263)
,p_db_column_name=>'GENERACION'
,p_display_order=>200
,p_column_identifier=>'AT'
,p_column_label=>'Generacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885222516525832259)
,p_db_column_name=>'SEXO'
,p_display_order=>300
,p_column_identifier=>'BD'
,p_column_label=>'Sexo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885223001484832259)
,p_db_column_name=>'CONDICION'
,p_display_order=>350
,p_column_identifier=>'BI'
,p_column_label=>'Condicion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885223405832832259)
,p_db_column_name=>'CLIENTE'
,p_display_order=>360
,p_column_identifier=>'BJ'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885223791552832259)
,p_db_column_name=>'MONEDA'
,p_display_order=>370
,p_column_identifier=>'BK'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885224159494832260)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>380
,p_column_identifier=>'BL'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885224557156832260)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>390
,p_column_identifier=>'BM'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885224975709832260)
,p_db_column_name=>'GRADO_ACADEMICO'
,p_display_order=>400
,p_column_identifier=>'BN'
,p_column_label=>'Grado Academico'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885225408837832261)
,p_db_column_name=>'SEDE'
,p_display_order=>410
,p_column_identifier=>'BO'
,p_column_label=>'Sede'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885225788736832261)
,p_db_column_name=>'DECANATURA'
,p_display_order=>420
,p_column_identifier=>'BP'
,p_column_label=>'Decanatura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885226119384832261)
,p_db_column_name=>'PROGRAMA'
,p_display_order=>430
,p_column_identifier=>'BQ'
,p_column_label=>'Programa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885227399462832262)
,p_db_column_name=>'EMAIL'
,p_display_order=>460
,p_column_identifier=>'BT'
,p_column_label=>'Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885227724069832262)
,p_db_column_name=>'TELEFONO'
,p_display_order=>470
,p_column_identifier=>'BU'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885222117905832258)
,p_db_column_name=>'PERIODO'
,p_display_order=>490
,p_column_identifier=>'BW'
,p_column_label=>'Periodo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022011947727657)
,p_db_column_name=>'MATERIA'
,p_display_order=>500
,p_column_identifier=>'BX'
,p_column_label=>'Materia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886021891582727656)
,p_db_column_name=>'CREDITOS'
,p_display_order=>510
,p_column_identifier=>'BY'
,p_column_label=>'Creditos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14106186127621008636)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'34553'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID_PERSONA:NOMBRE:GENERACION::SEXO:CONDICION:CLIENTE:MONEDA:TIPO_DOCUMENTO:DOCUMENTO:GRADO_ACADEMICO:SEDE:DECANATURA:PROGRAMA:EMAIL:TELEFONO:PERIODO:MATERIA:CREDITOS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13885220290261832251)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14106186559206008712)
,p_button_name=>'CONSULTAR'
,p_button_static_id=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13885220633368832253)
,p_name=>'P185_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14106186559206008712)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13885221054499832254)
,p_name=>'P185_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14106186559206008712)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13885221472823832254)
,p_name=>'P185_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14106186559206008712)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
