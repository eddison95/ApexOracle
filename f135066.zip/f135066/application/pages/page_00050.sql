prompt --application/pages/page_00050
begin
--   Manifest
--     PAGE: 00050
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>50
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('INV \2013 Inventarios')
,p_step_title=>'Inventarios'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ESALAS'
,p_last_upd_yyyymmddhh24miss=>'20210507144231'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167884906638175817)
,p_plug_name=>'Inventarios'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167883118128165322)
,p_plug_name=>'Inventarios'
,p_parent_plug_id=>wwv_flow_api.id(14167884906638175817)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT aln_emp_empresa empresa,',
'       aln_ato_articulo articulo,',
'       ato_categoria categoria,',
'       aln_clase clase,',
'       aln_lcn_localizacion localizacion,',
'       lcn_descripcion desc_localizacion,',
'       ato_descripcion descripcion,',
'       ato_fma_familia familia,',
'       ato_parte_fabricante parte_fabricante,',
'       ato_paa_partida   partida,',
'       ato_descontinuado descontinuado,',
'       ato_cbs_id        cabys_id,',
'       fma_descripcion desc_familia,',
'       (SELECT cfn_tao_tipo',
'       FROM inv_clasificacion_tb_nx',
'       WHERE cfn_emp_empresa = ato_emp_empresa',
'       AND cfn_ato_articulo = ato_articulo',
'       ORDER BY cfn_ind_principal',
'       FETCH FIRST 1 ROWS ONLY) tipo,',
'       aln_cantidad_total cstock,',
'       aln_cantidad_transito_interno ctransito,',
'       (aln_cantidad_total + aln_cantidad_transito_interno) ctotal,',
'       valor lista,',
'       aln_costo_unitario costounitario,',
'       (aln_costo_unitario * (aln_cantidad_total + aln_cantidad_transito_interno))',
'          costototal,',
'       (SELECT pco_precio',
'       FROM inv_precio_tb_nx',
'       WHERE pco_emp_empresa = ato_emp_empresa',
'       AND pco_ato_articulo = ato_articulo',
'       AND pco_lpo_lista = valor) precio,',
'       DECODE (ato_itemizado, ''N'', ''NO'', ''S'', ''SI'') itemizado,',
'       DECODE (ato_bloqueado_compra, ''N'', ''NO'', ''S'', ''SI'') bloqueado_compra,',
'       aln_ultimo_costo ultimo_costo,',
'       ato_cantidad_minima cant_minima,',
'       ato_cantidad_maxima cant_maxima,',
'       aln_costo_unitario_ant costo_uni_ant,',
'       aln_fecha_ultimo_costo fec_ult_costo,',
'       (SELECT hlp_precio_ant',
'       FROM INV_HISTORICO_PRECIO_TB_NX',
'       WHERE hlp_emp_empresa = aln_emp_empresa',
'       AND hlp_ato_articulo = aln_ato_articulo',
'       AND hlp_lpo_lista =  valor',
'       ORDER BY hlp_fecha_creacion desc',
'       FETCH FIRST 1 ROWS ONLY) precio_ant,',
'       (SELECT hlp_fecha_creacion',
'       FROM INV_HISTORICO_PRECIO_TB_NX',
'       WHERE hlp_emp_empresa = aln_emp_empresa',
'       AND hlp_ato_articulo = aln_ato_articulo',
'       AND hlp_lpo_lista =  valor',
'       ORDER BY hlp_fecha_creacion desc',
'       FETCH FIRST 1 ROWS ONLY) fec_precio_ant  ,',
'       ato_mod_modelo modelo,',
'       ato_mar_marca marca,',
'       ATO_IND_COMBO indica_combo,',
'       ATO_PLU Codigo_de_barras',
'FROM inv_articulo_localizacion_tb_n,',
'     inv_localizacion_tb_nx,',
'     inv_articulo_tb_nx, ',
'     inv_familia_tb_nx,',
'     gnl_parametro_empresa_tb_nx',
'WHERE INSTR ('':'' || :P50_EMPRESA || '':'', '':'' || aln_emp_empresa || '':'') > 0',
'      AND aln_emp_empresa = lcn_emp_empresa',
'      AND aln_lcn_localizacion = lcn_localizacion',
'      AND aln_emp_empresa = ato_emp_empresa',
'      AND aln_ato_articulo = ato_articulo',
'      AND ato_emp_empresa = fma_emp_empresa',
'      AND ato_fma_familia = fma_familia',
'      AND fma_disponible = ''S''',
'      AND aln_emp_empresa = empresa',
'      AND subsistema = ''INV''',
'      AND parametro = ''LISTA DE PRECIOS DETALLE'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P50_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14167883202129165322)
,p_name=>'Reporte de Inventarios'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10769308717666022
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097733029745647144)
,p_db_column_name=>'EMPRESA'
,p_display_order=>10
,p_column_identifier=>'Q'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167883511039165347)
,p_db_column_name=>'ARTICULO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
,p_static_id=>'ARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094457519789116430)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>30
,p_column_identifier=>'N'
,p_column_label=>'Categoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167883607660165348)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167883822256165350)
,p_db_column_name=>'FAMILIA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
,p_static_id=>'FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082254576853365819)
,p_db_column_name=>'DESC_FAMILIA'
,p_display_order=>60
,p_column_identifier=>'W'
,p_column_label=>'Desc. Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167884125060165352)
,p_db_column_name=>'LISTA'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
,p_static_id=>'LISTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167884197277165353)
,p_db_column_name=>'COSTOUNITARIO'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'COSTOUNITARIO'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P50_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167884294736165417)
,p_db_column_name=>'COSTOTOTAL'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'COSTOTOTAL'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P50_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168126614312383409)
,p_db_column_name=>'PRECIO'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PRECIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097415070959365602)
,p_db_column_name=>'CLASE'
,p_display_order=>110
,p_column_identifier=>'O'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732998649647143)
,p_db_column_name=>'ITEMIZADO'
,p_display_order=>120
,p_column_identifier=>'P'
,p_column_label=>'Itemizado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082254429828365818)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>130
,p_column_identifier=>'V'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098170109359481043)
,p_db_column_name=>'DESC_LOCALIZACION'
,p_display_order=>140
,p_column_identifier=>'S'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082254629924365820)
,p_db_column_name=>'TIPO'
,p_display_order=>150
,p_column_identifier=>'X'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082254800040365821)
,p_db_column_name=>'CSTOCK'
,p_display_order=>160
,p_column_identifier=>'Y'
,p_column_label=>'Cant. Stock'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082254892418365822)
,p_db_column_name=>'CTRANSITO'
,p_display_order=>170
,p_column_identifier=>'Z'
,p_column_label=>'Cant. Transito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082254987535365823)
,p_db_column_name=>'CTOTAL'
,p_display_order=>180
,p_column_identifier=>'AA'
,p_column_label=>'Cant. Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082255053888365824)
,p_db_column_name=>'BLOQUEADO_COMPRA'
,p_display_order=>190
,p_column_identifier=>'AB'
,p_column_label=>'Bloq. Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058209217722913589)
,p_db_column_name=>'ULTIMO_COSTO'
,p_display_order=>200
,p_column_identifier=>'AC'
,p_column_label=>'Ultimo costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846476748807350)
,p_db_column_name=>'CANT_MINIMA'
,p_display_order=>210
,p_column_identifier=>'AD'
,p_column_label=>'Cant. Minima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846600521807351)
,p_db_column_name=>'CANT_MAXIMA'
,p_display_order=>220
,p_column_identifier=>'AE'
,p_column_label=>'Cant. Maxima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846694213807352)
,p_db_column_name=>'COSTO_UNI_ANT'
,p_display_order=>230
,p_column_identifier=>'AF'
,p_column_label=>'Costo Uni. Anterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846746278807353)
,p_db_column_name=>'FEC_ULT_COSTO'
,p_display_order=>240
,p_column_identifier=>'AG'
,p_column_label=>'F. Ult. Costo'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846873000807354)
,p_db_column_name=>'PRECIO_ANT'
,p_display_order=>250
,p_column_identifier=>'AH'
,p_column_label=>'Precio Ant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846986692807355)
,p_db_column_name=>'FEC_PRECIO_ANT'
,p_display_order=>260
,p_column_identifier=>'AI'
,p_column_label=>'F. Precio Ant'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003698663270907963)
,p_db_column_name=>'MODELO'
,p_display_order=>270
,p_column_identifier=>'AJ'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003698707684907964)
,p_db_column_name=>'MARCA'
,p_display_order=>280
,p_column_identifier=>'AK'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003698889486907965)
,p_db_column_name=>'INDICA_COMBO'
,p_display_order=>290
,p_column_identifier=>'AL'
,p_column_label=>'Indica combo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13903092704556689636)
,p_db_column_name=>'CODIGO_DE_BARRAS'
,p_display_order=>300
,p_column_identifier=>'AM'
,p_column_label=>'Codigo De Barras'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13910744822626769209)
,p_db_column_name=>'PARTE_FABRICANTE'
,p_display_order=>310
,p_column_identifier=>'AN'
,p_column_label=>'Parte Fabricante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13910744723240769208)
,p_db_column_name=>'PARTIDA'
,p_display_order=>320
,p_column_identifier=>'AO'
,p_column_label=>'Partida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13910744591513769207)
,p_db_column_name=>'DESCONTINUADO'
,p_display_order=>330
,p_column_identifier=>'AP'
,p_column_label=>'Descontinuado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13910744554116769206)
,p_db_column_name=>'CABYS_ID'
,p_display_order=>340
,p_column_identifier=>'AQ'
,p_column_label=>'Cabys Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14167884404429165671)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'107706'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:ARTICULO:DESCRIPCION:CLASE:CATEGORIA:FAMILIA:DESC_FAMILIA:LISTA:LOCALIZACION:DESC_LOCALIZACION:TIPO:PRECIO:COSTOUNITARIO:CSTOCK:CTRANSITO:CTOTAL:COSTOTOTAL:ITEMIZADO::BLOQUEADO_COMPRA:ULTIMO_COSTO:CANT_MINIMA:CANT_MAXIMA:COSTO_UNI_ANT:FEC_ULT'
||'_COSTO:PRECIO_ANT:FEC_PRECIO_ANT:MODELO:MARCA:INDICA_COMBO:CODIGO_DE_BARRAS:PARTE_FABRICANTE:PARTIDA:DESCONTINUADO:CABYS_ID'
,p_sort_column_1=>'ARTICULO'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168178802770811509)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14167884906638175817)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098470624100008871)
,p_name=>'P50_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14167884906638175817)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE   use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167885717669175856)
,p_name=>'P50_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14167884906638175817)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
