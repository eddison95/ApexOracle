prompt --application/pages/page_00061
begin
--   Manifest
--     PAGE: 00061
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>61
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'TAL - Detalle Orden Servicio'
,p_step_title=>'Detalle Orden Servicio'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ESALAS'
,p_last_upd_yyyymmddhh24miss=>'20210520104733'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112667780640150230)
,p_plug_name=>'Detalle Orden Servicio'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112666153368150199)
,p_plug_name=>'Detalle Orden Servicio'
,p_region_name=>'Ordenes de Trabajo'
,p_parent_plug_id=>wwv_flow_api.id(14112667780640150230)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   det_empresa empresa,',
'         det_orden,',
'         det_fecha det_fecha,',
'         det_lista,',
'         det_desc_lista,',
'         det_codigo,',
'         det_descripcion,',
'         det_estado,',
'         det_estado_orden,',
'         det_cantidad_pedida,',
'         det_cantidad_asignada,',
'         det_cantidad_devuelta,',
'         det_precio,',
'         det_descuento,',
'         det_impuesto,',
'         det_categoria,',
'         det_prioridad,',
'         det_fecha_asignacion det_fecha_asignacion,',
'         det_fecha_cierre det_fecha_cierre,',
'         det_fecha_inicio det_fecha_inicio,',
'         det_fecha_fin det_fecha_fin,',
'         det_duracion,',
'         det_empleado,',
'         det_tipo,',
'         det_tipo_compra,',
'         det_cli_cliente,',
'         det_cliente,',
'         det_asesor,',
'         det_cod_localizacion,',
'         det_desc_localizacion,',
'         det_serial,',
'         det_motor,',
'         det_chasis,',
'         det_placa,',
'         det_anio,',
'         det_dist_recorrida,',
'         det_fec_adquisicion,',
'         det_item,',
'         det_marca,',
'         det_modelo,',
'         det_segmento,',
'         det_seg_grupo,',
'         duracion_estandar,',
'         det_color,',
'         TRUNC(MOD((det_fecha_inicio - det_fecha_fin) * 24, 24)) DIFERENCIA_HORAS',
'  FROM   tal_det_orden_servicio_vw_nx',
' WHERE   INSTR ('':'' || :p61_empresa || '':'', '':'' || det_empresa || '':'') > 0',
'         AND det_fecha BETWEEN :p61_inicio',
'                           AND  TO_DATE (:p61_fin || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P61_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14112666381826150203)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>11875131134361592
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094368846521236795)
,p_db_column_name=>'DET_ORDEN'
,p_display_order=>20
,p_column_identifier=>'AF'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094368945848236796)
,p_db_column_name=>'DET_FECHA'
,p_display_order=>30
,p_column_identifier=>'AG'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369078021236797)
,p_db_column_name=>'DET_CODIGO'
,p_display_order=>40
,p_column_identifier=>'AH'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369217891236798)
,p_db_column_name=>'DET_DESCRIPCION'
,p_display_order=>50
,p_column_identifier=>'AI'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369314338236799)
,p_db_column_name=>'DET_ESTADO'
,p_display_order=>60
,p_column_identifier=>'AJ'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094866143982014717)
,p_db_column_name=>'DET_ESTADO_ORDEN'
,p_display_order=>70
,p_column_identifier=>'BA'
,p_column_label=>'Estado Orden'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369379896236800)
,p_db_column_name=>'DET_CANTIDAD_PEDIDA'
,p_display_order=>80
,p_column_identifier=>'AK'
,p_column_label=>'Cant Pedida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369471388236801)
,p_db_column_name=>'DET_CANTIDAD_ASIGNADA'
,p_display_order=>90
,p_column_identifier=>'AL'
,p_column_label=>'Cant Asignada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369596654236802)
,p_db_column_name=>'DET_CANTIDAD_DEVUELTA'
,p_display_order=>100
,p_column_identifier=>'AM'
,p_column_label=>'Cant Devuelta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369656406236803)
,p_db_column_name=>'DET_PRECIO'
,p_display_order=>110
,p_column_identifier=>'AN'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369767900236804)
,p_db_column_name=>'DET_DESCUENTO'
,p_display_order=>120
,p_column_identifier=>'AO'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369900601236805)
,p_db_column_name=>'DET_IMPUESTO'
,p_display_order=>130
,p_column_identifier=>'AP'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094369996484236806)
,p_db_column_name=>'DET_CATEGORIA'
,p_display_order=>140
,p_column_identifier=>'AQ'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370097742236807)
,p_db_column_name=>'DET_PRIORIDAD'
,p_display_order=>150
,p_column_identifier=>'AR'
,p_column_label=>'Prioridad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370173976236808)
,p_db_column_name=>'DET_FECHA_ASIGNACION'
,p_display_order=>160
,p_column_identifier=>'AS'
,p_column_label=>'Fecha Asignacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370259260236809)
,p_db_column_name=>'DET_FECHA_CIERRE'
,p_display_order=>170
,p_column_identifier=>'AT'
,p_column_label=>'Fecha Cierre'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370387693236810)
,p_db_column_name=>'DET_FECHA_INICIO'
,p_display_order=>180
,p_column_identifier=>'AU'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370438890236811)
,p_db_column_name=>'DET_FECHA_FIN'
,p_display_order=>190
,p_column_identifier=>'AV'
,p_column_label=>'Fecha Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370602487236812)
,p_db_column_name=>'DET_DURACION'
,p_display_order=>200
,p_column_identifier=>'AW'
,p_column_label=>'Duracion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370647206236813)
,p_db_column_name=>'DET_EMPLEADO'
,p_display_order=>210
,p_column_identifier=>'AX'
,p_column_label=>'Empleado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370745569236814)
,p_db_column_name=>'DET_TIPO'
,p_display_order=>220
,p_column_identifier=>'AY'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094370894224236815)
,p_db_column_name=>'DET_TIPO_COMPRA'
,p_display_order=>230
,p_column_identifier=>'AZ'
,p_column_label=>'Tipo Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900241158642710)
,p_db_column_name=>'EMPRESA'
,p_display_order=>240
,p_column_identifier=>'BB'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314001301873795)
,p_db_column_name=>'DET_LISTA'
,p_display_order=>250
,p_column_identifier=>'BC'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314045761873796)
,p_db_column_name=>'DET_DESC_LISTA'
,p_display_order=>260
,p_column_identifier=>'BD'
,p_column_label=>'Desc. Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314181124873797)
,p_db_column_name=>'DET_CLI_CLIENTE'
,p_display_order=>270
,p_column_identifier=>'BE'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314231972873798)
,p_db_column_name=>'DET_CLIENTE'
,p_display_order=>280
,p_column_identifier=>'BF'
,p_column_label=>'Nom. Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099123416209152599)
,p_db_column_name=>'DET_ASESOR'
,p_display_order=>290
,p_column_identifier=>'BG'
,p_column_label=>'Asesor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099123455935152600)
,p_db_column_name=>'DET_COD_LOCALIZACION'
,p_display_order=>300
,p_column_identifier=>'BH'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099123548197152601)
,p_db_column_name=>'DET_DESC_LOCALIZACION'
,p_display_order=>310
,p_column_identifier=>'BI'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000675834925697986)
,p_db_column_name=>'DET_SERIAL'
,p_display_order=>320
,p_column_identifier=>'BJ'
,p_column_label=>'Serial'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000675932600697987)
,p_db_column_name=>'DET_MOTOR'
,p_display_order=>330
,p_column_identifier=>'BK'
,p_column_label=>'Motor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000676051848697988)
,p_db_column_name=>'DET_CHASIS'
,p_display_order=>340
,p_column_identifier=>'BL'
,p_column_label=>'Chasis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000676126524697989)
,p_db_column_name=>'DET_PLACA'
,p_display_order=>350
,p_column_identifier=>'BM'
,p_column_label=>'Placa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000676249088697990)
,p_db_column_name=>'DET_ANIO'
,p_display_order=>360
,p_column_identifier=>'BN'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000676339684697991)
,p_db_column_name=>'DET_DIST_RECORRIDA'
,p_display_order=>370
,p_column_identifier=>'BO'
,p_column_label=>'Recorrido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000676474551697992)
,p_db_column_name=>'DET_FEC_ADQUISICION'
,p_display_order=>380
,p_column_identifier=>'BP'
,p_column_label=>'F. Adquisicion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000676585361697993)
,p_db_column_name=>'DET_ITEM'
,p_display_order=>390
,p_column_identifier=>'BQ'
,p_column_label=>'Item'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000676662525697994)
,p_db_column_name=>'DET_MARCA'
,p_display_order=>400
,p_column_identifier=>'BR'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000676714756697995)
,p_db_column_name=>'DET_MODELO'
,p_display_order=>410
,p_column_identifier=>'BS'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846097017807346)
,p_db_column_name=>'DET_SEGMENTO'
,p_display_order=>420
,p_column_identifier=>'BT'
,p_column_label=>'Segmento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846119300807347)
,p_db_column_name=>'DET_SEG_GRUPO'
,p_display_order=>430
,p_column_identifier=>'BU'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000846284588807348)
,p_db_column_name=>'DET_COLOR'
,p_display_order=>440
,p_column_identifier=>'BV'
,p_column_label=>'Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885353434151840924)
,p_db_column_name=>'DURACION_ESTANDAR'
,p_display_order=>450
,p_column_identifier=>'BW'
,p_column_label=>'Duracion Estandar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885353319800840923)
,p_db_column_name=>'DIFERENCIA_HORAS'
,p_display_order=>460
,p_column_identifier=>'BX'
,p_column_label=>'Tiempo Real '
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14094523915333671644)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_report_seq=>10
,p_report_alias=>'67802'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'DET_ORDEN:DET_FECHA:DET_CODIGO:DET_DESCRIPCION:DET_ESTADO:DET_CANTIDAD_PEDIDA:DET_CANTIDAD_ASIGNADA:DET_CANTIDAD_DEVUELTA:DET_PRECIO:DET_DESCUENTO:DET_IMPUESTO:DET_CATEGORIA:DET_PRIORIDAD:DET_FECHA_ASIGNACION:DET_FECHA_CIERRE:DET_FECHA_INICIO:DET_FEC'
||'HA_FIN:DET_DURACION:DET_EMPLEADO:DET_TIPO:DET_TIPO_COMPRA:DET_ESTADO_ORDEN:EMPRESA:DET_LISTA:DET_DESC_LISTA:DET_CLI_CLIENTE:DET_CLIENTE:DET_ASESOR:DET_COD_LOCALIZACION:DET_DESC_LOCALIZACION:DET_SERIAL:DET_MOTOR:DET_CHASIS:DET_PLACA:DET_ANIO:DET_DIST_'
||'RECORRIDA:DET_FEC_ADQUISICION:DET_ITEM:DET_MARCA:DET_MODELO:DET_SEGMENTO:DET_SEG_GRUPO:DET_COLOR'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14112667566190150223)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118764'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:DET_ORDEN:DET_FECHA:DET_CODIGO:DET_DESCRIPCION:DET_ESTADO:DET_ESTADO_ORDEN:DET_CANTIDAD_PEDIDA:DET_CANTIDAD_ASIGNADA:DET_CANTIDAD_DEVUELTA:DET_PRECIO:DET_DESCUENTO:DET_IMPUESTO:DET_CATEGORIA:DET_PRIORIDAD:DET_FECHA_ASIGNACION:DET_FECHA_CIERRE'
||':DET_FECHA_INICIO:DET_FECHA_FIN:DET_DURACION:DET_EMPLEADO:DET_ASESOR:DET_COD_LOCALIZACION:DET_DESC_LOCALIZACION:DET_TIPO:DET_TIPO_COMPRA:DET_LISTA:DET_DESC_LISTA:DET_CLI_CLIENTE:DET_CLIENTE::DET_SERIAL:DET_MOTOR:DET_CHASIS:DET_PLACA:DET_ANIO:DET_DIST'
||'_RECORRIDA:DET_FEC_ADQUISICION:DET_ITEM:DET_MARCA:DET_MODELO:DET_SEGMENTO:DET_SEG_GRUPO:DET_COLOR:DURACION_ESTANDAR:DIFERENCIA_HORAS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14112667959995150232)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14112667780640150230)
,p_button_name=>'P61_CONSULTAR'
,p_button_static_id=>'P61_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112668165644150235)
,p_name=>'P61_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14112667780640150230)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112668372026150235)
,p_name=>'P61_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14112667780640150230)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112668557498150236)
,p_name=>'P61_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14112667780640150230)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
