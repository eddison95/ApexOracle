prompt --application/pages/page_00080
begin
--   Manifest
--     PAGE: 00080
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>80
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('PLA - Hist\00F3rico Planillas')
,p_step_title=>'Historico Planillas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20210109171712'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095345424696455112)
,p_plug_name=>'Historico Planillas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095347276814455177)
,p_plug_name=>'Historico Planillas'
,p_parent_plug_id=>wwv_flow_api.id(14095345424696455112)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  TRUNC(rph.RPH_FECHA_INICIO) RPH_FECHA_INICIO,',
'  TRUNC(rph.RPH_FECHA_FINAL) RPH_FECHA_FINAL,',
'  rph.RPH_ENC_ID,',
'  rph.RPH_EMP_EMPRESA Id_Empresa,',
'  rph.RPH_ID,',
'  (rph.RPH_TPL_ID || '' - '' || pla_nombre_tipo_planilla_v_nx (rph.RPH_EMP_EMPRESA,   rph.RPH_TPL_ID)) Planilla,',
'  rph.RPH_PER_PERSONA Persona,',
'  nombre || '' ''|| apellidos Nombre,',
'  documento Cedula,',
'  rph.RPH_TOTAL_DEVENGO,',
'  null Devengo,',
'  rph.RPH_TOTAL_DEDUCCION,',
'  null Deduccion,',
'  rph.RPH_TOTAL_PROVISION,',
'  null Provision,',
'  rph.RPH_TOTAL_CARGA_SOCIAL,',
'  null Carga_Social,',
'  rph.RPH_TOTAL_DEVENGO -  rph.RPH_TOTAL_DEDUCCION Total_Neto,',
'CASE rph_ptp_forma_pago',
'WHEN  ''C'' THEN ''Cheque''',
'WHEN ''T'' THEN ''Transferencia''',
'WHEN ''E'' THEN ''Efectivo''',
'ELSE ''No Definido''',
'END',
'forma_pago,',
'CASE rph_ptp_tipo_cuenta',
'      WHEN ''C'' THEN ''Cuenta Corriente''',
'      WHEN ''A'' THEN ''Ahorros''',
'      WHEN ''O'' THEN ''Otro''',
'ELSE ''No Definido''',
'      END',
'      tipo_cuenta,',
'  rph_ptp_cuenta_bancaria cuenta_bancaria,',
'  rph_ptp_cuenta_cliente cuenta_cliente',
'FROM PLA_RESPLAN_HIST_TB_NX rph, GNL_PERSONA_TR_NX',
'WHERE rph.RPH_EMP_EMPRESA = :P80_EMPRESA',
'AND rph.RPH_FECHA_INICIO >= :P80_INICIO',
'AND rph.RPH_FECHA_FINAL <= :P80_FIN',
'AND rph.RPH_PER_PERSONA = PERSONA',
'ORDER BY APELLIDOS ASC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P80_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095347660523455181)
,p_name=>'Ventas Diarias'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>7603935751566087
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777067920343106)
,p_db_column_name=>'RPH_FECHA_INICIO'
,p_display_order=>10
,p_column_identifier=>'BF'
,p_column_label=>'Rph fecha inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777156370343107)
,p_db_column_name=>'RPH_FECHA_FINAL'
,p_display_order=>20
,p_column_identifier=>'BG'
,p_column_label=>'Rph fecha final'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777302251343108)
,p_db_column_name=>'RPH_ENC_ID'
,p_display_order=>30
,p_column_identifier=>'BH'
,p_column_label=>'Rph enc id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777353469343109)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>40
,p_column_identifier=>'BI'
,p_column_label=>'Id empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777439598343110)
,p_db_column_name=>'RPH_ID'
,p_display_order=>50
,p_column_identifier=>'BJ'
,p_column_label=>'Rph id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777598862343111)
,p_db_column_name=>'PLANILLA'
,p_display_order=>60
,p_column_identifier=>'BK'
,p_column_label=>'Planilla'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777696389343112)
,p_db_column_name=>'PERSONA'
,p_display_order=>70
,p_column_identifier=>'BL'
,p_column_label=>'Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777759379343113)
,p_db_column_name=>'NOMBRE'
,p_display_order=>80
,p_column_identifier=>'BM'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777864531343114)
,p_db_column_name=>'RPH_TOTAL_DEVENGO'
,p_display_order=>90
,p_column_identifier=>'BN'
,p_column_label=>'Total Devengo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095777958404343115)
,p_db_column_name=>'DEVENGO'
,p_display_order=>100
,p_column_identifier=>'BO'
,p_column_label=>'Devengo'
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP:P85_RPH_ID,P85_TPLA,P85_NOMBRE,P85_TIPO_DET:#RPH_ID#,#PLANILLA#,#NOMBRE#,Dv'
,p_column_linktext=>'<button type="button">Devengos</button> '
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095778079292343116)
,p_db_column_name=>'RPH_TOTAL_DEDUCCION'
,p_display_order=>110
,p_column_identifier=>'BP'
,p_column_label=>'Total Deduccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095778159196343117)
,p_db_column_name=>'DEDUCCION'
,p_display_order=>120
,p_column_identifier=>'BQ'
,p_column_label=>'Deduccion'
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP:P85_RPH_ID,P85_TPLA,P85_NOMBRE,P85_TIPO_DET:#RPH_ID#,#PLANILLA#,#NOMBRE#,Dd'
,p_column_linktext=>'<button type="button">Deducciones</button> '
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095778309353343118)
,p_db_column_name=>'RPH_TOTAL_PROVISION'
,p_display_order=>130
,p_column_identifier=>'BR'
,p_column_label=>'Total Provision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095778379226343119)
,p_db_column_name=>'PROVISION'
,p_display_order=>140
,p_column_identifier=>'BS'
,p_column_label=>'Provision'
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP:P85_RPH_ID,P85_TPLA,P85_NOMBRE,P85_TIPO_DET:#RPH_ID#,#PLANILLA#,#NOMBRE#,P'
,p_column_linktext=>'<button type="button">Provisiones</button> '
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095778433750343120)
,p_db_column_name=>'RPH_TOTAL_CARGA_SOCIAL'
,p_display_order=>150
,p_column_identifier=>'BT'
,p_column_label=>'Total Carga Social'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095778580682343121)
,p_db_column_name=>'CARGA_SOCIAL'
,p_display_order=>160
,p_column_identifier=>'BU'
,p_column_label=>'Carga social'
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP:P85_RPH_ID,P85_TPLA,P85_NOMBRE,P85_TIPO_DET:#RPH_ID#,#PLANILLA#,#NOMBRE#,C'
,p_column_linktext=>'<button type="button">Carga Social</button> '
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095778661044343122)
,p_db_column_name=>'TOTAL_NETO'
,p_display_order=>170
,p_column_identifier=>'BV'
,p_column_label=>'Total neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14023995633432493050)
,p_db_column_name=>'CEDULA'
,p_display_order=>180
,p_column_identifier=>'BW'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13906472521006042007)
,p_db_column_name=>'FORMA_PAGO'
,p_display_order=>190
,p_column_identifier=>'BX'
,p_column_label=>'Forma Pago'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13906472590743042008)
,p_db_column_name=>'TIPO_CUENTA'
,p_display_order=>200
,p_column_identifier=>'BY'
,p_column_label=>'Tipo Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13906472760831042009)
,p_db_column_name=>'CUENTA_BANCARIA'
,p_display_order=>210
,p_column_identifier=>'BZ'
,p_column_label=>'Cuenta Bancaria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13906472782968042010)
,p_db_column_name=>'CUENTA_CLIENTE'
,p_display_order=>220
,p_column_identifier=>'CA'
,p_column_label=>'Cuenta Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095359409404455232)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'76157'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'KDM_KDM_TIPO:RPH_FECHA_INICIO:RPH_FECHA_FINAL:RPH_ENC_ID:ID_EMPRESA:RPH_ID:PLANILLA:PERSONA:NOMBRE:RPH_TOTAL_DEVENGO:DEVENGO:RPH_TOTAL_DEDUCCION:DEDUCCION:RPH_TOTAL_PROVISION:PROVISION:RPH_TOTAL_CARGA_SOCIAL:CARGA_SOCIAL:TOTAL_NETO:CEDULA:FORMA_PAGO:'
||'TIPO_CUENTA:CUENTA_BANCARIA:CUENTA_CLIENTE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14095345814684455135)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14095345424696455112)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095346221744455150)
,p_name=>'P80_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14095345424696455112)
,p_prompt=>'Fecha'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095346450840455170)
,p_name=>'P80_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14095345424696455112)
,p_prompt=>'Fecha Fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095404854255222893)
,p_name=>'P80_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14095345424696455112)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
