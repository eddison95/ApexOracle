prompt --application/pages/page_00095
begin
--   Manifest
--     PAGE: 00095
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>95
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CRM - Oportunidades'
,p_step_title=>'Oportunidades'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164752'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096896744114627221)
,p_plug_name=>'Oportunidades'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095655015063995317)
,p_plug_name=>'Oportunidades'
,p_parent_plug_id=>wwv_flow_api.id(14096896744114627221)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 17/02/2017 04:01:51 p.m. (QP5 v5.115.810.9015) */',
'  SELECT   OPPORTUNITIES.ID AS ID,',
'           ORGANIZATIONS.NAME AS ORGANIZATION,',
'           OPPORTUNITIES.REFERRAL AS REFERRAL,',
'           OPPORTUNITIES.NAME AS NAME,',
'           OPPORTUNITIES.DESCRIPTION AS DESCRIPTION,',
'           OPPORTUNITIES.COST AS COST,',
'           OPPORTUNITIES.ASSIGNED_TO AS ASSIGNED_TO,',
'           TRUNC (OPPORTUNITIES.ESTIMATED_CLOSE_DATE) AS ESTIMATED_CLOSE_DATE,',
'           OPPORTUNITIES.TEMPLATE AS TEMPLATE,',
'           FOLLOWUPS_TEMPLATES.NAME DESC_TEMPLATE,',
'           OPPORTUNITIES.MNG_TEMPLATE AS MNG_TEMPLATE,',
'           DECODE (OPPORTUNITIES.STATUS,',
'                   1,',
'                   ''En Proceso'',',
'                   2,',
'                   ''Ganada'',',
'                   3,',
'                   ''Perdida'',',
'                   4,',
'                   ''Desierta'',',
'                   5,',
unistr('                   ''Cr\00E9dito en Estudio'','),
'                   8,',
'                   ''Precalificado'',',
'                   7,',
unistr('                   ''Cr\00E9dito Rechazado'','),
'                   6,',
unistr('                   ''Cr\00E9dito Condicionado'','),
'                   9,',
unistr('                   ''Cr\00E9dito Aprobado'')'),
'              AS STATUS,',
'           OPPORTUNITIES.COMMENTS AS COMMENTS,',
'           OPPORTUNITIES.MNG_BY AS MNG_BY,',
'           DECODE (OPPORTUNITIES.STATUS_MNG,',
'                   ''P'',',
'                   ''En Proceso'',',
'                   ''F'',',
'                   ''Finalizado'')',
'              AS STATUS_MNG,',
'           PRICE_BOOKS.NAME AS PRICE_BOOK,',
'           TRUNC (OPPORTUNITIES.FECHA_CRE) AS FECHA_CRE,',
'           ADVERTISING_ORIGIN.NAME AS ADVERTISING_ORIGIN,',
'           OPPORTUNITIES.COMPANY AS COMPANY,',
'           TRUNC (OPPORTUNITIES.DATE_DELIVERY) AS DATE_DELIVERY,',
'           OPPORTUNITIES.DISCOUNTS_PRICEBOOK AS DISCOUNTS_PRICEBOOK,',
'           SALESMAN.ID AS SALESMAN_ID,',
'           SALESMAN.NAME AS SALESMAN,',
'           PRODUCTS_BY_OPPORTUNITY.LIST_PRICE,',
'           PRODUCTS_BY_OPPORTUNITY.SALE_PRICE,',
'           PRODUCTS_BY_OPPORTUNITY.DISCOUNT,',
'           PRODUCTS_BY_OPPORTUNITY.UNITS,',
'           PRODUCTS_BY_OPPORTUNITY.TOTAL_PRICE,',
'           PRODUCTS.NAME product',
'    FROM   OPPORTUNITIES OPPORTUNITIES,',
'           ORGANIZATIONS ORGANIZATIONS,',
'           PRICE_BOOKS PRICE_BOOKS,',
'           ADVERTISING_ORIGIN ADVERTISING_ORIGIN,',
'           SALESMAN SALESMAN,',
'           FOLLOWUPS_TEMPLATES FOLLOWUPS_TEMPLATES,',
'           PRODUCTS_BY_OPPORTUNITY PRODUCTS_BY_OPPORTUNITY,',
'           PRODUCTS PRODUCTS',
'   WHERE       INSTR ('':'' || :P95_EMPRESA || '':'',',
'                      '':'' || OPPORTUNITIES.COMPANY || '':'') > 0',
'           AND OPPORTUNITIES.ORGANIZATION = ORGANIZATIONS.ID',
'           AND OPPORTUNITIES.PRICE_BOOK = PRICE_BOOKS.ID',
'           AND OPPORTUNITIES.ADVERTISING_ORIGIN = ADVERTISING_ORIGIN.ID',
'           AND OPPORTUNITIES.TEMPLATE = FOLLOWUPS_TEMPLATES.ID',
'           AND SALESMAN.ID IN',
'                    (SELECT   PRODUCT_BY_SALESMAN.SALESMAN',
'                       FROM   PRODUCTS_BY_OPPORTUNITY, PRODUCT_BY_SALESMAN',
'                      WHERE   PRODUCTS_BY_OPPORTUNITY.OPPORTUNITY =',
'                                 OPPORTUNITIES.ID',
'                              AND PRODUCTS_BY_OPPORTUNITY.PRODUCT =',
'                                    PRODUCT_BY_SALESMAN.PRODUCT)',
'           AND PRODUCTS_BY_OPPORTUNITY.OPPORTUNITY = OPPORTUNITIES.ID',
'           AND PRODUCTS_BY_OPPORTUNITY.PRODUCT = PRODUCTS.ID',
'ORDER BY   1;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P95_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095655357879995330)
,p_name=>'Ventas Diarias'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>7911633108106236
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095655850008995331)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'CI'
,p_column_label=>'Oportunidad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095656308036995332)
,p_db_column_name=>'ID'
,p_display_order=>90
,p_column_identifier=>'CJ'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095657467729995335)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>120
,p_column_identifier=>'CM'
,p_column_label=>'Descripcion'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095657863680995336)
,p_db_column_name=>'COMMENTS'
,p_display_order=>130
,p_column_identifier=>'CN'
,p_column_label=>'Comentarios'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095659516753995339)
,p_db_column_name=>'STATUS'
,p_display_order=>170
,p_column_identifier=>'CR'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095633919454928901)
,p_db_column_name=>'ORGANIZATION'
,p_display_order=>180
,p_column_identifier=>'CX'
,p_column_label=>'Organizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095633939937928902)
,p_db_column_name=>'REFERRAL'
,p_display_order=>190
,p_column_identifier=>'CY'
,p_column_label=>'Referencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634070038928903)
,p_db_column_name=>'COST'
,p_display_order=>200
,p_column_identifier=>'CZ'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634207027928904)
,p_db_column_name=>'ASSIGNED_TO'
,p_display_order=>210
,p_column_identifier=>'DA'
,p_column_label=>'Asignado a'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634257782928905)
,p_db_column_name=>'ESTIMATED_CLOSE_DATE'
,p_display_order=>220
,p_column_identifier=>'DB'
,p_column_label=>'F. Cierre Estimada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634353586928906)
,p_db_column_name=>'TEMPLATE'
,p_display_order=>230
,p_column_identifier=>'DC'
,p_column_label=>'Template'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634489404928907)
,p_db_column_name=>'MNG_TEMPLATE'
,p_display_order=>240
,p_column_identifier=>'DD'
,p_column_label=>'Mng Template'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634550902928908)
,p_db_column_name=>'MNG_BY'
,p_display_order=>250
,p_column_identifier=>'DE'
,p_column_label=>'Mng By'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634720744928909)
,p_db_column_name=>'STATUS_MNG'
,p_display_order=>260
,p_column_identifier=>'DF'
,p_column_label=>'Estado Mng'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634789170928910)
,p_db_column_name=>'PRICE_BOOK'
,p_display_order=>270
,p_column_identifier=>'DG'
,p_column_label=>'Price Book'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634902923928911)
,p_db_column_name=>'FECHA_CRE'
,p_display_order=>280
,p_column_identifier=>'DH'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095634928705928912)
,p_db_column_name=>'ADVERTISING_ORIGIN'
,p_display_order=>290
,p_column_identifier=>'DI'
,p_column_label=>'Origen Publicidad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635069371928913)
,p_db_column_name=>'COMPANY'
,p_display_order=>300
,p_column_identifier=>'DJ'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635197904928914)
,p_db_column_name=>'DATE_DELIVERY'
,p_display_order=>310
,p_column_identifier=>'DK'
,p_column_label=>'F. Entrega'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635239099928915)
,p_db_column_name=>'DISCOUNTS_PRICEBOOK'
,p_display_order=>320
,p_column_identifier=>'DL'
,p_column_label=>'Descuento Price Book'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635333768928916)
,p_db_column_name=>'SALESMAN_ID'
,p_display_order=>330
,p_column_identifier=>'DM'
,p_column_label=>'Vendedor Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635474884928917)
,p_db_column_name=>'SALESMAN'
,p_display_order=>340
,p_column_identifier=>'DN'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098670126462192123)
,p_db_column_name=>'DESC_TEMPLATE'
,p_display_order=>350
,p_column_identifier=>'DO'
,p_column_label=>'Desc. Template'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098670251411192124)
,p_db_column_name=>'LIST_PRICE'
,p_display_order=>360
,p_column_identifier=>'DP'
,p_column_label=>'Precio Lista'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098670329773192125)
,p_db_column_name=>'SALE_PRICE'
,p_display_order=>370
,p_column_identifier=>'DQ'
,p_column_label=>'Precio de Venta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098670472635192126)
,p_db_column_name=>'DISCOUNT'
,p_display_order=>380
,p_column_identifier=>'DR'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098670570564192127)
,p_db_column_name=>'UNITS'
,p_display_order=>390
,p_column_identifier=>'DS'
,p_column_label=>'Unidades'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098670651480192128)
,p_db_column_name=>'TOTAL_PRICE'
,p_display_order=>400
,p_column_identifier=>'DT'
,p_column_label=>'Precio Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098670802737192129)
,p_db_column_name=>'PRODUCT'
,p_display_order=>410
,p_column_identifier=>'DU'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095661920454995370)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'79182'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'COMPANY:ID:ASSIGNED_TO:NAME:DESCRIPTION:COMMENTS:STATUS:ORGANIZATION:REFERRAL:COST:FECHA_CRE:ESTIMATED_CLOSE_DATE:DATE_DELIVERY:TEMPLATE:DESC_TEMPLATE:MNG_TEMPLATE:MNG_BY:STATUS_MNG:PRICE_BOOKS_PRICEBOOK:ADVERTISING_ORIGIN:SALESMAN_ID:SALESMAN::LIST_'
||'PRICE:SALE_PRICE:DISCOUNT:UNITS:TOTAL_PRICE:PRODUCT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096897060525627222)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14096896744114627221)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096897425827627224)
,p_name=>'P95_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096896744114627221)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
