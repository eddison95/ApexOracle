prompt --application/pages/page_00062
begin
--   Manifest
--     PAGE: 00062
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>62
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CXC - Clientes'
,p_step_title=>'Clientes'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104153119'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112699673973853204)
,p_plug_name=>'Clientes'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112695952456853160)
,p_plug_name=>'Clientes'
,p_region_name=>'Clientes'
,p_parent_plug_id=>wwv_flow_api.id(14112699673973853204)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   a.cli_emp_empresa empresa,',
'         a.cli_per_persona persona,',
'         a.cli_cliente codigo,',
'         gnl_nombre_persona_v_nx (a.cli_per_persona) nombre,',
'         a.cli_fecha_creacion fecha_creacion,         ',
'         cxc_descrip_clase_v_nx (a.cli_emp_empresa, a.cli_ccl_clase) clase,',
'         a.cli_mon_moneda moneda,',
'         (SELECT   c.tcl_descripcion',
'            FROM   cxc_tipo_cliente_tb_nx c',
'           WHERE   c.tcl_tipo = a.cli_tcl_tipo)',
'            tipo,',
'         DECODE (a.cli_credito_contado,',
'                 ''CR'',',
'                 ''Credito'',',
'                 ''CO'',',
'                 ''Contado'')',
'            credito_contado,',
'         DECODE (',
'            a.cli_status,',
'            ''A'',',
'            ''Activo'',',
'            ''B'',',
'            ''Bloqueado para crear nuevas trans. con supertipo FAC,NC u OC'',',
'            ''I'',',
'            ''Inactivo para crear cualquier transaccion.'',',
'            ''T'',',
unistr('            ''Tr\00E1mite legal'','),
'            ''J'',',
'            ''Cobro Judicial'',',
'            ''L'',',
'            ''Lista Negra''',
'         )',
'            estado,',
'         DECODE (a.cli_dia_pago,',
'                 ''LU'',',
'                 ''Lunes'',',
'                 ''MA'',',
'                 ''Martes'',',
'                 ''MI'',',
'                 ''Miercoles'',',
'                 ''JU'',',
'                 ''Jueves'',',
'                 ''VI'',',
'                 ''Viernes'',',
'                 ''SA'',',
'                 ''Sabado'',',
'                 ''DO'',',
'                 ''Domingo'')',
'            dia_pago,',
'         DECODE (a.cli_dia_tramite,',
'                 ''LU'',',
'                 ''Lunes'',',
'                 ''MA'',',
'                 ''Martes'',',
'                 ''MI'',',
'                 ''Miercoles'',',
'                 ''JU'',',
'                 ''Jueves'',',
'                 ''VI'',',
'                 ''Viernes'',',
'                 ''SA'',',
'                 ''Sabado'',',
'                 ''DO'',',
'                 ''Domingo'')',
'            dia_tramite,',
'         DECODE (a.cli_asignacion_vendedor,',
'                 ''A'',',
'                 ''Asignado'',',
'                 ''D'',',
'                 ''Directo'')',
'            tipo_vendedor,',
'         DECODE (a.cli_acepta_cheques,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            acepta_cheques,',
'         DECODE (a.cli_valida_cedula,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            valida_cedula,',
'         DECODE (a.cli_filial,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            filial,',
'         a.cli_limite_credito limite_credito,',
'         DECODE (a.cli_control_credito,',
'                 ''C'',',
'                 ''Control por Cliente'',',
'                 ''D'',',
'                 ''Control por Departamento'')',
'            control_credito,',
'         a.cli_plazo plazo,',
'         a.cli_porcentaje_max_descuento porcentaje_max_descuento, ',
'         DECODE (a.cli_retencion,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            retencion,',
'         DECODE (a.cli_impuesto,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            impuesto,',
'         DECODE (a.cli_es_corporativo,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            corporativo,',
'         DECODE (a.cli_es_pagador,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            pagador,',
'         DECODE (a.cli_valida_corporacion,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            valida_corporacion,',
'         DECODE (a.cli_descuento_aparte,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            descuento_aparte,',
'         DECODE (a.cli_orden_compra,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            orden_compra,',
'         DECODE (a.cli_ind_nombre,',
'                 ''N'',',
'                 ''Nunca'',',
'                 ''U'',',
'                 ''Una Vez'',',
'                 ''S'',',
'                 ''Siempre'')',
'            cambiar_nombre,',
'         gnl_nombre_persona_v_nx (a.cli_per_persona_banco) banco,',
'         a.cli_cuenta_banco cuenta_banco,',
'         a.cli_cuenta_sinpe cuenta_sinpe,',
'         DECODE (a.cli_tipo_cuenta_banco,',
'                 1,',
'                 ''Cuenta Corriente'',',
'                 2,',
'                 ''Cuenta de Ahorros'')',
'            tipo_cuenta,',
'         gnl_nombre_vendedor_vi (a.cli_emp_empresa, a.cli_ven_vendedor)',
'            vendedor,',
'         cxc_nombre_cli_v_nx (a.cli_cli_emp_empresa,',
'                              a.cli_cli_cliente,',
'                              a.cli_cli_mon_moneda)',
'            cliente,',
'         H.DIRECCION,H.TELEFONO1,H.TELEFONO2,H.TELEFONO3 , ',
'         gnl_pais_persona_v_nx(h.persona) pais_persona,',
'         gnl_ciudad_persona_v_nx(h.persona) ciudad_persona,',
'         gnl_descripcion_zona_v_nx(h.zon_zona) zona_persona,',
'         (SELECT pro_nombre ',
'         FROM gnl_provincia_tb_nx b',
'         WHERE b.pro_id = h.per_pro_provincia) provincia_persona,',
'         cli_cliente codigo_cliente,',
'         cli_mon_moneda moneda_cliente,',
'         cli_tcl_tipo tipo_cliente,',
'cli_cob_codigo,',
'cxc_nombre_cobrador_v_nx(',
'cli_emp_empresa,',
'    cli_cob_codigo',
') nombre_cobrador,',
'cli_cpg_condicion_tiene1,',
'cli_cpg_condicion_tiene2,',
'cli_cpg_condicion_tiene3,',
'cli_cpg_condicion_tiene4,',
'cli_cli_emp_empresa empresa_cliente_referencia,',
'cli_cli_mon_moneda moneda_cliente_referencia,',
'cli_tasa_interes tasa_interes,',
'cli_tasa_redescuento tasa_redescuento,',
'cli_tasa_deposito tasa_deposito,',
'cli_dias_periodo_gracia periodo_gracia,',
'cli_dias_fin_mora fin_mora,',
'cli_dias_recordatorio_pago recordatorio_pago,',
'CLI_SALDO_FINANCIACION saldo_financiacion,',
'CLI_SALDO_CUENTA_CORRIENTE saldo_cuenta_cliente,',
'CLI_SALDO_ANTICIPO_RESERVACION saldo_anticipo_reservacion,',
'CLI_SALDO_EFECTOS saldo_efectos,',
'CLI_OBSERVACION observacion,',
'CLI_CREADO_POR creado_por,',
'CLI_MODIFICADO_POR modificado_por,',
'CLI_FECHA_MODIFICACION fecha_modificacion,',
'CLI_USERNAME usuario_cliente,',
'CLI_PER_PERSONA_BANCO persona_banco,',
'CLI_DIAS_MIN_INT_DESC,',
'CLI_PORCENTAJE_EXONERACION porcentaje_exoneracion,',
'CLI_UBN_UBICACION ubicacion,',
'CLI_NOM_ALTERNO nombre_alterno, ',
'CLI_DESCUENTO_SDI descuento_sdi,',
'CLI_PMAT_MENOR_M pmat_menor_m,',
'CLI_PMAT_MENOR_P pmat_menor_o,',
'CLI_PRECIO_HM precio_hm,',
'CLI_PRECIO_HP precio_hp,',
'CLI_PORC_REDU_TIEMPO_REAL_M,',
'CLI_PORC_REDU_TIEMPO_REAL_P,',
'CLI_LPO_LISTA lista_precios,',
'inv_descrip_lista_v_nx(',
'    cli_emp_empresa,',
'    cli_lpo_lista',
') descripcion_lista, ',
'         DECODE (a.CLI_IND_FINANCIAMIENTO,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'') indicado_financiamiento,',
'case WHEN CLI_TIPO_EXONERACION =  ''01'' THEN',
'''Compras autorizadas'' ',
'WHEN cli_tipo_exoneracion = ''02'' THEN',
'''Ventas exentas a diplomaticos''',
'WHEN cli_tipo_exoneracion = ''03'' THEN',
'''Orden de compra (Instituciones Publicas)''',
'WHEN cli_tipo_exoneracion = ''04'' THEN',
'''Exenciones Direccion General de Hacienda'' ',
'WHEN cli_tipo_exoneracion = ''05'' THEN',
'''Zonas Francas''',
'WHEN cli_tipo_exoneracion = ''99'' THEN',
'''Otros''',
'END tipo_exoneracion,',
'CLI_NUMERO_EXONERACION numero_exoneracion,',
'CLI_INICIO_EXONERACION inicio_exoneracion,',
'CLI_FINAL_EXONERACION final_exoneracion,',
'CLI_INSTITUCION_EXONERACION institucion_exoneracion, ',
'         DECODE (a.CLI_FAC_ENTRE_EMPRESAS,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'') factura_entre_empresas,',
'CLI_REPORTE reporte,',
'CLI_BGR_ID_GRAV id_gravable,',
'gnl_nom_base_grav_v_nx (',
'cli_emp_empresa,',
'    CLI_BGR_ID_GRAV',
') nombre_gravamen',
'  FROM   cxc_cliente_tb_nx a, GNL_PERSONA_TR_NX h',
' WHERE   INSTR ('':'' || :p62_empresa || '':'', '':'' || a.cli_emp_empresa || '':'') >',
'            0',
'   AND   H.PERSONA = a.cli_per_persona'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P62_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14112696155352853174)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>11904904661064563
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112696279114853181)
,p_db_column_name=>'MONEDA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112696979566853185)
,p_db_column_name=>'NOMBRE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112697155529853185)
,p_db_column_name=>'CLASE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
,p_static_id=>'CLASE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112697478376853185)
,p_db_column_name=>'BANCO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_static_id=>'BANCO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112697669305853186)
,p_db_column_name=>'IMPUESTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Impuesto'
,p_column_type=>'STRING'
,p_static_id=>'IMPUESTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112697783313853186)
,p_db_column_name=>'RETENCION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Retencion'
,p_column_type=>'STRING'
,p_static_id=>'RETENCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112697873351853186)
,p_db_column_name=>'DIA_PAGO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Dia Pago'
,p_column_type=>'STRING'
,p_static_id=>'DIA_PAGO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112697971722853186)
,p_db_column_name=>'PLAZO'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Plazo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PLAZO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112698169614853187)
,p_db_column_name=>'LIMITE_CREDITO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Limite Credito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'LIMITE_CREDITO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112698970608853188)
,p_db_column_name=>'FILIAL'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Filial'
,p_column_type=>'STRING'
,p_static_id=>'FILIAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112696669056853184)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112701575573894595)
,p_db_column_name=>'CREDITO_CONTADO'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Credito Contado'
,p_column_type=>'STRING'
,p_static_id=>'CREDITO_CONTADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112701661036894601)
,p_db_column_name=>'ESTADO'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_static_id=>'ESTADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112701753268894601)
,p_db_column_name=>'DIA_TRAMITE'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Dia Tramite'
,p_column_type=>'STRING'
,p_static_id=>'DIA_TRAMITE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112701868401894601)
,p_db_column_name=>'TIPO_VENDEDOR'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Tipo Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'TIPO_VENDEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112701976730894602)
,p_db_column_name=>'ACEPTA_CHEQUES'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Acepta Cheques'
,p_column_type=>'STRING'
,p_static_id=>'ACEPTA_CHEQUES'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702058837894602)
,p_db_column_name=>'VALIDA_CEDULA'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Valida Cedula'
,p_column_type=>'STRING'
,p_static_id=>'VALIDA_CEDULA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702175740894602)
,p_db_column_name=>'CONTROL_CREDITO'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Control Credito'
,p_column_type=>'STRING'
,p_static_id=>'CONTROL_CREDITO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702259781894602)
,p_db_column_name=>'PORCENTAJE_MAX_DESCUENTO'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Porcentaje Max Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PORCENTAJE_MAX_DESCUENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702363436894602)
,p_db_column_name=>'DESCUENTO_SDI'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Descuento Sdi'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DESCUENTO_SDI'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702452906894603)
,p_db_column_name=>'CORPORATIVO'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Corporativo'
,p_column_type=>'STRING'
,p_static_id=>'CORPORATIVO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702575939894603)
,p_db_column_name=>'PAGADOR'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Pagador'
,p_column_type=>'STRING'
,p_static_id=>'PAGADOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702660740894603)
,p_db_column_name=>'VALIDA_CORPORACION'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Valida Corporacion'
,p_column_type=>'STRING'
,p_static_id=>'VALIDA_CORPORACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702777842894603)
,p_db_column_name=>'DESCUENTO_APARTE'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Descuento Aparte'
,p_column_type=>'STRING'
,p_static_id=>'DESCUENTO_APARTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702869366894603)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_static_id=>'ORDEN_COMPRA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112702973716894603)
,p_db_column_name=>'CAMBIAR_NOMBRE'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Cambiar Nombre'
,p_column_type=>'STRING'
,p_static_id=>'CAMBIAR_NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112703252319894604)
,p_db_column_name=>'TIPO_CUENTA'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Tipo Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'TIPO_CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112703368816894604)
,p_db_column_name=>'VENDEDOR'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'VENDEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112703475274894604)
,p_db_column_name=>'CLIENTE'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112875575816757303)
,p_db_column_name=>'PERSONA'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PERSONA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112875667720757362)
,p_db_column_name=>'CODIGO'
,p_display_order=>52
,p_column_identifier=>'AZ'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
,p_static_id=>'CODIGO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112875765437757362)
,p_db_column_name=>'CUENTA_BANCO'
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>'Cuenta Banco'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA_BANCO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112875881090757362)
,p_db_column_name=>'CUENTA_SINPE'
,p_display_order=>54
,p_column_identifier=>'BB'
,p_column_label=>'Cuenta Sinpe'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA_SINPE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098965520901251904)
,p_db_column_name=>'EMPRESA'
,p_display_order=>64
,p_column_identifier=>'BC'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086273947712786967)
,p_db_column_name=>'DIRECCION'
,p_display_order=>74
,p_column_identifier=>'BD'
,p_column_label=>'Direccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086274128990786968)
,p_db_column_name=>'TELEFONO1'
,p_display_order=>84
,p_column_identifier=>'BE'
,p_column_label=>'Telefono1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086274143059786969)
,p_db_column_name=>'TELEFONO2'
,p_display_order=>94
,p_column_identifier=>'BF'
,p_column_label=>'Telefono2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086274280637786970)
,p_db_column_name=>'TELEFONO3'
,p_display_order=>104
,p_column_identifier=>'BG'
,p_column_label=>'Telefono3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058209610769913593)
,p_db_column_name=>'PAIS_PERSONA'
,p_display_order=>114
,p_column_identifier=>'BH'
,p_column_label=>'Pais Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058209779908913594)
,p_db_column_name=>'CIUDAD_PERSONA'
,p_display_order=>124
,p_column_identifier=>'BI'
,p_column_label=>'Ciudad Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058209828297913595)
,p_db_column_name=>'ZONA_PERSONA'
,p_display_order=>134
,p_column_identifier=>'BJ'
,p_column_label=>'Zona Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14051157856436635453)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>144
,p_column_identifier=>'BL'
,p_column_label=>'Fecha Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001216720860589481)
,p_db_column_name=>'PROVINCIA_PERSONA'
,p_display_order=>154
,p_column_identifier=>'BM'
,p_column_label=>'Provincia Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958105847371942806)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>164
,p_column_identifier=>'BN'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958105927679942807)
,p_db_column_name=>'MONEDA_CLIENTE'
,p_display_order=>174
,p_column_identifier=>'BO'
,p_column_label=>'Moneda Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958106006474942808)
,p_db_column_name=>'TIPO_CLIENTE'
,p_display_order=>184
,p_column_identifier=>'BP'
,p_column_label=>'Tipo Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958106124383942809)
,p_db_column_name=>'CLI_COB_CODIGO'
,p_display_order=>194
,p_column_identifier=>'BQ'
,p_column_label=>'Cli Cob Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958106333683942811)
,p_db_column_name=>'CLI_CPG_CONDICION_TIENE1'
,p_display_order=>214
,p_column_identifier=>'BS'
,p_column_label=>'Cli Cpg Condicion Tiene1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958106378319942812)
,p_db_column_name=>'CLI_CPG_CONDICION_TIENE2'
,p_display_order=>224
,p_column_identifier=>'BT'
,p_column_label=>'Cli Cpg Condicion Tiene2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958106530823942813)
,p_db_column_name=>'CLI_CPG_CONDICION_TIENE3'
,p_display_order=>234
,p_column_identifier=>'BU'
,p_column_label=>'Cli Cpg Condicion Tiene3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958106618000942814)
,p_db_column_name=>'CLI_CPG_CONDICION_TIENE4'
,p_display_order=>244
,p_column_identifier=>'BV'
,p_column_label=>'Cli Cpg Condicion Tiene4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958106950006942817)
,p_db_column_name=>'TASA_INTERES'
,p_display_order=>274
,p_column_identifier=>'BY'
,p_column_label=>'Tasa Interes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958107002724942818)
,p_db_column_name=>'TASA_REDESCUENTO'
,p_display_order=>284
,p_column_identifier=>'BZ'
,p_column_label=>'Tasa Redescuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958107129931942819)
,p_db_column_name=>'TASA_DEPOSITO'
,p_display_order=>294
,p_column_identifier=>'CA'
,p_column_label=>'Tasa Deposito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958107240467942820)
,p_db_column_name=>'PERIODO_GRACIA'
,p_display_order=>304
,p_column_identifier=>'CB'
,p_column_label=>'Periodo Gracia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958107325466942821)
,p_db_column_name=>'FIN_MORA'
,p_display_order=>314
,p_column_identifier=>'CC'
,p_column_label=>'Fin Mora'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958107367338942822)
,p_db_column_name=>'RECORDATORIO_PAGO'
,p_display_order=>324
,p_column_identifier=>'CD'
,p_column_label=>'Recordatorio Pago'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958107564912942823)
,p_db_column_name=>'SALDO_FINANCIACION'
,p_display_order=>334
,p_column_identifier=>'CE'
,p_column_label=>'Saldo Financiacion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962064596279078176)
,p_db_column_name=>'SALDO_EFECTOS'
,p_display_order=>364
,p_column_identifier=>'CH'
,p_column_label=>'Saldo Efectos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962064696861078177)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>374
,p_column_identifier=>'CI'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962064791494078178)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>384
,p_column_identifier=>'CJ'
,p_column_label=>'Creado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962064953916078179)
,p_db_column_name=>'MODIFICADO_POR'
,p_display_order=>394
,p_column_identifier=>'CK'
,p_column_label=>'Modificado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962064966593078180)
,p_db_column_name=>'FECHA_MODIFICACION'
,p_display_order=>404
,p_column_identifier=>'CL'
,p_column_label=>'Fecha Modificacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962065150306078181)
,p_db_column_name=>'USUARIO_CLIENTE'
,p_display_order=>414
,p_column_identifier=>'CM'
,p_column_label=>'Usuario Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962065475448078185)
,p_db_column_name=>'CLI_DIAS_MIN_INT_DESC'
,p_display_order=>454
,p_column_identifier=>'CQ'
,p_column_label=>'Cli Dias Min Int Desc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962066788954078198)
,p_db_column_name=>'CLI_PORC_REDU_TIEMPO_REAL_M'
,p_display_order=>584
,p_column_identifier=>'DD'
,p_column_label=>'Cli Porc Redu Tiempo Real M'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962066909478078199)
,p_db_column_name=>'CLI_PORC_REDU_TIEMPO_REAL_P'
,p_display_order=>594
,p_column_identifier=>'DE'
,p_column_label=>'Cli Porc Redu Tiempo Real P'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962066981249078200)
,p_db_column_name=>'LISTA_PRECIOS'
,p_display_order=>604
,p_column_identifier=>'DF'
,p_column_label=>'Lista Precios'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962067612276078206)
,p_db_column_name=>'INSTITUCION_EXONERACION'
,p_display_order=>664
,p_column_identifier=>'DL'
,p_column_label=>'Institucion Exoneracion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962067955938078209)
,p_db_column_name=>'ID_GRAVABLE'
,p_display_order=>694
,p_column_identifier=>'DO'
,p_column_label=>'Id Gravable'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068062183078210)
,p_db_column_name=>'DESCRIPCION_LISTA'
,p_display_order=>704
,p_column_identifier=>'DP'
,p_column_label=>'Descripcion Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068154641078211)
,p_db_column_name=>'INDICADO_FINANCIAMIENTO'
,p_display_order=>714
,p_column_identifier=>'DQ'
,p_column_label=>'Indicado Financiamiento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068236575078212)
,p_db_column_name=>'TIPO_EXONERACION'
,p_display_order=>724
,p_column_identifier=>'DR'
,p_column_label=>'Tipo Exoneracion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068319784078213)
,p_db_column_name=>'FACTURA_ENTRE_EMPRESAS'
,p_display_order=>734
,p_column_identifier=>'DS'
,p_column_label=>'Factura Entre Empresas'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068394315078214)
,p_db_column_name=>'NOMBRE_GRAVAMEN'
,p_display_order=>744
,p_column_identifier=>'DT'
,p_column_label=>'Nombre Gravamen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068548182078215)
,p_db_column_name=>'NOMBRE_COBRADOR'
,p_display_order=>754
,p_column_identifier=>'DU'
,p_column_label=>'Nombre Cobrador'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068643221078216)
,p_db_column_name=>'EMPRESA_CLIENTE_REFERENCIA'
,p_display_order=>764
,p_column_identifier=>'DV'
,p_column_label=>'Empresa Cliente Referencia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068734043078217)
,p_db_column_name=>'MONEDA_CLIENTE_REFERENCIA'
,p_display_order=>774
,p_column_identifier=>'DW'
,p_column_label=>'Moneda Cliente Referencia'
,p_column_type=>'STRING'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962068774712078218)
,p_db_column_name=>'PERSONA_BANCO'
,p_display_order=>784
,p_column_identifier=>'DX'
,p_column_label=>'Persona Banco'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962069038423078220)
,p_db_column_name=>'PORCENTAJE_EXONERACION'
,p_display_order=>804
,p_column_identifier=>'DZ'
,p_column_label=>'Porcentaje Exoneracion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962069145325078221)
,p_db_column_name=>'UBICACION'
,p_display_order=>814
,p_column_identifier=>'EA'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962069203490078222)
,p_db_column_name=>'NOMBRE_ALTERNO'
,p_display_order=>824
,p_column_identifier=>'EB'
,p_column_label=>'Nombre Alterno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962069300783078223)
,p_db_column_name=>'PMAT_MENOR_M'
,p_display_order=>834
,p_column_identifier=>'EC'
,p_column_label=>'Pmat Menor M'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962069422223078224)
,p_db_column_name=>'PMAT_MENOR_O'
,p_display_order=>844
,p_column_identifier=>'ED'
,p_column_label=>'Pmat Menor O'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962069556239078225)
,p_db_column_name=>'PRECIO_HM'
,p_display_order=>854
,p_column_identifier=>'EE'
,p_column_label=>'Precio Hm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962108191572317676)
,p_db_column_name=>'PRECIO_HP'
,p_display_order=>864
,p_column_identifier=>'EF'
,p_column_label=>'Precio Hp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962108283175317677)
,p_db_column_name=>'REPORTE'
,p_display_order=>874
,p_column_identifier=>'EG'
,p_column_label=>'Reporte'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962108419475317678)
,p_db_column_name=>'NUMERO_EXONERACION'
,p_display_order=>884
,p_column_identifier=>'EH'
,p_column_label=>'Numero Exoneracion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962108488031317679)
,p_db_column_name=>'INICIO_EXONERACION'
,p_display_order=>894
,p_column_identifier=>'EI'
,p_column_label=>'Inicio Exoneracion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962108649412317680)
,p_db_column_name=>'FINAL_EXONERACION'
,p_display_order=>904
,p_column_identifier=>'EJ'
,p_column_label=>'Final Exoneracion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962108698358317681)
,p_db_column_name=>'SALDO_CUENTA_CLIENTE'
,p_display_order=>914
,p_column_identifier=>'EK'
,p_column_label=>'Saldo Cuenta Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962108806715317682)
,p_db_column_name=>'SALDO_ANTICIPO_RESERVACION'
,p_display_order=>924
,p_column_identifier=>'EL'
,p_column_label=>'Saldo Anticipo Reservacion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14112699460375853190)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'119083'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'PERSONA:CODIGO:NOMBRE:CLASE:MONEDA:TIPO:CREDITO_CONTADO:ESTADO:DIA_PAGO:DIA_TRAMITE:TIPO_VENDEDOR:ACEPTA_CHEQUES:VALIDA_CEDULA:FILIAL:LIMITE_CREDITO:CONTROL_CREDITO:PLAZO:PORCENTAJE_MAX_DESCUENTO:DESCUENTO_SDI:RETENCION:IMPUESTO:CORPORATIVO:PAGADOR:V'
||'ALIDA_CORPORACION:DESCUENTO_APARTE:ORDEN_COMPRA:CAMBIAR_NOMBRE:BANCO:CUENTA_BANCO:CUENTA_SINPE:TIPO_CUENTA:VENDEDOR:CLIENTE::EMPRESA:DIRECCION:TELEFONO1:TELEFONO2:TELEFONO3:PAIS_PERSONA:CIUDAD_PERSONA:ZONA_PERSONA:FECHA_CREACION:PROVINCIA_PERSONA:COD'
||'IGO_CLIENTE:MONEDA_CLIENTE:TIPO_CLIENTE:CLI_COB_CODIGO:CLI_CPG_CONDICION_TIENE1:CLI_CPG_CONDICION_TIENE2:CLI_CPG_CONDICION_TIENE3:CLI_CPG_CONDICION_TIENE4:TASA_INTERES:TASA_REDESCUENTO:TASA_DEPOSITO:PERIODO_GRACIA:FIN_MORA:RECORDATORIO_PAGO:SALDO_FIN'
||'ANCIACION:CLI_SALDO_EFECTOS:OBSERVACION:CREADO_POR:MODIFICADO_POR:FECHA_MODIFICACION:USUARIO_CLIENTE:CLI_PER_CLI_CLI_CUENTA_SINPE:CLI_DIAS_MIN_INT_DESC:CLI_CLI_UBN_CLI_NOM_ALTERNO:CLI_CLI_PMAT_MENOR_P:CLI_CLI_CLI_PORC_REDU_TIEMPO_REAL_M:CLI_PORC_REDU'
||'_TIEMPO_REAL_P:LISTA_PRECIOS:CLI_CLI_CLI_CLI_INSTITUCION_EXONERACION:CLI_ID_GRAVABLE:DESCRIPCION_LISTA:INDICADO_FINANCIAMIENTO:TIPO_EXONERACION:FACTURA_ENTRE_EMPRESAS:NOMBRE_GRAVAMEN:NOMBRE_COBRADOR:EMPRESA_CLIENTE_REFERENCIA:MONEDA_CLIENTE_REFERENCI'
||'A:PERSONA_BANCO:PORCENTAJE_EXONERACION:UBICACION:NOMBRE_ALTERNO:PMAT_MENOR_M:PMAT_MENOR_O:PRECIO_HM:PRECIO_HP:REPORTE:NUMERO_EXONERACION:INICIO_EXONERACION:FINAL_EXONERACION:SALDO_CUENTA_CLIENTE:SALDO_ANTICIPO_RESERVACION'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14112699860023853208)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14112699673973853204)
,p_button_name=>'P62_CONSULTAR'
,p_button_static_id=>'P62_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112700078890853213)
,p_name=>'P62_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14112699673973853204)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
