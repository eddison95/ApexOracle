prompt --application/pages/page_00065
begin
--   Manifest
--     PAGE: 00065
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>65
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CXC - Antiguedad de Saldos'
,p_step_title=>'Antiguedad de Saldos'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201213184653'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14113068160830326677)
,p_plug_name=>'Antiguedad de Saldos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14113066180348326580)
,p_plug_name=>'Antiguedad de Saldos'
,p_region_name=>'Antiguedad de Saldos'
,p_parent_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   trx_emp_empresa empresa,',
'         trx_transaccion transaccion,',
'         trx_ttc_tipo tipo_transaccion,',
'         ttc_descripcion desc_tipo_trans,',
'         (SELECT   (tra_ord_orden)',
'            FROM   fac_factura_tb_nx',
'           WHERE   tra_transaccion = trx_tra_transaccion)',
'            orden_taller,',
'         trx_documento documento,',
'         trx_detalle_documento detalle_documento,',
'         trx_cli_cliente cliente,',
'         trx_cli_mon_moneda moneda,',
'         cxc_nombre_cli_v_nx (trx_emp_empresa,',
'                              trx_cli_cliente,',
'                              trx_cli_mon_moneda)',
'            nombre,',
'         cxc_clase_cli_v_nx (trx_emp_empresa,',
'                             trx_cli_cliente,',
'                             trx_cli_mon_moneda)',
'            clase,',
'         cxc_descrip_clase_v_nx (',
'            trx_emp_empresa,',
'            cxc_clase_cli_v_nx (trx_emp_empresa,',
'                                trx_cli_cliente,',
'                                trx_cli_mon_moneda)',
'         )',
'            desc_clase,',
'         gnl_cedula_persona_v_nx(cxc_persona_cli_n_nx (trx_emp_empresa,',
'                                                       trx_cli_cliente,',
'                                                       trx_cli_mon_moneda))',
'            cli_cedula,',
'         trx_dep_departamento departamento,',
'         cgl_nombre_depto_v_nx (trx_emp_empresa, trx_dep_departamento)',
'            desc_departamento,',
'         fac_seg_cliente_v_nx (trx_emp_empresa,',
'                               trx_cli_cliente,',
'                               trx_cli_mon_moneda)',
'            segmento_cliente,',
'         fac_descrip_seg_v_nx(fac_seg_cliente_v_nx (trx_emp_empresa,',
'                                                    trx_cli_cliente,',
'                                                    trx_cli_mon_moneda))',
'            desc_segmento,',
'         TRUNC (trx_fecha_transaccion) fecha_transaccion,',
'         TRUNC (trx_fecha_vencimiento) fecha_vencimiento,',
'         ttc_signo signo,',
'         trx_monto monto,',
'         cxc_saldo_fecha_n_nx (trx_transaccion, :p65_fin) saldo,',
'         trx_plazo plazo,',
'         (SELECT   tra_ven_vendedor',
'            FROM   fac_factura_tb_nx',
'           WHERE   tra_emp_empresa = trx_emp_empresa',
'                   AND tra_transaccion = trx_tra_transaccion)',
'            cod_vend,',
'         gnl_nombre_vendedor_vi (',
'            trx_emp_empresa,',
'            (SELECT   tra_ven_vendedor',
'               FROM   fac_factura_tb_nx',
'              WHERE   tra_emp_empresa = trx_emp_empresa',
'                      AND tra_transaccion = trx_tra_transaccion)',
'         )',
'            nombre_vend,',
'         (SELECT   frs_cli_cliente',
'            FROM   fac_reserva_tb_nx, fac_factura_tb_nx',
'           WHERE   frs_reserva = tra_frs_reserva',
'                   AND tra_transaccion = trx_tra_transaccion)',
'            cliente_reserva,',
'         (SELECT   gnl_cedula_persona_v_nx(cxc_persona_cli_n_nx (',
'                                              frs_emp_empresa,',
'                                              frs_cli_cliente,',
'                                              frs_cli_mon_moneda',
'                                           ))',
'                      frs_cedula',
'            FROM   fac_reserva_tb_nx, fac_factura_tb_nx',
'           WHERE   frs_reserva = tra_frs_reserva',
'                   AND tra_transaccion = trx_tra_transaccion)',
'            cedula_cli_reserva,',
'         (SELECT   frs_nombre',
'            FROM   fac_reserva_tb_nx, fac_factura_tb_nx',
'           WHERE   frs_reserva = tra_frs_reserva',
'                   AND tra_transaccion = trx_tra_transaccion)',
'            nombre_cli_reserva,',
'         trx_tipo_cuenta,',
'         DECODE (trx_tipo_cuenta,',
'                 ''C'',',
'                 ''Cuenta Corriente'',',
'                 ''A'',',
'                 ''Anticipo o Reservacion'',',
'                 ''E'',',
'                 ''Efectos por Cobrar o Pagar'',',
'                 ''D'',',
'                 ''Factoreo (Descuento Facturas)'',',
'                 ''G'',',
unistr('                 ''Garant\00EDas'')'),
'            tipo_cuenta,',
'         (SELECT   GRE_GRUPO_CUENTA GRUPO_CUENTA',
'            FROM   CXC_ENC_GRUPO_CUENTA_TB_NX',
'           WHERE   GRE_EMP_EMPRESA = trx_emp_empresa',
'                   AND GRE_ID IN',
'                            (SELECT   GRC_GRE_ID FROM CXC_GRUPO_CUENTA_TB_NX))',
'            grupo_cuenta,',
'         (SELECT   GRE_DESCRIPCION GRC_DESCRIPCION',
'            FROM   CXC_ENC_GRUPO_CUENTA_TB_NX',
'           WHERE   GRE_EMP_EMPRESA = trx_emp_empresa',
'                   AND GRE_ID IN',
'                            (SELECT   GRC_GRE_ID FROM CXC_GRUPO_CUENTA_TB_NX))',
'            desc_grupo_cuenta,',
'         (SELECT   TRA_NOMBRE',
'            FROM   FAC_FACTURA_TB_NX',
'           WHERE   TRA_TRANSACCION = TRX_TRA_TRANSACCION)',
'            tra_nombre,',
'cxc_cobrador_cli_v_nx (',
'  trx_emp_Empresa',
' ,trx_cli_cliente',
' ,trx_cli_mon_moneda',
' ,trx_dep_departamento',
') cobrador,',
'cxc_nombre_cobrador_v_nx (trx_emp_Empresa,												 cxc_cobrador_cli_v_nx (',
'  trx_emp_Empresa',
' ,trx_cli_cliente',
' ,trx_cli_mon_moneda',
' ,trx_dep_departamento',
')) nombre_cobrador',
'  FROM   cxc_transaccion_tb_nx, cxc_tipo_transaccion_tb_nx',
' WHERE       INSTR ('':'' || :p65_empresa || '':'',',
'                    '':'' || trx_emp_empresa || '':'') > 0',
'         AND cxc_es_trx_padre_v_nx (trx_emp_empresa, trx_transaccion) = ''S''',
'         AND trx_status <> ''E''',
'         AND ttc_emp_empresa = trx_emp_empresa',
'         AND ttc_tipo = trx_ttc_tipo',
'         AND ttc_signo <> ''N''',
'         AND trx_tipo_cuenta <> ''F''',
'         AND trx_fecha_transaccion BETWEEN :p65_inicio',
'                                       AND  TO_DATE (:p65_fin || '' 23:59'',',
'                                                     ''dd/mm/rrrr hh24:mi'')',
'         AND trx_cli_mon_moneda = :P65_MONEDA',
'         AND trx_cli_cliente = NVL (:P65_CLIENTE, trx_cli_cliente)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P65_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14113066380868326588)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>12275130176537977
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14113076054406361331)
,p_db_column_name=>'NOMBRE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097416101463365612)
,p_db_column_name=>'CLASE'
,p_display_order=>26
,p_column_identifier=>'Q'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097477840814436400)
,p_db_column_name=>'EMPRESA'
,p_display_order=>36
,p_column_identifier=>'AI'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097477938919436401)
,p_db_column_name=>'TRANSACCION'
,p_display_order=>46
,p_column_identifier=>'AJ'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478188106436403)
,p_db_column_name=>'ORDEN_TALLER'
,p_display_order=>66
,p_column_identifier=>'AL'
,p_column_label=>'Orden taller'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478242829436404)
,p_db_column_name=>'CLIENTE'
,p_display_order=>76
,p_column_identifier=>'AM'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478399779436405)
,p_db_column_name=>'MONEDA'
,p_display_order=>86
,p_column_identifier=>'AN'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478442662436406)
,p_db_column_name=>'DETALLE_DOCUMENTO'
,p_display_order=>96
,p_column_identifier=>'AO'
,p_column_label=>'Num. Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478576035436407)
,p_db_column_name=>'FECHA_TRANSACCION'
,p_display_order=>106
,p_column_identifier=>'AP'
,p_column_label=>'Fecha transaccion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478651119436408)
,p_db_column_name=>'FECHA_VENCIMIENTO'
,p_display_order=>116
,p_column_identifier=>'AQ'
,p_column_label=>'Fecha vencimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478824082436409)
,p_db_column_name=>'SIGNO'
,p_display_order=>126
,p_column_identifier=>'AR'
,p_column_label=>'Signo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478867976436410)
,p_db_column_name=>'MONTO'
,p_display_order=>136
,p_column_identifier=>'AS'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097478925046436411)
,p_db_column_name=>'SALDO'
,p_display_order=>146
,p_column_identifier=>'AT'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097479088271436412)
,p_db_column_name=>'PLAZO'
,p_display_order=>156
,p_column_identifier=>'AU'
,p_column_label=>'Plazo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899078098642698)
,p_db_column_name=>'TIPO_TRANSACCION'
,p_display_order=>166
,p_column_identifier=>'AV'
,p_column_label=>'T. Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899130743642699)
,p_db_column_name=>'DESC_TIPO_TRANS'
,p_display_order=>176
,p_column_identifier=>'AW'
,p_column_label=>'Desc. T. Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899306535642700)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>186
,p_column_identifier=>'AX'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899382582642701)
,p_db_column_name=>'DESC_CLASE'
,p_display_order=>196
,p_column_identifier=>'AY'
,p_column_label=>'Desc. Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899452671642702)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>206
,p_column_identifier=>'AZ'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899558713642703)
,p_db_column_name=>'DESC_DEPARTAMENTO'
,p_display_order=>216
,p_column_identifier=>'BA'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899682475642704)
,p_db_column_name=>'SEGMENTO_CLIENTE'
,p_display_order=>226
,p_column_identifier=>'BB'
,p_column_label=>'Segmento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899742847642705)
,p_db_column_name=>'DESC_SEGMENTO'
,p_display_order=>236
,p_column_identifier=>'BC'
,p_column_label=>'Desc. Segmento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314857819873804)
,p_db_column_name=>'COD_VEND'
,p_display_order=>256
,p_column_identifier=>'BE'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314959707873805)
,p_db_column_name=>'NOMBRE_VEND'
,p_display_order=>266
,p_column_identifier=>'BF'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099379973684841219)
,p_db_column_name=>'CLI_CEDULA'
,p_display_order=>276
,p_column_identifier=>'BG'
,p_column_label=>'Cedula Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099380054769841220)
,p_db_column_name=>'CLIENTE_RESERVA'
,p_display_order=>286
,p_column_identifier=>'BH'
,p_column_label=>'Cliente Reserva'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099380127306841221)
,p_db_column_name=>'CEDULA_CLI_RESERVA'
,p_display_order=>296
,p_column_identifier=>'BI'
,p_column_label=>'Cedula Cliente Reserva'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099380252572841222)
,p_db_column_name=>'NOMBRE_CLI_RESERVA'
,p_display_order=>306
,p_column_identifier=>'BJ'
,p_column_label=>'Nombre Cliente Reserva'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099380325997841223)
,p_db_column_name=>'TIPO_CUENTA'
,p_display_order=>316
,p_column_identifier=>'BK'
,p_column_label=>'Desc. Tipo Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099380493318841224)
,p_db_column_name=>'GRUPO_CUENTA'
,p_display_order=>326
,p_column_identifier=>'BL'
,p_column_label=>'Grupo Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099380527083841225)
,p_db_column_name=>'DESC_GRUPO_CUENTA'
,p_display_order=>336
,p_column_identifier=>'BM'
,p_column_label=>'Desc. Grupo Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099380632976841226)
,p_db_column_name=>'TRX_TIPO_CUENTA'
,p_display_order=>346
,p_column_identifier=>'BN'
,p_column_label=>'Tipo Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099380861709841228)
,p_db_column_name=>'TRA_NOMBRE'
,p_display_order=>366
,p_column_identifier=>'BP'
,p_column_label=>'Nombre Factura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086273572571786963)
,p_db_column_name=>'COBRADOR'
,p_display_order=>376
,p_column_identifier=>'BQ'
,p_column_label=>'Cobrador'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086273641665786964)
,p_db_column_name=>'NOMBRE_COBRADOR'
,p_display_order=>386
,p_column_identifier=>'BR'
,p_column_label=>'Nombre cobrador'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14113067956624326661)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'122768'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:TRANSACCION:TIPO_TRANSACCION:COD_VEND:NOMBRE_VEND:DESC_TIPO_TRANS:DOCUMENTO:DETALLE_DOCUMENTO:FECHA_TRANSACCION:FECHA_VENCIMIENTO:ORDEN_TALLER:SIGNO:MONEDA:NOMBRE:CLI_CEDULA:CLIENTE:CLASE:DESC_CLASE:TRA_NOMBRE:DEPARTAMENTO:DESC_DEPARTAMENTO:S'
||'EGMENTO_CLIENTE:DESC_SEGMENTO:MONTO:SALDO:PLAZO:CLIENTE_RESERVA:NOMBRE_CLI_RESERVA:CEDULA_CLI_RESERVA:TRX_TIPO_CUENTA:TIPO_CUENTA:GRUPO_CUENTA:DESC_GRUPO_CUENTA:COBRADOR:NOMBRE_COBRADOR'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14113069777810326687)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_button_name=>'CONSULTAR'
,p_button_static_id=>'65_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113068358324326681)
,p_name=>'P65_MONEDA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT NOMBRE ||''(''||MONEDA||'')'' as d, moneda as r from gnl_moneda_tr_nx'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113068565627326685)
,p_name=>'P65_SALDO_INICIAL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saldo Inicial'
,p_source=>'return to_char(cxc_saldo_cliente_n_nx (:P65_EMPRESA, :P65_CLIENTE, :P65_MONEDA, TO_DATE(:P65_INICIO) - 1), ''999G999G999G990D00'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P65_CLIENTE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113068757749326686)
,p_name=>'P65_CLIENTE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CLI_CLIENTE ||'' - ''|| CXC_NOMBRE_CLI_V_NX(CLI_EMP_EMPRESA, CLI_CLIENTE, CLI_MON_MONEDA), ',
'CLI_CLIENTE FROM CXC_CLIENTE_TB_NX',
'WHERE CLI_EMP_EMPRESA = :P65_EMPRESA',
'AND CLI_MON_MONEDA = :P65_MONEDA',
'ORDER BY CLI_CLIENTE'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P65_MONEDA'
,p_ajax_items_to_submit=>'P65_EMPRESA,P65_MONEDA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113068952775326686)
,p_name=>'P65_SALDO_FINAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saldo Final'
,p_source=>'return to_char(cxc_saldo_cliente_n_nx (:P65_EMPRESA, :P65_CLIENTE, :P65_MONEDA, :P65_FIN), ''999G999G999G990D00'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P65_CLIENTE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113069178380326687)
,p_name=>'P65_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113069360337326687)
,p_name=>'P65_INICIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113069567254326687)
,p_name=>'P65_FIN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14113068160830326677)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966308461976995403)
,p_validation_name=>'MONEDA_EMPRESA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P65_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P65_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P65_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P65_EMPRESA,''[^:]+'', 1, level) is not null;',
'             ',
'IF (cantidad_local_v > 1 AND :P65_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
'',
'IF (cantidad_alt_v > 1 AND :P65_MONEDA = ''A'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
'',
' ',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_api.id(14113069777810326687)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
