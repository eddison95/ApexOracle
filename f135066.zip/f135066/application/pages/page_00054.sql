prompt --application/pages/page_00054
begin
--   Manifest
--     PAGE: 00054
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>54
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('COM \2013 Detalle de Entregas')
,p_step_title=>'Detalle de Entregas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170301'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094645641710986144)
,p_plug_name=>'Detalle de Entregas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094647937155986209)
,p_plug_name=>'Detalle de Entregas'
,p_parent_plug_id=>wwv_flow_api.id(14094645641710986144)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 15/02/2017 03:22:09 p.m. (QP5 v5.115.810.9015) */',
'SELECT   ent_empresa,',
'   ent_fecha,',
'   ent_orden,',
'   ent_codigo,',
'   ent_descripcion,',
'   ent_familia,',
'   ent_solicitada,',
'   ent_recibida,',
'   ent_costo,',
'   ent_descuento,',
'   ent_impuesto,',
'   ent_total,',
'   ent_pro_moneda,',
'   ent_proveedor,',
'   ent_pro_nombre,',
'   ent_entrega,',
'   ent_ttm_tipo,',
'   ent_documento,',
'   ent_numero,',
'   ent_lcg_localizacion,',
'   ent_lcn_localizacion,',
'   ent_recibido_por,',
'   ent_transito_local_itm transito_local_item,',
'   ent_transito_local transito_local,',
'   ent_item,',
'   ent_tipo_cambio valor_de_cambio',
'  FROM   com_detalle_entregas_vw_nx',
' WHERE   INSTR ('':'' || :p54_empresa || '':'', '':'' || ent_empresa || '':'') > 0',
' AND ent_estado IN (''P'',''T'')',
'         AND ent_fecha BETWEEN :p54_inicio',
'                       AND  TO_DATE (:p54_fin || '' 23:59'',',
'                                     ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P54_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14094648394919986215)
,p_name=>'Compras'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>6904670148097121
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082253514765365809)
,p_db_column_name=>'ENT_TTM_TIPO'
,p_display_order=>160
,p_column_identifier=>'AT'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082253884827365812)
,p_db_column_name=>'ENT_LCG_LOCALIZACION'
,p_display_order=>190
,p_column_identifier=>'AW'
,p_column_label=>'Localizacion Gen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082253963478365813)
,p_db_column_name=>'ENT_LCN_LOCALIZACION'
,p_display_order=>200
,p_column_identifier=>'AX'
,p_column_label=>'Localizacion Inv'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082254011688365814)
,p_db_column_name=>'ENT_RECIBIDO_POR'
,p_display_order=>210
,p_column_identifier=>'AY'
,p_column_label=>'Recibido por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086980841929568402)
,p_db_column_name=>'ENT_EMPRESA'
,p_display_order=>220
,p_column_identifier=>'BV'
,p_column_label=>'Ent empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086980984155568403)
,p_db_column_name=>'ENT_FECHA'
,p_display_order=>230
,p_column_identifier=>'BW'
,p_column_label=>'Ent fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086981113820568404)
,p_db_column_name=>'ENT_ORDEN'
,p_display_order=>240
,p_column_identifier=>'BX'
,p_column_label=>'Ent orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086981209394568405)
,p_db_column_name=>'ENT_CODIGO'
,p_display_order=>250
,p_column_identifier=>'BY'
,p_column_label=>'Ent codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086981260582568406)
,p_db_column_name=>'ENT_DESCRIPCION'
,p_display_order=>260
,p_column_identifier=>'BZ'
,p_column_label=>'Ent descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086981427676568407)
,p_db_column_name=>'ENT_FAMILIA'
,p_display_order=>270
,p_column_identifier=>'CA'
,p_column_label=>'Ent familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086981475255568408)
,p_db_column_name=>'ENT_SOLICITADA'
,p_display_order=>280
,p_column_identifier=>'CB'
,p_column_label=>'Ent solicitada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086981570462568409)
,p_db_column_name=>'ENT_RECIBIDA'
,p_display_order=>290
,p_column_identifier=>'CC'
,p_column_label=>'Ent recibida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087172421312264160)
,p_db_column_name=>'ENT_COSTO'
,p_display_order=>300
,p_column_identifier=>'CD'
,p_column_label=>'Ent costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087172521059264161)
,p_db_column_name=>'ENT_DESCUENTO'
,p_display_order=>310
,p_column_identifier=>'CE'
,p_column_label=>'Ent descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087172625180264162)
,p_db_column_name=>'ENT_IMPUESTO'
,p_display_order=>320
,p_column_identifier=>'CF'
,p_column_label=>'Ent impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087172706773264163)
,p_db_column_name=>'ENT_TOTAL'
,p_display_order=>330
,p_column_identifier=>'CG'
,p_column_label=>'Ent total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087172773909264164)
,p_db_column_name=>'ENT_PRO_MONEDA'
,p_display_order=>340
,p_column_identifier=>'CH'
,p_column_label=>'Ent pro moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087172914647264165)
,p_db_column_name=>'ENT_PROVEEDOR'
,p_display_order=>350
,p_column_identifier=>'CI'
,p_column_label=>'Ent proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087173024430264166)
,p_db_column_name=>'ENT_PRO_NOMBRE'
,p_display_order=>360
,p_column_identifier=>'CJ'
,p_column_label=>'Ent pro nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087173042766264167)
,p_db_column_name=>'ENT_ENTREGA'
,p_display_order=>370
,p_column_identifier=>'CK'
,p_column_label=>'Ent entrega'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087173225056264168)
,p_db_column_name=>'ENT_DOCUMENTO'
,p_display_order=>380
,p_column_identifier=>'CL'
,p_column_label=>'Ent documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087173292019264169)
,p_db_column_name=>'ENT_NUMERO'
,p_display_order=>390
,p_column_identifier=>'CM'
,p_column_label=>'Ent numero'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087173681731264173)
,p_db_column_name=>'ENT_ITEM'
,p_display_order=>410
,p_column_identifier=>'CQ'
,p_column_label=>'Ent item'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087173838886264175)
,p_db_column_name=>'TRANSITO_LOCAL_ITEM'
,p_display_order=>420
,p_column_identifier=>'CS'
,p_column_label=>'Transito local item'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087173949298264176)
,p_db_column_name=>'TRANSITO_LOCAL'
,p_display_order=>430
,p_column_identifier=>'CT'
,p_column_label=>'Transito local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087174041393264177)
,p_db_column_name=>'VALOR_DE_CAMBIO'
,p_display_order=>440
,p_column_identifier=>'CU'
,p_column_label=>'Valor de cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14094653581898986292)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'69099'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ENT_ENT_ENT_ENT_ENT_ENT_ENT_ENT_ENT_TTM_TIPO:ENT_LCG_LOCALIZACION:ENT_LCN_LOCALIZACION:ENT_RECIBIDO_POR::MONEDA_ENT_PRO_PROVEEDOR:ENT_EMPRESA:ENT_FECHA:ENT_ORDEN:ENT_CODIGO:ENT_DESCRIPCION:ENT_FAMILIA:ENT_SOLICITADA:ENT_RECIBIDA:ENT_COSTO:ENT_DESCUEN'
||'TO:ENT_IMPUESTO:ENT_TOTAL:ENT_PRO_MONEDA:ENT_PROVEEDOR:ENT_PRO_NOMBRE:ENT_ENTREGA:ENT_DOCUMENTO:ENT_NUMERO:ENT_ENT_ITEM:ENT_TRANSITO_LOCAL_ITM_ITEM:TRANSITO_LOCAL:VALOR_DE_CAMBIO'
,p_sum_columns_on_break=>'CED_SUBTOTAL:CED_DESCUENTO:CED_IMPUESTO:CED_OTROS_IMPUESTOS:CED_TOTAL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14094645944401986171)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14094645641710986144)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094646410608986186)
,p_name=>'P54_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14094645641710986144)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094646760082986202)
,p_name=>'P54_INICIO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14094645641710986144)
,p_prompt=>'Inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'RETURN TRUNC (SYSDATE, ''MM'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094647170439986202)
,p_name=>'P54_FIN'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14094645641710986144)
,p_prompt=>'Fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'SYSDATE'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
