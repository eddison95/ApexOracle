prompt --application/pages/page_00060
begin
--   Manifest
--     PAGE: 00060
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>60
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CXP - Proveedores'
,p_step_title=>'Proveedores'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153900'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112659768977127531)
,p_plug_name=>'Proveedores'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112657952141127502)
,p_plug_name=>'Proveedores'
,p_region_name=>'Proveedores'
,p_parent_plug_id=>wwv_flow_api.id(14112659768977127531)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 23/02/2017 05:50:54 p.m. (QP5 v5.115.810.9015) */',
'SELECT   A.pro_emp_empresa EMPRESA,',
'         A.PRO_PER_PERSONA PERSONA,',
'         A.PRO_PROVEEDOR CODIGO,',
'         A.PRO_MON_MONEDA MONEDA,',
'         gnl_nombre_persona_v_nx (A.PRO_PER_PERSONA) NOMBRE,',
'         gnl_cedula_persona_v_nx (A.PRO_PER_PERSONA) CEDULA,',
'         cxp_des_clase_prov_v_nx (A.PRO_EMP_EMPRESA, PRO_CCP_CLASE) CLASE,',
'         cxp_des_tipo_prov_v_nx (A.PRO_TIA_TIPO) TIPO_PROV,',
'         A.PRO_CUENTA_BANCO CUENTA_BANCO,',
'         gnl_nombre_persona_v_nx (A.PRO_PER_PERSONA_PERBANCO) BANCO,',
'         DECODE (A.PRO_TIPO_CUENTA_BANCO,',
'                 1,',
'                 ''Cuenta Corriente'',',
'                 2,',
'                 ''Cuenta de Ahorros'')',
'            TIPO_CUENTA_BANCARIA,',
'         DECODE (A.PRO_IMPUESTO,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            IMPUESTO,',
'         DECODE (A.PRO_RETENCION,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            RETENCION,',
'         DECODE (A.PRO_DIA_PAGO,',
'                 ''LU'',',
'                 ''Lunes'',',
'                 ''MA'',',
'                 ''Martes'',',
'                 ''MI'',',
'                 ''Miercoles'',',
'                 ''JU'',',
'                 ''Jueves'',',
'                 ''VI'',',
'                 ''Viernes'',',
'                 ''SA'',',
'                 ''Sabado'',',
'                 ''DO'',',
'                 ''Domingo'')',
'            DIA_PAGO,',
'         A.PRO_PLAZO PLAZO,',
'         A.PRO_PORCENTAJE_DESCUENTO PORCENTAJE_DESCUENTO,',
'         A.PRO_LIMITE_CREDITO LIMITE_CREDITO,',
'         A.PRO_OBSERVACION OBSERVACIONES,',
'         A.PRO_CODIGO_PAIS CODIGO_PAIS,',
'         (SELECT   C.CPA_OBSERVACION',
'            FROM   CXP_CONDICIONES_PAGO_TB_NX C',
'           WHERE   C.CPA_CONDICION = A.PRO_CPA_CONDICION)',
'            CONDICION1,',
'         (SELECT   D.CPA_OBSERVACION',
'            FROM   CXP_CONDICIONES_PAGO_TB_NX D',
'           WHERE   D.CPA_CONDICION = A.PRO_CPA_CONDICION_TIENE1)',
'            CONDICION2,',
'         (SELECT   E.CPA_OBSERVACION',
'            FROM   CXP_CONDICIONES_PAGO_TB_NX E',
'           WHERE   E.CPA_CONDICION = A.PRO_CPA_CONDICION_TIENE3)',
'            CONDICION3,',
'         (SELECT   F.CPA_OBSERVACION',
'            FROM   CXP_CONDICIONES_PAGO_TB_NX F',
'           WHERE   F.CPA_CONDICION = A.PRO_CPA_CONDICION_TIENE4)',
'            CONDICION4,',
'         cxp_nombre_prov_v_nx (A.PRO_PRO_EMP_EMPRESA,',
'                               A.PRO_PRO_PROVEEDOR,',
'                               A.PRO_PRO_MON_MONEDA)',
'            NOMBRE_PROVEEDOR,',
'         DECODE (A.PRO_FILIAL,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            FILIAL,',
'         DECODE (A.PRO_SOLVENCIA_MORAL,',
'                 1,',
'                 ''Excelente'',',
'                 2,',
'                 ''Muy Buena'',',
'                 3,',
'                 ''Buena'',',
'                 4,',
'                 ''Regular'',',
'                 5,',
'                 ''Mala'')',
'            SOLVENCIA_MORAL,',
'         DECODE (A.PRO_AVISO_PROV_DEP,',
'                 ''F'',',
'                 ''FAX'',',
'                 ''C'',',
'                 ''CORREO'',',
'                 ''N'',',
'                 ''NINGUNA'')',
'            AVISAR_POR,',
'         A.PRO_NUMERO_FAX FAX,',
'         A.PRO_CORREO_ELECTRONICO CORREO,',
'         (SELECT   G.CEC_DESCRIPCION',
'            FROM   COM_ESQUEMA_IMPORTACION_TB_NX G',
'           WHERE   G.CEC_EMP_EMPRESA = A.PRO_EMP_EMPRESA',
'                   AND G.CEC_ESQUEMA = A.PRO_CEC_ESQUEMA)',
'            ESQUEMA,',
'         DECODE (A.PRO_SOLVENCIA_ECONOMICA,',
'                 1,',
'                 ''Excelente'',',
'                 2,',
'                 ''Muy Buena'',',
'                 3,',
'                 ''Buena'',',
'                 4,',
'                 ''Regular'',',
'                 5,',
'                 ''Mala'')',
'            SOLVENCIA_ECONOMICA,',
'         A.PRO_IMPORTANCIA_FLUJO IMP_FLUJO,',
'         DECODE (A.PRO_TIPO,',
'                 ''L'',',
'                 ''Local'',',
'                 ''E'',',
'                 ''Externo'')',
'            TIPO,',
'         DECODE (A.PRO_ACTIVO,',
'                 ''S'',',
'                 ''Si'',',
'                 ''N'',',
'                 ''No'')',
'            ACTIVO,',
'         A.PRO_REPORTE_ORDEN REPORTE_ORDEN',
'  FROM   CXP_PROVEEDOR_TB_NX A',
' WHERE   INSTR ('':'' || :p60_empresa || '':'', '':'' || a.pro_emp_empresa || '':'') >',
'            0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P60_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14112658167924127508)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>11866917232338897
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112661567134138849)
,p_db_column_name=>'MONEDA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112661660883138855)
,p_db_column_name=>'NOMBRE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112661771361138856)
,p_db_column_name=>'CEDULA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_static_id=>'CEDULA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112661867662138856)
,p_db_column_name=>'CLASE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
,p_static_id=>'CLASE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112661974761138856)
,p_db_column_name=>'TIPO_PROV'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Tipo Prov'
,p_column_type=>'STRING'
,p_static_id=>'TIPO_PROV'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662066842138856)
,p_db_column_name=>'CUENTA_BANCO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Cuenta Banco'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA_BANCO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662167240138856)
,p_db_column_name=>'BANCO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_static_id=>'BANCO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662277359138857)
,p_db_column_name=>'TIPO_CUENTA_BANCARIA'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Tipo Cuenta Bancaria'
,p_column_type=>'STRING'
,p_static_id=>'TIPO_CUENTA_BANCARIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662357828138857)
,p_db_column_name=>'IMPUESTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Impuesto'
,p_column_type=>'STRING'
,p_static_id=>'IMPUESTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662467070138857)
,p_db_column_name=>'RETENCION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Retencion'
,p_column_type=>'STRING'
,p_static_id=>'RETENCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662572563138857)
,p_db_column_name=>'DIA_PAGO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Dia Pago'
,p_column_type=>'STRING'
,p_static_id=>'DIA_PAGO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662669533138858)
,p_db_column_name=>'PLAZO'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Plazo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PLAZO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662761047138858)
,p_db_column_name=>'PORCENTAJE_DESCUENTO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Porcentaje Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PORCENTAJE_DESCUENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662867935138858)
,p_db_column_name=>'LIMITE_CREDITO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Limite Credito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'LIMITE_CREDITO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112662954967138858)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_static_id=>'OBSERVACIONES'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663051512138858)
,p_db_column_name=>'CODIGO_PAIS'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Codigo Pais'
,p_column_type=>'STRING'
,p_static_id=>'CODIGO_PAIS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663161761138858)
,p_db_column_name=>'CONDICION1'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Condicion1'
,p_column_type=>'STRING'
,p_static_id=>'CONDICION1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663255183138859)
,p_db_column_name=>'CONDICION2'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Condicion2'
,p_column_type=>'STRING'
,p_static_id=>'CONDICION2'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663369117138859)
,p_db_column_name=>'CONDICION3'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Condicion3'
,p_column_type=>'STRING'
,p_static_id=>'CONDICION3'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663475844138859)
,p_db_column_name=>'CONDICION4'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Condicion4'
,p_column_type=>'STRING'
,p_static_id=>'CONDICION4'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663572158138859)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Nombre Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE_PROVEEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663680655138859)
,p_db_column_name=>'FILIAL'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Filial'
,p_column_type=>'STRING'
,p_static_id=>'FILIAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663754187138860)
,p_db_column_name=>'SOLVENCIA_MORAL'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Solvencia Moral'
,p_column_type=>'STRING'
,p_static_id=>'SOLVENCIA_MORAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663852107138860)
,p_db_column_name=>'AVISAR_POR'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Avisar Por'
,p_column_type=>'STRING'
,p_static_id=>'AVISAR_POR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112663962872138860)
,p_db_column_name=>'FAX'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Fax'
,p_column_type=>'STRING'
,p_static_id=>'FAX'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112664056966138860)
,p_db_column_name=>'CORREO'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_static_id=>'CORREO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112664178896138860)
,p_db_column_name=>'ESQUEMA'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Esquema'
,p_column_type=>'STRING'
,p_static_id=>'ESQUEMA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112664279218138862)
,p_db_column_name=>'SOLVENCIA_ECONOMICA'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Solvencia Economica'
,p_column_type=>'STRING'
,p_static_id=>'SOLVENCIA_ECONOMICA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112664379666138862)
,p_db_column_name=>'IMP_FLUJO'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Imp Flujo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'IMP_FLUJO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112664453763138862)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112664570516138862)
,p_db_column_name=>'ACTIVO'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Activo'
,p_column_type=>'STRING'
,p_static_id=>'ACTIVO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112664668447138863)
,p_db_column_name=>'REPORTE_ORDEN'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Reporte Orden'
,p_column_type=>'STRING'
,p_static_id=>'REPORTE_ORDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112895652931798271)
,p_db_column_name=>'PERSONA'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PERSONA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112895760539798276)
,p_db_column_name=>'CODIGO'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
,p_static_id=>'CODIGO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098965133409251901)
,p_db_column_name=>'EMPRESA'
,p_display_order=>44
,p_column_identifier=>'AI'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14112659569460127518)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118684'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'PERSONA:CODIGO:MONEDA:NOMBRE:CEDULA:CLASE:TIPO_PROV:CUENTA_BANCO:BANCO:TIPO_CUENTA_BANCARIA:IMPUESTO:RETENCION:DIA_PAGO:PLAZO:PORCENTAJE_DESCUENTO:LIMITE_CREDITO:OBSERVACIONES:CODIGO_PAIS:CONDICION1:CONDICION2:CONDICION3:CONDICION4:NOMBRE_PROVEEDOR:F'
||'ILIAL:SOLVENCIA_MORAL:AVISAR_POR:FAX:CORREO:ESQUEMA:SOLVENCIA_ECONOMICA:IMP_FLUJO:TIPO:ACTIVO:REPORTE_ORDEN::EMPRESA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14112659960030127536)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14112659768977127531)
,p_button_name=>'P60_CONSULTAR'
,p_button_static_id=>'P60_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112660154109127539)
,p_name=>'P60_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14112659768977127531)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
