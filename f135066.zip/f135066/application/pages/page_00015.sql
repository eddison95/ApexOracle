prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>15
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CGL \2013 Balance de Comprobacion')
,p_step_title=>'Balance Comprobacion'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163358'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193534863823796342)
,p_plug_name=>'Balance Comprobacion'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193535865937796346)
,p_plug_name=>'Balance Comprobacion'
,p_parent_plug_id=>wwv_flow_api.id(14193534863823796342)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 15/02/2017 03:13:50 p.m. (QP5 v5.115.810.9015) */',
'SELECT   a.emp_empresa,',
'         a.cuenta,',
'         a.descripcion,',
'         DECODE (a.tipo,',
'                 1,',
'                 ''Mayor'',',
'                 2,',
'                 ''Detalle'')',
'            tipo,',
'         periodo,',
'         ano,',
'         TRUNC (fecha_inicio) fecha_inicio,',
'         TRUNC (fecha_fin) fecha_fin,',
'         inicial_local,',
'         debe_local,',
'         haber_local,',
'         final_local,',
'         inicial_alterno,',
'         debe_alterno,',
'         haber_alterno,',
'         final_alterno,',
'         ''Fiscal'' contabilidad,',
'         nivel,',
'         DECODE (grupo,',
'                 1, ''Activos'',',
'                 2, ''Pasivos'',',
'                 3, ''Patrimonio'',',
'                 4, ''Ingresos'',',
'                 5, ''Gastos'',',
'                 6, ''Costos de Ventas'',',
'                 7, ''Costos de Produccion'',',
'                 8, ''Orden Deudora'',',
'                 9, ''Orden Acreedora'',',
'                 ''S/D'')',
'            grupo,',
'         tip_tipo_cambio,',
'         tip_tipo_cambio_valuacion,',
'         tip_tipo_cambio_fasb52,',
'         saldo_conversion',
'  FROM   cgl_cuenta_tr_nx a, cgl_saldos_fiscales_tr_nx b, cgl_periodo_tr_nx c',
' WHERE       a.emp_empresa = b.cta_emp_empresa',
'         AND a.cuenta = b.cta_cuenta',
'         AND b.peri_emp_empresa = c.emp_empresa',
'         AND b.peri_id = c.id',
'         AND INSTR ('':'' || :p15_empresa || '':'', '':'' || a.emp_empresa || '':'') >',
'               0',
'         AND INSTR ('':'' || :p15_periodo || '':'', '':'' || c.id || '':'') >',
'               0',
'         AND a.nivel <= :p15_nivel',
'         AND:p15_contabilidad IN (1, 2)',
'UNION ALL',
'SELECT   a.emp_empresa,',
'         a.cuenta,',
'         a.descripcion,',
'         DECODE (a.tipo,',
'                 1,',
'                 ''Mayor'',',
'                 2,',
'                 ''Detalle'')',
'            tipo,',
'         periodo,',
'         ano,',
'         TRUNC (fecha_inicio) fecha_inicio,',
'         TRUNC (fecha_fin) fecha_fin,',
'         inicial_local,',
'         debe_local,',
'         haber_local,',
'         final_local,',
'         inicial_alterno,',
'         debe_alterno,',
'         haber_alterno,',
'         final_alterno,',
'         ''Corporativa'' contabilidad,',
'         nivel,',
'         DECODE (grupo,',
'                 1, ''Activos'',',
'                 2, ''Pasivos'',',
'                 3, ''Patrimonio'',',
'                 4, ''Ingresos'',',
'                 5, ''Gastos'',',
'                 6, ''Costos de Ventas'',',
'                 7, ''Costos de Produccion'',',
'                 8, ''Orden Deudora'',',
'                 9, ''Orden Acreedora'',',
'                 ''S/D'')',
'            grupo,',
'         tip_tipo_cambio,',
'         tip_tipo_cambio_valuacion,',
'         tip_tipo_cambio_fasb52,',
'         saldo_fasb',
'  FROM   cgl_cuenta_tr_nx a,',
'         cgl_saldos_corporativos_tr_nx b,',
'         cgl_periodo_tr_nx c',
' WHERE       a.emp_empresa = b.cta_emp_empresa',
'         AND a.cuenta = b.cta_cuenta',
'         AND b.peri_emp_empresa = c.emp_empresa',
'         AND b.peri_id = c.id',
'         AND INSTR ('':'' || :p15_empresa || '':'', '':'' || a.emp_empresa || '':'') >',
'               0',
'         AND INSTR ('':'' || :p15_periodo || '':'', '':'' || c.id || '':'') >',
'               0',
'         AND a.nivel <= :p15_nivel',
'         AND:p15_contabilidad IN (1, 3)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P15_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14193536066651796349)
,p_name=>'Consulta de Asientos'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>7536714532610672
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193536161352796350)
,p_db_column_name=>'CUENTA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193536273328796350)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193536375547796351)
,p_db_column_name=>'TIPO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193537265546796355)
,p_db_column_name=>'PERIODO'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Periodo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PERIODO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193537379953796356)
,p_db_column_name=>'ANO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Ano'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ANO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193537479058796356)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA_INICIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193537583203796356)
,p_db_column_name=>'FECHA_FIN'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Fecha Fin'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA_FIN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14116034892079011875)
,p_db_column_name=>'CONTABILIDAD'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Contabilidad'
,p_column_type=>'STRING'
,p_static_id=>'CONTABILIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095031715336628843)
,p_db_column_name=>'INICIAL_LOCAL'
,p_display_order=>26
,p_column_identifier=>'AG'
,p_column_label=>'Inicial local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095031794625628844)
,p_db_column_name=>'DEBE_LOCAL'
,p_display_order=>36
,p_column_identifier=>'AH'
,p_column_label=>'Debe local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095127645443798795)
,p_db_column_name=>'HABER_LOCAL'
,p_display_order=>46
,p_column_identifier=>'AI'
,p_column_label=>'Haber local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095127774226798796)
,p_db_column_name=>'FINAL_LOCAL'
,p_display_order=>56
,p_column_identifier=>'AJ'
,p_column_label=>'Final local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095127897044798797)
,p_db_column_name=>'INICIAL_ALTERNO'
,p_display_order=>66
,p_column_identifier=>'AK'
,p_column_label=>'Inicial alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095127954704798798)
,p_db_column_name=>'DEBE_ALTERNO'
,p_display_order=>76
,p_column_identifier=>'AL'
,p_column_label=>'Debe alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128026489798799)
,p_db_column_name=>'HABER_ALTERNO'
,p_display_order=>86
,p_column_identifier=>'AM'
,p_column_label=>'Haber alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128176799798800)
,p_db_column_name=>'FINAL_ALTERNO'
,p_display_order=>96
,p_column_identifier=>'AN'
,p_column_label=>'Final alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128249883798801)
,p_db_column_name=>'NIVEL'
,p_display_order=>106
,p_column_identifier=>'AO'
,p_column_label=>'Nivel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128423297798802)
,p_db_column_name=>'GRUPO'
,p_display_order=>116
,p_column_identifier=>'AP'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128430770798803)
,p_db_column_name=>'TIP_TIPO_CAMBIO'
,p_display_order=>126
,p_column_identifier=>'AQ'
,p_column_label=>'Tipo Cambio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128576562798804)
,p_db_column_name=>'TIP_TIPO_CAMBIO_VALUACION'
,p_display_order=>136
,p_column_identifier=>'AR'
,p_column_label=>'Tipo Cambio Valuacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128646361798805)
,p_db_column_name=>'TIP_TIPO_CAMBIO_FASB52'
,p_display_order=>146
,p_column_identifier=>'AS'
,p_column_label=>'Tipo Cambio Conversion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128739772798806)
,p_db_column_name=>'SALDO_CONVERSION'
,p_display_order=>156
,p_column_identifier=>'AT'
,p_column_label=>'Fasb'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098668646909192108)
,p_db_column_name=>'EMP_EMPRESA'
,p_display_order=>166
,p_column_identifier=>'AU'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14193537681549796357)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75384'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CUENTA:DESCRIPCION:TIPO:CONTABILIDAD:PERIODO:ANO:FECHA_INICIO:FECHA_FIN::SDF_SDF_SDF_SDF_SDF_SDF_SDF_SDF_SDF_SALDO:INICIAL_LOCAL:DEBE_LOCAL:HABER_LOCAL:FINAL_LOCAL:INICIAL_ALTERNO:DEBE_ALTERNO:HABER_ALTERNO:FINAL_ALTERNO:NIVEL:GRUPO:TIP_TIPO_CAMBIO:T'
||'IP_TIPO_CAMBIO_VALUACION:TIP_TIPO_CAMBIO_FASB52:SALDO_CONVERSION:EMP_EMPRESA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168169322278680867)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(14193534863823796342)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14116031984364954689)
,p_name=>'P15_CONTABILIDAD'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14193534863823796342)
,p_prompt=>'Contabilidad'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Fiscal;2,Corporativa;3,Ambos;1'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193535068657796343)
,p_name=>'P15_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14193534863823796342)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193535460279796344)
,p_name=>'P15_PERIODO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14193534863823796342)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (periodo||'' ''||ano||'' ''||fecha_inicio||'' ''||fecha_fin) descripcion, id',
'from cgl_periodo_tr_nx',
'where emp_empresa = :P15_EMPRESA',
'AND tipo = :P15_CONTABILIDAD',
'ORDER BY ano desc, periodo desc'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P15_EMPRESA'
,p_ajax_items_to_submit=>'P15_EMPRESA,P15_CONTABILIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193535657099796345)
,p_name=>'P15_NIVEL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14193534863823796342)
,p_prompt=>'Nivel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
