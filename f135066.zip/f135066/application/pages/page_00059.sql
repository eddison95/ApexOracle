prompt --application/pages/page_00059
begin
--   Manifest
--     PAGE: 00059
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>59
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'TAL - Servicios Taller'
,p_step_title=>'Servicios Taller'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153900'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112651770653100857)
,p_plug_name=>'Servicios Taller'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112649981692100778)
,p_plug_name=>'Servicios Taller'
,p_region_name=>'Servicios'
,p_parent_plug_id=>wwv_flow_api.id(14112651770653100857)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.ser_consecutivo codigo,',
'       a.ser_descripcion descripcion,',
'       (SELECT fma_descripcion',
'        FROM inv_familia_tb_nx e',
'        WHERE e.fma_emp_empresa = a.ser_emp_empresa',
'              AND e.fma_familia = a.ser_fma_familia)',
'          familia,',
'       (SELECT b.ubf_descripcion',
'        FROM tal_ubicacion_fisica_tb_nx b',
'        WHERE b.ubf_emp_empresa = a.ser_emp_empresa',
'              AND b.ubf_ubicacion = a.ser_ubf_ubicacion)',
'          ubicacion,',
'       a.ser_dist_recorrida_ini dist_recorrida_ini,',
'       a.ser_dist_recorrida_fin dist_recorrida_fin,',
'       DECODE (a.ser_interno_externo, ''I'', ''Interno'', ''N'', ''Externo'')',
'          interno_externo,',
'       DECODE (a.ser_multiplicador, ''S'', ''Si'', ''N'', ''No'') multiplicador,',
'       DECODE (a.ser_diagnostico, ''S'', ''Si'', ''N'', ''No'') diagnostico,',
'       DECODE (a.ser_gravado, ''S'', ''Si'', ''N'', ''No'') gravado,',
'       a.ser_duracion_estandar duracion_estandar,',
'       a.ser_margen_venta margen_venta,',
'       (SELECT ato_descripcion',
'        FROM inv_articulo_tb_nx c',
'        WHERE c.ato_emp_empresa = a.ser_ato_emp_empresa',
'              AND c.ato_articulo = a.ser_ato_articulo)',
'          articulo,',
'       (SELECT cat_descripcion',
'        FROM tal_categoria_tb_nx d',
'        WHERE d.cat_categoria = a.ser_cat_categoria',
'              AND d.cat_emp_empresa = a.ser_emp_empresa)',
'          categoria,',
'       inv_obt_cabys_codid_v_nx (a.ser_emp_empresa,a.ser_cbs_id) codigo_cabys',
'FROM tal_servicio_tb_nx a',
'WHERE a.ser_emp_empresa = :p59_empresa'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P59_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14112650171973100798)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>11858921281312187
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112653566296108881)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112653682121108887)
,p_db_column_name=>'FAMILIA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
,p_static_id=>'FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112653757000108888)
,p_db_column_name=>'UBICACION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_static_id=>'UBICACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112654069189108888)
,p_db_column_name=>'INTERNO_EXTERNO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Interno Externo'
,p_column_type=>'STRING'
,p_static_id=>'INTERNO_EXTERNO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112654178972108889)
,p_db_column_name=>'MULTIPLICADOR'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Multiplicador'
,p_column_type=>'STRING'
,p_static_id=>'MULTIPLICADOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112654265301108889)
,p_db_column_name=>'DIAGNOSTICO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Diagnostico'
,p_column_type=>'STRING'
,p_static_id=>'DIAGNOSTICO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112654362157108889)
,p_db_column_name=>'GRAVADO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Gravado'
,p_column_type=>'STRING'
,p_static_id=>'GRAVADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112654656191108890)
,p_db_column_name=>'ARTICULO'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
,p_static_id=>'ARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112654768471108890)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
,p_static_id=>'CATEGORIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112981580990243244)
,p_db_column_name=>'CODIGO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Codigo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CODIGO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112985557483254223)
,p_db_column_name=>'DIST_RECORRIDA_INI'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Dist Recorrida Ini'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DIST_RECORRIDA_INI'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112985664235254229)
,p_db_column_name=>'DIST_RECORRIDA_FIN'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Dist Recorrida Fin'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DIST_RECORRIDA_FIN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112985751271254229)
,p_db_column_name=>'DURACION_ESTANDAR'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Duracion Estandar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DURACION_ESTANDAR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112985861171254229)
,p_db_column_name=>'MARGEN_VENTA'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Margen Venta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'MARGEN_VENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962846309550640326)
,p_db_column_name=>'CODIGO_CABYS'
,p_display_order=>28
,p_column_identifier=>'S'
,p_column_label=>'Codigo Cabys'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14112651565092100834)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118604'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CODIGO:DESCRIPCION:FAMILIA:UBICACION:DIST_RECORRIDA_INI:DIST_RECORRIDA_FIN:INTERNO_EXTERNO:MULTIPLICADOR:DIAGNOSTICO:GRAVADO:DURACION_ESTANDAR:MARGEN_VENTA:ARTICULO:CATEGORIA::CODIGO_CABYS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14112651971331100858)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14112651770653100857)
,p_button_name=>'P59_CONSULTAR'
,p_button_static_id=>'P59_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112652157091100880)
,p_name=>'P59_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14112651770653100857)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
