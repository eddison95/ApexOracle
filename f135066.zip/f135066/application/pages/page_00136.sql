prompt --application/pages/page_00136
begin
--   Manifest
--     PAGE: 00136
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>136
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'Inv-Detalle de Transacciones Item'
,p_step_title=>'Inv-Detalle de Transacciones Item'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165401'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14117736709146968388)
,p_plug_name=>'Detalle Transacciones Item'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_required_role=>wwv_flow_api.id(14193430675880859352)
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14117739087027968466)
,p_plug_name=>'Detalle Transacciones Item'
,p_parent_plug_id=>wwv_flow_api.id(14117736709146968388)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 23/10/2017 12:19:33 p.m. (QP5 v5.115.810.9015) */',
'SELECT   t.TSN_EMP_EMPRESA,',
'         t.TSN_TTN_TIPO,',
'         inv_desc_tran_v_nx (t.TSN_EMP_EMPRESA, t.TSN_TTN_TIPO)',
'            TSN_T_TRANSACCION,',
'         DECODE (t.TSN_STATUS,',
'                 ''C'',',
'                 ''CREADO'',',
'                 ''R'',',
'                 ''REGISTRADA'',',
'                 ''P'',',
'                 ''PROCESADA'',',
'                 ''O'',',
'                 ''CONFIRMADO'',',
'                 ''E'',',
'                 ''RECHAZADO'')',
'            TSN_ESTADO,',
'         TRUNC (t.TSN_FECHA_REGISTRO) TSN_FECHA_REGISTRO,',
'         t.TSN_DEP_DEPARTAMENTO,',
'         fac_nombre_depto_v_nx (t.TSN_EMP_EMPRESA, t.TSN_DEP_DEPARTAMENTO)',
'            TSN_DESC_DEPARTAMENTO,',
'         d.DTN_TSN_TRANSACCION,',
'         d.DTN_LINEA,',
'         d.DTN_LCN_LOCALIZACION,',
'         inv_descrip_loca_v_nx (t.TSN_EMP_EMPRESA, d.DTN_LCN_LOCALIZACION)',
'            TSN_DESC_LOCALIZACION,',
'         d.DTN_ATO_ARTICULO,',
'         inv_descrip_art_v_nx (t.TSN_EMP_EMPRESA, d.DTN_ATO_ARTICULO)',
'            DESCRIPCION,',
'         DIM_CANTIDAD,',
'         d.DTN_PRECIO_VENTA,',
'         (d.DTN_MONTO_SIN_IVA / DIM_CANTIDAD) DTN_MONTO_SIN_IVA,',
'         (d.DTN_MONTO / DIM_CANTIDAD) DTN_MONTO,',
'         (d.DTN_MONTO_ALT / DIM_CANTIDAD) DTN_MONTO_ALT,',
'         (d.DTN_COSTO_TOTAL / DIM_CANTIDAD) DTN_COSTO_TOTAL,',
'         (d.DTN_COSTO_TOTAL_ALT / DIM_CANTIDAD) DTN_COSTO_TOTAL_ALT,',
'         (d.DTN_COSTO_TOTAL_CORP / DIM_CANTIDAD) DTN_COSTO_TOTAL_CORP,',
'         (d.DTN_COSTO_TOTAL_CORP_ALT / DIM_CANTIDAD) DTN_COSTO_TOTAL_CORP_ALT,',
'         DECODE (d.DTN_IMPUESTO_VENTA,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'') ',
'            DTN_IMPUESTO_VENTA,',
'         (d.DTN_IMPUESTO_VENTAS / DIM_CANTIDAD) DTN_IMPUESTO_VENTAS,',
'         (d.DTN_IMPUESTO_VENTAS_ALT / DIM_CANTIDAD) DTN_IMPUESTO_VENTAS_ALT,',
'         (d.DTN_IMPUESTO_VENTAS_CORP / DIM_CANTIDAD) DTN_IMPUESTO_VENTAS_CORP,',
'         (d.DTN_IMPUESTO_VENTAS_CORP_ALT / DIM_CANTIDAD)',
'            DTN_IMPUESTO_VENTAS_CORP_ALT,',
'         t.TSN_OBSERVACIONES,',
'         t.TSN_NUMERO_DOCUMENTO,',
'         t.TSN_LCN_LOCALIZACION,',
'         INV_DESCRIP_LOCA_V_NX (t.TSN_EMP_EMPRESA, t.TSN_LCN_LOCALIZACION)',
'            desc_localizacion,',
'         TSN_FECHA_TRANSACCION,',
'         TSN_CREADO_POR,',
'         TSN_FECHA_CREACION,',
'         TSN_REGISTRADA_POR,',
'         ITM_ITEM,',
'         ITM_ATO_ARTICULO,',
'         ITM_MAR_MARCA,',
'         ITM_MOD_MODELO,',
'         ITM_CLR_COLOR,',
'         ITM_MOTOR,',
'         ITM_CHASIS,',
'         ITM_ANO',
'  FROM   INV_TRANSACCION_TB_NX t,',
'         INV_DETALLE_TRANSACCION_TB_NX d,',
'         INV_DETALLE_ITEM_TB_NX,',
'         INV_ITEM_TB_NX',
' WHERE       INSTR ('':'' || :P136_EMPRESA || '':'',',
'                    '':'' || t.TSN_EMP_EMPRESA || '':'') > 0',
'         AND t.TSN_TRANSACCION = d.DTN_TSN_TRANSACCION',
'         AND DTN_LINEA = DIM_DTN_LINEA',
'         AND DTN_TSN_TRANSACCION = DIM_TSN_TRANSACCION',
'         AND DIM_EMP_EMPRESA = ITM_EMP_EMPRESA',
'         AND DIM_ITM_ITEM = ITM_ITEM',
'         AND t.TSN_FECHA_TRANSACCION BETWEEN :P136_INICIO',
'                                         AND  TO_DATE (:P136_FIN || '' 23:59'',',
'                                                       ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(14193430675880859352)
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14117739411454968471)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>54719681014752212
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083760795481395103)
,p_db_column_name=>'TSN_EMP_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'AW'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083774334037395121)
,p_db_column_name=>'TSN_TTN_TIPO'
,p_display_order=>20
,p_column_identifier=>'CE'
,p_column_label=>'T. Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083761225446395103)
,p_db_column_name=>'TSN_T_TRANSACCION'
,p_display_order=>30
,p_column_identifier=>'AX'
,p_column_label=>'Desc. T.Ttransaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083761549917395103)
,p_db_column_name=>'TSN_ESTADO'
,p_display_order=>40
,p_column_identifier=>'AY'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083761979798395104)
,p_db_column_name=>'TSN_FECHA_REGISTRO'
,p_display_order=>50
,p_column_identifier=>'AZ'
,p_column_label=>'F. Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083775139769395122)
,p_db_column_name=>'TSN_DEP_DEPARTAMENTO'
,p_display_order=>60
,p_column_identifier=>'CG'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083762427483395104)
,p_db_column_name=>'TSN_DESC_DEPARTAMENTO'
,p_display_order=>70
,p_column_identifier=>'BA'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083762819704395104)
,p_db_column_name=>'DTN_TSN_TRANSACCION'
,p_display_order=>80
,p_column_identifier=>'BB'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083763132195395105)
,p_db_column_name=>'DTN_LINEA'
,p_display_order=>90
,p_column_identifier=>'BC'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083763570851395105)
,p_db_column_name=>'DTN_LCN_LOCALIZACION'
,p_display_order=>100
,p_column_identifier=>'BD'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083774760285395122)
,p_db_column_name=>'TSN_DESC_LOCALIZACION'
,p_display_order=>110
,p_column_identifier=>'CF'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083764017036395105)
,p_db_column_name=>'DTN_ATO_ARTICULO'
,p_display_order=>120
,p_column_identifier=>'BE'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083764794210395110)
,p_db_column_name=>'DTN_PRECIO_VENTA'
,p_display_order=>140
,p_column_identifier=>'BG'
,p_column_label=>'Precio Venta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083765223561395110)
,p_db_column_name=>'DTN_MONTO_SIN_IVA'
,p_display_order=>150
,p_column_identifier=>'BH'
,p_column_label=>'Monto sin IVA'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083765573414395111)
,p_db_column_name=>'DTN_MONTO'
,p_display_order=>160
,p_column_identifier=>'BI'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083766006728395114)
,p_db_column_name=>'DTN_MONTO_ALT'
,p_display_order=>170
,p_column_identifier=>'BJ'
,p_column_label=>'Monto Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083766417664395114)
,p_db_column_name=>'DTN_COSTO_TOTAL'
,p_display_order=>180
,p_column_identifier=>'BK'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P136_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083766790113395114)
,p_db_column_name=>'DTN_COSTO_TOTAL_ALT'
,p_display_order=>190
,p_column_identifier=>'BL'
,p_column_label=>'Costo Total Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P136_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083767190874395115)
,p_db_column_name=>'DTN_COSTO_TOTAL_CORP'
,p_display_order=>200
,p_column_identifier=>'BM'
,p_column_label=>'Costo Total Corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P136_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083767567800395115)
,p_db_column_name=>'DTN_COSTO_TOTAL_CORP_ALT'
,p_display_order=>210
,p_column_identifier=>'BN'
,p_column_label=>'Costo Total Corp Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P136_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083767991745395115)
,p_db_column_name=>'DTN_IMPUESTO_VENTA'
,p_display_order=>220
,p_column_identifier=>'BO'
,p_column_label=>'Impuesto Venta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083769183620395116)
,p_db_column_name=>'DTN_IMPUESTO_VENTAS'
,p_display_order=>250
,p_column_identifier=>'BR'
,p_column_label=>'Impuesto Ventas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083769581894395117)
,p_db_column_name=>'DTN_IMPUESTO_VENTAS_ALT'
,p_display_order=>260
,p_column_identifier=>'BS'
,p_column_label=>'Impuesto Ventas Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083769940091395117)
,p_db_column_name=>'DTN_IMPUESTO_VENTAS_CORP'
,p_display_order=>270
,p_column_identifier=>'BT'
,p_column_label=>'Impuesto Ventas Corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083770381810395117)
,p_db_column_name=>'DTN_IMPUESTO_VENTAS_CORP_ALT'
,p_display_order=>280
,p_column_identifier=>'BU'
,p_column_label=>'Impuesto Ventas Corp Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083775553951395122)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>380
,p_column_identifier=>'CH'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083776415120395123)
,p_db_column_name=>'TSN_OBSERVACIONES'
,p_display_order=>400
,p_column_identifier=>'CJ'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083776789726395124)
,p_db_column_name=>'TSN_NUMERO_DOCUMENTO'
,p_display_order=>410
,p_column_identifier=>'CK'
,p_column_label=>'Num. Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083777130730395124)
,p_db_column_name=>'TSN_LCN_LOCALIZACION'
,p_display_order=>420
,p_column_identifier=>'CL'
,p_column_label=>'Localizacion Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083777594772395124)
,p_db_column_name=>'DESC_LOCALIZACION'
,p_display_order=>430
,p_column_identifier=>'CM'
,p_column_label=>'Desc. Localizacion Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083778020200395124)
,p_db_column_name=>'TSN_FECHA_TRANSACCION'
,p_display_order=>440
,p_column_identifier=>'CN'
,p_column_label=>'F. Transaccion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083759602941395085)
,p_db_column_name=>'TSN_CREADO_POR'
,p_display_order=>450
,p_column_identifier=>'CO'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083759989281395102)
,p_db_column_name=>'TSN_FECHA_CREACION'
,p_display_order=>460
,p_column_identifier=>'CP'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083760369546395102)
,p_db_column_name=>'TSN_REGISTRADA_POR'
,p_display_order=>470
,p_column_identifier=>'CQ'
,p_column_label=>'Registrada por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083388521078714371)
,p_db_column_name=>'DIM_CANTIDAD'
,p_display_order=>480
,p_column_identifier=>'CR'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083388537792714372)
,p_db_column_name=>'ITM_ITEM'
,p_display_order=>490
,p_column_identifier=>'CS'
,p_column_label=>'Item'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083388714994714373)
,p_db_column_name=>'ITM_ATO_ARTICULO'
,p_display_order=>500
,p_column_identifier=>'CT'
,p_column_label=>unistr('\00CDtem Articulo')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083388792733714374)
,p_db_column_name=>'ITM_MAR_MARCA'
,p_display_order=>510
,p_column_identifier=>'CU'
,p_column_label=>unistr('\00CDtem Marca')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083388869762714375)
,p_db_column_name=>'ITM_MOD_MODELO'
,p_display_order=>520
,p_column_identifier=>'CV'
,p_column_label=>unistr('\00CDtem  Modelo')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083388986922714376)
,p_db_column_name=>'ITM_CLR_COLOR'
,p_display_order=>530
,p_column_identifier=>'CW'
,p_column_label=>unistr('\00CDtem Color')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083389099543714377)
,p_db_column_name=>'ITM_MOTOR'
,p_display_order=>540
,p_column_identifier=>'CX'
,p_column_label=>unistr('\00CDtem Motor')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083389132846714378)
,p_db_column_name=>'ITM_CHASIS'
,p_display_order=>550
,p_column_identifier=>'CY'
,p_column_label=>unistr('\00CDtem Chasis ')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083389271884714379)
,p_db_column_name=>'ITM_ANO'
,p_display_order=>560
,p_column_identifier=>'CZ'
,p_column_label=>unistr('\00CDtem A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14117746681777968535)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'207586'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TSN_EMP_EMPRESA:DTN_TSN_TRANSACCION:TSN_TTN_TIPO:TSN_T_TRANSACCION:TSN_ESTADO:TSN_FECHA_REGISTRO:TSN_FECHA_TRANSACCION:TSN_DEP_DEPARTAMENTO:TSN_DESC_DEPARTAMENTO:DTN_LINEA:DTN_LCN_LOCALIZACION:TSN_LCN_LOCALIZACION:DESC_LOCALIZACION:DTN_MONTO:DTN_MONT'
||'O_ALT:DTN_COSTO_TOTAL:DTN_COSTO_TOTAL_ALT:DTN_COSTO_TOTAL_CORP:DTN_COSTO_TOTAL_CORP_ALT:DTN_IMPUESTO_VENTA:DTN_IMPUESTO_VENTAS:DTN_IMPUESTO_VENTAS_ALT:DTN_IMPUESTO_VENTAS_CORP:DTN_IMPUESTO_VENTAS_CORP_ALT:DESCRIPCION:TSN_NUMERO_DOCUMENTO:TSN_OBSERVAC'
||'IONES::TSN_CREADO_POR:TSN_FECHA_CREACION:TSN_REGISTRADA_POR:DIM_CANTIDAD:ITM_ITEM:ITM_ATO_ARTICULO:ITM_MAR_MARCA:ITM_MOD_MODELO:ITM_CLR_COLOR:ITM_MOTOR:ITM_CHASIS:ITM_ANO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14083757363426395038)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14117736709146968388)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14083757739089395047)
,p_name=>'P136_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14117736709146968388)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE       use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_api.id(14193430675880859352)
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14083758058744395070)
,p_name=>'P136_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14117736709146968388)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14083758515742395072)
,p_name=>'P136_INICIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14117736709146968388)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14083758905048395073)
,p_name=>'P136_FIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14117736709146968388)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
