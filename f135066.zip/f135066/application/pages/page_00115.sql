prompt --application/pages/page_00115
begin
--   Manifest
--     PAGE: 00115
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>115
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'INV - Transacciones de Inventario'
,p_step_title=>'Transacciones de Inventario'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165126'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096999731480789782)
,p_plug_name=>'Transacciones de Inventario'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14097002109361789860)
,p_plug_name=>'Transacciones de Inventario'
,p_parent_plug_id=>wwv_flow_api.id(14096999731480789782)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   t.TSN_EMP_EMPRESA,',
'         t.TSN_TTN_TIPO,',
'         inv_desc_tran_v_nx (t.TSN_EMP_EMPRESA, t.TSN_TTN_TIPO)',
'            TSN_T_TRANSACCION,',
'         DECODE (t.TSN_STATUS,',
'                 ''C'',',
'                 ''CREADO'',',
'                 ''R'',',
'                 ''REGISTRADA'',',
'                 ''P'',',
'                 ''PROCESADA'',',
'                 ''O'',',
'                 ''CONFIRMADO'',',
'                 ''E'',',
'                 ''RECHAZADO'')',
'            TSN_ESTADO,',
'         TRUNC (t.TSN_FECHA_REGISTRO) TSN_FECHA_REGISTRO,',
'         t.TSN_DEP_DEPARTAMENTO,',
'         fac_nombre_depto_v_nx (t.TSN_EMP_EMPRESA, t.TSN_DEP_DEPARTAMENTO)',
'            TSN_DESC_DEPARTAMENTO,',
'         d.DTN_TSN_TRANSACCION,',
'         d.DTN_LINEA,',
'         d.DTN_LCN_LOCALIZACION,',
'         inv_descrip_loca_v_nx (t.TSN_EMP_EMPRESA, d.DTN_LCN_LOCALIZACION)',
'            TSN_DESC_LOCALIZACION,',
'         d.DTN_ATO_ARTICULO,',
'         inv_descrip_art_v_nx (t.TSN_EMP_EMPRESA, d.DTN_ATO_ARTICULO)',
'            DESCRIPCION,',
'         d.DTN_CANTIDAD,',
'         d.DTN_PRECIO_VENTA,',
'         d.DTN_MONTO_SIN_IVA,',
'         d.DTN_MONTO,',
'         d.DTN_MONTO_ALT,',
'         d.DTN_COSTO_TOTAL,',
'         d.DTN_COSTO_TOTAL_ALT,',
'         d.DTN_COSTO_TOTAL_CORP,',
'         d.DTN_COSTO_TOTAL_CORP_ALT,',
'         DECODE (d.DTN_IMPUESTO_VENTA,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            DTN_IMPUESTO_VENTA,',
'         d.DTN_COSTO_AJC_TOTAL,',
'         d.DTN_COSTO_AJC_TOTAL_ALT,',
'         d.DTN_IMPUESTO_VENTAS,',
'         d.DTN_IMPUESTO_VENTAS_ALT,',
'         d.DTN_IMPUESTO_VENTAS_CORP,',
'         d.DTN_IMPUESTO_VENTAS_CORP_ALT,',
'         d.DTN_AJC_ENTRADA_INV,',
'         d.DTN_AJC_ENTRADA_INV_ALT,',
'         d.DTN_ORD_ORDEN_INTERNA,',
'         d.DTN_CANTIDAD_ORIGINAL,',
'         d.DTN_CANTIDAD_ETIQUETA,',
'         d.DTN_IND_ENTRADA_CMP,',
'         d.DTN_MONTO_ORIGINAL,',
'         d.DTN_CANTIDAD_ORIGINAL_DP,',
'         d.DTN_IVA_ORIGINAL,',
'         DECODE (',
'            inv_itemizado_art_v_nx (t.TSN_EMP_EMPRESA, d.DTN_ATO_ARTICULO),',
'            ''N'',',
'            ''NO'',',
'            ''S'',',
'            ''SI''',
'         )',
'            itemizado,',
'         t.TSN_OBSERVACIONES,',
'         t.TSN_NUMERO_DOCUMENTO,',
'         t.TSN_LCN_LOCALIZACION,',
'         INV_DESCRIP_LOCA_V_NX (t.TSN_EMP_EMPRESA, t.TSN_LCN_LOCALIZACION)',
'            desc_localizacion,',
'         TSN_FECHA_TRANSACCION,',
'         TSN_CREADO_POR,',
'         TSN_FECHA_CREACION,',
'         TSN_REGISTRADA_POR,',
'         TSN_COMPROBANTE_ELECTRONICO,',
'         TSN_PRO_PROVEEDOR codigo_proveedor,',
'         TSN_PRO_MON_MONEDA moneda_proveedor,',
'         cxp_nombre_prov_v_nx(',
'             TSN_EMP_EMPRESA',
'             ,TSN_PRO_PROVEEDOR',
'             ,TSN_PRO_MON_MONEDA',
'        ) NOMBRE_PROVEEDOR',
'  FROM   INV_TRANSACCION_TB_NX t, INV_DETALLE_TRANSACCION_TB_NX d',
' WHERE   INSTR ('':'' || :P115_EMPRESA || '':'', '':'' || t.TSN_EMP_EMPRESA || '':'') >',
'            0',
'         AND t.TSN_TRANSACCION = d.DTN_TSN_TRANSACCION',
'         AND t.TSN_FECHA_TRANSACCION BETWEEN :P115_INICIO',
'                                         AND  TO_DATE (:P115_FIN || '' 23:59'',',
'                                                       ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P115_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14097002433788789865)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>9258709016900771
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096728612790981439)
,p_db_column_name=>'TSN_EMP_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'AW'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097119543915535318)
,p_db_column_name=>'TSN_TTN_TIPO'
,p_display_order=>20
,p_column_identifier=>'CE'
,p_column_label=>'T. Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096728707733981440)
,p_db_column_name=>'TSN_T_TRANSACCION'
,p_display_order=>30
,p_column_identifier=>'AX'
,p_column_label=>'Desc. T.Ttransaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096728820179981441)
,p_db_column_name=>'TSN_ESTADO'
,p_display_order=>40
,p_column_identifier=>'AY'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096728841601981442)
,p_db_column_name=>'TSN_FECHA_REGISTRO'
,p_display_order=>50
,p_column_identifier=>'AZ'
,p_column_label=>'F. Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097326318973671336)
,p_db_column_name=>'TSN_DEP_DEPARTAMENTO'
,p_display_order=>60
,p_column_identifier=>'CG'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096728926495981443)
,p_db_column_name=>'TSN_DESC_DEPARTAMENTO'
,p_display_order=>70
,p_column_identifier=>'BA'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096729032529981444)
,p_db_column_name=>'DTN_TSN_TRANSACCION'
,p_display_order=>80
,p_column_identifier=>'BB'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097010764754927195)
,p_db_column_name=>'DTN_LINEA'
,p_display_order=>90
,p_column_identifier=>'BC'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097010874513927196)
,p_db_column_name=>'DTN_LCN_LOCALIZACION'
,p_display_order=>100
,p_column_identifier=>'BD'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097119686979535319)
,p_db_column_name=>'TSN_DESC_LOCALIZACION'
,p_display_order=>110
,p_column_identifier=>'CF'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097010927573927197)
,p_db_column_name=>'DTN_ATO_ARTICULO'
,p_display_order=>120
,p_column_identifier=>'BE'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011120771927198)
,p_db_column_name=>'DTN_CANTIDAD'
,p_display_order=>130
,p_column_identifier=>'BF'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011189103927199)
,p_db_column_name=>'DTN_PRECIO_VENTA'
,p_display_order=>140
,p_column_identifier=>'BG'
,p_column_label=>'Precio Venta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011228046927200)
,p_db_column_name=>'DTN_MONTO_SIN_IVA'
,p_display_order=>150
,p_column_identifier=>'BH'
,p_column_label=>'Monto sin IVA'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011403758927201)
,p_db_column_name=>'DTN_MONTO'
,p_display_order=>160
,p_column_identifier=>'BI'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011486131927202)
,p_db_column_name=>'DTN_MONTO_ALT'
,p_display_order=>170
,p_column_identifier=>'BJ'
,p_column_label=>'Monto Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011612836927203)
,p_db_column_name=>'DTN_COSTO_TOTAL'
,p_display_order=>180
,p_column_identifier=>'BK'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P115_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011683998927204)
,p_db_column_name=>'DTN_COSTO_TOTAL_ALT'
,p_display_order=>190
,p_column_identifier=>'BL'
,p_column_label=>'Costo Total Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P115_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011757599927205)
,p_db_column_name=>'DTN_COSTO_TOTAL_CORP'
,p_display_order=>200
,p_column_identifier=>'BM'
,p_column_label=>'Costo Total Corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P115_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011844554927206)
,p_db_column_name=>'DTN_COSTO_TOTAL_CORP_ALT'
,p_display_order=>210
,p_column_identifier=>'BN'
,p_column_label=>'Costo Total Corp Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P115_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097011926469927207)
,p_db_column_name=>'DTN_IMPUESTO_VENTA'
,p_display_order=>220
,p_column_identifier=>'BO'
,p_column_label=>'Impuesto Venta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012044843927208)
,p_db_column_name=>'DTN_COSTO_AJC_TOTAL'
,p_display_order=>230
,p_column_identifier=>'BP'
,p_column_label=>'Costo Ajc Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P115_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012172951927209)
,p_db_column_name=>'DTN_COSTO_AJC_TOTAL_ALT'
,p_display_order=>240
,p_column_identifier=>'BQ'
,p_column_label=>'Costo Ajc Total Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P115_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012248249927210)
,p_db_column_name=>'DTN_IMPUESTO_VENTAS'
,p_display_order=>250
,p_column_identifier=>'BR'
,p_column_label=>'Impuesto Ventas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012392290927211)
,p_db_column_name=>'DTN_IMPUESTO_VENTAS_ALT'
,p_display_order=>260
,p_column_identifier=>'BS'
,p_column_label=>'Impuesto Ventas Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012479095927212)
,p_db_column_name=>'DTN_IMPUESTO_VENTAS_CORP'
,p_display_order=>270
,p_column_identifier=>'BT'
,p_column_label=>'Impuesto Ventas Corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012567159927213)
,p_db_column_name=>'DTN_IMPUESTO_VENTAS_CORP_ALT'
,p_display_order=>280
,p_column_identifier=>'BU'
,p_column_label=>'Impuesto Ventas Corp Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012689147927214)
,p_db_column_name=>'DTN_AJC_ENTRADA_INV'
,p_display_order=>290
,p_column_identifier=>'BV'
,p_column_label=>'Ajc Antrada Inv'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012734244927215)
,p_db_column_name=>'DTN_AJC_ENTRADA_INV_ALT'
,p_display_order=>300
,p_column_identifier=>'BW'
,p_column_label=>'Ajc Entrada Inv Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097012851064927216)
,p_db_column_name=>'DTN_ORD_ORDEN_INTERNA'
,p_display_order=>310
,p_column_identifier=>'BX'
,p_column_label=>'Orden interna'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097013005476927217)
,p_db_column_name=>'DTN_CANTIDAD_ORIGINAL'
,p_display_order=>320
,p_column_identifier=>'BY'
,p_column_label=>'Cantidad Original'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097013122965927218)
,p_db_column_name=>'DTN_CANTIDAD_ETIQUETA'
,p_display_order=>330
,p_column_identifier=>'BZ'
,p_column_label=>'Cantidad Etiqueta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097013147151927219)
,p_db_column_name=>'DTN_IND_ENTRADA_CMP'
,p_display_order=>340
,p_column_identifier=>'CA'
,p_column_label=>'Entrada CMP'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097013298973927220)
,p_db_column_name=>'DTN_MONTO_ORIGINAL'
,p_display_order=>350
,p_column_identifier=>'CB'
,p_column_label=>'Monto Original'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097013350889927221)
,p_db_column_name=>'DTN_CANTIDAD_ORIGINAL_DP'
,p_display_order=>360
,p_column_identifier=>'CC'
,p_column_label=>'Cantidad Original DP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097013441632927222)
,p_db_column_name=>'DTN_IVA_ORIGINAL'
,p_display_order=>370
,p_column_identifier=>'CD'
,p_column_label=>'IVA Original'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098170206087481044)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>380
,p_column_identifier=>'CH'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099124144988152607)
,p_db_column_name=>'ITEMIZADO'
,p_display_order=>390
,p_column_identifier=>'CI'
,p_column_label=>'Itemizado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099125556765152621)
,p_db_column_name=>'TSN_OBSERVACIONES'
,p_display_order=>400
,p_column_identifier=>'CJ'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099125699217152622)
,p_db_column_name=>'TSN_NUMERO_DOCUMENTO'
,p_display_order=>410
,p_column_identifier=>'CK'
,p_column_label=>'Num. Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099125768189152623)
,p_db_column_name=>'TSN_LCN_LOCALIZACION'
,p_display_order=>420
,p_column_identifier=>'CL'
,p_column_label=>'Localizacion Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099125848197152624)
,p_db_column_name=>'DESC_LOCALIZACION'
,p_display_order=>430
,p_column_identifier=>'CM'
,p_column_label=>'Desc. Localizacion Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099125943652152625)
,p_db_column_name=>'TSN_FECHA_TRANSACCION'
,p_display_order=>440
,p_column_identifier=>'CN'
,p_column_label=>'F. Transaccion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082582972335100318)
,p_db_column_name=>'TSN_CREADO_POR'
,p_display_order=>450
,p_column_identifier=>'CO'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583063225100319)
,p_db_column_name=>'TSN_FECHA_CREACION'
,p_display_order=>460
,p_column_identifier=>'CP'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583178226100320)
,p_db_column_name=>'TSN_REGISTRADA_POR'
,p_display_order=>470
,p_column_identifier=>'CQ'
,p_column_label=>'Registrada por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084692025006360972)
,p_db_column_name=>'TSN_COMPROBANTE_ELECTRONICO'
,p_display_order=>480
,p_column_identifier=>'CR'
,p_column_label=>unistr('Comprobante electr\00F3nico')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086273430629786962)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>510
,p_column_identifier=>'CU'
,p_column_label=>'Nombre proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086273770650786965)
,p_db_column_name=>'CODIGO_PROVEEDOR'
,p_display_order=>520
,p_column_identifier=>'CV'
,p_column_label=>'Codigo proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086273861187786966)
,p_db_column_name=>'MONEDA_PROVEEDOR'
,p_display_order=>530
,p_column_identifier=>'CW'
,p_column_label=>'Moneda proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14097009704111789929)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'92660'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TSN_EMP_EMPRESA:DTN_TSN_TRANSACCION:TSN_TTN_TIPO:TSN_T_TRANSACCION:TSN_ESTADO:TSN_FECHA_REGISTRO:TSN_FECHA_TRANSACCION:TSN_DEP_DEPARTAMENTO:TSN_DESC_DEPARTAMENTO:DTN_LINEA:DTN_LCN_LOCALIZACION:TSN_LCN_LOCALIZACION:DESC_LOCALIZACION:DTN_CANTIDAD:DTN_M'
||'ONTO:DTN_MONTO_ALT:DTN_IMPUESTO_VENTA:DTN_IMPUESTO_VENTAS:DTN_IMPUESTO_VENTAS_ALT:DTN_IMPUESTO_VENTAS_CORP:DTN_IMPUESTO_VENTAS_CORP_ALT:DTN_AJC_ENTRADA_INV:DTN_AJC_ENTRADA_INV_ALT:DTN_ORD_ORDEN_INTERNA:DTN_CANTIDAD_ORIGINAL:DTN_CANTIDAD_ETIQUETA:DTN_'
||'IND_ENTRADA_CMP:DTN_MONTO_ORIGINAL:DTN_CANTIDAD_ORIGINAL_DP:DTN_IVA_ORIGINAL:ITEMIZADO:DESCRIPCION:TSN_NUMERO_DOCUMENTO:TSN_COMPROBANTE_ELECTRONICO:TSN_OBSERVACIONES:TSN_CREADO_POR:TSN_FECHA_CREACION:TSN_REGISTRADA_POR::NOMBRE_PROVEEDOR:CODIGO_PROVEE'
||'DOR:MONEDA_PROVEEDOR'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14097000185720789804)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14096999731480789782)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14097000523853789831)
,p_name=>'P115_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096999731480789782)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14097000899314789850)
,p_name=>'P115_INICIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14096999731480789782)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14097001230757789851)
,p_name=>'P115_FIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14096999731480789782)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098474977154129575)
,p_name=>'P115_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14096999731480789782)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE       use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
