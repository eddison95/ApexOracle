prompt --application/pages/page_00163
begin
--   Manifest
--     PAGE: 00163
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>163
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'PLA - Prontuario'
,p_step_title=>'Prontuario'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14034774636470179463)
,p_plug_name=>'Prontuario'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14034679370003673774)
,p_plug_name=>'Prontuario'
,p_parent_plug_id=>wwv_flow_api.id(14034774636470179463)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PRO_EMP_EMPRESA,',
'    PRO_ID, ',
'    PRO_PER_PERSONA,',
'    SUBSTR ( (nombre || '' '' || apellidos), 1, 60) PERSONA,',
'    (CASE WHEN PRO_ESTADO = ''A'' THEN ''ACTIVO''',
'          WHEN PRO_ESTADO = ''I'' THEN ''INACTVIO''',
'          WHEN PRO_ESTADO = ''L'' THEN ''LIQUIDADO''',
'          WHEN PRO_ESTADO = ''D'' THEN ''DESPEDIDO''',
'          WHEN PRO_ESTADO = ''P'' THEN ''PENSIONADO''',
'          WHEN PRO_ESTADO = ''R'' THEN ''RENUNCIO''',
'          ELSE  ''SUSPENDIDO'' END ) ESTADO,',
'    PRO_FECHA_INGRESO, ',
'    DEP_DESCRIPCION,',
'    PRO_TEM_ID ID_EMP,',
'    TEM_DESCRIPCION TIPO_EMPLEADO,',
'    ''INS'',',
'    PRO_POLIZA_INS,',
'    PRO_PROF_INS,',
'    PRO_INS_TIPO_JORNADA,',
'    PTP_TPL_ID,',
'    TPL_DESCRIPCION TIPO_PLANILLA,',
'    TPL_MON_MONEDA,',
'    (CASE WHEN PTP_ESTADO = ''A'' THEN ''ACTIVO''',
'          WHEN PTP_ESTADO = ''I'' THEN ''INACTVIO''',
'          ELSE  ''LIQUIDADO'' END ) AS ESTADO_PL,',
'    (CASE WHEN PTP_FORMA_PAGO = ''C'' THEN ''CHEQUE''',
'          WHEN PTP_FORMA_PAGO = ''T'' THEN ''TRANSFERENCIA''',
'          ELSE ''EFECTIVO'' END  )AS FORMAPAGO,',
'    (CASE WHEN PTP_TIPO_CUENTA = ''A'' THEN ''AHORRO''',
'          WHEN PTP_TIPO_CUENTA = ''C'' THEN ''CUENTA CORRIENTE''',
'          ELSE ''OTRO'' END )AS TIPO_CUENTA_EMPLEADO,',
'    PTP_CUENTA_BANCARIA,',
'    PTP_CUENTA_CLIENTE,',
'    PTP_CTB_BCO_BANCO,',
'    PTP_CTB_CUENTA,',
'    PTP_CTB_MON_MONEDA,',
'    PTP_CLI_CLIENTE,',
'    PTP_CLI_MON_MONEDA,',
'    SAL_FECHA_INICIAL,',
'    SAL_SALARIO_HORA,',
'    SAL_SALARIO_DIA,',
'    SAL_SALARIO_MENSUAL,',
'    DEE_DEV_ID,',
'    (CASE WHEN DEE_INDICADOR_FRECUENCIA = ''R'' THEN ''RECURRENTE''',
'          WHEN DEE_INDICADOR_FRECUENCIA = ''U'' THEN ''ULTOMO PAGO''',
'          WHEN DEE_INDICADOR_FRECUENCIA = ''A'' THEN ''MANUAL''',
'          ELSE ''COPIA'' END ) AS FRECUENCIA,',
'    DEE_DEV_ID AS DEV,',
'    (CASE WHEN DEE_INDICADOR_FRECUENCIA = ''R'' THEN ''RECURRENTE''',
'          WHEN DEE_INDICADOR_FRECUENCIA = ''U'' THEN ''ULTOMO PAGO''',
'          WHEN DEE_INDICADOR_FRECUENCIA = ''A'' THEN ''MANUAL''',
'          ELSE ''COPIA'' END ) AS FRECUENCIA_DEV   ',
'FROM PLA_PRONTUARIO_TB_NX,',
'     PLA_TIPOPLA_PRONTUARIO_TB_NX,',
'     PLA_TIPO_PLANILLA_TB_NX,',
'     PLA_SALARIO_TB_NX,',
'     PLA_DEVEMP_TB_NX,',
'     FAC_DEPARTAMENTO_TB_NX,',
'     GNL_PERSONA_TR_NX,',
'     PLA_TIPO_EMPLEADO_TB_NX',
'WHERE PRO_EMP_EMPRESA  = :P163_EMPRESA',
'      AND PRO_ID = PTP_PRO_ID',
'      AND TPL_ID = PTP_TPL_ID',
'      AND SAL_PRO_ID =PRO_ID',
'      AND SAL_TPL_ID = TPL_ID     ',
'      AND DEE_PTP_ID = PTP_ID',
'      AND DEP_EMP_EMPRESA = PRO_EMP_EMPRESA',
'      AND PERSONA = PRO_PER_PERSONA',
'      AND TEM_EMP_EMPRESA = PRO_EMP_EMPRESA ',
'      AND TEM_ID = PRO_TEM_ID',
'      AND TPL_EMP_EMPRESA = PRO_EMP_EMPRESA'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14034679472860673775)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'KSALAZAR'
,p_internal_uid=>13886474965818747
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034814690641103735)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'AR'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034815948151103748)
,p_db_column_name=>'ESTADO_PL'
,p_display_order=>170
,p_column_identifier=>'BE'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034816083439103749)
,p_db_column_name=>'FORMAPAGO'
,p_display_order=>180
,p_column_identifier=>'BF'
,p_column_label=>'Forma pago'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034816098421103750)
,p_db_column_name=>'TIPO_CUENTA_EMPLEADO'
,p_display_order=>190
,p_column_identifier=>'BG'
,p_column_label=>'Tipo cuenta empleado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034817400689103763)
,p_db_column_name=>'FRECUENCIA'
,p_display_order=>320
,p_column_identifier=>'BT'
,p_column_label=>'Frecuencia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034817772376103766)
,p_db_column_name=>'DEV'
,p_display_order=>350
,p_column_identifier=>'BW'
,p_column_label=>'Devengo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034817887909103767)
,p_db_column_name=>'FRECUENCIA_DEV'
,p_display_order=>360
,p_column_identifier=>'BX'
,p_column_label=>'Frecuencia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034893276361258447)
,p_db_column_name=>'PRO_EMP_EMPRESA'
,p_display_order=>370
,p_column_identifier=>'BY'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034893314693258448)
,p_db_column_name=>'PRO_ID'
,p_display_order=>380
,p_column_identifier=>'BZ'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034893476312258449)
,p_db_column_name=>'PRO_PER_PERSONA'
,p_display_order=>390
,p_column_identifier=>'CA'
,p_column_label=>'Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034893654495258451)
,p_db_column_name=>'PRO_FECHA_INGRESO'
,p_display_order=>410
,p_column_identifier=>'CC'
,p_column_label=>'Fecha ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894040236258455)
,p_db_column_name=>'''INS'''
,p_display_order=>450
,p_column_identifier=>'CG'
,p_column_label=>'Aseguradora'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894132100258456)
,p_db_column_name=>'PRO_POLIZA_INS'
,p_display_order=>460
,p_column_identifier=>'CH'
,p_column_label=>'Poliza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894241825258457)
,p_db_column_name=>'PRO_PROF_INS'
,p_display_order=>470
,p_column_identifier=>'CI'
,p_column_label=>unistr('Profesi\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894364412258458)
,p_db_column_name=>'PRO_INS_TIPO_JORNADA'
,p_display_order=>480
,p_column_identifier=>'CJ'
,p_column_label=>'Tipo jornada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894412698258459)
,p_db_column_name=>'PTP_TPL_ID'
,p_display_order=>490
,p_column_identifier=>'CK'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894680368258461)
,p_db_column_name=>'TPL_MON_MONEDA'
,p_display_order=>510
,p_column_identifier=>'CM'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894794119258462)
,p_db_column_name=>'PTP_CUENTA_BANCARIA'
,p_display_order=>520
,p_column_identifier=>'CN'
,p_column_label=>'Cuenta bancaria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894863919258463)
,p_db_column_name=>'PTP_CUENTA_CLIENTE'
,p_display_order=>530
,p_column_identifier=>'CO'
,p_column_label=>'Cuenta cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034894902095258464)
,p_db_column_name=>'PTP_CTB_BCO_BANCO'
,p_display_order=>540
,p_column_identifier=>'CP'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895063093258465)
,p_db_column_name=>'PTP_CTB_CUENTA'
,p_display_order=>550
,p_column_identifier=>'CQ'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895195349258466)
,p_db_column_name=>'PTP_CTB_MON_MONEDA'
,p_display_order=>560
,p_column_identifier=>'CR'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895227519258467)
,p_db_column_name=>'PTP_CLI_CLIENTE'
,p_display_order=>570
,p_column_identifier=>'CS'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895304128258468)
,p_db_column_name=>'PTP_CLI_MON_MONEDA'
,p_display_order=>580
,p_column_identifier=>'CT'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895454702258469)
,p_db_column_name=>'SAL_FECHA_INICIAL'
,p_display_order=>590
,p_column_identifier=>'CU'
,p_column_label=>'Fecha inicial'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895521582258470)
,p_db_column_name=>'SAL_SALARIO_HORA'
,p_display_order=>600
,p_column_identifier=>'CV'
,p_column_label=>'Salario hora'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895648476258471)
,p_db_column_name=>'SAL_SALARIO_DIA'
,p_display_order=>610
,p_column_identifier=>'CW'
,p_column_label=>unistr('Salario d\00EDa')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895716906258472)
,p_db_column_name=>'SAL_SALARIO_MENSUAL'
,p_display_order=>620
,p_column_identifier=>'CX'
,p_column_label=>'Salario mensual'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14034895856688258473)
,p_db_column_name=>'DEE_DEV_ID'
,p_display_order=>630
,p_column_identifier=>'CY'
,p_column_label=>'Devengo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14042550935243305972)
,p_db_column_name=>'DEP_DESCRIPCION'
,p_display_order=>660
,p_column_identifier=>'DB'
,p_column_label=>'Dep descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14042551038751305973)
,p_db_column_name=>'PERSONA'
,p_display_order=>670
,p_column_identifier=>'DC'
,p_column_label=>'Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14042551164970305974)
,p_db_column_name=>'TIPO_EMPLEADO'
,p_display_order=>680
,p_column_identifier=>'DD'
,p_column_label=>'Tipo empleado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14042551209549305975)
,p_db_column_name=>'TIPO_PLANILLA'
,p_display_order=>690
,p_column_identifier=>'DE'
,p_column_label=>'Tipo planilla'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049586998555902063)
,p_db_column_name=>'ID_EMP'
,p_display_order=>700
,p_column_identifier=>'DF'
,p_column_label=>'Id emp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14034797579963180415)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'140046'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>'ESTADO_PL:FORMAPAGO:FRECUENCIA:DEV:FRECUENCIA_DEV:PRO_EMP_EMPRESA:PRO_ID:PERSONA:TIPO_EMPLEADO:TIPO_PLANILLA:PRO_FECHA_INGRESO:DEP_DESCRIPCION:''INS'':PRO_POLIZA_INS:PRO_PROF_INS:PRO_INS_TIPO_JORNADA:PTP_TPL_ID:TPL_MON_MONEDA:PTP_CUENTA_BANCARIA:PTP_CU'
||'ENTA_CLIENTE:PTP_CTB_BCO_BANCO:PTP_CTB_CUENTA:PTP_CTB_MON_MONEDA:PTP_CLI_CLIENTE:PTP_CLI_MON_MONEDA:SAL_FECHA_INICIAL:SAL_SALARIO_HORA:SAL_SALARIO_DIA:SAL_SALARIO_MENSUAL:DEE_DEV_ID::ID_EMP'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14034817920560103768)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14034774636470179463)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14034774734921179464)
,p_name=>'P163_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14034774636470179463)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
