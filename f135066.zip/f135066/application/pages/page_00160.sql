prompt --application/pages/page_00160
begin
--   Manifest
--     PAGE: 00160
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>160
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'D151 Auxiliar Detalle'
,p_page_mode=>'MODAL'
,p_step_title=>'D151 Auxiliar Detalle'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14111814717019290841)
,p_plug_name=>'D151 Auxiliar'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    c002   d_origen,',
'    c003   d_transaccion,',
'    c004   d_numero,',
'    TO_DATE(c005) d_fecha,',
'    c006   d_cedula,',
'    c007   d_nombre,',
'    to_number(c008) d_monto,',
'    c009   d_codigo,',
'    c010   d_tipo,',
'    c011   d_desc_tipo',
'FROM',
'    apex_collections',
'WHERE',
'    collection_name = ''D151''',
'    AND TO_DATE(c005) BETWEEN :p159_inicio AND :p159_fin',
'    AND c006 = :p160_cedula',
'    AND c009 = :p160_codigo'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14111815069915290844)
,p_name=>'Detalle de Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>91022072020435816
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14031361794448915959)
,p_db_column_name=>'D_ORIGEN'
,p_display_order=>10
,p_column_identifier=>'EY'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14033903597215355281)
,p_db_column_name=>'D_CEDULA'
,p_display_order=>20
,p_column_identifier=>'EU'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14033903994505355282)
,p_db_column_name=>'D_NOMBRE'
,p_display_order=>30
,p_column_identifier=>'EV'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14031361823776915960)
,p_db_column_name=>'D_TRANSACCION'
,p_display_order=>40
,p_column_identifier=>'EZ'
,p_column_label=>'Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14031361983140915961)
,p_db_column_name=>'D_NUMERO'
,p_display_order=>50
,p_column_identifier=>'FA'
,p_column_label=>'Numero'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14033904309047355282)
,p_db_column_name=>'D_MONTO'
,p_display_order=>70
,p_column_identifier=>'EW'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14033904788053355282)
,p_db_column_name=>'D_CODIGO'
,p_display_order=>80
,p_column_identifier=>'EX'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14031362119945915963)
,p_db_column_name=>'D_FECHA'
,p_display_order=>90
,p_column_identifier=>'FC'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14031362245539915964)
,p_db_column_name=>'D_TIPO'
,p_display_order=>100
,p_column_identifier=>'FD'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14031362337489915965)
,p_db_column_name=>'D_DESC_TIPO'
,p_display_order=>110
,p_column_identifier=>'FE'
,p_column_label=>'Desc. Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14111840813946290909)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'131121'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'D_ORIGEN:D_CEDULA:D_NOMBRE:D_TRANSACCION:D_NUMERO:D_MONTO:D_CODIGO:D_TIPO:D_DESC_TIPO'
,p_sort_column_1=>'D_FECHA'
,p_sort_direction_1=>'DESC'
,p_sum_columns_on_break=>'D_MONTO'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14031361513595915957)
,p_name=>'P160_CEDULA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14111814717019290841)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14031361676428915958)
,p_name=>'P160_CODIGO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14111814717019290841)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14033907450128355289)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'llena_reporte_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   cgl_rep_d151_pr_nx(:P160_EMPRESA, :P160_INICIO, :P160_FIN);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
