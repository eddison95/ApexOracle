prompt --application/pages/page_00151
begin
--   Manifest
--     PAGE: 00151
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>151
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Facturas Canceladas'
,p_step_title=>'Facturas Canceladas'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201210093307'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14056205292495641237)
,p_plug_name=>'Facturas Canceladas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY_1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14049590877938675018)
,p_plug_name=>'Facturas Canceladas'
,p_parent_plug_id=>wwv_flow_api.id(14056205292495641237)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT A.TRX_EMP_EMPRESA EMPRESA,',
'        A.TRX_TRANSACCION TRX_TRANSACCION,',
'        E.TRA_TRANSACCION TRA_TRANSACCION,',
'        A.TRX_FECHA_TRANSACCION FECHA_TRANSACCION,',
'        E.TRA_FACTURA FACTURA,',
'              DECODE (E.tra_tipo,',
'                 ''CRE'',',
'                 ''CREDITO'',',
'                 ''CON'',',
'                 ''CONTADO'',',
'                 ''FIN'',',
'                 ''FINANCIAMIENTO'',',
'                 ''NIT'',',
'                 ''NOTA INTERNA'')',
'            tipo, ',
'        A.TRX_SUB_SUBSISTEMA SUBSISTEMA,',
'        TRA_TTR_TIPO TIPO_FACTURA,',
'        A.TRX_DOC_DOCUMENTO DOCUMENTO,',
'        E.tra_ven_vendedor codigo_vendedor,',
'        gnl_nombre_vendedor_vi (E.tra_emp_empresa, E.tra_ven_vendedor)',
'            nombre_vendedor,',
'        A.TRX_CLI_CLIENTE CLIENTE,',
'        E.TRA_NOMBRE,',
'        A.TRX_CLI_MON_MONEDA MONEDA,',
'        A.TRX_MONTO,',
'        CASE',
'            WHEN (:p151_moneda = ''ND'')',
'            THEN',
'               E.tra_subtotal',
'            WHEN (E.tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (E.tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               E.tra_subtotal',
'            WHEN (E.tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               E.tra_subtotal',
'            WHEN (E.tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               E.tra_subtotal / tra_valor_cambio',
'            WHEN (E.tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               E.tra_subtotal * tra_valor_cambio',
'         END',
'            subtotal,',
'        E.TRA_IMPUESTO_VENTAS IMPUESTO,',
'          CASE',
'            WHEN (:p151_moneda = ''ND'')',
'            THEN',
'               E.tra_descuento',
'            WHEN (E.tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (E.tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               E.tra_descuento',
'            WHEN (E.tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               E.tra_descuento',
'            WHEN (E.tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               E.tra_descuento / tra_valor_cambio',
'            WHEN (E.tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               E.tra_descuento * tra_valor_cambio',
'         END',
'            descuento,',
'            CASE',
'            WHEN (:p151_moneda = ''ND'')',
'            THEN',
'               E.TRA_TOTAL',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               E.TRA_TOTAL',
'            WHEN (tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               E.TRA_TOTAL',
'            WHEN (tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               E.TRA_TOTAL / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               E.TRA_TOTAL * tra_valor_cambio',
'         END Total_Factura,',
'        ROUND(A.TRX_MONTO-(A.TRX_MONTO* (TRA_IMPUESTO_VENTAS/E.TRA_TOTAL))) COMISION',
'FROM CXC_TRANSACCION_TB_NX A,',
'     CXC_TRANSACCION_TB_NX B,',
'     CXC_RECIBO_CAJA_TB_NX C, ',
'     CXC_REFERENCIA_TB_NX  D,',
'     FAC_FACTURA_TB_NX E',
'WHERE INSTR ('':'' || :p151_empresa || '':'', '':'' || A.TRX_EMP_EMPRESA || '':'') > 0',
'AND A.TRX_FECHA_TRANSACCION BETWEEN :P151_INICIO AND to_date(:P151_FIN||'' 23:59'', ''dd/mm/rrrr hh24:mi'')',
'AND A.TRX_REC_NUMERO_RECIBO = C.REC_NUMERO_RECIBO',
'AND D.REF_TRX_TRANSACCION_HIJAS = A.TRX_TRANSACCION',
'AND A.TRX_EMP_EMPRESA = C.REC_EMP_EMPRESA',
'AND B.TRX_TRANSACCION = D.REF_TRX_TRANSACCION',
'AND B.TRX_TRA_TRANSACCION = E.TRA_TRANSACCION',
'UNION ALL',
'SELECT TRA_EMP_EMPRESA,',
'        NULL TRX_TRANSACCION,',
'        TRA_TRANSACCION TRA_TRANSACCION,',
'        TRA_FECHA,',
'        TRA_FACTURA,',
'                      DECODE (tra_tipo,',
'                 ''CRE'',',
'                 ''CREDITO'',',
'                 ''CON'',',
'                 ''CONTADO'',',
'                 ''FIN'',',
'                 ''FINANCIAMIENTO'',',
'                 ''NIT'',',
'                 ''NOTA INTERNA'')',
'            tipo, ',
'        TRA_SUB_SUBSISTEMA,',
'        TRA_TTR_TIPO,',
'        TRA_DOC_DOCUMENTO,',
'        tra_ven_vendedor codigo_vendedor,',
'        gnl_nombre_vendedor_vi (tra_emp_empresa,tra_ven_vendedor)',
'            nombre_vendedor,',
'        TRA_CLI_CLIENTE,',
'        TRA_NOMBRE,',
'        TRA_MON_MONEDA,',
'        NULL TRX_MONTO,',
'        CASE',
'            WHEN (:p151_moneda = ''ND'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               tra_subtotal / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               tra_subtotal * tra_valor_cambio',
'         END',
'            subtotal,',
'        TRA_IMPUESTO_VENTAS,',
'          CASE',
'            WHEN (:p151_moneda = ''ND'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               tra_descuento / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               tra_descuento * tra_valor_cambio',
'         END',
'            descuento,',
'            CASE',
'            WHEN (:p151_moneda = ''ND'')',
'            THEN',
'               tra_total',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               tra_total',
'            WHEN (tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               tra_total',
'            WHEN (tra_mon_moneda = :P151_MON_LOCAL AND :p151_moneda = ''EX'')',
'            THEN',
'               tra_total / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P151_MON_LOCAL AND :p151_moneda = ''LO'')',
'            THEN',
'               tra_total * tra_valor_cambio',
'         END Total_Factura,',
'        TRA_SUBTOTAL COMISION',
'FROM FAC_FACTURA_TB_NX',
'WHERE  INSTR ('':'' || :p151_empresa || '':'', '':'' || TRA_EMP_EMPRESA || '':'') > 0',
'AND TRA_FECHA BETWEEN :P151_INICIO AND to_date(:P151_FIN||'' 23:59'', ''dd/mm/rrrr hh24:mi'')',
'AND TRA_TTR_TIPO =''FACCON''',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P151_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14056196390943640748)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'JJIMENEZ'
,p_internal_uid=>9604540815166836
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056196897511640753)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056205451679641239)
,p_db_column_name=>'EMPRESA'
,p_display_order=>60
,p_column_identifier=>'CA'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056206254151641247)
,p_db_column_name=>'TIPO'
,p_display_order=>140
,p_column_identifier=>'CI'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056206571536641250)
,p_db_column_name=>'CLIENTE'
,p_display_order=>170
,p_column_identifier=>'CL'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056206777651641252)
,p_db_column_name=>'MONEDA'
,p_display_order=>190
,p_column_identifier=>'CN'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056206913579641253)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>200
,p_column_identifier=>'CO'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056207409308641258)
,p_db_column_name=>'FACTURA'
,p_display_order=>250
,p_column_identifier=>'CT'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056207454437641259)
,p_db_column_name=>'CODIGO_VENDEDOR'
,p_display_order=>260
,p_column_identifier=>'CU'
,p_column_label=>'Codigo vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056207551248641260)
,p_db_column_name=>'NOMBRE_VENDEDOR'
,p_display_order=>270
,p_column_identifier=>'CV'
,p_column_label=>'Nombre vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056207676740641261)
,p_db_column_name=>'IMPUESTO'
,p_display_order=>280
,p_column_identifier=>'CW'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14056207780935641262)
,p_db_column_name=>'COMISION'
,p_display_order=>290
,p_column_identifier=>'CX'
,p_column_label=>'Comision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057043581423526313)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>300
,p_column_identifier=>'CY'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058124549054120045)
,p_db_column_name=>'TRX_TRANSACCION'
,p_display_order=>310
,p_column_identifier=>'DB'
,p_column_label=>'Trx transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058124620583120046)
,p_db_column_name=>'TRA_TRANSACCION'
,p_display_order=>320
,p_column_identifier=>'DC'
,p_column_label=>'Tra transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058124651911120047)
,p_db_column_name=>'FECHA_TRANSACCION'
,p_display_order=>330
,p_column_identifier=>'DD'
,p_column_label=>'Fecha transaccion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058124788887120048)
,p_db_column_name=>'SUBSISTEMA'
,p_display_order=>340
,p_column_identifier=>'DE'
,p_column_label=>'Subsistema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058124932233120049)
,p_db_column_name=>'TIPO_FACTURA'
,p_display_order=>350
,p_column_identifier=>'DF'
,p_column_label=>'Tipo factura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058125005193120050)
,p_db_column_name=>'TRA_NOMBRE'
,p_display_order=>360
,p_column_identifier=>'DG'
,p_column_label=>'Tra nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058125125063120051)
,p_db_column_name=>'TRX_MONTO'
,p_display_order=>370
,p_column_identifier=>'DH'
,p_column_label=>'Trx monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058125209245120052)
,p_db_column_name=>'TOTAL_FACTURA'
,p_display_order=>380
,p_column_identifier=>'DI'
,p_column_label=>'Total factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14056271345192764834)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'96795'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMPRESA:DOCUMENTO:FACTURA:CODIGO_VENDEDOR:NOMBRE_VENDEDOR:MONEDA:TIPO:SUBTOTAL:IMPUESTO:DESCUENTO:COMISION::TRX_TRANSACCION:TRA_TRANSACCION:FECHA_TRANSACCION:SUBSISTEMA:TIPO_FACTURA:TRA_NOMBRE:TRX_MONTO:TOTAL_FACTURA'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14057058266580620471)
,p_report_id=>wwv_flow_api.id(14056271345192764834)
,p_name=>'Row text contains ''141002'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'141002'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14056204264051641227)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14056205292495641237)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14056204484784641229)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14049590877938675018)
,p_button_name=>'RESTABLECER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Restablecer'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14056204557759641230)
,p_name=>'P151_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14056205292495641237)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14056204785724641232)
,p_name=>'P151_INICIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14056205292495641237)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14056204944621641233)
,p_name=>'P151_FIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14056205292495641237)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14056205114842641235)
,p_name=>'P151_TRANSACCION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14056205292495641237)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14056205388733641238)
,p_name=>'P151_MONEDA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14056205292495641237)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:No Definida;ND,Local;LO,Alterna;EX'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14056573564740690321)
,p_name=>'P151_MON_LOCAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14056205292495641237)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14056573839659690323)
,p_computation_sequence=>10
,p_computation_item=>'P151_MON_LOCAL'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VALOR',
'FROM GNL_PARAMETRO_EMPRESA_TB_NX',
'WHERE INSTR ('':'' || :p151_empresa || '':'', '':'' || EMPRESA || '':'') > 0',
'AND PARAMETRO = ''MONEDA''',
'AND SUBSISTEMA= ''CGL''',
'GROUP BY VALOR'))
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966308891634995407)
,p_validation_name=>'MONEDA_EMPRESA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P151_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P151_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P151_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P151_EMPRESA,''[^:]+'', 1, level) is not null;',
'             ',
'IF (cantidad_local_v > 1 AND :P151_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
'',
'IF (cantidad_alt_v > 1 AND :P151_MONEDA = ''A'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
'',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_api.id(14056204264051641227)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
