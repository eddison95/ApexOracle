prompt --application/pages/page_00072
begin
--   Manifest
--     PAGE: 00072
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>72
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GNL - Explorador de Sesiones'
,p_step_title=>'Explorador de Sesiones'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104160546'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094314315792420499)
,p_plug_name=>'Explorador de Sesiones'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094448936582293207)
,p_plug_name=>'Explorador de Sesiones'
,p_parent_plug_id=>wwv_flow_api.id(14094314315792420499)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT null ses_disconnect_session,',
'       username ses_usuario,',
'       status ses_estado,',
'       blocking_session ses_bloqueado_por,',
'       program ses_programa,',
'       client_info ses_informacion,',
'       machine ses_equipo,',
'       osuser ses_usuario_so,',
'       server ses_servidor,',
'       terminal ses_terminal,',
'       TYPE ses_tipo,',
'       module ses_modulo,',
'       schemaname ses_esquema,',
'       logon_time ses_tiempo_sesion,',
'       sid ses_id,',
'       serial# ses_serial',
'FROM v$session',
'WHERE TYPE = ''USER''',
'ORDER BY 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14094449100230293208)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>6705375458404114
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094449216936293209)
,p_db_column_name=>'SES_DISCONNECT_SESSION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Desconectar'
,p_column_link=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:RP:P72_SID,P72_SERIAL:#SES_ID#,#SES_SERIAL#'
,p_column_linktext=>'<button type="button">Desconectar</button> '
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094449303235293210)
,p_db_column_name=>'SES_USUARIO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094449381733293211)
,p_db_column_name=>'SES_ESTADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094449494363293212)
,p_db_column_name=>'SES_BLOQUEADO_POR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bloqueado Por'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094449616409293213)
,p_db_column_name=>'SES_PROGRAMA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Programa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094449648315293214)
,p_db_column_name=>'SES_INFORMACION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Informacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094449778885293215)
,p_db_column_name=>'SES_EQUIPO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Equipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094449833260293216)
,p_db_column_name=>'SES_USUARIO_SO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Usuario SO'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094450006037293217)
,p_db_column_name=>'SES_SERVIDOR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Servidor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094450042083293218)
,p_db_column_name=>'SES_TERMINAL'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Terminal'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094450137040293219)
,p_db_column_name=>'SES_TIPO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094450295788293220)
,p_db_column_name=>'SES_MODULO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Modulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094450351354293221)
,p_db_column_name=>'SES_ESQUEMA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Esquema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094450446489293222)
,p_db_column_name=>'SES_TIEMPO_SESION'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Tempo Sesion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094450622292293223)
,p_db_column_name=>'SES_ID'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094450703281293224)
,p_db_column_name=>'SES_SERIAL'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Serial'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14094483509955532664)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'67398'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SES_DISCONNECT_SESSION:SES_USUARIO:SES_ESTADO:SES_BLOQUEADO_POR:SES_PROGRAMA:SES_INFORMACION:SES_EQUIPO:SES_USUARIO_SO:SES_SERVIDOR:SES_TERMINAL:SES_TIPO:SES_MODULO:SES_ESQUEMA:SES_TIEMPO_SESION:SES_ID:SES_SERIAL:'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094314472978420501)
,p_name=>'P72_SID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14094314315792420499)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094314607633420502)
,p_name=>'P72_SERIAL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14094314315792420499)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14096300290370424235)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'KillSession'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'EXECUTE IMMEDIATE ''ALTER SYSTEM KILL SESSION ''',
'                  ||''''''''',
'                  || :P72_SID ||'',''|| :P72_SERIAL ',
'                  ||''''''''',
'                  || '' IMMEDIATE'';',
'EXCEPTION',
'WHEN OTHERS THEN',
'NULL;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P72_SID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.component_end;
end;
/
