prompt --application/pages/page_00156
begin
--   Manifest
--     PAGE: 00156
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>156
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GNL - Carga Pedidos'
,p_step_title=>'Carga Pedidos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165831'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14109677680505359048)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14099488772412417636)
,p_plug_name=>'Archivo'
,p_parent_plug_id=>wwv_flow_api.id(14109677680505359048)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14099488979344417639)
,p_plug_name=>'Datos'
,p_parent_plug_id=>wwv_flow_api.id(14109677680505359048)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT seq_id, ',
'       c001, c002, c003, c004, c005, c006, c007, c008, c009, c010, c011, c012, c013, c014, c015, c016, c017, c018, c019, c020, ',
'       c021, c022, c023, c024, c025, c026, c027, c028, c029, c030, c031, c032, c033, c034, c035, c036, c037, c038, c039, c040,',
'       c041, c042, c043, c044, c045, c046, c047, c048, c049, c050',
'FROM APEX_COLLECTIONS',
'WHERE COLLECTION_NAME = ''P156_PEDIDO'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P156_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14099489111538417640)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>52897261409943728
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057508050411081478)
,p_db_column_name=>'C001'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057508403203081488)
,p_db_column_name=>'C002'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057508835151081489)
,p_db_column_name=>'C003'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057509232899081490)
,p_db_column_name=>'C004'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057509573428081491)
,p_db_column_name=>'C005'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057510046547081491)
,p_db_column_name=>'C006'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057510401767081491)
,p_db_column_name=>'C007'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057510828981081492)
,p_db_column_name=>'C008'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057511235422081493)
,p_db_column_name=>'C009'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Especial'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057511626956081494)
,p_db_column_name=>'C010'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Dcto Aparte'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057512045338081494)
,p_db_column_name=>'C011'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057512429362081494)
,p_db_column_name=>'C012'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057512766224081495)
,p_db_column_name=>'C013'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Cantidad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057513188804081495)
,p_db_column_name=>'C014'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Descuento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057513625763081495)
,p_db_column_name=>'C015'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'% Exoneracion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057513978298081496)
,p_db_column_name=>'C016'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'U. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057514384101081496)
,p_db_column_name=>'C017'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'C017'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057514814828081496)
,p_db_column_name=>'C018'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'C018'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057515208058081497)
,p_db_column_name=>'C019'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'C019'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057515609157081497)
,p_db_column_name=>'C020'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'C020'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057515957641081497)
,p_db_column_name=>'C021'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'C021'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057516426705081498)
,p_db_column_name=>'C022'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'C022'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057516809586081498)
,p_db_column_name=>'C023'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'C023'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057517217954081498)
,p_db_column_name=>'C024'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'C024'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057517575780081499)
,p_db_column_name=>'C025'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'C025'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057517962666081499)
,p_db_column_name=>'C026'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'C026'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057518394033081499)
,p_db_column_name=>'C027'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'C027'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057518782325081500)
,p_db_column_name=>'C028'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'C028'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057519184711081500)
,p_db_column_name=>'C029'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'C029'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057519635926081500)
,p_db_column_name=>'C030'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'C030'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057519991714081501)
,p_db_column_name=>'C031'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'C031'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057520377789081501)
,p_db_column_name=>'C032'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'C032'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057520759457081502)
,p_db_column_name=>'C033'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'C033'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057521209466081502)
,p_db_column_name=>'C034'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'C034'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057521622503081503)
,p_db_column_name=>'C035'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'C035'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057522040201081503)
,p_db_column_name=>'C036'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'C036'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057522440723081503)
,p_db_column_name=>'C037'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'C037'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057522755166081504)
,p_db_column_name=>'C038'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'C038'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057523183867081504)
,p_db_column_name=>'C039'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'C039'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057523602807081504)
,p_db_column_name=>'C040'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'C040'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057524002530081505)
,p_db_column_name=>'C041'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'C041'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057524439811081505)
,p_db_column_name=>'C042'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'C042'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057524847593081505)
,p_db_column_name=>'C043'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'C043'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057525184764081506)
,p_db_column_name=>'C044'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'C044'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057525636759081506)
,p_db_column_name=>'C045'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'C045'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057526026030081506)
,p_db_column_name=>'C046'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'C046'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057526380000081507)
,p_db_column_name=>'C047'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'C047'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057526847906081508)
,p_db_column_name=>'C048'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'C048'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057527220560081508)
,p_db_column_name=>'C049'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'C049'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057527553469081508)
,p_db_column_name=>'C050'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'C050'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057527972133081509)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fila'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14100092380500305251)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'109365'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004:C005:C006:C007:C008:C009:C010:C011:C012:C013:C014:C015:C016:C017:C018:C019:C020:C021:C022:C023:C024:C025:C026:C027:C028:C029:C030:C031:C032:C033:C034:C035:C036:C037:C038:C039:C040:C041:C042:C043:C044:C045:C046:C047:C048:C04'
||'9:C050:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14100074185467262143)
,p_plug_name=>'Plantilla'
,p_parent_plug_id=>wwv_flow_api.id(14109677680505359048)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'gnl_carga_nx.pla_pedido_pr;'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P156_PLANTILLA'
,p_plug_display_when_cond2=>'S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14057529791887081559)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14099488772412417636)
,p_button_name=>'CARGAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cargar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14057528844010081548)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14099488979344417639)
,p_button_name=>'PROCESAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Procesar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14057506974164081423)
,p_name=>'P156_EMPRESA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14109677680505359048)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14057507418373081449)
,p_name=>'P156_PLANTILLA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14109677680505359048)
,p_item_default=>'N'
,p_prompt=>'Plantilla'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:SI;S,NO;N'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14057530157512081560)
,p_name=>'P156_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14099488772412417636)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14057530596627081612)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'cargar_pr'
,p_attribute_01=>'P156_ARCHIVO'
,p_attribute_02=>'P156_PEDIDO'
,p_attribute_04=>';'
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14057529791887081559)
,p_process_success_message=>'Carga Completa'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14057530903083081624)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'procesar_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    pedido_v    fac_consulta_tb_nx%rowtype;',
'    detpedido_v fac_detalle_consulta_tb_nx%rowtype;',
'    consulta_v  fac_consulta_tb_nx.enc_consulta%type;',
'BEGIN',
'    gnl_carga_nx.ac_pedido_pr(:p156_empresa);',
'    /*FOR a IN (',
'        SELECT',
'            c001, c002, c003, ',
'            c004, c005, c006, ',
'            c007, c008, c009,',
'            c010, c011',
'        FROM',
'            apex_collections',
'        WHERE',
'            collection_name = ''P156_PEDIDO''',
'        GROUP BY',
'            c001, c002, c003, ',
'            c004, c005, c006, ',
'            c007, c008, c009,',
'            c010, c011',
'        ORDER BY',
'            1, 2, 3, 4, 5, 6, 7',
'    ) LOOP',
'        pedido_v.enc_emp_empresa := :p156_empresa;',
'        pedido_v.enc_consulta := NULL;',
'        pedido_v.enc_fecha := SYSDATE;',
'        pedido_v.enc_lcn_localizacion := a.c001;',
'        pedido_v.enc_lpo_lista := a.c002;',
'        pedido_v.enc_mon_moneda := a.c006;',
'        pedido_v.enc_ven_vendedor := a.c003;',
'        pedido_v.creado_por := :app_user;',
'        pedido_v.fecha_creacion := sysdate;',
'        pedido_v.modificado_por := :app_user;',
'        pedido_v.fecha_modificacion := sysdate;',
'        pedido_v.enc_tipo := a.c004;',
'        pedido_v.enc_cli_cliente := a.c005;',
'        pedido_v.enc_cli_mon_moneda := a.c006;',
'        pedido_v.enc_dep_departamento := a.c007;',
'        pedido_v.enc_status := ''C'';',
'        pedido_v.enc_pedido := NULL;',
'        pedido_v.enc_tpe_tipo := NULL;',
'        pedido_v.enc_mod_modelo := NULL;',
'        pedido_v.enc_telefono_contacto := NULL;',
'        pedido_v.enc_email_contacto := NULL;',
'        pedido_v.enc_observaciones := a.c008;',
'        pedido_v.enc_pedido_especial := a.c009;',
'        pedido_v.enc_scm_solicitud_compra := NULL;',
'        pedido_v.enc_rec_numero_recibo := NULL;',
'        pedido_v.enc_adelanto := NULL;',
'        pedido_v.enc_mpg_consecutivo := NULL;',
'        pedido_v.enc_cat_categoria := NULL;',
'        pedido_v.enc_impuesto := 0;',
'        pedido_v.enc_descuento := 0;',
'        pedido_v.enc_porc_exento := 0;',
'        pedido_v.enc_nombre := NULL;',
'        pedido_v.enc_documento := NULL;        ',
'        pedido_v.enc_pedido_web := NULL;',
'        pedido_v.enc_desc_aparte := a.c010;        ',
'        pedido_v.enc_orden_compra := a.c011;',
'        pedido_v.enc_descuento_aparte := 0;',
'        pedido_v.enc_sexo := ''N'';',
'        pedido_v.enc_fed_id := NULL;',
'        pedido_v.enc_ven_autoriza := NULL;',
'        pedido_v.enc_autorizada_cxc := NULL;',
'        pedido_v.enc_usuario_autorizada_cxc := NULL;',
'        pedido_v.enc_fecha_autorizada_cxc := NULL;',
'        pedido_v.enc_premio := ''N'';',
'        pedido_v.enc_caj_caja := NULL;',
'        pedido_v.enc_bco_banco := NULL;',
'        pedido_v.enc_ind_cedida := NULL;',
'        pedido_v.enc_per_persona := NULL;',
'        pedido_v.enc_concurso := NULL;',
'        pedido_v.enc_ref_cli_cliente := NULL;',
'        pedido_v.enc_ref_cli_mon_moneda := NULL;',
'        pedido_v.enc_tipo_pago := NULL;',
'        pedido_v.enc_ind_retencion_iva := NULL;',
'        consulta_v := gnl_carga_nx.pedido_n(pedido_v);',
'        ',
'        FOR b IN (',
'            SELECT',
'                seq_id,',
'                c012, c013, c014, c015, c016',
'            FROM',
'                apex_collections',
'            WHERE',
'                collection_name = ''P156_PEDIDO''',
'                AND c005 = a.c005',
'                AND c006 = a.c006',
'                AND c011 = a.c011',
'            ORDER BY',
'                seq_id',
'        ) LOOP',
'           detpedido_v.deo_emp_empresa := pedido_v.enc_emp_empresa;',
'           detpedido_v.deo_enc_consulta := consulta_v;',
'           detpedido_v.deo_linea := NULL;',
'           detpedido_v.deo_ato_articulo := b.c012;',
'           detpedido_v.deo_cantidad := b.c013;',
'           detpedido_v.deo_marcado := ''S'';',
'           detpedido_v.deo_indicador := ''N'';',
'           detpedido_v.deo_despachado := 0;',
'           detpedido_v.deo_backorder := 0;',
'           detpedido_v.deo_status := ''C'';',
'           detpedido_v.deo_peso := 0;',
'           detpedido_v.deo_descuento := b.c014;           ',
'           detpedido_v.deo_impuesto := 0;',
'           detpedido_v.deo_precio := 0;',
'           detpedido_v.deo_lcn_localizacion := pedido_v.enc_lcn_localizacion;',
'           detpedido_v.deo_fecha_prestamo := NULL;                      ',
'           detpedido_v.deo_entrega := ''R'';       ',
'           detpedido_v.deo_ind_linea_bonificacion := ''N'';                      ',
'           detpedido_v.deo_ind_linea_bonificada := ''N'';       ',
'           detpedido_v.deo_com_id := NULL;                      ',
'           detpedido_v.deo_bonificacion := 0;       ',
'           detpedido_v.deo_descripcion := NULL;                      ',
'           detpedido_v.deo_descuento_aparte := 0;       ',
'           detpedido_v.deo_ord_orden_interna := NULL;                      ',
'           detpedido_v.deo_ind_feria_desc := ''N'';       ',
'           detpedido_v.deo_bqd_id := NULL;                      ',
'           detpedido_v.deo_impuesto_otro := 0;       ',
'           detpedido_v.deo_porc_exo_imp := 0;                      ',
'           detpedido_v.deo_porc_exo_oim := 0;       ',
'           detpedido_v.deo_porc_exoneracion := b.c015;                      ',
'           detpedido_v.deo_med_medida := b.c016;                  ',
'           gnl_carga_nx.detpedido_pr(detpedido_v);',
'        END LOOP;',
'        ',
'        fac_calcula_pedido_pr_nx(consulta_v, ''S'');',
'        COMMIT;        ',
'    END LOOP;*/',
'    ',
'    apex_collection.truncate_collection(''P156_PEDIDO'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14056574555061690331)
,p_process_success_message=>'Proceso Terminado'
);
wwv_flow_api.component_end;
end;
/
