prompt --application/pages/page_00037
begin
--   Manifest
--     PAGE: 00037
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>37
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('GNL \2013 Activos Fijos')
,p_step_title=>'Activos Fijos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'MBACASE'
,p_last_upd_yyyymmddhh24miss=>'20210520091916'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096887634241859313)
,p_plug_name=>'Activos Fijos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167765721526072206)
,p_plug_name=>'Activos Fijos'
,p_parent_plug_id=>wwv_flow_api.id(14096887634241859313)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    act_emp_empresa                                                                        empresa,',
'    act_activo                                                                             activo,',
'    act_num_activo                                                                         num_activo,',
'    trunc(act_fecha_adquisicion)                                                           fecha_adquisicion,',
'    act_monto_adquisicion                                                                  monto_adquisicion,',
'    act_dep_acumu_fiscal                                                                   acumulado_fiscal,',
'    act_val_hist_fiscal                                                                    valor_historico_fiscal,',
'    act_val_hist_corp                                                                      valor_historico_corp,',
'    CASE',
'        WHEN act_monto_adquisicion <> 0 THEN',
'            CAST(act_dep_acumu_fiscal / act_monto_adquisicion * 100 AS DECIMAL(5, 2))',
'    END                                                                                    porcentaje_depreciado,',
'    act_corre_monetaria                                                                    correccion_monetaria,',
'    act_monto_deterioro_fis                                                                monto_deterioro_fiscal,',
'    act_monto_deterioro_cor                                                                monto_deterioro_corporativo,',
'    act_descripcion                                                                        descripcion,',
'    act_meses_vida_fiscal                                                                  meses_vida_util,',
'    act_pro_mon_moneda                                                                     moneda,',
'     CASE',
'        WHEN act_meses_vida_fiscal <> 0 THEN',
'    CAST((act_val_act_tot_fiscal / act_meses_vida_fiscal) / 12 AS DECIMAL(5, 2))  END      depreciacion_mensual_fiscal,',
'     CASE',
'        WHEN act_meses_vida_corp <> 0 THEN',
'    CAST((act_val_act_tot_corp / act_meses_vida_corp) / 12 AS DECIMAL(5, 2))    END        depreciacion_mensual_corporativa,',
'    act_dep_acumu_fiscal                                                                   depreciacion_acumulada_fiscal,',
'    act_dep_acumu_corp                                                                     depreciacion_acumulada_corporativo,',
'    act_dep_acumu_cm                                                                       valor_libros_cm,',
'    ( act_monto_adquisicion - act_dep_acumu_fiscal )                                         valor_libros,',
'    ( act_meses_vida_fiscal - act_meses_vida_rest_fiscal )                                   meses_depreciados,',
'    act_val_hist_fiscal                                                                    valor_total_neto,',
'    act_loc_localizacion                                                                   localizacion,',
'    act_status                                                                             estado,',
'    act_ubi_ubicacion                                                                      ubicacion,',
'    act_cac_tac_tipo                                                                       tipo,',
'    act_cac_clase                                                                          clase,',
'    act_valor_reposicion                                                                   reposicion,',
'    act_valor_rescate                                                                      rescate,',
'    act_reint_acumu_det_fis                                                                reintegro_deterioro_fiscal,',
'    act_reint_acumu_det_cor                                                                reintegro_deterioro_coporativo,',
'    act_valor_cambio                                                                       valor_cambio,',
'    act_val_act_tot_fiscal                                                                 valor_actual_total_fiscal,',
'    act_val_act_tot_corp                                                                   valor_actual_total_corp,',
'    act_met_deprecia_fiscal                                                                met_depre_fiscal,',
'    act_met_deprecia_corp                                                                  met_depre_corp',
'FROM',
'    afj_activo_tb_nx',
'WHERE INSTR ('':''||:P37_EMPRESA||'':'','':''||act_emp_empresa||'':'') > 0',
'   ORDER BY 1,2;',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P37_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14167765806096072206)
,p_name=>'Listado general de activos fijos'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'CANDERSON'
,p_internal_uid=>10651912684572906
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167766018079072209)
,p_db_column_name=>'EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167766209795072210)
,p_db_column_name=>'FECHA_ADQUISICION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fecha Adquisicion'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA_ADQUISICION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167766311318072210)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167766406505072211)
,p_db_column_name=>'MESES_VIDA_UTIL'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Meses Vida Util'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'MESES_VIDA_UTIL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167766513675072211)
,p_db_column_name=>'MONTO_ADQUISICION'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Monto Adquisicion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'MONTO_ADQUISICION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167766595753072212)
,p_db_column_name=>'MONEDA'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167767026150072213)
,p_db_column_name=>'VALOR_LIBROS'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Valor Libros'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'VALOR_LIBROS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167771714239169695)
,p_db_column_name=>'MESES_DEPRECIADOS'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Meses Depreciados'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'MESES_DEPRECIADOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885307788259783511)
,p_db_column_name=>'ACTIVO'
,p_display_order=>22
,p_column_identifier=>'M'
,p_column_label=>'Activo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885307905780783512)
,p_db_column_name=>'NUM_ACTIVO'
,p_display_order=>32
,p_column_identifier=>'N'
,p_column_label=>'Num Activo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885307997994783513)
,p_db_column_name=>'ACUMULADO_FISCAL'
,p_display_order=>42
,p_column_identifier=>'O'
,p_column_label=>'Acumulado Fiscal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308102095783514)
,p_db_column_name=>'VALOR_HISTORICO_FISCAL'
,p_display_order=>52
,p_column_identifier=>'P'
,p_column_label=>'Valor Historico Fiscal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308237749783515)
,p_db_column_name=>'VALOR_HISTORICO_CORP'
,p_display_order=>62
,p_column_identifier=>'Q'
,p_column_label=>'Valor Historico Corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308319094783516)
,p_db_column_name=>'PORCENTAJE_DEPRECIADO'
,p_display_order=>72
,p_column_identifier=>'R'
,p_column_label=>'Porcentaje Depreciado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308439778783517)
,p_db_column_name=>'CORRECCION_MONETARIA'
,p_display_order=>82
,p_column_identifier=>'S'
,p_column_label=>'Correccion Monetaria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308511158783518)
,p_db_column_name=>'MONTO_DETERIORO_FISCAL'
,p_display_order=>92
,p_column_identifier=>'T'
,p_column_label=>'Monto Deterioro Fiscal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308642926783519)
,p_db_column_name=>'MONTO_DETERIORO_CORPORATIVO'
,p_display_order=>102
,p_column_identifier=>'U'
,p_column_label=>'Monto Deterioro Corporativo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308730227783520)
,p_db_column_name=>'DEPRECIACION_MENSUAL_FISCAL'
,p_display_order=>112
,p_column_identifier=>'V'
,p_column_label=>'Depreciacion Mensual Fiscal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308833780783521)
,p_db_column_name=>'DEPRECIACION_MENSUAL_CORPORATIVA'
,p_display_order=>122
,p_column_identifier=>'W'
,p_column_label=>'Depreciacion Mensual Corporativa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308931745783522)
,p_db_column_name=>'DEPRECIACION_ACUMULADA_FISCAL'
,p_display_order=>132
,p_column_identifier=>'X'
,p_column_label=>'Depreciacion Acumulada Fiscal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885308982769783523)
,p_db_column_name=>'DEPRECIACION_ACUMULADA_CORPORATIVO'
,p_display_order=>142
,p_column_identifier=>'Y'
,p_column_label=>'Depreciacion Acumulada Corporativo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309128604783524)
,p_db_column_name=>'VALOR_LIBROS_CM'
,p_display_order=>152
,p_column_identifier=>'Z'
,p_column_label=>'Valor Libros Cm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309220886783525)
,p_db_column_name=>'VALOR_TOTAL_NETO'
,p_display_order=>162
,p_column_identifier=>'AA'
,p_column_label=>'Valor Total Neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309254384783526)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>172
,p_column_identifier=>'AB'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309361082783527)
,p_db_column_name=>'ESTADO'
,p_display_order=>182
,p_column_identifier=>'AC'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309489468783528)
,p_db_column_name=>'UBICACION'
,p_display_order=>192
,p_column_identifier=>'AD'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309629250783529)
,p_db_column_name=>'TIPO'
,p_display_order=>202
,p_column_identifier=>'AE'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309674098783530)
,p_db_column_name=>'CLASE'
,p_display_order=>212
,p_column_identifier=>'AF'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309797787783531)
,p_db_column_name=>'REPOSICION'
,p_display_order=>222
,p_column_identifier=>'AG'
,p_column_label=>'Reposicion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309937948783532)
,p_db_column_name=>'RESCATE'
,p_display_order=>232
,p_column_identifier=>'AH'
,p_column_label=>'Rescate'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885309966391783533)
,p_db_column_name=>'REINTEGRO_DETERIORO_FISCAL'
,p_display_order=>242
,p_column_identifier=>'AI'
,p_column_label=>'Reintegro Deterioro Fiscal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885310100370783534)
,p_db_column_name=>'REINTEGRO_DETERIORO_COPORATIVO'
,p_display_order=>252
,p_column_identifier=>'AJ'
,p_column_label=>'Reintegro Deterioro Coporativo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885310214666783535)
,p_db_column_name=>'VALOR_CAMBIO'
,p_display_order=>262
,p_column_identifier=>'AK'
,p_column_label=>'Valor Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885310268679783536)
,p_db_column_name=>'VALOR_ACTUAL_TOTAL_FISCAL'
,p_display_order=>272
,p_column_identifier=>'AL'
,p_column_label=>'Valor Actual Total Fiscal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885310370851783537)
,p_db_column_name=>'VALOR_ACTUAL_TOTAL_CORP'
,p_display_order=>282
,p_column_identifier=>'AM'
,p_column_label=>'Valor Actual Total Corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885327881733816388)
,p_db_column_name=>'MET_DEPRE_FISCAL'
,p_display_order=>292
,p_column_identifier=>'AN'
,p_column_label=>'Met Depre Fiscal'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885327991833816389)
,p_db_column_name=>'MET_DEPRE_CORP'
,p_display_order=>302
,p_column_identifier=>'AO'
,p_column_label=>'Met Depre Corp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14167767118879072881)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'106533'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5000
,p_report_columns=>'EMPRESA:NUM_ACTIVO:ACTIVO:DESCRIPCION:LOCALIZACION:UBICACION:TIPO:CLASE:MET_DEPRE_FISCAL:MET_DEPRE_CORP:FECHA_ADQUISICION:MESES_VIDA_UTIL:MONEDA:VALOR_CAMBIO:MONTO_ADQUISICION:DEPRECIACION_MENSUAL_FISCAL:DEPRECIACION_MENSUAL_CORPORATIVA:DEPRECIACION_'
||'ACUMULADA_FISCAL:DEPRECIACION_ACUMULADA_CORPORATIVO:MESES_DEPRECIADOS:PORCENTAJE_DEPRECIADO:CORRECCION_MONETARIA:MONTO_DETERIORO_FISCAL:MONTO_DETERIORO_CORPORATIVO:REINTEGRO_DETERIORO_FISCAL:REINTEGRO_DETERIORO_COPORATIVO:RESCATE:REPOSICION:VALOR_HIS'
||'TORICO_FISCAL:VALOR_HISTORICO_CORP:VALOR_ACTUAL_TOTAL_FISCAL:VALOR_ACTUAL_TOTAL_CORP:ESTADO:VALOR_LIBROS:VALOR_TOTAL_NETO:VALOR_LIBROS_CM:ACUMULADO_FISCAL:'
,p_sum_columns_on_break=>'MONTO_ADQUISICION:DEPRECIACION_MENSUAL_FISCAL:DEPRECIACION_MENSUAL_CORPORATIVA:MESES_DEPRECIADOS:PORCENTAJE_DEPRECIADO:MONTO_DETERIORO_FISCAL:MONTO_DETERIORO_CORPORATIVO:REINTEGRO_DETERIORO_FISCAL:REINTEGRO_DETERIORO_COPORATIVO:RESCATE:REPOSICION:VAL'
||'OR_HISTORICO_FISCAL:VALOR_HISTORICO_CORP:VALOR_ACTUAL_TOTAL_FISCAL:VALOR_ACTUAL_TOTAL_CORP:VALOR_LIBROS:VALOR_TOTAL_NETO:VALOR_LIBROS_CM:ACUMULADO_FISCAL:DEPRECIACION_ACUMULADA_FISCAL:DEPRECIACION_ACUMULADA_CORPORATIVO:CORRECCION_MONETARIA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096888020374859314)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14096887634241859313)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096888399811859315)
,p_name=>'P37_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096887634241859313)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
