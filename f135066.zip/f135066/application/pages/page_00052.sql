prompt --application/pages/page_00052
begin
--   Manifest
--     PAGE: 00052
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>52
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('COM \2013 Compras')
,p_step_title=>'Compras'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164112'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167922600242736663)
,p_plug_name=>'Compras'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167925900949773332)
,p_plug_name=>'Compras'
,p_parent_plug_id=>wwv_flow_api.id(14167922600242736663)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 15/02/2017 03:17:57 p.m. (QP5 v5.115.810.9015) */',
'  SELECT   ced_emp_empresa,',
'           ced_etapa,',
'           TRUNC (ced_fecha) ced_fecha,',
'           ced_num_doc,',
'           ced_doc_documento,',
'           ded_tet_tipo,',
'           ced_pro_proveedor,',
'           ced_pro_mon_moneda,',
'           cxp_nombre_prov_v_nx (ced_pro_emp_empresa,',
'                                 ced_pro_proveedor,',
'                                 ced_pro_mon_moneda)',
'              ced_nombre,',
'           ced_ttm_tipo,',
'           ttm_descripcion,',
'           NULL loc_id,',
'           NULL loc_descrip,',
'           NVL (ced_monto, 0) ced_subtotal,',
'           NVL (ced_descuento, 0) ced_descuento,',
'           NVL (ced_iva, 0) ced_impuesto,',
'           NVL (ced_otros_impuestos, 0) ced_otros_impuestos,',
'             NVL (ced_monto, 0)',
'           - NVL (ced_descuento, 0)',
'           + NVL (ced_iva, 0)',
'           + NVL (ced_otros_impuestos, 0)',
'           + NVL (ced_monto_no_aplicable, 0)',
'           - NVL (ced_retencion, 0)',
'           - NVL (ced_retencion_ica, 0)',
'           - NVL (ced_retencion_iva, 0)',
'              ced_total,',
'           DECODE (',
'              cxp_impuesto_prov_v_nx (ced_pro_emp_empresa,',
'                                      ced_pro_proveedor,',
'                                      ced_pro_mon_moneda),',
'              ''N'',',
'              ''NO'',',
'              ''S'',',
'              ''SI''',
'           )',
'              ind_impuesto,',
'           CED_CREADO_POR creado_por,',
'           CED_FECHA_CREACION fecha_creacion',
'    FROM   com_etapa_despacho_tb_nx,',
'           com_det_etapa_despacho_tb_nx,',
'           com_tipo_transaccion_tb_nx',
'   WHERE       ced_etapa = ded_ced_etapa',
'           AND ced_accion = ''F''',
'           AND ced_status <> ''C''',
'           AND ced_pro_mon_moneda =',
'                 gnl_parametro_emp_v_nx (ced_emp_empresa, ''CGL'', ''MONEDA'')',
'           AND ced_ttm_tipo = ttm_tipo',
'           AND ced_emp_empresa = ttm_emp_empresa',
'           AND INSTR ('':'' || :p52_empresa || '':'',',
'                      '':'' || ced_emp_empresa || '':'') > 0',
'           AND ced_fecha BETWEEN :p52_inicio',
'                             AND  TO_DATE (:p52_fin || '' 23:59'',',
'                                           ''dd/mm/rrrr hh24:mi'')',
'GROUP BY   ced_emp_empresa,',
'           ced_etapa,',
'           ced_fecha,',
'           ced_num_doc,',
'           ced_doc_documento,',
'           ded_tet_tipo,',
'           ced_pro_emp_empresa,',
'           ced_pro_proveedor,',
'           ced_pro_mon_moneda,',
'           ced_ttm_tipo,',
'           ttm_descripcion,',
'           ced_monto,',
'           ced_descuento,',
'           ced_iva,',
'           ced_otros_impuestos,',
'           ced_monto,',
'           ced_descuento,',
'           ced_iva,',
'           ced_otros_impuestos,',
'           ced_monto_no_aplicable,',
'           ced_retencion,',
'           ced_retencion_ica,',
'           ced_retencion_iva,',
'           CED_CREADO_POR,',
'           CED_FECHA_CREACION ',
'UNION ALL',
'  SELECT   ced_emp_empresa,',
'           ced_etapa,',
'           TRUNC (ced_fecha) ced_fecha,',
'           ced_num_doc,',
'           ced_doc_documento,',
'           ded_tet_tipo,',
'           ced_pro_proveedor,',
'           ced_pro_mon_moneda,',
'           cxp_nombre_prov_v_nx (ced_pro_emp_empresa,',
'                                 ced_pro_proveedor,',
'                                 ced_pro_mon_moneda)',
'              ced_nombre,',
'           ced_ttm_tipo,',
'           ttm_descripcion,',
'           NULL loc_id,',
'           NULL loc_descrip,',
'           SUM (epf_costo * epf_cantidad) ced_subtotal,',
'           0 ced_descuento,',
'           0 ced_impuesto,',
'           0 ced_otros_impuestos,',
'           SUM (epf_costo * epf_cantidad) ced_total,',
'           DECODE (',
'              cxp_impuesto_prov_v_nx (ced_pro_emp_empresa,',
'                                      ced_pro_proveedor,',
'                                      ced_pro_mon_moneda),',
'              ''N'',',
'              ''NO'',',
'              ''S'',',
'              ''SI''',
'           )',
'              ind_impuesto,',
'           CED_CREADO_POR creado_por,',
'           CED_FECHA_CREACION fecha_creacion',
'    FROM   com_etapa_despacho_tb_nx,',
'           com_det_etapa_despacho_tb_nx,',
'           com_det_etapa_tarifa_tb_nx,',
'           com_tipo_transaccion_tb_nx',
'   WHERE       ced_etapa = ded_ced_etapa',
'           AND ced_accion = ''F''',
'           AND ced_status IN (''R'', ''P'')',
'           AND ded_id = epf_ded_id',
'           AND ced_pro_mon_moneda =',
'                 gnl_parametro_emp_v_nx (ced_emp_empresa,',
'                                         ''GNL'',',
'                                         ''MONEDA CONVERSION'')',
'           AND ced_ttm_tipo = ttm_tipo',
'           AND ced_emp_empresa = ttm_emp_empresa',
'           AND INSTR ('':'' || :p52_empresa || '':'',',
'                      '':'' || ced_emp_empresa || '':'') > 0',
'           AND ced_fecha BETWEEN :p52_inicio',
'                             AND  TO_DATE (:p52_fin || '' 23:59'',',
'                                           ''dd/mm/rrrr hh24:mi'')',
'GROUP BY   ced_emp_empresa,',
'           ced_etapa,',
'           ced_fecha,',
'           ced_num_doc,',
'           ced_doc_documento,',
'           ded_tet_tipo,',
'           ced_pro_emp_empresa,',
'           ced_pro_proveedor,',
'           ced_pro_mon_moneda,',
'           ced_ttm_tipo,',
'           ttm_descripcion,',
'           CED_CREADO_POR,',
'           CED_FECHA_CREACION',
'UNION ALL',
'SELECT   ent_emp_empresa_entrega,',
'         ent_entrega,',
'         TRUNC (ent_fecha) ent_fecha,',
'         ent_num_doc_proveedor,',
'         ent_doc_documento,',
'         ''LOCAL'',',
'         ent_pro_proveedor,',
'         ent_pro_mon_moneda,',
'         cxp_nombre_prov_v_nx (ent_pro_emp_empresa,',
'                               ent_pro_proveedor,',
'                               ent_pro_mon_moneda)',
'            ent_nombre,',
'         ent_ttm_tipo,',
'         ttm_descripcion,',
'         ent_lcn_localizacion,',
'         inv_descrip_loca_v_nx (ent_lcn_emp_empresa, ent_lcn_localizacion)',
'            loc_descrip,',
'         ent_subtotal,',
'         ent_descuento,',
'         ent_impuesto_ventas,',
'         ent_otros_impuestos,',
'         ent_total,',
'         DECODE (',
'            cxp_impuesto_prov_v_nx (ent_pro_emp_empresa,',
'                                    ent_pro_proveedor,',
'                                    ent_pro_mon_moneda),',
'            ''N'',',
'            ''NO'',',
'            ''S'',',
'            ''SI''',
'         )',
'            ind_impuesto,',
'         ENT_CREADO_POR,',
'         ENT_FECHA_CREACION',
'  FROM   com_entrega_tb_nx, com_tipo_transaccion_tb_nx',
' WHERE       ent_tipo_entrega = ''L''',
'         AND ent_status IN (''T'', ''P'')',
'         AND ent_ttm_tipo = ttm_tipo',
'         AND ent_emp_empresa_entrega = ttm_emp_empresa',
'         AND INSTR ('':'' || :p52_empresa || '':'',',
'                    '':'' || ent_emp_empresa_entrega || '':'') > 0',
'         AND ent_fecha BETWEEN :p52_inicio',
'                           AND  TO_DATE (:p52_fin || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P52_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14167925994418773333)
,p_name=>'Compras'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>10812101007274033
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167926197689773362)
,p_db_column_name=>'CED_ETAPA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Etapa / Entrega'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CED_ETAPA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167926307052773362)
,p_db_column_name=>'CED_FECHA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'CED_FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167926402476773363)
,p_db_column_name=>'CED_DOC_DOCUMENTO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_static_id=>'CED_DOC_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167926497244773364)
,p_db_column_name=>'DED_TET_TIPO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'DED_TET_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167926604634773364)
,p_db_column_name=>'CED_PRO_PROVEEDOR'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'CED_PRO_PROVEEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167926700438773364)
,p_db_column_name=>'CED_PRO_MON_MONEDA'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'CED_PRO_MON_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167926816229773365)
,p_db_column_name=>'CED_NOMBRE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'CED_NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112719557948890251)
,p_db_column_name=>'CED_NUM_DOC'
,p_display_order=>8
,p_column_identifier=>'M'
,p_column_label=>'# Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CED_NUM_DOC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167926916790773365)
,p_db_column_name=>'CED_SUBTOTAL'
,p_display_order=>9
,p_column_identifier=>'H'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'CED_SUBTOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167927003249773366)
,p_db_column_name=>'CED_DESCUENTO'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'CED_DESCUENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167927108299773366)
,p_db_column_name=>'CED_IMPUESTO'
,p_display_order=>11
,p_column_identifier=>'J'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'CED_IMPUESTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167927200507773366)
,p_db_column_name=>'CED_OTROS_IMPUESTOS'
,p_display_order=>12
,p_column_identifier=>'K'
,p_column_label=>'Otros Impuestos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'CED_OTROS_IMPUESTOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167927322004773367)
,p_db_column_name=>'CED_TOTAL'
,p_display_order=>13
,p_column_identifier=>'L'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'CED_TOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095028130528628808)
,p_db_column_name=>'CED_TTM_TIPO'
,p_display_order=>23
,p_column_identifier=>'N'
,p_column_label=>unistr('Tipo Transacci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095028305585628809)
,p_db_column_name=>'TTM_DESCRIPCION'
,p_display_order=>33
,p_column_identifier=>'O'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095028415199628810)
,p_db_column_name=>'LOC_ID'
,p_display_order=>43
,p_column_identifier=>'P'
,p_column_label=>'Id Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095028492554628811)
,p_db_column_name=>'LOC_DESCRIP'
,p_display_order=>53
,p_column_identifier=>'Q'
,p_column_label=>'Desc Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098668171280192103)
,p_db_column_name=>'IND_IMPUESTO'
,p_display_order=>63
,p_column_identifier=>'R'
,p_column_label=>'Impuesto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098668804212192109)
,p_db_column_name=>'CED_EMP_EMPRESA'
,p_display_order=>73
,p_column_identifier=>'S'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082582721353100316)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>83
,p_column_identifier=>'T'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082582834488100317)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>93
,p_column_identifier=>'U'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14167927401988773637)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'108136'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CED_EMP_EMPRESA:CED_ETAPA:CED_FECHA:CED_DOC_DOCUMENTO:DED_TET_TIPO:CED_PRO_PROVEEDOR:CED_PRO_MON_MONEDA:CED_NOMBRE:CED_TTM_TIPO:TTM_DESCRIPCION:LOC_ID:LOC_DESCRIP:CED_NUM_DOC:CED_SUBTOTAL:CED_DESCUENTO:CED_TOTAL:IND_IMPUESTO::CREADO_POR:FECHA_CREACIO'
||'N'
,p_sum_columns_on_break=>'CED_SUBTOTAL:CED_DESCUENTO:CED_IMPUESTO:CED_OTROS_IMPUESTOS:CED_TOTAL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168179097378813960)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14167922600242736663)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167922818168736665)
,p_name=>'P52_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14167922600242736663)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167923913839749116)
,p_name=>'P52_INICIO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14167922600242736663)
,p_prompt=>'Inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'RETURN TRUNC (SYSDATE, ''MM'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167924408879751462)
,p_name=>'P52_FIN'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14167922600242736663)
,p_prompt=>'Fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'SYSDATE'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
