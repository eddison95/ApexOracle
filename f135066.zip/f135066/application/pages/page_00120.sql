prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>120
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Movimientos de Facturacion'
,p_step_title=>'Movimimentos de Facturacion'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201208143104'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098917999673564142)
,p_plug_name=>'Movimimentos de Facturacion'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098895238888563709)
,p_plug_name=>'Movimimentos de Facturacion'
,p_parent_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   def_empresa empresa,',
'         def_factura factura,',
'         def_u_netas u_netas,',
'         def_orden_taller orden_taller,',
'         def_depto_padre padre_departamento,',
'         def_desc_depto_padre desc_departamento_padre,',
'         def_departamento departamento,',
'         def_desc_depto desc_departamento,',
'         def_localizacion localizacion,',
'         def_desc_loc desc_localizacion,',
'         def_tipo_fact tipo_fact,',
'         TRUNC (def_fecha_vencimiento) fecha_vencimiento,',
'         def_tipo_transaccion tipo_transaccion,',
'         def_u_vendidas u_vendidas,',
'         def_tipo_cambio t_cambio,',
'         def_vendedor cod_vend,',
'         def_nom_vend nombre_vend,',
'         def_cliente cliente,',
'         def_cedula cedula,',
'         def_cli_moneda moneda,',
'         def_nombre nombre,',
'         def_transaccion transaccion,',
'         def_lista tra_lpo_lista,',
'         def_articulo articulo,',
'         def_descripcion descripcion,',
'         def_familia codigo_familia,',
'         def_desc_familia familia,',
'         def_familia_padre familia_padre,',
'         def_tipo_articulo tipoarticulo,',
'         def_clase clase,',
'         def_moneda moneda_lista,',
'         def_costo_unit costo_unit,',
'         def_costo_total costo_total,',
'         def_cantidad cantidad,',
'         def_preciounitario preciounitario,',
'         def_preciototal preciototal,',
'         def_descuento descuento,',
'         def_impuesto impuesto,',
'         def_total total,',
'         TRUNC (def_fecha) fecha,',
'         def_dnc_cantidad cantidad_nota,',
'         def_total_notas total_notas,',
'         def_itm_color itm_clr_color,',
'         def_u_anuladas u_anuladas,',
'         def_itm_motor itm_motor,',
'         def_seg_segmento segmento_cliente,',
'         def_anno itm_ano,',
'         def_creado_por creado_por,',
'         def_cliente_reser cliente_reser,',
'         def_cedula_reser cedula_reser,',
'         def_cli_nombre_reser cli_nombre_reser,',
'         TRUNC (def_fecha_nota) fecha_nota,',
'         def_monto_nota monto_nota,',
'         def_descuento_nota descuento_nota,',
'         def_iva_nota iva_nota,',
'         def_precio_neto precio_neto,',
'         def_nota_neta nota_neta,',
'         def_venta_neta venta_neta,',
'         def_ato_gravado articulo_gravado,',
'         DECODE(def_cli_gravado,',
'            ''N'',',
'            ''NO'',',
'            ''S'',',
'            ''SI''',
'         ) cliente_gravado,',
'         def_costo_nc_total costo_nc_total,',
'         def_costo_nc_neto costo_nc_neto,',
'         def_costo_f_neto costo_f_neto,',
'         def_banco banco,',
'         def_comprobante_electronico def_comp_elect,',
'def_ncd_ttr_tipo',
'  FROM   FAC_DET_MOV_FACT_REP_TB_NX',
'  WHERE def_usuario = V(''APP_USER'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P120_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14098895686629563726)
,p_name=>'Detalle de Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>11151961857674632
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098895761854563788)
,p_db_column_name=>'EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098905884324563976)
,p_db_column_name=>'FACTURA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'FACTURA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098909098502563985)
,p_db_column_name=>'CLIENTE'
,p_display_order=>5
,p_column_identifier=>'D'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098909472507563986)
,p_db_column_name=>'MONEDA'
,p_display_order=>6
,p_column_identifier=>'E'
,p_column_label=>'Moneda Cliente'
,p_column_type=>'STRING'
,p_static_id=>'MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098909825064563987)
,p_db_column_name=>'NOMBRE'
,p_display_order=>7
,p_column_identifier=>'F'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098910246213563988)
,p_db_column_name=>'TRANSACCION'
,p_display_order=>8
,p_column_identifier=>'G'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098910670047563989)
,p_db_column_name=>'ARTICULO'
,p_display_order=>9
,p_column_identifier=>'H'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
,p_static_id=>'ARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098911043556563990)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098911490575563991)
,p_db_column_name=>'CODIGO_FAMILIA'
,p_display_order=>11
,p_column_identifier=>'J'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
,p_static_id=>'CODIGO_FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098911828555563991)
,p_db_column_name=>'FAMILIA'
,p_display_order=>12
,p_column_identifier=>'K'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'FAMILIA'
,p_help_text=>'FAMILIA DE PRODUCTOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098917097908564073)
,p_db_column_name=>'FAMILIA_PADRE'
,p_display_order=>13
,p_column_identifier=>'Z'
,p_column_label=>'Familia Padre'
,p_column_type=>'STRING'
,p_static_id=>'FAMILIA_PADRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098912312537563992)
,p_db_column_name=>'TIPOARTICULO'
,p_display_order=>14
,p_column_identifier=>'L'
,p_column_label=>'Tipo Articulo'
,p_column_type=>'STRING'
,p_static_id=>'TIPOARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098912723385563993)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>15
,p_column_identifier=>'M'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CANTIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098913036323563994)
,p_db_column_name=>'PRECIOUNITARIO'
,p_display_order=>16
,p_column_identifier=>'N'
,p_column_label=>'Precio Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PRECIOUNITARIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098913425266564021)
,p_db_column_name=>'PRECIOTOTAL'
,p_display_order=>17
,p_column_identifier=>'O'
,p_column_label=>'Precio Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PRECIOTOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098913900749564022)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>18
,p_column_identifier=>'P'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DESCUENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098914303071564061)
,p_db_column_name=>'IMPUESTO'
,p_display_order=>20
,p_column_identifier=>'R'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'IMPUESTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098914637609564062)
,p_db_column_name=>'TOTAL'
,p_display_order=>21
,p_column_identifier=>'S'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'TOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098915041626564063)
,p_db_column_name=>'COD_VEND'
,p_display_order=>22
,p_column_identifier=>'T'
,p_column_label=>'Codigo Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'COD_VEND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098915516013564064)
,p_db_column_name=>'NOMBRE_VEND'
,p_display_order=>23
,p_column_identifier=>'U'
,p_column_label=>'Nombre Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE_VEND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098915879814564065)
,p_db_column_name=>'COSTO_UNIT'
,p_display_order=>24
,p_column_identifier=>'V'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'COSTO_UNIT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P120_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098916293007564066)
,p_db_column_name=>'COSTO_TOTAL'
,p_display_order=>25
,p_column_identifier=>'W'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'COSTO_TOTAL'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P120_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098916707973564067)
,p_db_column_name=>'FECHA'
,p_display_order=>26
,p_column_identifier=>'X'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098896108444563845)
,p_db_column_name=>'ORDEN_TALLER'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Orden Taller'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ORDEN_TALLER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098896353534563846)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>37
,p_column_identifier=>'AB'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098897136003563848)
,p_db_column_name=>'TOTAL_NOTAS'
,p_display_order=>57
,p_column_identifier=>'AD'
,p_column_label=>'Total Notas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098897570892563849)
,p_db_column_name=>'ITM_CLR_COLOR'
,p_display_order=>67
,p_column_identifier=>'AE'
,p_column_label=>'Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098898378926563894)
,p_db_column_name=>'ITM_MOTOR'
,p_display_order=>87
,p_column_identifier=>'AG'
,p_column_label=>'Motor - Chasis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098899222253563896)
,p_db_column_name=>'DESC_DEPARTAMENTO'
,p_display_order=>117
,p_column_identifier=>'AJ'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098899567743563897)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>127
,p_column_identifier=>'AK'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098899964045563897)
,p_db_column_name=>'DESC_LOCALIZACION'
,p_display_order=>137
,p_column_identifier=>'AL'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098900781755563899)
,p_db_column_name=>'TRA_LPO_LISTA'
,p_display_order=>157
,p_column_identifier=>'AN'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098901158177563900)
,p_db_column_name=>'CEDULA'
,p_display_order=>167
,p_column_identifier=>'AO'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098901610760563901)
,p_db_column_name=>'TIPO_FACT'
,p_display_order=>177
,p_column_identifier=>'AP'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098901943687563902)
,p_db_column_name=>'FECHA_VENCIMIENTO'
,p_display_order=>187
,p_column_identifier=>'AQ'
,p_column_label=>'F. Vencimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098902407546563902)
,p_db_column_name=>'TIPO_TRANSACCION'
,p_display_order=>197
,p_column_identifier=>'AR'
,p_column_label=>'T. Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098903136815563904)
,p_db_column_name=>'CLASE'
,p_display_order=>217
,p_column_identifier=>'AT'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098903591959563905)
,p_db_column_name=>'MONEDA_LISTA'
,p_display_order=>227
,p_column_identifier=>'AU'
,p_column_label=>'Moneda Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098903854268563949)
,p_db_column_name=>'T_CAMBIO'
,p_display_order=>237
,p_column_identifier=>'AV'
,p_column_label=>'T. Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098904310299563972)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>247
,p_column_identifier=>'AW'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098904638847563973)
,p_db_column_name=>'CLIENTE_RESER'
,p_display_order=>257
,p_column_identifier=>'AX'
,p_column_label=>'Cliente Reserva'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098905118972563974)
,p_db_column_name=>'CEDULA_RESER'
,p_display_order=>267
,p_column_identifier=>'AY'
,p_column_label=>unistr('C\00E9dula Cliente Reserva')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098905506241563975)
,p_db_column_name=>'CLI_NOMBRE_RESER'
,p_display_order=>277
,p_column_identifier=>'AZ'
,p_column_label=>'Nombre Cliente Reserva'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098906258283563977)
,p_db_column_name=>'FECHA_NOTA'
,p_display_order=>287
,p_column_identifier=>'BA'
,p_column_label=>'Fecha Nota'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098906689542563978)
,p_db_column_name=>'PADRE_DEPARTAMENTO'
,p_display_order=>297
,p_column_identifier=>'BB'
,p_column_label=>'Departamento Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098907027897563978)
,p_db_column_name=>'DESC_DEPARTAMENTO_PADRE'
,p_display_order=>307
,p_column_identifier=>'BC'
,p_column_label=>'Desc. Departamento Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098907485626563982)
,p_db_column_name=>'MONTO_NOTA'
,p_display_order=>317
,p_column_identifier=>'BD'
,p_column_label=>'Monto Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098907861772563983)
,p_db_column_name=>'DESCUENTO_NOTA'
,p_display_order=>327
,p_column_identifier=>'BE'
,p_column_label=>'Descuento Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098908254950563984)
,p_db_column_name=>'IVA_NOTA'
,p_display_order=>337
,p_column_identifier=>'BF'
,p_column_label=>'Impuesto Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098671044701192132)
,p_db_column_name=>'PRECIO_NETO'
,p_display_order=>357
,p_column_identifier=>'BJ'
,p_column_label=>'Precio Neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098671127891192133)
,p_db_column_name=>'NOTA_NETA'
,p_display_order=>367
,p_column_identifier=>'BK'
,p_column_label=>'Nota Neta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098672306008192144)
,p_db_column_name=>'VENTA_NETA'
,p_display_order=>407
,p_column_identifier=>'BP'
,p_column_label=>'Venta Neta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098964707722251896)
,p_db_column_name=>'U_NETAS'
,p_display_order=>417
,p_column_identifier=>'BR'
,p_column_label=>'U. Netas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098964796459251897)
,p_db_column_name=>'U_VENDIDAS'
,p_display_order=>427
,p_column_identifier=>'BS'
,p_column_label=>'U. Vendidas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098964827350251898)
,p_db_column_name=>'CANTIDAD_NOTA'
,p_display_order=>437
,p_column_identifier=>'BT'
,p_column_label=>'Cantidad Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098964980432251899)
,p_db_column_name=>'U_ANULADAS'
,p_display_order=>447
,p_column_identifier=>'BU'
,p_column_label=>'U. Anuladas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098966122321251910)
,p_db_column_name=>'SEGMENTO_CLIENTE'
,p_display_order=>457
,p_column_identifier=>'BV'
,p_column_label=>'Segmento Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099126108633152626)
,p_db_column_name=>'ITM_ANO'
,p_display_order=>467
,p_column_identifier=>'BW'
,p_column_label=>'Itm ano'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099126319149152628)
,p_db_column_name=>'ARTICULO_GRAVADO'
,p_display_order=>477
,p_column_identifier=>'BX'
,p_column_label=>'Articulo Gravado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099126334245152629)
,p_db_column_name=>'CLIENTE_GRAVADO'
,p_display_order=>487
,p_column_identifier=>'BY'
,p_column_label=>'Cliente Gravado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099126475458152630)
,p_db_column_name=>'COSTO_NC_TOTAL'
,p_display_order=>497
,p_column_identifier=>'BZ'
,p_column_label=>'Costo NC Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099126578073152631)
,p_db_column_name=>'COSTO_NC_NETO'
,p_display_order=>507
,p_column_identifier=>'CA'
,p_column_label=>'Costo NC Neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099126636190152632)
,p_db_column_name=>'COSTO_F_NETO'
,p_display_order=>517
,p_column_identifier=>'CB'
,p_column_label=>'Costo F Neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099126811124152633)
,p_db_column_name=>'BANCO'
,p_display_order=>527
,p_column_identifier=>'CC'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084691217611360964)
,p_db_column_name=>'DEF_COMP_ELECT'
,p_display_order=>537
,p_column_identifier=>'CD'
,p_column_label=>unistr('Comprobante electr\00F3nico ')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14063056987345035796)
,p_db_column_name=>'DEF_NCD_TTR_TIPO'
,p_display_order=>547
,p_column_identifier=>'CE'
,p_column_label=>'Tipo Tran Nota'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14098917438058564074)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'111738'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:TRANSACCION:FACTURA:DEF_COMP_ELECT:ORDEN_TALLER:FECHA:PADRE_DEPARTAMENTO:DESC_DEPARTAMENTO_PADRE:DEPARTAMENTO:DESC_DEPARTAMENTO:LOCALIZACION:DESC_LOCALIZACION:MONEDA:SEGMENTO_CLIENTE:T_CAMBIO:TRA_LPO_LISTA:MONEDA_LISTA:COD_VEND:NOMBRE_VEND:CL'
||'IENTE:CEDULA:NOMBRE:CLIENTE_RESER:CEDULA_RESER:CLI_NOMBRE_RESER:TIPO_FACT:FECHA_VENCIMIENTO:TIPO_TRANSACCION:ARTICULO:DESCRIPCION:CODIGO_FAMILIA:FAMILIA:FAMILIA_PADRE:TIPOARTICULO:CANTIDAD:PRECIOUNITARIO:CLASE:ITM_CLR_COLOR:ITM_MOTOR:DESCUENTO:IMPUES'
||'TO:TOTAL:PRECIOTOTAL:TOTAL_NOTAS:MONTO_NOTA:DESCUENTO_NOTA:IVA_NOTA:CREADO_POR:FECHA_NOTA:PRECIO_NETO:NOTA_NETA:VENTA_NETA:U_NETAS:U_VENDIDAS:CANTIDAD_NOTA:U_ANULADAS:ARTICULO_GRAVADO:CLIENTE_GRAVADO:COSTO_NC_TOTAL:COSTO_NC_NETO:COSTO_F_NETO:BANCO::D'
||'EF_NCD_TTR_TIPO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14098918313452564143)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13967055299760886877)
,p_name=>'P120_LOCAL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   FROM DUAL',
'connect by regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13967055368303886878)
,p_name=>'P120_ALTERNA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )   FROM DUAL',
'connect by regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098918678039564189)
,p_name=>'P120_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE   use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098919325246564222)
,p_name=>'P120_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098919727964564225)
,p_name=>'P120_MONEDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MONEDA'
,p_lov=>'.'||wwv_flow_api.id(13966336081955007059)||'.'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098920183565564226)
,p_name=>'P120_INICIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098920611700564227)
,p_name=>'P120_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14098917999673564142)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14098921753919564297)
,p_computation_sequence=>10
,p_computation_item=>'P120_AUTO_CCA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE   use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966308677161995405)
,p_validation_name=>'MONEDA_EMPRESA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level) is not null;',
'             ',
'IF (cantidad_local_v > 1 AND :P120_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
'',
'IF (cantidad_alt_v > 1 AND :P120_MONEDA = ''A'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
'',
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   INTO :P120_LOCAL FROM DUAL',
'connect by regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )  INTO :P120_ALTERNA   FROM DUAL',
'connect by regexp_substr(:P120_EMPRESA,''[^:]+'', 1, level) is not null;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_api.id(14098918313452564143)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14098922062625564325)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'llena_reporte_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   fac_mov_facturacion_pr_nx (:P120_EMPRESA,',
'                              CASE WHEN :P120_MONEDA = ''L'' THEN :P120_LOCAL WHEN :P120_MONEDA = ''A'' THEN :P120_ALTERNA ELSE :P120_MONEDA  END,',
'                              :P120_INICIO,',
'                              :P120_FIN,',
'                              :APP_USER);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14098918313452564143)
);
null;
wwv_flow_api.component_end;
end;
/
