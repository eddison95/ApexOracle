prompt --application/pages/page_00046
begin
--   Manifest
--     PAGE: 00046
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>46
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'BCO - Movimientos Bancos'
,p_step_title=>'Movimientos Bancos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164020'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112489576084885012)
,p_plug_name=>'Movimientos Bancos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112486082560884891)
,p_plug_name=>'Movimientos Bancos'
,p_region_name=>'Reporte Movimientos'
,p_parent_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   mov_consecutivo transaccion,',
'         mov_ctb_bco_banco banco,',
'         mov_ctb_cuenta cuenta,',
'         b.ctb_descripcion descripcion,',
'         b.ctb_mon_moneda moneda,',
'         mov_bct_tipo tipo,',
'         TRUNC (mov_fecha) fecha,',
'         mov_tipo_movimiento tipo_mov,',
'         mov_beneficiario beneficiario,',
'         bco_signo_tran_v_nx (mov_ctb_bco_emp_empresa, mov_bct_tipo) signo,',
'         DECODE (bco_signo_tran_v_nx (mov_ctb_bco_emp_empresa, mov_bct_tipo),',
'                 ''A'', mov_monto,',
'                 0)',
'            debe,',
'         DECODE (bco_signo_tran_v_nx (mov_ctb_bco_emp_empresa, mov_bct_tipo),',
'                 ''D'', mov_monto,',
'                 0)',
'            haber,',
'         mov_numero_documento documento,',
'         mov_observaciones observaciones,',
'         DECODE (mov_status,',
'                 ''C'',',
'                 ''Creado'',',
'                 ''R'',',
'                 ''Registrado'',',
'                 ''P'',',
'                 ''Procesado'')',
'            estado,',
'         cxp_nombre_prov_v_nx (mov_pro_emp_empresa,',
'                               mov_pro_proveedor,',
'                               mov_pro_mon_moneda)',
'            proveedor,',
'         mov_hcj_hoja_caja hoja_caja,',
'         mov_creado_por creado_por,',
'         mov_fecha_creado fecha_creacion,',
'         DECODE (mov_conciliado, 1, ''Si'', ''No'') conciliado,',
'         DECODE (mov_anulado, 1, ''Si'', ''No'') anulado,',
'         CASE (SELECT   COUNT (''x'')',
'                 FROM   krn_bco_trans_cpto_tb_nx',
'                WHERE   bct_emp_empresa = a.mov_ctb_bco_emp_empresa',
'                        AND bct_tipo = mov_bct_tipo)',
'            WHEN 0',
'            THEN',
'               ''No''',
'            ELSE',
'               ''Si''',
'         END',
'            tiene_conta',
'  FROM   bco_movimiento_tr_nx a, bco_cuenta_bancaria_tr_nx b',
' WHERE       a.mov_ctb_bco_emp_empresa = b.ctb_bco_emp_empresa',
'         AND a.mov_ctb_bco_per_persona = b.ctb_bco_per_persona',
'         AND a.mov_ctb_bco_banco = b.ctb_bco_banco',
'         AND a.mov_ctb_cuenta = b.ctb_cuenta',
'         AND a.mov_ctb_bco_emp_empresa = :p46_empresa',
'         AND a.mov_ctb_bco_per_persona =',
'               NVL (:p46_persona, a.mov_ctb_bco_per_persona)',
'         AND a.mov_ctb_bco_banco = NVL (:p46_banco, a.mov_ctb_bco_banco)',
'         AND a.mov_ctb_cuenta = NVL (:p46_cuenta, a.mov_ctb_cuenta)',
'         AND a.mov_fecha BETWEEN :p46_inicio',
'                             AND  TO_DATE (:p46_fin || '' 23:59'',',
'                                           ''dd/mm/rrrr hh24:mi'');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P46_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14112486267113884920)
,p_name=>'Reporte Ventas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>11695016422096309
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112497571819912055)
,p_db_column_name=>'TRANSACCION'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112497678121912062)
,p_db_column_name=>'BANCO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_static_id=>'BANCO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112497769087912062)
,p_db_column_name=>'CUENTA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112497860483912062)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112497973137912063)
,p_db_column_name=>'MONEDA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498077989912063)
,p_db_column_name=>'TIPO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498152820912063)
,p_db_column_name=>'FECHA'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498260558912063)
,p_db_column_name=>'TIPO_MOV'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Tipo Mov'
,p_column_type=>'STRING'
,p_static_id=>'TIPO_MOV'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498380486912063)
,p_db_column_name=>'BENEFICIARIO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Beneficiario'
,p_column_type=>'STRING'
,p_static_id=>'BENEFICIARIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498459539912063)
,p_db_column_name=>'SIGNO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Signo'
,p_column_type=>'STRING'
,p_static_id=>'SIGNO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498557055912064)
,p_db_column_name=>'DEBE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Debe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DEBE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498681917912064)
,p_db_column_name=>'HABER'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Haber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'HABER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498780299912064)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498853720912064)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_static_id=>'OBSERVACIONES'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112498968532912064)
,p_db_column_name=>'ESTADO'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_static_id=>'ESTADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112499059416912065)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PROVEEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112499182340912065)
,p_db_column_name=>'HOJA_CAJA'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Hoja Caja'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'HOJA_CAJA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082582554112100314)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>27
,p_column_identifier=>'R'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082582664329100315)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>37
,p_column_identifier=>'S'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087174240025264179)
,p_db_column_name=>'CONCILIADO'
,p_display_order=>47
,p_column_identifier=>'U'
,p_column_label=>'Conciliado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087233087617160878)
,p_db_column_name=>'ANULADO'
,p_display_order=>57
,p_column_identifier=>'W'
,p_column_label=>'Anulado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13995908387472191163)
,p_db_column_name=>'TIENE_CONTA'
,p_display_order=>67
,p_column_identifier=>'X'
,p_column_label=>'Tiene conta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14112489270911884987)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'116981'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TRANSACCION:BANCO:CUENTA:DESCRIPCION:MONEDA:TIPO:FECHA:TIPO_MOV:BENEFICIARIO:SIGNO:DEBE:HABER:DOCUMENTO:OBSERVACIONES:ESTADO:PROVEEDOR:HOJA_CAJA:CREADO_POR:FECHA_CREACION:CONCILIADO:ANULADO::TIENE_CONTA'
,p_sort_column_1=>'TRA_FECHA'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14112489758627885015)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112490172246885049)
,p_name=>'P46_FIN'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112490352704885049)
,p_name=>'P46_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112490572400885050)
,p_name=>'P46_INICIO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113015581553998394)
,p_name=>'P46_PERSONA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_prompt=>'Persona'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT GNL_NOMBRE_PERSONA_V_NX(BCO_PER_PERSONA), BCO_PER_PERSONA FROM BCO_BANCO_TR_NX',
'WHERE BCO_EMP_EMPRESA = :P46_Empresa'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_lov_cascade_parent_items=>'P46_EMPRESA'
,p_ajax_items_to_submit=>'P46_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113017580032014329)
,p_name=>'P46_BANCO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_prompt=>'Banco'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT BCO_BANCO NOMBRE, BCO_BANCO ID FROM BCO_BANCO_TR_NX',
'WHERE BCO_EMP_EMPRESA = :P46_EMPRESA',
'AND BCO_PER_PERSONA = :P46_PERSONA'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_lov_cascade_parent_items=>'P46_PERSONA'
,p_ajax_items_to_submit=>'P46_PERSONA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113023568793049879)
,p_name=>'P46_CUENTA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_prompt=>'Cuenta'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CTB_CUENTA ||''-''|| CTB_MON_MONEDA ||''-''|| CTB_DESCRIPCION, CTB_CUENTA FROM BCO_CUENTA_BANCARIA_TR_NX',
'WHERE CTB_BCO_EMP_EMPRESA = :P46_Empresa',
'AND CTB_BCO_PER_PERSONA = :P46_Persona',
'AND CTB_BCO_BANCO = :P46_Banco'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_lov_cascade_parent_items=>'P46_BANCO'
,p_ajax_items_to_submit=>'P46_BANCO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113027552581103006)
,p_name=>'P46_SALDO_INICIAL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saldo Inicial'
,p_source=>'return to_char(bco_saldo_cta_v_nx (:P46_Empresa, :P46_Persona, :P46_Banco, :P46_Cuenta, TO_DATE(:P46_Inicio) - 1), ''999G999G999G990D00'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_display_when=>'P46_Cuenta'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14113033561627113922)
,p_name=>'P46_SALDO_FINAL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(14112489576084885012)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saldo Final'
,p_source=>'return to_char(bco_saldo_cta_v_nx (:P46_Empresa, :P46_Persona, :P46_Banco, :P46_Cuenta, :P46_Fin), ''999G999G999G990D00'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P46_Cuenta'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.component_end;
end;
/
