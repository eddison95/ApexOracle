prompt --application/pages/page_00113
begin
--   Manifest
--     PAGE: 00113
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>113
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GNL - Parametros Empresa'
,p_step_title=>'Parametros Empresa'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096614384526524517)
,p_plug_name=>'Parametros Empresa'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096616598569524787)
,p_plug_name=>'Parametros Empresa'
,p_parent_plug_id=>wwv_flow_api.id(14096614384526524517)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 22/02/2017 02:16:44 p.m. (QP5 v5.115.810.9015) */',
'SELECT   P.EMPRESA EMPRESA,',
'         P.SUBSISTEMA SUBSISTEMA,',
'         P.PARAMETRO PARAMETRO,',
'         P.DESCRIPCION DESCRIPCION,',
'         DECODE (P.TIPO,',
'                 ''C'',',
'                 ''Char'',',
'                 ''N'',',
'                 ''Numerico'',',
'                 ''E'',',
'                 ''Entero'',',
'                 ''R'',',
'                 ''Referencia'',',
'                 ''S'',',
'                 ''Si / No'',',
'                 ''D'',',
'                 ''Date'')',
'            TIPO,',
'         P.VALOR VALOR,',
'         P.VARIABLE VAR,',
'         P.VALIDACION VALIDACION,',
'         P.MENSAJE MENSAJE',
'  FROM   GNL_PARAMETRO_EMPRESA_TB_NX P',
' WHERE   INSTR ('':'' || :P113_EMPRESA || '':'', '':'' || P.EMPRESA || '':'') > 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P113_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14096616852223524792)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>8873127451635698
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096300341284424236)
,p_db_column_name=>'EMPRESA'
,p_display_order=>10
,p_column_identifier=>'AW'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096300435005424237)
,p_db_column_name=>'SUBSISTEMA'
,p_display_order=>20
,p_column_identifier=>'AX'
,p_column_label=>'Subsistema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096300607404424238)
,p_db_column_name=>'PARAMETRO'
,p_display_order=>30
,p_column_identifier=>'AY'
,p_column_label=>'Parametro'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096300625971424239)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>40
,p_column_identifier=>'AZ'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096300761351424240)
,p_db_column_name=>'TIPO'
,p_display_order=>50
,p_column_identifier=>'BA'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096300874253424241)
,p_db_column_name=>'VALOR'
,p_display_order=>60
,p_column_identifier=>'BB'
,p_column_label=>'Valor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096301002081424242)
,p_db_column_name=>'VAR'
,p_display_order=>70
,p_column_identifier=>'BC'
,p_column_label=>'Variable'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096301090104424243)
,p_db_column_name=>'VALIDACION'
,p_display_order=>80
,p_column_identifier=>'BD'
,p_column_label=>'Validacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096301166228424244)
,p_db_column_name=>'MENSAJE'
,p_display_order=>90
,p_column_identifier=>'BE'
,p_column_label=>'Mensaje'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14096624032463524923)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'88804'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>':REC_CREADO_PORTRANSACCION:DRC_EMP_DRC_REC_NUMERO_RECIBO:DRC_DRC_MONTO:DRC_EMPRESA:SUBSISTEMA:PARAMETRO:DESCRIPCION:TIPO:VALOR:VAR:VALIDACION:MENSAJE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096614672852524550)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14096614384526524517)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096615056785524642)
,p_name=>'P113_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14096614384526524517)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
