prompt --application/pages/page_00153
begin
--   Manifest
--     PAGE: 00153
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>153
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GNL - Carga Articulos UM'
,p_step_title=>'Carga Articulos UM'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165758'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14077384029889319283)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14067195121796377871)
,p_plug_name=>'Archivo'
,p_parent_plug_id=>wwv_flow_api.id(14077384029889319283)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14067195328728377874)
,p_plug_name=>'Datos'
,p_parent_plug_id=>wwv_flow_api.id(14077384029889319283)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT seq_id, ',
'       c001, c002, c003, c004, c005, c006, c007, c008, c009, c010, c011, c012, c013, c014, c015, c016, c017, c018, c019, c020, ',
'       c021, c022, c023, c024, c025, c026, c027, c028, c029, c030, c031, c032, c033, c034, c035, c036, c037, c038, c039, c040,',
'       c041, c042, c043, c044, c045, c046, c047, c048, c049, c050',
'FROM APEX_COLLECTIONS',
'WHERE COLLECTION_NAME = ''P153_ARTICULO'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P153_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14067195460922377875)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>20603610793903963
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057214988375161648)
,p_db_column_name=>'C001'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057215414194161664)
,p_db_column_name=>'C002'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'C. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057215760456161665)
,p_db_column_name=>'C003'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'U. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057216194015161665)
,p_db_column_name=>'C004'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Peso Neto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057216595318161665)
,p_db_column_name=>'C005'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'U. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057216978709161666)
,p_db_column_name=>'C006'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Peso Bruto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057217292977161669)
,p_db_column_name=>'C007'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'U. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057217685576161669)
,p_db_column_name=>'C008'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vol. Alto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057218088404161670)
,p_db_column_name=>'C009'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'U. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057218515905161670)
,p_db_column_name=>'C010'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Vol. Largo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057218873022161671)
,p_db_column_name=>'C011'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'U. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057219294055161671)
,p_db_column_name=>'C012'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Vol. Ancho'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057219726323161671)
,p_db_column_name=>'C013'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'U. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057220134707161679)
,p_db_column_name=>'C014'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'C. Empaque'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057220521408161680)
,p_db_column_name=>'C015'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'U. Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057220920580161680)
,p_db_column_name=>'C016'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'C. Maquina'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057221344767161681)
,p_db_column_name=>'C017'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'C. Minima'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057221674063161681)
,p_db_column_name=>'C018'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'C. Maxima'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057222056965161681)
,p_db_column_name=>'C019'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Pedido Minimo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057222460143161682)
,p_db_column_name=>'C020'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Punto Reorden'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057222941676161682)
,p_db_column_name=>'C021'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Agrupacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057223307131161682)
,p_db_column_name=>'C022'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Tiempo Entrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057223715294161683)
,p_db_column_name=>'C023'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'C023'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057224065268161683)
,p_db_column_name=>'C024'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'C024'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057224490553161683)
,p_db_column_name=>'C025'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'C025'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057224899428161684)
,p_db_column_name=>'C026'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'C026'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057225264871161684)
,p_db_column_name=>'C027'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'C027'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057225680842161685)
,p_db_column_name=>'C028'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'C028'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057226103612161686)
,p_db_column_name=>'C029'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'C029'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057226459471161686)
,p_db_column_name=>'C030'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'C030'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057226854409161686)
,p_db_column_name=>'C031'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'C031'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057227314520161687)
,p_db_column_name=>'C032'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'C032'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057227695713161688)
,p_db_column_name=>'C033'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'C033'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057228115505161688)
,p_db_column_name=>'C034'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'C034'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057228502332161688)
,p_db_column_name=>'C035'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'C035'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057228865390161688)
,p_db_column_name=>'C036'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'C036'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057229344028161689)
,p_db_column_name=>'C037'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'C037'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057229722450161689)
,p_db_column_name=>'C038'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'C038'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057230106644161689)
,p_db_column_name=>'C039'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'C039'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057230544590161690)
,p_db_column_name=>'C040'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'C040'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057230885307161690)
,p_db_column_name=>'C041'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'C041'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057231271676161690)
,p_db_column_name=>'C042'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'C042'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057231722742161691)
,p_db_column_name=>'C043'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'C043'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057232074450161691)
,p_db_column_name=>'C044'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'C044'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057232532867161691)
,p_db_column_name=>'C045'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'C045'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057232932375161692)
,p_db_column_name=>'C046'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'C046'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057233326420161692)
,p_db_column_name=>'C047'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'C047'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057233738042161692)
,p_db_column_name=>'C048'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'C048'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057234122561161693)
,p_db_column_name=>'C049'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'C049'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057234474128161693)
,p_db_column_name=>'C050'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'C050'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057234948645161693)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fila'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14067798729884265486)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'106434'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004:C005:C006:C007:C008:C009:C010:C011:C012:C013:C014:C015:C016:C017:C018:C019:C020:C021:C022:C023:C024:C025:C026:C027:C028:C029:C030:C031:C032:C033:C034:C035:C036:C037:C038:C039:C040:C041:C042:C043:C044:C045:C046:C047:C048:C04'
||'9:C050:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14067780534851222378)
,p_plug_name=>'Plantilla'
,p_parent_plug_id=>wwv_flow_api.id(14077384029889319283)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'gnl_carga_nx.pla_articuloum_pr;'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P153_PLANTILLA'
,p_plug_display_when_cond2=>'S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14057236700765161724)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14067195121796377871)
,p_button_name=>'CARGAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cargar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14057235723145161711)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14067195328728377874)
,p_button_name=>'PROCESAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Procesar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14057213904540161592)
,p_name=>'P153_EMPRESA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14077384029889319283)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14057214283808161625)
,p_name=>'P153_PLANTILLA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14077384029889319283)
,p_item_default=>'N'
,p_prompt=>'Plantilla'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:SI;S,NO;N'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14057237123097161725)
,p_name=>'P153_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14067195121796377871)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14057237467414161792)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'cargar_pr'
,p_attribute_01=>'P153_ARCHIVO'
,p_attribute_02=>'P153_ARTICULO'
,p_attribute_04=>';'
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14057236700765161724)
,p_process_success_message=>'Carga Completa'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14057237805307161797)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'procesar_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    articulo_v   inv_articulo_tb_nx%rowtype;',
'BEGIN',
'    FOR a IN (',
'        SELECT',
'            seq_id,',
'            c001, c002, c003, c004, c005,',
'            c006, c007, c008, c009, c010,',
'            c011, c012, c013, c014, c015,',
'            c016, c017, c018, c019, c020,',
'            c021, c022',
'        FROM',
'            apex_collections',
'        WHERE',
'            collection_name = ''P153_ARTICULO''',
'        ORDER BY',
'            seq_id',
'    ) LOOP',
'        articulo_v.ato_emp_empresa := :p153_empresa;',
'        articulo_v.ato_articulo := a.c001;',
'        articulo_v.ato_cantidad_medida := a.c002;',
'        articulo_v.ato_med_medida := a.c003;',
'        articulo_v.ato_peso_neto := a.c004;',
'        articulo_v.ato_med_medida_peso_neto := a.c005;',
'        articulo_v.ato_peso_bruto := a.c006;       ',
'        articulo_v.ato_med_medida_peso_bruto := a.c007;        ',
'        articulo_v.ato_volumen_alto := a.c008;',
'        articulo_v.ato_med_medida_volumen_alto := a.c009;',
'        articulo_v.ato_volumen_largo := a.c010;',
'        articulo_v.ato_med_medida_volumen_largo := a.c011;',
'        articulo_v.ato_volumen_ancho := a.c012;',
'        articulo_v.ato_med_medida_volumen_ancho := a.c013;',
'        articulo_v.ato_cantidad_empaque := a.c014;        ',
'        articulo_v.ato_med_medida_empaque := a.c015;',
'        articulo_v.ato_cantidad_maquina := a.c016;',
'        articulo_v.ato_cantidad_minima := a.c017;',
'        articulo_v.ato_cantidad_maxima := a.c018;',
'        articulo_v.ato_pedido_minimo := a.c019;',
'        articulo_v.ato_punto_reorden := a.c020;',
'        articulo_v.ato_aga_agrupacion := a.c021;',
'        articulo_v.ato_tiempo_entrega := a.c022;',
'        gnl_carga_nx.articulo_pr(articulo_v, 2);',
'        COMMIT;',
'    END LOOP;',
'    ',
'    apex_collection.truncate_collection(''P153_ARTICULO'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14056574555061690331)
,p_process_success_message=>'Proceso Terminado'
);
wwv_flow_api.component_end;
end;
/
