prompt --application/pages/page_00179
begin
--   Manifest
--     PAGE: 00179
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>179
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'AFJ - Eventos Activos '
,p_step_title=>'Eventos Activos '
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'MBACASE'
,p_last_upd_yyyymmddhh24miss=>'20210520091428'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13885245823160718689)
,p_plug_name=>'Eventos Activos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13885245515884718686)
,p_plug_name=>'AFJ - Eventos Activos'
,p_parent_plug_id=>wwv_flow_api.id(13885245823160718689)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'   A.eve_emp_empresa, eve_act_activo,',
'   A.eve_act_num_activo, ',
'   A.eve_evento, eve_tit_tipo,',
'   A.eve_fecha,  eve_monto,',
'   A.eve_monto_corp Monto_Corp,',
'    A.EVE_LOC_LOCALIZACION Localizacion,',
'   A.EVE_ACT_NUM_ACTIVO Numweo_activo,',
'  A.EVE_DESCRIPCION Descripcion,',
'    A.EVE_FECHA_CREACION fecha_creacion,',
'   A.EVE_MONTO monto_fiscal,',
'  A.EVE_STATUS estado,',
'  A.EVE_FECHA_MODIFICACION Fecha_modificacion,',
'  B.ACT_UBI_UBICACION  Ubicacion,',
'  B.ACT_CAC_TAC_TIPO   Tipo,',
'  B.ACT_CAC_CLASE      Clase',
'FROM    afj_evento_tb_nx A,afj_activo_tb_nx B',
'WHERE  INSTR ('':''||:P179_EMPRESA||'':'','':''||EVE_EMP_EMPRESA||'':'') > 0',
'        AND A.EVE_EMP_EMPRESA = B.ACT_EMP_EMPRESA ',
'        AND A.EVE_ACT_ACTIVO = B.ACT_ACTIVO',
'        AND A.EVE_ACT_NUM_ACTIVO = B.ACT_NUM_ACTIVO'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P179_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13885245454464718685)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ESALAS'
,p_internal_uid=>28416804297125330
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885245338489718684)
,p_db_column_name=>'EVE_EMP_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Eve Emp Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885245208470718683)
,p_db_column_name=>'EVE_ACT_ACTIVO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Eve Act Activo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885245111934718682)
,p_db_column_name=>'EVE_ACT_NUM_ACTIVO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Eve Act Num Activo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885245058156718681)
,p_db_column_name=>'EVE_EVENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Eve Evento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244873746718680)
,p_db_column_name=>'EVE_TIT_TIPO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Eve Tit Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244822606718679)
,p_db_column_name=>'EVE_FECHA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Eve Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244694650718678)
,p_db_column_name=>'EVE_MONTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Eve Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244592227718677)
,p_db_column_name=>'MONTO_CORP'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Monto Corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244460387718676)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244414535718675)
,p_db_column_name=>'NUMWEO_ACTIVO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Numero Activo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244291017718674)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244161289718673)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fecha Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244061042718672)
,p_db_column_name=>'MONTO_FISCAL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Monto Fiscal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885244001759718671)
,p_db_column_name=>'ESTADO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885243889580718670)
,p_db_column_name=>'FECHA_MODIFICACION'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fecha Modificacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885243790021718669)
,p_db_column_name=>'UBICACION'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885243743694718668)
,p_db_column_name=>'TIPO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885243644423718667)
,p_db_column_name=>'CLASE'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13885229281642626427)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'285066'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5000
,p_report_columns=>'EVE_EMP_EMPRESA:EVE_ACT_ACTIVO:NUMWEO_ACTIVO:DESCRIPCION:LOCALIZACION:UBICACION:TIPO:CLASE:EVE_TIT_TIPO:EVE_EVENTO:FECHA_CREACION:EVE_FECHA:EVE_MONTO:MONTO_FISCAL:MONTO_CORP:FECHA_MODIFICACION:ESTADO:'
,p_sum_columns_on_break=>'MONTO_FISCAL:MONTO_CORP:EVE_MONTO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13885245653082718687)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(13885245823160718689)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13885245686133718688)
,p_name=>'P179_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13885245823160718689)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
