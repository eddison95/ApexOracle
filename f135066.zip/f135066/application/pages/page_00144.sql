prompt --application/pages/page_00144
begin
--   Manifest
--     PAGE: 00144
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>144
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'BCO - Solicitudes de Bancos'
,p_step_title=>'Solicitudes de Bancos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165537'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14134382901059954658)
,p_plug_name=>'Solicitudes Bancos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14134379407535954537)
,p_plug_name=>'Solicitudes Bancos'
,p_region_name=>'Reporte Bancos'
,p_parent_plug_id=>wwv_flow_api.id(14134382901059954658)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT sol.SOL_SUB_SUBSISTEMA subsistema,',
'         sol.SOL_EMP_EMPRESA empresa,',
'         sol.sol_solicitud solicitud,',
'         sol_mon_moneda moneda,',
'         sol_beneficiario beneficiario,',
'         sol_fecha fecha,',
'         sol_monto monto,',
'         des.des_razon razon,',
'         des.des_tsp_transaccion transaccion_cxp,',
'         DECODE (sol_status,',
'                 ''C'', ''Creado'',',
'                 ''P'', ''Pendiente'',',
'                 ''A'', ''Aprobada'',',
'                 ''R'', ''Rechazada'')',
'            estado,',
'         SOL_OBSERVACIONES observaciones,',
'         SOL_BCT_TIPO tipo_transaccion,',
'         SOL_SOLICITADO_POR,',
'         DECODE (SOL_TIPO_DE_PAGO,',
'                 ''N'', ''No Asignado'',',
'                 ''T'', ''TEF'',',
'                 ''C'', ''Cheque'') tipo_pago,',
'         SOL_CTB_CUENTA cuenta,',
'         (SELECT ctb_descripcion',
'            FROM bco_cuenta_bancaria_tr_nx',
'           WHERE     CTB_BCO_EMP_EMPRESA = SOL_CTB_BCO_EMP_EMPRESA',
'                 AND CTB_BCO_PER_PERSONA = SOL_CTB_BCO_PER_PERSONA',
'                 AND CTB_BCO_BANCO = sol_CTB_BCO_BANCO',
'                 AND CTB_CUENTA = SOL_CTB_CUENTA)',
'            cta_Descripcion',
'    FROM bco_solicitud_tr_nx sol, bco_detalle_solicitud_tr_nx des',
'   WHERE     sol.sol_emp_empresa = des.des_sol_emp_empresa',
'         AND sol.sol_solicitud = des.des_sol_solicitud',
'         AND sol_emp_empresa = :p144_empresa',
'         AND TRUNC (sol_fecha) BETWEEN :p144_inicio',
'                                   AND TO_DATE (:p144_fin || '' 23:59'',',
'                                                ''dd/mm/rrrr hh24:mi'')',
'ORDER BY sol.sol_solicitud DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P144_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14134379592088954566)
,p_name=>'Reporte Ventas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>71359861648738307
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084926506453317166)
,p_db_column_name=>'EMPRESA'
,p_display_order=>10
,p_column_identifier=>'BV'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084926598375317167)
,p_db_column_name=>'SOLICITUD'
,p_display_order=>20
,p_column_identifier=>'BW'
,p_column_label=>'Solicitud'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084926654991317168)
,p_db_column_name=>'MONEDA'
,p_display_order=>30
,p_column_identifier=>'BX'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084926745207317169)
,p_db_column_name=>'BENEFICIARIO'
,p_display_order=>40
,p_column_identifier=>'BY'
,p_column_label=>'Beneficiario'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084926914850317170)
,p_db_column_name=>'FECHA'
,p_display_order=>50
,p_column_identifier=>'BZ'
,p_column_label=>'Fecha Solicitud'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084926950693317171)
,p_db_column_name=>'MONTO'
,p_display_order=>60
,p_column_identifier=>'CA'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927036838317172)
,p_db_column_name=>'RAZON'
,p_display_order=>70
,p_column_identifier=>'CB'
,p_column_label=>unistr('Raz\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927136186317173)
,p_db_column_name=>'TRANSACCION_CXP'
,p_display_order=>80
,p_column_identifier=>'CC'
,p_column_label=>unistr('Transacci\00F3n CXP')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927346991317175)
,p_db_column_name=>'SUBSISTEMA'
,p_display_order=>90
,p_column_identifier=>'CD'
,p_column_label=>'Subsistema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927450535317176)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'CE'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927564417317177)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>110
,p_column_identifier=>'CF'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927689495317178)
,p_db_column_name=>'TIPO_TRANSACCION'
,p_display_order=>120
,p_column_identifier=>'CG'
,p_column_label=>'Tipo transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927794332317179)
,p_db_column_name=>'SOL_SOLICITADO_POR'
,p_display_order=>130
,p_column_identifier=>'CH'
,p_column_label=>'Sol solicitado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927869006317180)
,p_db_column_name=>'TIPO_PAGO'
,p_display_order=>140
,p_column_identifier=>'CI'
,p_column_label=>'Tipo pago'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084927935873317181)
,p_db_column_name=>'CUENTA'
,p_display_order=>150
,p_column_identifier=>'CJ'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084928091972317182)
,p_db_column_name=>'CTA_DESCRIPCION'
,p_display_order=>160
,p_column_identifier=>'CK'
,p_column_label=>'Cta descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14134382595886954633)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'219015'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'SOL_EMP_SOL_SOL_SUB_SOL_MON_SOL_PER_PERSONA:SOL_SOL_BCT_EMP_SOL_BCT_TIPO:SOL_SOL_STATUS:SOL_SOL_TIPO_DE_PAGO:SOL_CTB_BCO_EMP_SOL_CTB_BCO_BANCO:SOL_PRO_EMP_SOL_PRO_PROVEEDOR:SOL_PRO_MON_SOL_COMISION:SOL_CLI_EMP_SOL_CLI_CLIENTE:SOL_CLI_MON_SOL_BTC_TIPO'
||':SOL_LCC_CCH_EMP_SOL_LCC_CCH_CAJA_CHICA:SOL_IND_CONV_SOL_SESION:DES_SOL_EMP_DES_SOL_DES_CONSECUTIVO:DES_DES_DOC_DOCUMENTO:DES_DES_TSP_TRANSACCION:DES_IND_CONV_EMPRESA:SOLICITUD:MONEDA:BENEFICIARIO:FECHA:MONTO:RAZON:TRANSACCION_CXP:SUBSISTEMA:ESTADO:O'
||'BSERVACIONES:TIPO_TRANSACCION:SOL_SOLICITADO_POR:TIPO_PAGO:CUENTA:CTA_DESCRIPCION'
,p_sort_column_1=>'TRA_FECHA'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14084922416030286156)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(14134382901059954658)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084922738100286167)
,p_name=>'P144_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14134382901059954658)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084924256567286189)
,p_name=>'P144_INICIO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14134382901059954658)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084924637701286190)
,p_name=>'P144_FIN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(14134382901059954658)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
