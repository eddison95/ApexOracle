prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>22
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CGL \2013 Asientos CXC')
,p_step_title=>'Asientos CXC'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163546'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096877145411752569)
,p_plug_name=>'Asientos CXC'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193572970253103788)
,p_plug_name=>'Asientos CXC'
,p_parent_plug_id=>wwv_flow_api.id(14096877145411752569)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT	c.cxc_empresa,',
'			c.cxc_asiento,',
'			c.cxc_linea,',
'			c.cxc_transaccion,',
'			c.cxc_cliente,',
'			c.cxc_moneda,',
'			c.cxc_nombre,',
'			c.cxc_tipo,',
'			c.cxc_documento,',
'			c.cxc_monto,',
'                        c.cxc_recibo,',
'                        c.cxc_recibo_pagado',
'  FROM	cgl_cxc_asiento_vw_nx c',
'where cxc_empresa = :P22_EMPRESA',
'and CXC_ASIENTO = :P22_ASIENTO'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P22_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14193573182917103790)
,p_name=>'Cuentas por Cobrar'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>7573830797918113
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193573278701103790)
,p_db_column_name=>'CXC_EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'CXC_EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193573373245103791)
,p_db_column_name=>'CXC_ASIENTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Asiento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CXC_ASIENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193573465816103791)
,p_db_column_name=>'CXC_LINEA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CXC_LINEA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193573564357103791)
,p_db_column_name=>'CXC_TRANSACCION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CXC_TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193573657440103791)
,p_db_column_name=>'CXC_CLIENTE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CXC_CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193573763576103792)
,p_db_column_name=>'CXC_MONEDA'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'CXC_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193573855789103792)
,p_db_column_name=>'CXC_NOMBRE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'CXC_NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193573978026103792)
,p_db_column_name=>'CXC_TIPO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'CXC_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193574068595103793)
,p_db_column_name=>'CXC_DOCUMENTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CXC_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193574161155103793)
,p_db_column_name=>'CXC_MONTO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'CXC_MONTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193574257006103793)
,p_db_column_name=>'CXC_RECIBO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Recibo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CXC_RECIBO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193574352775103794)
,p_db_column_name=>'CXC_RECIBO_PAGADO'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Recibo Pagado'
,p_column_type=>'STRING'
,p_static_id=>'CXC_RECIBO_PAGADO'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14193574453813103794)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75752'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CXC_EMPRESA:CXC_ASIENTO:CXC_LINEA:CXC_TRANSACCION:CXC_CLIENTE:CXC_MONEDA:CXC_NOMBRE:CXC_TIPO:CXC_DOCUMENTO:CXC_MONTO:CXC_RECIBO:CXC_RECIBO_PAGADO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096877449528752571)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14096877145411752569)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096878245546752580)
,p_name=>'P22_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14096877145411752569)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193574872576103795)
,p_name=>'P22_ASIENTO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096877145411752569)
,p_prompt=>'Asiento'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
