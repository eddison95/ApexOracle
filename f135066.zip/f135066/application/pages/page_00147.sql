prompt --application/pages/page_00147
begin
--   Manifest
--     PAGE: 00147
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>147
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('Art\00EDculos por Proveedor')
,p_step_title=>unistr('Art\00EDculos por Proveedor')
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14148068840928458208)
,p_plug_name=>unistr('Art\00EDculos por Proveedor')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14148070507304458212)
,p_plug_name=>unistr('Art\00EDculos por Proveedor')
,p_parent_plug_id=>wwv_flow_api.id(14148068840928458208)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.*, b.*, cxp_nombre_prov_v_nx(',
'  apr_emp_Empresa',
' ,apr_pro_proveedor',
' ,apr_pro_mon_moneda',
') nombre_proveedor from inv_Articulo_tb_nx a , inv_articulo_proveedor_Tb_nx b',
'WHERE  ato_articulo = apr_ato_articulo(+)',
'AND  ato_Emp_Empresa = apr_emp_empresa (+) ',
'AND ato_emp_Empresa = :p147_empresa'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P147_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14148070862756458214)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>85051132316241955
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088487929210665892)
,p_db_column_name=>'ATO_EMP_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'FI'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488000893665893)
,p_db_column_name=>'ATO_ARTICULO'
,p_display_order=>20
,p_column_identifier=>'FJ'
,p_column_label=>unistr('Art\00EDculo')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488101232665894)
,p_db_column_name=>'ATO_FMA_FAMILIA'
,p_display_order=>30
,p_column_identifier=>'FK'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488176887665895)
,p_db_column_name=>'ATO_DESCRIPCION'
,p_display_order=>40
,p_column_identifier=>'FL'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488274273665896)
,p_db_column_name=>'ATO_DESCRIPCION_ALTERNA'
,p_display_order=>50
,p_column_identifier=>'FM'
,p_column_label=>unistr('Descripci\00F3n Alterna')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488345460665897)
,p_db_column_name=>'ATO_OBSERVACIONES'
,p_display_order=>60
,p_column_identifier=>'FN'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488462507665898)
,p_db_column_name=>'ATO_MOD_EMP_EMPRESA'
,p_display_order=>70
,p_column_identifier=>'FO'
,p_column_label=>'Empresa Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488552716665899)
,p_db_column_name=>'ATO_MOD_MODELO'
,p_display_order=>80
,p_column_identifier=>'FP'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488703300665900)
,p_db_column_name=>'ATO_MAR_MARCA'
,p_display_order=>90
,p_column_identifier=>'FQ'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488803439665901)
,p_db_column_name=>'ATO_CANTIDAD_MEDIDA'
,p_display_order=>100
,p_column_identifier=>'FR'
,p_column_label=>'Cantidad Medida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088488837072665902)
,p_db_column_name=>'ATO_MED_MEDIDA'
,p_display_order=>110
,p_column_identifier=>'FS'
,p_column_label=>'Medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088489003532665903)
,p_db_column_name=>'ATO_PESO_NETO'
,p_display_order=>120
,p_column_identifier=>'FT'
,p_column_label=>'Peso Neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088489068940665904)
,p_db_column_name=>'ATO_MED_MEDIDA_PESO_NETO'
,p_display_order=>130
,p_column_identifier=>'FU'
,p_column_label=>'Medida Peso'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088489223579665905)
,p_db_column_name=>'ATO_PESO_BRUTO'
,p_display_order=>140
,p_column_identifier=>'FV'
,p_column_label=>'Peso Bruto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088489322757665906)
,p_db_column_name=>'ATO_MED_MEDIDA_PESO_BRUTO'
,p_display_order=>150
,p_column_identifier=>'FW'
,p_column_label=>'Medida Peso Bruto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088489405158665907)
,p_db_column_name=>'ATO_VOLUMEN_ALTO'
,p_display_order=>160
,p_column_identifier=>'FX'
,p_column_label=>'Volumen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088489490541665908)
,p_db_column_name=>'ATO_MED_MEDIDA_VOLUMEN_ALTO'
,p_display_order=>170
,p_column_identifier=>'FY'
,p_column_label=>'Medida Volumen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088489611893665909)
,p_db_column_name=>'ATO_VOLUMEN_LARGO'
,p_display_order=>180
,p_column_identifier=>'FZ'
,p_column_label=>'Ato volumen largo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088617669207836560)
,p_db_column_name=>'ATO_MED_MEDIDA_VOLUMEN_LARGO'
,p_display_order=>190
,p_column_identifier=>'GA'
,p_column_label=>'Ato med medida volumen largo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088617752614836561)
,p_db_column_name=>'ATO_VOLUMEN_ANCHO'
,p_display_order=>200
,p_column_identifier=>'GB'
,p_column_label=>'Ato volumen ancho'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088617848681836562)
,p_db_column_name=>'ATO_MED_MEDIDA_VOLUMEN_ANCHO'
,p_display_order=>210
,p_column_identifier=>'GC'
,p_column_label=>'Ato med medida volumen ancho'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088617958796836563)
,p_db_column_name=>'ATO_CANTIDAD_EMPAQUE'
,p_display_order=>220
,p_column_identifier=>'GD'
,p_column_label=>'Ato cantidad empaque'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618053263836564)
,p_db_column_name=>'ATO_MED_MEDIDA_EMPAQUE'
,p_display_order=>230
,p_column_identifier=>'GE'
,p_column_label=>'Ato med medida empaque'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618189980836565)
,p_db_column_name=>'ATO_CANTIDAD_MAQUINA'
,p_display_order=>240
,p_column_identifier=>'GF'
,p_column_label=>'Ato cantidad maquina'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618329828836566)
,p_db_column_name=>'ATO_PLU'
,p_display_order=>250
,p_column_identifier=>'GG'
,p_column_label=>'Ato plu'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618338022836567)
,p_db_column_name=>'ATO_PARTE_FABRICANTE'
,p_display_order=>260
,p_column_identifier=>'GH'
,p_column_label=>'Ato parte fabricante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618492902836568)
,p_db_column_name=>'ATO_PAA_PARTIDA'
,p_display_order=>270
,p_column_identifier=>'GI'
,p_column_label=>'Ato paa partida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618614111836569)
,p_db_column_name=>'ATO_COSTO_FOB'
,p_display_order=>280
,p_column_identifier=>'GJ'
,p_column_label=>'Ato costo fob'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618708389836570)
,p_db_column_name=>'ATO_COSTO_ESTANDAR'
,p_display_order=>290
,p_column_identifier=>'GK'
,p_column_label=>'Ato costo estandar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618818851836571)
,p_db_column_name=>'ATO_DESCONTINUADO'
,p_display_order=>300
,p_column_identifier=>'GL'
,p_column_label=>'Ato descontinuado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618852583836572)
,p_db_column_name=>'ATO_MAXIMO_DESCUENTO'
,p_display_order=>310
,p_column_identifier=>'GM'
,p_column_label=>'Ato maximo descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088618964433836573)
,p_db_column_name=>'ATO_CANTIDAD_MINIMA'
,p_display_order=>320
,p_column_identifier=>'GN'
,p_column_label=>'Ato cantidad minima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619126623836574)
,p_db_column_name=>'ATO_CANTIDAD_MAXIMA'
,p_display_order=>330
,p_column_identifier=>'GO'
,p_column_label=>'Ato cantidad maxima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619157748836575)
,p_db_column_name=>'ATO_PEDIDO_MINIMO'
,p_display_order=>340
,p_column_identifier=>'GP'
,p_column_label=>'Ato pedido minimo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619230932836576)
,p_db_column_name=>'ATO_PUNTO_REORDEN'
,p_display_order=>350
,p_column_identifier=>'GQ'
,p_column_label=>'Ato punto reorden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619359657836577)
,p_db_column_name=>'ATO_AGA_AGRUPACION'
,p_display_order=>360
,p_column_identifier=>'GR'
,p_column_label=>'Ato aga agrupacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619514153836578)
,p_db_column_name=>'ATO_FECHA_PRIMER_INGRESO'
,p_display_order=>370
,p_column_identifier=>'GS'
,p_column_label=>'Ato fecha primer ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619545913836579)
,p_db_column_name=>'ATO_ITEMIZADO'
,p_display_order=>380
,p_column_identifier=>'GT'
,p_column_label=>'Ato itemizado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619696396836580)
,p_db_column_name=>'ATO_CLAVE'
,p_display_order=>390
,p_column_identifier=>'GU'
,p_column_label=>'Ato clave'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619823456836581)
,p_db_column_name=>'ATO_FLAG_TOMA_FISICA'
,p_display_order=>400
,p_column_identifier=>'GV'
,p_column_label=>'Ato flag toma fisica'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619834148836582)
,p_db_column_name=>'ATO_LIBRE_FACTURACION'
,p_display_order=>410
,p_column_identifier=>'GW'
,p_column_label=>'Ato libre facturacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088619950445836583)
,p_db_column_name=>'ATO_TIEMPO_ENTREGA'
,p_display_order=>420
,p_column_identifier=>'GX'
,p_column_label=>'Ato tiempo entrega'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620100420836584)
,p_db_column_name=>'ATO_CATEGORIA'
,p_display_order=>430
,p_column_identifier=>'GY'
,p_column_label=>'Ato categoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620168295836585)
,p_db_column_name=>'ATO_GPR_GRUPO_PRODUCTO'
,p_display_order=>440
,p_column_identifier=>'GZ'
,p_column_label=>'Ato gpr grupo producto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620311127836586)
,p_db_column_name=>'ATO_TUS_TIPO_USO'
,p_display_order=>450
,p_column_identifier=>'HA'
,p_column_label=>'Ato tus tipo uso'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620404359836587)
,p_db_column_name=>'ATO_GRAVADO'
,p_display_order=>460
,p_column_identifier=>'HB'
,p_column_label=>'Ato gravado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620523908836588)
,p_db_column_name=>'ATO_AJUSTA_INFLACION'
,p_display_order=>470
,p_column_identifier=>'HC'
,p_column_label=>'Ato ajusta inflacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620602825836589)
,p_db_column_name=>'ATO_REQUIERE_CERTIFICACION'
,p_display_order=>480
,p_column_identifier=>'HD'
,p_column_label=>'Ato requiere certificacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620721669836590)
,p_db_column_name=>'ATO_BLOQUEADO_COMPRA'
,p_display_order=>490
,p_column_identifier=>'HE'
,p_column_label=>'Ato bloqueado compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620807131836591)
,p_db_column_name=>'ATO_BLOQUEADO_COMPRA_POR'
,p_display_order=>500
,p_column_identifier=>'HF'
,p_column_label=>'Ato bloqueado compra por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620846274836592)
,p_db_column_name=>'ATO_FECHA_BLOQUEO_COMPRA'
,p_display_order=>510
,p_column_identifier=>'HG'
,p_column_label=>'Ato fecha bloqueo compra'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088620963655836593)
,p_db_column_name=>'ATO_BLOQUEADO_VENTA'
,p_display_order=>520
,p_column_identifier=>'HH'
,p_column_label=>'Ato bloqueado venta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621099303836594)
,p_db_column_name=>'ATO_BLOQUEADO_VENTA_POR'
,p_display_order=>530
,p_column_identifier=>'HI'
,p_column_label=>'Ato bloqueado venta por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621209139836595)
,p_db_column_name=>'ATO_FECHA_BLOQUEO_VENTA'
,p_display_order=>540
,p_column_identifier=>'HJ'
,p_column_label=>'Ato fecha bloqueo venta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621307954836596)
,p_db_column_name=>'ATO_EMP_REEMPLAZA'
,p_display_order=>550
,p_column_identifier=>'HK'
,p_column_label=>'Ato emp reemplaza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621375334836597)
,p_db_column_name=>'ATO_ATO_REEMPLAZA'
,p_display_order=>560
,p_column_identifier=>'HL'
,p_column_label=>'Ato ato reemplaza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621511378836598)
,p_db_column_name=>'ATO_EMP_REEMPLAZO'
,p_display_order=>570
,p_column_identifier=>'HM'
,p_column_label=>'Ato emp reemplazo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621601779836599)
,p_db_column_name=>'ATO_ATO_REEMPLAZO'
,p_display_order=>580
,p_column_identifier=>'HN'
,p_column_label=>'Ato ato reemplazo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621719111836600)
,p_db_column_name=>'ATO_NUMERO_MESES_INVENTARIO'
,p_display_order=>590
,p_column_identifier=>'HO'
,p_column_label=>'Ato numero meses inventario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621780608836601)
,p_db_column_name=>'ATO_ROTACION_SIMPLE'
,p_display_order=>600
,p_column_identifier=>'HP'
,p_column_label=>'Ato rotacion simple'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621878280836602)
,p_db_column_name=>'ATO_CREADO_POR'
,p_display_order=>610
,p_column_identifier=>'HQ'
,p_column_label=>'Ato creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088621985089836603)
,p_db_column_name=>'ATO_FECHA_CREACION'
,p_display_order=>620
,p_column_identifier=>'HR'
,p_column_label=>'Ato fecha creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622034129836604)
,p_db_column_name=>'ATO_MODIFICADO_POR'
,p_display_order=>630
,p_column_identifier=>'HS'
,p_column_label=>'Ato modificado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622145859836605)
,p_db_column_name=>'ATO_FECHA_MODIFICACION'
,p_display_order=>640
,p_column_identifier=>'HT'
,p_column_label=>'Ato fecha modificacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622253047836606)
,p_db_column_name=>'ATO_DUN14'
,p_display_order=>650
,p_column_identifier=>'HU'
,p_column_label=>'Ato dun14'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622378789836607)
,p_db_column_name=>'ATO_REG_SANITARIO'
,p_display_order=>660
,p_column_identifier=>'HV'
,p_column_label=>'Ato reg sanitario'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622477838836608)
,p_db_column_name=>'ATO_FECHA_VEN_REG_SANITAR'
,p_display_order=>670
,p_column_identifier=>'HW'
,p_column_label=>'Ato fecha ven reg sanitar'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622534750836609)
,p_db_column_name=>'ATO_FECHA_DESCONTINUADO'
,p_display_order=>680
,p_column_identifier=>'HX'
,p_column_label=>'Ato fecha descontinuado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622698352836560)
,p_db_column_name=>'ATO_FECHA_LIQUIDADO'
,p_display_order=>690
,p_column_identifier=>'HY'
,p_column_label=>'Ato fecha liquidado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622806206836561)
,p_db_column_name=>'ATO_EN_LIQUIDACION'
,p_display_order=>700
,p_column_identifier=>'HZ'
,p_column_label=>'Ato en liquidacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622897328836562)
,p_db_column_name=>'ATO_FACTURA_MINIMAS'
,p_display_order=>710
,p_column_identifier=>'IA'
,p_column_label=>'Ato factura minimas'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088622943356836563)
,p_db_column_name=>'ATO_TIEMPO_ENTREGA_DIAS'
,p_display_order=>720
,p_column_identifier=>'IB'
,p_column_label=>'Ato tiempo entrega dias'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623048443836564)
,p_db_column_name=>'ATO_NUMERO_DIAS_INVENTARIO'
,p_display_order=>730
,p_column_identifier=>'IC'
,p_column_label=>'Ato numero dias inventario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623180410836565)
,p_db_column_name=>'ATO_MAXDIAS_RESPETO_PRECIO'
,p_display_order=>740
,p_column_identifier=>'ID'
,p_column_label=>'Ato maxdias respeto precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623309277836566)
,p_db_column_name=>'ATO_TAM_EMP_EMPRESA'
,p_display_order=>750
,p_column_identifier=>'IE'
,p_column_label=>'Ato tam emp empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623371732836567)
,p_db_column_name=>'ATO_TAM_TAMANO'
,p_display_order=>760
,p_column_identifier=>'IF'
,p_column_label=>'Ato tam tamano'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623447106836568)
,p_db_column_name=>'ATO_CLR_EMP_EMPRESA'
,p_display_order=>770
,p_column_identifier=>'IG'
,p_column_label=>'Ato clr emp empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623629553836569)
,p_db_column_name=>'ATO_CLR_COLOR'
,p_display_order=>780
,p_column_identifier=>'IH'
,p_column_label=>'Ato clr color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623727164836570)
,p_db_column_name=>'ATO_CLASIFICACION_ABC'
,p_display_order=>790
,p_column_identifier=>'II'
,p_column_label=>'Ato clasificacion abc'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623788943836571)
,p_db_column_name=>'ATO_LOCAL_EXTERNO'
,p_display_order=>800
,p_column_identifier=>'IJ'
,p_column_label=>'Ato local externo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623843153836572)
,p_db_column_name=>'ATO_USO_CAR_ID'
,p_display_order=>810
,p_column_identifier=>'IK'
,p_column_label=>'Ato uso car id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088623942796836573)
,p_db_column_name=>'ATO_CLA_CAR_ID'
,p_display_order=>820
,p_column_identifier=>'IL'
,p_column_label=>'Ato cla car id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624046875836574)
,p_db_column_name=>'ATO_TIPO_COMBUSTIBLE'
,p_display_order=>830
,p_column_identifier=>'IM'
,p_column_label=>'Ato tipo combustible'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624136496836575)
,p_db_column_name=>'ATO_CILINDRAJE'
,p_display_order=>840
,p_column_identifier=>'IN'
,p_column_label=>'Ato cilindraje'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624250547836576)
,p_db_column_name=>'ATO_NUMERO_CILINDROS'
,p_display_order=>850
,p_column_identifier=>'IO'
,p_column_label=>'Ato numero cilindros'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624368953836577)
,p_db_column_name=>'ATO_TIPO_TRACCION'
,p_display_order=>860
,p_column_identifier=>'IP'
,p_column_label=>'Ato tipo traccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624431457836578)
,p_db_column_name=>'ATO_TIPO_CARROCERIA'
,p_display_order=>870
,p_column_identifier=>'IQ'
,p_column_label=>'Ato tipo carroceria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624568703836579)
,p_db_column_name=>'ATO_TIPO_ESTILO'
,p_display_order=>880
,p_column_identifier=>'IR'
,p_column_label=>'Ato tipo estilo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624660501836580)
,p_db_column_name=>'ATO_CATEGORIA_CAR'
,p_display_order=>890
,p_column_identifier=>'IS'
,p_column_label=>'Ato categoria car'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624788419836581)
,p_db_column_name=>'ATO_TIPO_SERVICIO'
,p_display_order=>900
,p_column_identifier=>'IT'
,p_column_label=>'Ato tipo servicio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624834852836582)
,p_db_column_name=>'ATO_BASE_MENSUAL'
,p_display_order=>910
,p_column_identifier=>'IU'
,p_column_label=>'Ato base mensual'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088624932085836583)
,p_db_column_name=>'ATO_PAIS_ORIGEN'
,p_display_order=>920
,p_column_identifier=>'IV'
,p_column_label=>'Ato pais origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625111680836584)
,p_db_column_name=>'ATO_IND_COMBO'
,p_display_order=>930
,p_column_identifier=>'IW'
,p_column_label=>'Ato ind combo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625143865836585)
,p_db_column_name=>'ATO_MODIFICAR_PRECIO'
,p_display_order=>940
,p_column_identifier=>'IX'
,p_column_label=>'Ato modificar precio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625286375836586)
,p_db_column_name=>'ATO_IND_DESPIECE'
,p_display_order=>950
,p_column_identifier=>'IY'
,p_column_label=>'Ato ind despiece'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625381278836587)
,p_db_column_name=>'ATO_IND_OBSERVACIONES'
,p_display_order=>960
,p_column_identifier=>'IZ'
,p_column_label=>'Ato ind observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625430466836588)
,p_db_column_name=>'ATO_BAJO_MARGEN'
,p_display_order=>970
,p_column_identifier=>'JA'
,p_column_label=>'Ato bajo margen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625573290836589)
,p_db_column_name=>'ATO_MODIFICA_DESCRIPCION'
,p_display_order=>980
,p_column_identifier=>'JB'
,p_column_label=>'Ato modifica descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625711183836590)
,p_db_column_name=>'ATO_FRACCIONABLE'
,p_display_order=>990
,p_column_identifier=>'JC'
,p_column_label=>'Ato fraccionable'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625796744836591)
,p_db_column_name=>'ATO_SOS_ID'
,p_display_order=>1000
,p_column_identifier=>'JD'
,p_column_label=>'Ato sos id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088625859467836592)
,p_db_column_name=>'ATO_CRM'
,p_display_order=>1010
,p_column_identifier=>'JE'
,p_column_label=>'Ato crm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626010714836593)
,p_db_column_name=>'ATO_SIN_GESTION_ESTUDIANTE'
,p_display_order=>1020
,p_column_identifier=>'JF'
,p_column_label=>'Ato sin gestion estudiante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626072742836594)
,p_db_column_name=>'APR_EMP_EMPRESA'
,p_display_order=>1030
,p_column_identifier=>'JG'
,p_column_label=>'Apr emp empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626163406836595)
,p_db_column_name=>'APR_ATO_ARTICULO'
,p_display_order=>1040
,p_column_identifier=>'JH'
,p_column_label=>'Apr ato articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626277477836596)
,p_db_column_name=>'APR_PRO_PROVEEDOR'
,p_display_order=>1050
,p_column_identifier=>'JI'
,p_column_label=>'Apr pro proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626384733836597)
,p_db_column_name=>'APR_PRO_MON_MONEDA'
,p_display_order=>1060
,p_column_identifier=>'JJ'
,p_column_label=>'Apr pro mon moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626433837836598)
,p_db_column_name=>'APR_CODIGO_ARTICULO'
,p_display_order=>1070
,p_column_identifier=>'JK'
,p_column_label=>'Apr codigo articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626583404836599)
,p_db_column_name=>'APR_ULTIMA_FECHA_COMPRA'
,p_display_order=>1080
,p_column_identifier=>'JL'
,p_column_label=>'Apr ultima fecha compra'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626694963836600)
,p_db_column_name=>'APR_ULTIMO_PRECIO_COMPRA'
,p_display_order=>1090
,p_column_identifier=>'JM'
,p_column_label=>'Apr ultimo precio compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626755842836601)
,p_db_column_name=>'APR_ULTIMA_CANTIDAD_COMPRA'
,p_display_order=>1100
,p_column_identifier=>'JN'
,p_column_label=>'Apr ultima cantidad compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088626842786836602)
,p_db_column_name=>'APR_ULTIMO_TIEMPO_ENTREGA'
,p_display_order=>1110
,p_column_identifier=>'JO'
,p_column_label=>'Apr ultimo tiempo entrega'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627004157836603)
,p_db_column_name=>'APR_NIVEL_PROVEEDOR'
,p_display_order=>1120
,p_column_identifier=>'JP'
,p_column_label=>'Apr nivel proveedor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627033311836604)
,p_db_column_name=>'APR_RETORNABLE'
,p_display_order=>1130
,p_column_identifier=>'JQ'
,p_column_label=>'Apr retornable'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627146279836605)
,p_db_column_name=>'APR_CANTIDAD_MEDIDA'
,p_display_order=>1140
,p_column_identifier=>'JR'
,p_column_label=>'Apr cantidad medida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627318463836606)
,p_db_column_name=>'APR_MED_MEDIDA'
,p_display_order=>1150
,p_column_identifier=>'JS'
,p_column_label=>'Apr med medida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627393684836607)
,p_db_column_name=>'APR_PESO_NETO'
,p_display_order=>1160
,p_column_identifier=>'JT'
,p_column_label=>'Apr peso neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627484165836608)
,p_db_column_name=>'APR_MED_MEDIDA_PESO_NETO'
,p_display_order=>1170
,p_column_identifier=>'JU'
,p_column_label=>'Apr med medida peso neto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627547047836609)
,p_db_column_name=>'APR_PESO_BRUTO'
,p_display_order=>1180
,p_column_identifier=>'JV'
,p_column_label=>'Apr peso bruto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627688443836560)
,p_db_column_name=>'APR_MED_MEDIDA_PESO_BRUTO'
,p_display_order=>1190
,p_column_identifier=>'JW'
,p_column_label=>'Apr med medida peso bruto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627799922836561)
,p_db_column_name=>'APR_VOLUMEN_ALTO'
,p_display_order=>1200
,p_column_identifier=>'JX'
,p_column_label=>'Apr volumen alto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627918123836562)
,p_db_column_name=>'APR_MED_MEDIDA_VOLUMEN_ALTO'
,p_display_order=>1210
,p_column_identifier=>'JY'
,p_column_label=>'Apr med medida volumen alto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088627974372836563)
,p_db_column_name=>'APR_VOLUMEN_LARGO'
,p_display_order=>1220
,p_column_identifier=>'JZ'
,p_column_label=>'Apr volumen largo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628117196836564)
,p_db_column_name=>'APR_MED_MEDIDA_VOLUMEN_LARGO'
,p_display_order=>1230
,p_column_identifier=>'KA'
,p_column_label=>'Apr med medida volumen largo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628177866836565)
,p_db_column_name=>'APR_VOLUMEN_ANCHO'
,p_display_order=>1240
,p_column_identifier=>'KB'
,p_column_label=>'Apr volumen ancho'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628294903836566)
,p_db_column_name=>'APR_MED_MEDIDA_VOLUMEN_ANCHO'
,p_display_order=>1250
,p_column_identifier=>'KC'
,p_column_label=>'Apr med medida volumen ancho'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628390442836567)
,p_db_column_name=>'APR_CANTIDAD_EMPAQUE'
,p_display_order=>1260
,p_column_identifier=>'KD'
,p_column_label=>'Apr cantidad empaque'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628513221836568)
,p_db_column_name=>'APR_MED_MEDIDA_EMPAQUE'
,p_display_order=>1270
,p_column_identifier=>'KE'
,p_column_label=>'Apr med medida empaque'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628586971836569)
,p_db_column_name=>'APR_VIGENCIA_OFERTA'
,p_display_order=>1280
,p_column_identifier=>'KF'
,p_column_label=>'Apr vigencia oferta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628657115836570)
,p_db_column_name=>'APR_CALIDAD'
,p_display_order=>1290
,p_column_identifier=>'KG'
,p_column_label=>'Apr calidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628740475836571)
,p_db_column_name=>'APR_DESCUENTO'
,p_display_order=>1300
,p_column_identifier=>'KH'
,p_column_label=>'Apr descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628930071836572)
,p_db_column_name=>'APR_MAR_MARCA'
,p_display_order=>1310
,p_column_identifier=>'KI'
,p_column_label=>'Apr mar marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088628945074836573)
,p_db_column_name=>'APR_PRE_PRESENTACION'
,p_display_order=>1320
,p_column_identifier=>'KJ'
,p_column_label=>'Apr pre presentacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088629070807836574)
,p_db_column_name=>'APR_FRECUENCIA_PEDIDOS'
,p_display_order=>1330
,p_column_identifier=>'KK'
,p_column_label=>'Apr frecuencia pedidos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088629194578836575)
,p_db_column_name=>'APR_FACTOR_CONVERSION'
,p_display_order=>1340
,p_column_identifier=>'KL'
,p_column_label=>'Apr factor conversion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088629263368836576)
,p_db_column_name=>'APR_INV_MAX_EN_DIAS'
,p_display_order=>1350
,p_column_identifier=>'KM'
,p_column_label=>'Apr inv max en dias'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088629415810836577)
,p_db_column_name=>'APR_PAI_PAIS'
,p_display_order=>1360
,p_column_identifier=>'KN'
,p_column_label=>'Apr pai pais'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088629485753836578)
,p_db_column_name=>'APR_TIPO_PROVEEDOR'
,p_display_order=>1370
,p_column_identifier=>'KO'
,p_column_label=>'Apr tipo proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088629630227836579)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>1380
,p_column_identifier=>'KP'
,p_column_label=>'Nombre proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14148080199423458233)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'255965'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PCO_DSP_PCO_PRECIO::ATO_EMP_EMPRESA:ATO_ARTICULO:ATO_FMA_FAMILIA:ATO_DESCRIPCION:ATO_DESCRIPCION_ALTERNA:ATO_OBSERVACIONES:ATO_MOD_EMP_EMPRESA:ATO_MOD_MODELO:ATO_MAR_MARCA:ATO_CANTIDAD_MEDIDA:ATO_MED_MEDIDA:ATO_PESO_NETO:ATO_MED_MEDIDA_PESO_NETO:ATO_'
||'PESO_BRUTO:ATO_MED_MEDIDA_PESO_BRUTO:ATO_VOLUMEN_ALTO:ATO_MED_MEDIDA_VOLUMEN_ALTO:ATO_VOLUMEN_LARGO:ATO_MED_MEDIDA_VOLUMEN_LARGO:ATO_VOLUMEN_ANCHO:ATO_MED_MEDIDA_VOLUMEN_ANCHO:ATO_CANTIDAD_EMPAQUE:ATO_MED_MEDIDA_EMPAQUE:ATO_CANTIDAD_MAQUINA:ATO_PLU:A'
||'TO_PARTE_FABRICANTE:ATO_PAA_PARTIDA:ATO_COSTO_FOB:ATO_COSTO_ESTANDAR:ATO_DESCONTINUADO:ATO_MAXIMO_DESCUENTO:ATO_CANTIDAD_MINIMA:ATO_CANTIDAD_MAXIMA:ATO_PEDIDO_MINIMO:ATO_PUNTO_REORDEN:ATO_AGA_AGRUPACION:ATO_FECHA_PRIMER_INGRESO:ATO_ITEMIZADO:ATO_CLAV'
||'E:ATO_FLAG_TOMA_FISICA:ATO_LIBRE_FACTURACION:ATO_TIEMPO_ENTREGA:ATO_CATEGORIA:ATO_GPR_GRUPO_PRODUCTO:ATO_TUS_TIPO_USO:ATO_GRAVADO:ATO_AJUSTA_INFLACION:ATO_REQUIERE_CERTIFICACION:ATO_BLOQUEADO_COMPRA:ATO_BLOQUEADO_COMPRA_POR:ATO_FECHA_BLOQUEO_COMPRA:A'
||'TO_BLOQUEADO_VENTA:ATO_BLOQUEADO_VENTA_POR:ATO_FECHA_BLOQUEO_VENTA:ATO_EMP_REEMPLAZA:ATO_ATO_REEMPLAZA:ATO_EMP_REEMPLAZO:ATO_ATO_REEMPLAZO:ATO_NUMERO_MESES_INVENTARIO:ATO_ROTACION_SIMPLE:ATO_CREADO_POR:ATO_FECHA_CREACION:ATO_MODIFICADO_POR:ATO_FECHA_'
||'MODIFICACION:ATO_DUN14:ATO_REG_SANITARIO:ATO_FECHA_VEN_REG_SANITAR:ATO_FECHA_DESCONTINUADO:ATO_FECHA_LIQUIDADO:ATO_EN_LIQUIDACION:ATO_FACTURA_MINIMAS:ATO_TIEMPO_ENTREGA_DIAS:ATO_NUMERO_DIAS_INVENTARIO:ATO_MAXDIAS_RESPETO_PRECIO:ATO_TAM_EMP_EMPRESA:AT'
||'O_TAM_TAMANO:ATO_CLR_EMP_EMPRESA:ATO_CLR_COLOR:ATO_CLASIFICACION_ABC:ATO_LOCAL_EXTERNO:ATO_USO_CAR_ID:ATO_CLA_CAR_ID:ATO_TIPO_COMBUSTIBLE:ATO_CILINDRAJE:ATO_NUMERO_CILINDROS:ATO_TIPO_TRACCION:ATO_TIPO_CARROCERIA:ATO_TIPO_ESTILO:ATO_CATEGORIA_CAR:ATO_'
||'TIPO_SERVICIO:ATO_BASE_MENSUAL:ATO_PAIS_ORIGEN:ATO_IND_COMBO:ATO_MODIFICAR_PRECIO:ATO_IND_DESPIECE:ATO_IND_OBSERVACIONES:ATO_BAJO_MARGEN:ATO_MODIFICA_DESCRIPCION:ATO_FRACCIONABLE:ATO_SOS_ID:ATO_CRM:ATO_SIN_GESTION_ESTUDIANTE:APR_EMP_EMPRESA:APR_ATO_A'
||'RTICULO:APR_PRO_PROVEEDOR:APR_PRO_MON_MONEDA:APR_CODIGO_ARTICULO:APR_ULTIMA_FECHA_COMPRA:APR_ULTIMO_PRECIO_COMPRA:APR_ULTIMA_CANTIDAD_COMPRA:APR_ULTIMO_TIEMPO_ENTREGA:APR_NIVEL_PROVEEDOR:APR_RETORNABLE:APR_CANTIDAD_MEDIDA:APR_MED_MEDIDA:APR_PESO_NETO'
||':APR_MED_MEDIDA_PESO_NETO:APR_PESO_BRUTO:APR_MED_MEDIDA_PESO_BRUTO:APR_VOLUMEN_ALTO:APR_MED_MEDIDA_VOLUMEN_ALTO:APR_VOLUMEN_LARGO:APR_MED_MEDIDA_VOLUMEN_LARGO:APR_VOLUMEN_ANCHO:APR_MED_MEDIDA_VOLUMEN_ANCHO:APR_CANTIDAD_EMPAQUE:APR_MED_MEDIDA_EMPAQUE:'
||'APR_VIGENCIA_OFERTA:APR_CALIDAD:APR_DESCUENTO:APR_MAR_MARCA:APR_PRE_PRESENTACION:APR_FRECUENCIA_PEDIDOS:APR_FACTOR_CONVERSION:APR_INV_MAX_EN_DIAS:APR_PAI_PAIS:APR_TIPO_PROVEEDOR:NOMBRE_PROVEEDOR'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14088616858492834399)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14148068840928458208)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14088617297884834413)
,p_name=>'P147_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14148068840928458208)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
