prompt --application/pages/page_00184
begin
--   Manifest
--     PAGE: 00184
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>184
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Boletas y Facturas'
,p_step_title=>'Boletas y Facturas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20210531102030'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14172790706104760525)
,p_plug_name=>'Boletas de Planillas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14172786809824676067)
,p_plug_name=>'Boletas de Planillas'
,p_parent_plug_id=>wwv_flow_api.id(14172790706104760525)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bol_id id_boleta, bol_emp_empresa empresa_boleta, bol_tpl_id id_tipo_planilla, pla_nombre_tipo_planilla_v_nx(',
'  bol_emp_empresa,',
'  bol_tpl_id) nombre_tipo_planilla,',
'CASE WHEN bol_estado = ''C'' THEN ''CREADO'' WHEN bol_estado = ''R'' THEN ''REGISTRADO'' WHEN bol_estado = ''A'' THEN ''ANULADO'' END estado_boleta,',
'bol_fecha_desde fecha_desde_boleta, bol_fecha_hasta fecha_hasta_boleta, bol_fecha_creacion fecha_Creacion_boleta, ',
'bol_creado_por creado_por_boleta, bol_modificado_por modificado_por_boleta, bol_fecha_modificacion fecha_modificacion_boleta,',
'dbo_id id_detalle,dbo_per_persona persona_afecta, gnl_nombre_persona_v_nx (dbo_per_persona) nombre_persona, ',
'dbo_dev_id devengo_id, pla_nombre_devengo_v_nx(',
'  bol_emp_empresa,',
' dbo_dev_id) nombre_devengo, dbo_cantidad cantidad_boleta, dbo_valor valor_boleta, dbo_creado_por creado_por_detalle, ',
' dbo_fecha_Creacion fecha_creado_detalle, dbo_modificado_por modificado_por_Detalle, dbo_fecha_modificacion fecha_modificado_det,',
' dbo_ind_seleccion seleccionado_det',
'from pla_boleta_tb_nx, pla_detalle_boleta_tb_nx',
'WHERE dbo_bol_id = bol_id ',
'AND INSTR ('':''||:P184_EMPRESA||'':'','':''||bol_emp_empresa||'':'') > 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P184_EMPRESA'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14172786931249676067)
,p_name=>'Comisiones'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'CANDERSON'
,p_internal_uid=>289964946853080344
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885284747241655372)
,p_db_column_name=>'ID_BOLETA'
,p_display_order=>10
,p_column_identifier=>'DK'
,p_column_label=>'Id Boleta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885284869256655373)
,p_db_column_name=>'EMPRESA_BOLETA'
,p_display_order=>20
,p_column_identifier=>'DL'
,p_column_label=>'Empresa Boleta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407279043404124)
,p_db_column_name=>'ID_TIPO_PLANILLA'
,p_display_order=>30
,p_column_identifier=>'DM'
,p_column_label=>'Id Tipo Planilla'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407363750404125)
,p_db_column_name=>'NOMBRE_TIPO_PLANILLA'
,p_display_order=>40
,p_column_identifier=>'DN'
,p_column_label=>'Nombre Tipo Planilla'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407470910404126)
,p_db_column_name=>'ESTADO_BOLETA'
,p_display_order=>50
,p_column_identifier=>'DO'
,p_column_label=>'Estado Boleta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407571845404127)
,p_db_column_name=>'FECHA_DESDE_BOLETA'
,p_display_order=>60
,p_column_identifier=>'DP'
,p_column_label=>'Fecha Desde Boleta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407600585404128)
,p_db_column_name=>'FECHA_HASTA_BOLETA'
,p_display_order=>70
,p_column_identifier=>'DQ'
,p_column_label=>'Fecha Hasta Boleta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407762527404129)
,p_db_column_name=>'FECHA_CREACION_BOLETA'
,p_display_order=>80
,p_column_identifier=>'DR'
,p_column_label=>'Fecha Creacion Boleta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407818271404130)
,p_db_column_name=>'CREADO_POR_BOLETA'
,p_display_order=>90
,p_column_identifier=>'DS'
,p_column_label=>'Creado Por Boleta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407896446404131)
,p_db_column_name=>'MODIFICADO_POR_BOLETA'
,p_display_order=>100
,p_column_identifier=>'DT'
,p_column_label=>'Modificado Por Boleta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885407990187404132)
,p_db_column_name=>'FECHA_MODIFICACION_BOLETA'
,p_display_order=>110
,p_column_identifier=>'DU'
,p_column_label=>'Fecha Modificacion Boleta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408125074404133)
,p_db_column_name=>'ID_DETALLE'
,p_display_order=>120
,p_column_identifier=>'DV'
,p_column_label=>'Id Detalle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408203087404134)
,p_db_column_name=>'PERSONA_AFECTA'
,p_display_order=>130
,p_column_identifier=>'DW'
,p_column_label=>'Persona Afecta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408333411404135)
,p_db_column_name=>'NOMBRE_PERSONA'
,p_display_order=>140
,p_column_identifier=>'DX'
,p_column_label=>'Nombre Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408461972404136)
,p_db_column_name=>'DEVENGO_ID'
,p_display_order=>150
,p_column_identifier=>'DY'
,p_column_label=>'Devengo Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408516882404137)
,p_db_column_name=>'NOMBRE_DEVENGO'
,p_display_order=>160
,p_column_identifier=>'DZ'
,p_column_label=>'Nombre Devengo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408620796404138)
,p_db_column_name=>'CANTIDAD_BOLETA'
,p_display_order=>170
,p_column_identifier=>'EA'
,p_column_label=>'Cantidad Boleta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408775990404139)
,p_db_column_name=>'VALOR_BOLETA'
,p_display_order=>180
,p_column_identifier=>'EB'
,p_column_label=>'Valor Boleta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408862790404140)
,p_db_column_name=>'CREADO_POR_DETALLE'
,p_display_order=>190
,p_column_identifier=>'EC'
,p_column_label=>'Creado Por Detalle'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885408885475404141)
,p_db_column_name=>'FECHA_CREADO_DETALLE'
,p_display_order=>200
,p_column_identifier=>'ED'
,p_column_label=>'Fecha Creado Detalle'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885409080643404142)
,p_db_column_name=>'MODIFICADO_POR_DETALLE'
,p_display_order=>210
,p_column_identifier=>'EE'
,p_column_label=>'Modificado Por Detalle'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885409102410404143)
,p_db_column_name=>'FECHA_MODIFICADO_DET'
,p_display_order=>220
,p_column_identifier=>'EF'
,p_column_label=>'Fecha Modificado Det'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885409257874404144)
,p_db_column_name=>'SELECCIONADO_DET'
,p_display_order=>230
,p_column_identifier=>'EG'
,p_column_label=>'Seleccionado Det'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14172788209773676376)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'25271'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>':BOL_BOL_TRA_TRANSACCION:ID_BOLETA:EMPRESA_BOLETA:ID_TIPO_PLANILLA:NOMBRE_TIPO_PLANILLA:ESTADO_BOLETA:FECHA_DESDE_BOLETA:FECHA_HASTA_BOLETA:FECHA_CREACION_BOLETA:CREADO_POR_BOLETA:MODIFICADO_POR_BOLETA:FECHA_MODIFICACION_BOLETA:ID_DETALLE:PERSONA_AFE'
||'CTA:NOMBRE_PERSONA:DEVENGO_ID:NOMBRE_DEVENGO:CANTIDAD_BOLETA:VALOR_BOLETA:CREADO_POR_DETALLE:FECHA_CREADO_DETALLE:MODIFICADO_POR_DETALLE:FECHA_MODIFICADO_DET:SELECCIONADO_DET'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13885326987924303657)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14172790706104760525)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13885327424115303661)
,p_name=>'P184_EMPRESA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14172790706104760525)
,p_item_default=>'NULL'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13885349507267303692)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ejecutar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'fac_comision_articulo_pr_nx (:P184_EMPRESA,to_date(:P184_INICIO,''DD/MM/RRRR''),to_date(:P184_FIN,''DD/MM/RRRR''));',
'commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error.'
,p_process_when_button_id=>wwv_flow_api.id(13885326987924303657)
,p_process_when_type=>'NEVER'
,p_process_success_message=>'Done.'
);
wwv_flow_api.component_end;
end;
/
