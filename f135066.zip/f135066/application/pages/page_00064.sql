prompt --application/pages/page_00064
begin
--   Manifest
--     PAGE: 00064
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>64
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'INV - Inventario por Localizacion'
,p_step_title=>'Inventario por Localizacion'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153900'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112748850882863804)
,p_plug_name=>'Inventario por Localizacion'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112747971279863777)
,p_plug_name=>'Inventario por Localizacion'
,p_region_name=>'Inventario por Localizacion'
,p_parent_plug_id=>wwv_flow_api.id(14112748850882863804)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 31/05/2017 09:48:57 a.m. (QP5 v5.115.810.9015) */',
'SELECT ato_emp_empresa empresa,',
'       CASE :REQUEST',
'       WHEN ''CSV'' THEN',
'          CHR(39)||ato_articulo',
'       ELSE ato_articulo END articulo,',
'       aun_cantidad cantidad_total,',
'       ato_fma_familia cod_familia,',
'       inv_descrip_fam_v_nx (ato_emp_empresa, ato_fma_familia) familia,',
'       ato_descripcion descripcion,',
'       ato_categoria categoria,',
'       aln_lcn_localizacion cod_localizacion,',
'       aln_clase clase,',
'       inv_descrip_loca_v_nx (aln_emp_empresa, aln_lcn_localizacion)',
'          localizacion,',
'       CASE :REQUEST',
'       WHEN ''CSV'' THEN',
'          CHR(39)||aun_ubn_ubicacion',
'       ELSE aun_ubn_ubicacion END ubicacion,          ',
'       aln_costo_unitario costo_unitario,',
'       DECODE (inv_itemizado_art_v_nx (ato_emp_empresa, ato_articulo),',
'               ''N'',',
'               ''NO'',',
'               ''S'',',
'               ''SI''',
'       )',
'          itemizado,',
'      DECODE (ato_bloqueado_compra, ''N'', ''NO'', ''S'', ''SI'') bloqueado_compra    ,',
'      aln_ultimo_costo ultimo_costo',
'FROM inv_articulo_tb_nx,',
'     inv_articulo_localizacion_tb_n,',
'     inv_articulo_ubicacion_tb_nx',
'WHERE INSTR ('':'' || :P64_EMPRESA || '':'', '':'' || ato_emp_empresa || '':'') > 0',
'      AND ato_emp_empresa = aln_emp_empresa',
'      AND ato_articulo = aln_ato_articulo',
'      AND aln_emp_empresa = aun_emp_empresa',
'      AND aln_lcn_localizacion = aun_lcn_localizacion',
'      AND aln_ato_articulo = aun_aln_ato_articulo',
'      AND aun_cantidad > 0;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P64_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14112748182090863781)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>11956931399075170
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112789669104120051)
,p_db_column_name=>'ARTICULO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
,p_static_id=>'ARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112789750732120051)
,p_db_column_name=>'CANTIDAD_TOTAL'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Cantidad Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CANTIDAD_TOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112789866159120051)
,p_db_column_name=>'FAMILIA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
,p_static_id=>'FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112789970340120051)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112790066913120051)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Categoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CATEGORIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112790166396120052)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
,p_static_id=>'LOCALIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112790275966120052)
,p_db_column_name=>'UBICACION'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Ubicacion'
,p_column_type=>'STRING'
,p_static_id=>'UBICACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112823558128648212)
,p_db_column_name=>'COD_FAMILIA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Cod Familia'
,p_column_type=>'STRING'
,p_static_id=>'COD_FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112825572349656843)
,p_db_column_name=>'COD_LOCALIZACION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Cod Localizacion'
,p_column_type=>'STRING'
,p_static_id=>'COD_LOCALIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097415204656365603)
,p_db_column_name=>'CLASE'
,p_display_order=>20
,p_column_identifier=>'K'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099123688155152602)
,p_db_column_name=>'COSTO_UNITARIO'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097899903964642706)
,p_db_column_name=>'EMPRESA'
,p_display_order=>40
,p_column_identifier=>'L'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099123833079152604)
,p_db_column_name=>'ITEMIZADO'
,p_display_order=>50
,p_column_identifier=>'N'
,p_column_label=>'Itemizado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082255212664365826)
,p_db_column_name=>'BLOQUEADO_COMPRA'
,p_display_order=>60
,p_column_identifier=>'P'
,p_column_label=>'Bloqueado Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058209368451913590)
,p_db_column_name=>'ULTIMO_COSTO'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Ultimo costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14112748663416863796)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'119575'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:COD_LOCALIZACION:LOCALIZACION:COD_FAMILIA:FAMILIA:ARTICULO:DESCRIPCION:CLASE:ITEMIZADO:COSTO_UNITARIO:CANTIDAD_TOTAL:CATEGORIA:UBICACION::BLOQUEADO_COMPRA:ULTIMO_COSTO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14112749667223863808)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14112748850882863804)
,p_button_name=>'CONSULTAR'
,p_button_static_id=>'64_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14112749079593863804)
,p_name=>'P64_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14112748850882863804)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
