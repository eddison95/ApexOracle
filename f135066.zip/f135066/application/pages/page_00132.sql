prompt --application/pages/page_00132
begin
--   Manifest
--     PAGE: 00132
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>132
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('GAC-Oferta Acad\00E9mica')
,p_step_title=>'Oferta'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20210602075201'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14117185643176197511)
,p_plug_name=>'Oferta Academica'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14117183662694197414)
,p_plug_name=>'Oferta academica'
,p_region_name=>'Antiguedad de Saldos'
,p_parent_plug_id=>wwv_flow_api.id(14117185643176197511)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 24/04/2018 03:33:41 p.m. (QP5 v5.115.810.9015) */',
'SELECT   OAC_SLO_SEGMENTO AS Facultad,',
'         OAC_ULA_SLO_SEGMENTO AS Carrera,',
'         OAC_ULA_ANTIGUEDAD AS Generacion,',
unistr('         RAZON_SOCIAL Nombre_Asistente_Acad\00E8mico,'),
'         DOA_ATO_ARTICULO AS Codigo,',
'         ATO_DESCRIPCION AS Descripcion,',
'         OAC_ULA_SLO_GRUPO AS Creditos,',
'         OAC_SLO_GRUPO AS Horas,',
'         NVL (DOA_TOTAL_ALUMNOS, 0) AS Total_Alumnos,',
'         NVL (DOA_ALUMNOS_MATRICULADOS, 0) AS Matriculados,',
'         NVL (DOA_FECHA_INI_CUPO, NULL) AS Fecha_inicial,',
'         NVL (DOA_FECHA_FIN_CUPO, NULL) AS Fecha_Final,',
'         DOA_STATUS_CUPO AS Estado_Curso,',
'         DOP_PRO_PROVEEDOR AS Profesor,',
'         (OHL_ATO_ARTICULO || ''-'' || PAC_PERIODO) AS Periodo,',
'         gnl_nombre_persona_v_nx (DOP_PRO_PROVEEDOR) nombre_profesor,',
'         (SELECT HAC_DESCRIPCION  ',
'            FROM GAC_HORARIOS_ACADEMICOS_TB_NX',
'            WHERE HAC_ID = OHL_HAC_ID) horario,',
'         DHL_UBN_UBICACION_D aula_d,',
'         DHL_UBN_UBICACION_L aula_l,',
'         DHL_UBN_UBICACION_K aula_k,',
'         DHL_UBN_UBICACION_M aula_m,',
'         DHL_UBN_UBICACION_J aula_j,',
'         DHL_UBN_UBICACION_V aula_v,',
'         DHL_UBN_UBICACION_S aula_s',
'  FROM   GAC_OFERTA_ACADEMICA_TB_NX,',
'         GAC_DET_OFERTA_ACADEMICA_TB_NX,',
'         INV_ARTICULO_TB_NX,',
'         GAC_OFERTA_HORA_LOCA_TB_NX,',
'         GAC_PERIODOS_ACADEMICOS_TB_NX,',
'         GNL_PERSONA_TR_NX,',
'         GAC_DET_OFERTA_ARTI_PROV_TB_NX,',
'         GAC_DET_HORARIOS_LOCA_TB_NX',
' WHERE       INSTR ('':'' || :P132_EMPRESA || '':'',',
'                    '':'' || DOA_EMP_EMPRESA || '':'') > 0',
'         AND DOA_OAC_ID = OAC_ID',
'         AND DOA_ATO_ARTICULO = ATO_ARTICULO',
'         AND DOA_ID = OHL_DOA_ID',
'         AND OHL_PAC_ID = PAC_ID',
'         AND OAC_ASISTENTE_ACADEMICO = PERSONA',
'         AND DOA_ATO_ARTICULO = DOP_ATO_ARTICULO',
'         AND DOA_ID = DOP_DOA_ID',
'         AND DHL_OHL_ID(+) = OHL_ID',
'         AND (DOA_FECHA_INI_CUPO >= :P132_INICIO AND  DOA_FECHA_FIN_CUPO <= :P132_FIN )'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P132_EMPRESA'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14117183863214197422)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>54164132773981163
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067155972852098260)
,p_db_column_name=>'FACULTAD'
,p_display_order=>10
,p_column_identifier=>'BQ'
,p_column_label=>'Facultad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156113160098261)
,p_db_column_name=>'CARRERA'
,p_display_order=>20
,p_column_identifier=>'BR'
,p_column_label=>'Carrera'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156134942098262)
,p_db_column_name=>'GENERACION'
,p_display_order=>30
,p_column_identifier=>'BS'
,p_column_label=>'Generacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156426706098264)
,p_db_column_name=>'CODIGO'
,p_display_order=>50
,p_column_identifier=>'BU'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156499360098265)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>60
,p_column_identifier=>'BV'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156603294098266)
,p_db_column_name=>'HORAS'
,p_display_order=>70
,p_column_identifier=>'BW'
,p_column_label=>'Horas'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156688459098267)
,p_db_column_name=>'CREDITOS'
,p_display_order=>80
,p_column_identifier=>'BX'
,p_column_label=>'Creditos'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156784647098268)
,p_db_column_name=>'TOTAL_ALUMNOS'
,p_display_order=>90
,p_column_identifier=>'BY'
,p_column_label=>'Total Alumnos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156864569098269)
,p_db_column_name=>'MATRICULADOS'
,p_display_order=>100
,p_column_identifier=>'BZ'
,p_column_label=>'Matriculados'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067156936348098270)
,p_db_column_name=>'FECHA_INICIAL'
,p_display_order=>110
,p_column_identifier=>'CA'
,p_column_label=>'Fecha Inicial'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067157113041098271)
,p_db_column_name=>'FECHA_FINAL'
,p_display_order=>120
,p_column_identifier=>'CB'
,p_column_label=>'Fecha Final'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067157137946098272)
,p_db_column_name=>'ESTADO_CURSO'
,p_display_order=>130
,p_column_identifier=>'CC'
,p_column_label=>'Estado Curso'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067157231945098273)
,p_db_column_name=>'PERIODO'
,p_display_order=>140
,p_column_identifier=>'CD'
,p_column_label=>'Periodo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067157937606098280)
,p_db_column_name=>unistr('NOMBRE_ASISTENTE_ACAD\00C8MICO')
,p_display_order=>150
,p_column_identifier=>'CE'
,p_column_label=>'Asistente Academico'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067158070103098281)
,p_db_column_name=>'PROFESOR'
,p_display_order=>160
,p_column_identifier=>'CF'
,p_column_label=>'Profesor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084695221750361004)
,p_db_column_name=>'NOMBRE_PROFESOR'
,p_display_order=>170
,p_column_identifier=>'CG'
,p_column_label=>'Nombre del profesor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022868375727665)
,p_db_column_name=>'HORARIO'
,p_display_order=>180
,p_column_identifier=>'CH'
,p_column_label=>'Horario'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022691498727664)
,p_db_column_name=>'AULA_D'
,p_display_order=>190
,p_column_identifier=>'CI'
,p_column_label=>'Aula D'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022593790727663)
,p_db_column_name=>'AULA_L'
,p_display_order=>200
,p_column_identifier=>'CJ'
,p_column_label=>'Aula L'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022521383727662)
,p_db_column_name=>'AULA_K'
,p_display_order=>210
,p_column_identifier=>'CK'
,p_column_label=>'Aula K'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022412153727661)
,p_db_column_name=>'AULA_M'
,p_display_order=>220
,p_column_identifier=>'CL'
,p_column_label=>'Aula M'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022313731727660)
,p_db_column_name=>'AULA_J'
,p_display_order=>230
,p_column_identifier=>'CM'
,p_column_label=>'Aula J'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022250588727659)
,p_db_column_name=>'AULA_V'
,p_display_order=>240
,p_column_identifier=>'CN'
,p_column_label=>'Aula V'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13886022092038727658)
,p_db_column_name=>'AULA_S'
,p_display_order=>250
,p_column_identifier=>'CO'
,p_column_label=>'Aula S'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14117185438970197495)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'41312'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>unistr('FACULTAD:CARRERA:NOMBRE_ASISTENTE_ACAD\00C8MICO:GENERACION:CODIGO:DESCRIPCION:HORAS:CREDITOS:TOTAL_ALUMNOS:MATRICULADOS:FECHA_INICIAL:FECHA_FINAL:ESTADO_CURSO:PROFESOR:PERIODO::NOMBRE_PROFESOR:HORARIO:AULA_D:AULA_L:AULA_K:AULA_M:AULA_J:AULA_V:AULA_S')
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14067151677995087205)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(14117185643176197511)
,p_button_name=>'CONSULTAR'
,p_button_static_id=>'65_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14067152086045087206)
,p_name=>'P132_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14117185643176197511)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14067153289470087211)
,p_name=>'P132_INICIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14117185643176197511)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14067153676070087214)
,p_name=>'P132_FIN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14117185643176197511)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
