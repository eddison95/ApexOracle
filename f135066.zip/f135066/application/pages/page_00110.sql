prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>110
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'TAL - Pronostico Servicios'
,p_step_title=>'Pronostico Servicios'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096002824674763375)
,p_plug_name=>'Pronostico Servicios'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14002502982569533747)
,p_plug_name=>'Pronostico'
,p_parent_plug_id=>wwv_flow_api.id(14096002824674763375)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT c001            pro_empresa,',
'       c002            pro_cliente,',
'       c003            pro_telefonos,',
'       c004            pro_marca,',
'       c005            pro_modelo,',
'       c006            pro_color,',
'       c007            pro_placa,',
'       To_number(c008) pro_ano,',
'       To_number(c009) pro_meses,',
'       To_number(c010) pro_odometro,',
'       To_number(c011) prom_odo_v,',
'       c012            pro_ult_ser,',
'       To_date(c013)   pro_fec_ult_ser,',
'       c014            pro_pro_ser,',
'       To_date(c015)   pro_fec_pro_ser,',
'       To_date(c016)   pro_fec_notificar',
'FROM   apex_collections',
'WHERE  collection_name = ''TAL-PRONOSTICO''  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14002503043497533748)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>37393337920989703
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002538358950121080)
,p_db_column_name=>'PRO_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'FZ'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002538477119121081)
,p_db_column_name=>'PRO_CLIENTE'
,p_display_order=>20
,p_column_identifier=>'GA'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002538526632121082)
,p_db_column_name=>'PRO_TELEFONOS'
,p_display_order=>30
,p_column_identifier=>'GB'
,p_column_label=>'Telefonos'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002538758507121084)
,p_db_column_name=>'PRO_MARCA'
,p_display_order=>40
,p_column_identifier=>'GC'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002538846524121085)
,p_db_column_name=>'PRO_MODELO'
,p_display_order=>50
,p_column_identifier=>'GD'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002538973076121086)
,p_db_column_name=>'PRO_COLOR'
,p_display_order=>60
,p_column_identifier=>'GE'
,p_column_label=>'Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002539097037121087)
,p_db_column_name=>'PRO_PLACA'
,p_display_order=>70
,p_column_identifier=>'GF'
,p_column_label=>'Placa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002539872915121095)
,p_db_column_name=>'PRO_ANO'
,p_display_order=>80
,p_column_identifier=>'GN'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002681105623081546)
,p_db_column_name=>'PRO_MESES'
,p_display_order=>90
,p_column_identifier=>'GO'
,p_column_label=>'Meses'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002681235453081547)
,p_db_column_name=>'PRO_ODOMETRO'
,p_display_order=>100
,p_column_identifier=>'GP'
,p_column_label=>'Odometro'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002681338447081548)
,p_db_column_name=>'PROM_ODO_V'
,p_display_order=>110
,p_column_identifier=>'GQ'
,p_column_label=>'Odo/Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002539357301121090)
,p_db_column_name=>'PRO_ULT_SER'
,p_display_order=>120
,p_column_identifier=>'GI'
,p_column_label=>'Ult. Servicio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002681803521081552)
,p_db_column_name=>'PRO_FEC_ULT_SER'
,p_display_order=>130
,p_column_identifier=>'GT'
,p_column_label=>'F. Ult. Servicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002539410971121091)
,p_db_column_name=>'PRO_PRO_SER'
,p_display_order=>140
,p_column_identifier=>'GJ'
,p_column_label=>'Prox. Servicio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002681884178081553)
,p_db_column_name=>'PRO_FEC_PRO_SER'
,p_display_order=>150
,p_column_identifier=>'GU'
,p_column_label=>'F. Prox. Servicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002681985035081554)
,p_db_column_name=>'PRO_FEC_NOTIFICAR'
,p_display_order=>160
,p_column_identifier=>'GV'
,p_column_label=>'F. Notificar'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14002643826307160953)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'375342'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PRO_EMPRESA:PRO_CLIENTE:PRO_TELEFONOS:PRO_MARCA:PRO_MODELO:PRO_COLOR:PRO_PLACA:PRO_ANO:PRO_MESES:PRO_ODOMETRO:PROM_ODO_V:PRO_ULT_SER:PRO_FEC_ULT_SER:PRO_PRO_SER:PRO_FEC_NOTIFICAR:PRO_FEC_PRO_SER:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096003155631763376)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14096002824674763375)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096003610230763377)
,p_name=>'P110_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14096002824674763375)
,p_item_default=>'return :P99_EMPRESA'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Empresa'
,p_source=>'return :P99_EMPRESA'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14002538676415121083)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Nuevo'
,p_process_sql_clob=>'tal_pronostico_pr_nx(:P110_EMPRESA);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14096003155631763376)
);
wwv_flow_api.component_end;
end;
/
