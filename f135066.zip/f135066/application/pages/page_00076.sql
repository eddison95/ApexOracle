prompt --application/pages/page_00076
begin
--   Manifest
--     PAGE: 00076
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>76
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'TAL - Proformas'
,p_step_title=>'Proformas Taller'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164448'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094486459290625473)
,p_plug_name=>'Proformas Taller'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094452086660293238)
,p_plug_name=>'Proformas Taller'
,p_parent_plug_id=>wwv_flow_api.id(14094486459290625473)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 23/02/2017 06:33:41 p.m. (QP5 v5.115.810.9015) */',
'SELECT   p.PRF_EMP_EMPRESA,',
'         p.PRF_PROFORMA,',
'         p.PRF_VEH_CONSECUTIVO,',
'         p.PRF_DIRIGIDO_A,',
'         p.PRF_DESCRIPCION,',
'         TRUNC (p.PRF_FECHA) PRF_FECHA,',
'         p.PRF_DIST_RECORRIDA,',
'         p.PRF_VIGENCIA,',
'         DECODE (p.PRF_STATUS,',
'                 ''R'',',
'                 ''Registrada'',',
'                 ''P'',',
'                 ''Procesada'',',
'                 ''A'',',
'                 ''Anulada'')',
'            ESTADO,',
'         p.PRF_PORC_DESC_SERV,',
'         p.PRF_PORC_DESC_REP,',
'         p.PRF_LPO_LISTA,',
'         p.PRF_LCN_LOCALIZACION,',
'         TRUNC (p.PRF_FECHA_REGISTRADA) PRF_FECHA_REGISTRADA,',
'         p.PRF_USUARIO_REGISTRADA,',
'         TRUNC (p.PRF_FECHA_PROCESADA) PRF_FECHA_PROCESADA,',
'         p.PRF_USUARIO_PROCESADA,',
'         TRUNC (p.PRF_FECHA_ANULADA) PRF_FECHA_ANULADA,',
'         p.PRF_USUARIO_ANULADA,',
'         p.PRF_VIS_CONSECUTIVO,',
'         tal_ord_servi_prf_n_nx (p.PRF_EMP_EMPRESA, p.PRF_PROFORMA) ORDEN#,',
'         d.DPR_EMP_EMPRESA,',
'         d.DPR_PRF_PROFORMA,',
'         d.DPR_LINEA,',
'         d.DPR_SER_CONSECUTIVO,',
'         d.DPR_ATO_ARTICULO,',
'         d.DPR_CANTIDAD,',
'         d.DPR_PRECIO,',
'         d.DPR_DESCUENTO,',
'         d.DPR_IMP_VENTA',
'  FROM   TAL_PROFORMA_TB_NX p, TAL_DET_PROFORMA_TB_NX d',
' WHERE       p.PRF_EMP_EMPRESA = d.DPR_EMP_EMPRESA',
'         AND INSTR ('':'' || :P76_EMPRESA || '':'',',
'                    '':'' || p.PRF_EMP_EMPRESA || '':'') > 0',
'         AND p.PRF_PROFORMA = d.DPR_PRF_PROFORMA',
'         AND p.PRF_FECHA BETWEEN :P76_INICIO',
'                             AND  TO_DATE (:P76_FIN || '' 23:59'',',
'                                           ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P76_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14094452204475293239)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>6708479703404145
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094452248183293240)
,p_db_column_name=>'PRF_EMP_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094452384909293241)
,p_db_column_name=>'PRF_PROFORMA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Proforma'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094452478673293242)
,p_db_column_name=>'PRF_VEH_CONSECUTIVO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Id Vehiculo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094452535450293243)
,p_db_column_name=>'PRF_DIRIGIDO_A'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Dirigido A'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094452652287293244)
,p_db_column_name=>'PRF_DESCRIPCION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094506661530780195)
,p_db_column_name=>'PRF_FECHA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094506738189780196)
,p_db_column_name=>'PRF_DIST_RECORRIDA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Dist Recorrida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094506858775780197)
,p_db_column_name=>'PRF_VIGENCIA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vigencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094506950420780198)
,p_db_column_name=>'ESTADO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507045655780199)
,p_db_column_name=>'PRF_PORC_DESC_SERV'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Desc Servicio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507167927780200)
,p_db_column_name=>'PRF_PORC_DESC_REP'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Desc Repuestos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507236156780201)
,p_db_column_name=>'PRF_LPO_LISTA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Lista Precio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507347766780202)
,p_db_column_name=>'PRF_LCN_LOCALIZACION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507450676780203)
,p_db_column_name=>'PRF_FECHA_REGISTRADA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'F. Registrada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507584484780204)
,p_db_column_name=>'PRF_USUARIO_REGISTRADA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Usuario Registrada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507695370780205)
,p_db_column_name=>'PRF_FECHA_PROCESADA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'F. Procesada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507792123780206)
,p_db_column_name=>'PRF_USUARIO_PROCESADA'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Usuario Procesada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094507842019780207)
,p_db_column_name=>'PRF_FECHA_ANULADA'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'F. Anulada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508011909780208)
,p_db_column_name=>'PRF_USUARIO_ANULADA'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Usuario Anulada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508092521780209)
,p_db_column_name=>'PRF_VIS_CONSECUTIVO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'# Visita'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508171847780210)
,p_db_column_name=>'ORDEN#'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'# Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508323783780211)
,p_db_column_name=>'DPR_EMP_EMPRESA'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508390042780212)
,p_db_column_name=>'DPR_PRF_PROFORMA'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Proforma'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508437932780213)
,p_db_column_name=>'DPR_LINEA'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508590873780214)
,p_db_column_name=>'DPR_SER_CONSECUTIVO'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Servicio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508670731780215)
,p_db_column_name=>'DPR_ATO_ARTICULO'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508801988780216)
,p_db_column_name=>'DPR_CANTIDAD'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094508858333780217)
,p_db_column_name=>'DPR_PRECIO'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509014392780218)
,p_db_column_name=>'DPR_DESCUENTO'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509078314780219)
,p_db_column_name=>'DPR_IMP_VENTA'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14094521031152834878)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'67774'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PRF_EMP_EMPRESA:PRF_PROFORMA:PRF_VEH_CONSECUTIVO:PRF_DIRIGIDO_A:PRF_DESCRIPCION:PRF_FECHA:PRF_DIST_RECORRIDA:PRF_VIGENCIA:PRF_PORC_DESC_SERV:PRF_PORC_DESC_REP:PRF_LPO_LISTA:PRF_LCN_LOCALIZACION:DPR_EMP_EMPRESA:ESTADO:DPR_PRF_PROFORMA:DPR_LINEA:DPR_SE'
||'R_CONSECUTIVO:DPR_ATO_ARTICULO:DPR_CANTIDAD:DPR_PRECIO:DPR_DESCUENTO:DPR_IMP_VENTA:PRF_FECHA_REGISTRADA:PRF_USUARIO_REGISTRADA:PRF_FECHA_PROCESADA:PRF_USUARIO_PROCESADA:PRF_FECHA_ANULADA:PRF_USUARIO_ANULADA:PRF_VIS_CONSECUTIVO:ORDEN#:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14094486922229625474)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14094486459290625473)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094493682662651569)
,p_name=>'P76_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14094486459290625473)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094493996567655859)
,p_name=>'P76_INICIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14094486459290625473)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094494245536658206)
,p_name=>'P76_FIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14094486459290625473)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
