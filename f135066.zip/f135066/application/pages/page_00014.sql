prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>14
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CGL \2013 Asientos por Departamento')
,p_step_title=>'Asientos por Departamento'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163329'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193527654636288012)
,p_plug_name=>'Asientos por Departamento'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193528675086288023)
,p_plug_name=>'Asientos por Departamento'
,p_parent_plug_id=>wwv_flow_api.id(14193527654636288012)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT	c.ded_asiento,',
'			c.ded_subsistema,',
'			TRUNC(c.ded_fecha) ded_fecha,',
'			DECODE (c.ded_estado,',
'					  1,',
'					  ''Subsistema'',',
'					  2,',
'					  ''Por Aplicar'',',
'					  3,',
'					  ''Autorizado'',',
'					  4,',
'					  ''Libros'',',
'					  5,',
'					  ''Historico''',
'					 )',
'				ded_estado,',
'			DECODE (c.ded_tipo,',
'					  1,',
'					  ''Normal'',',
'					  2,',
'					  ''Automatico'',',
'					  3,',
'					  ''Subsistema'',',
'					  4,',
'					  ''Fijo'',',
'					  5,',
'					  ''Cierre Anual''',
'					 )',
'				ded_tipo,',
'			DECODE (c.ded_contabilidad,',
'					  1,',
'					  ''Ambas'',',
'					  2,',
'					  ''Fiscal'',',
'					  3,',
'					  ''Corporativa''',
'					 )',
'				ded_contabilidad,',
'			DECODE (c.ded_moneda, 1, ''Ambas'', 2, ''Local'', 3, ''Alterna'')',
'				ded_moneda,',
'			c.ded_linea,',
'			c.ded_emp_cuenta,',
'			c.ded_cuenta,',
'			c.ded_desc_cta,',
'			c.ded_departamento,',
'			c.ded_desc_depto,',
'			c.ded_naturaleza,',
'			c.ded_debe,',
'			c.ded_haber,',
'			c.ded_valor_cambio,',
'			c.ded_debe_alt,',
'			c.ded_haber_alt,',
'			c.ded_fecha_doc,',
'			c.ded_tipo_doc,',
'			c.ded_documento,',
'			c.ded_observaciones',
'  FROM	cgl_detalle_dep_asi_vw_nx c',
'where ded_empresa = :P14_EMPRESA',
'AND ded_fecha BETWEEN :P14_INICIO AND to_date(:P14_FIN||'' 23:59'', ''dd/mm/rrrr hh24:mi'');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P14_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14193528866196288024)
,p_name=>'Consulta de Asientos'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>7529514077102347
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193528973407288026)
,p_db_column_name=>'DED_ASIENTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Asiento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DED_ASIENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529071609288026)
,p_db_column_name=>'DED_SUBSISTEMA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Subsistema'
,p_column_type=>'STRING'
,p_static_id=>'DED_SUBSISTEMA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529162950288027)
,p_db_column_name=>'DED_FECHA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'DED_FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529272990288027)
,p_db_column_name=>'DED_ESTADO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_static_id=>'DED_ESTADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529354106288029)
,p_db_column_name=>'DED_TIPO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'DED_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529469826288029)
,p_db_column_name=>'DED_CONTABILIDAD'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Contabilidad'
,p_column_type=>'STRING'
,p_static_id=>'DED_CONTABILIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529583725288029)
,p_db_column_name=>'DED_MONEDA'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'DED_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529671670288035)
,p_db_column_name=>'DED_LINEA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DED_LINEA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529762680288035)
,p_db_column_name=>'DED_EMP_CUENTA'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Empres Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'DED_EMP_CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529882356288035)
,p_db_column_name=>'DED_CUENTA'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'DED_CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193529955014288036)
,p_db_column_name=>'DED_DESC_CTA'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DED_DESC_CTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530070487288036)
,p_db_column_name=>'DED_DEPARTAMENTO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_static_id=>'DED_DEPARTAMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530162524288036)
,p_db_column_name=>'DED_DESC_DEPTO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DED_DESC_DEPTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530266476288037)
,p_db_column_name=>'DED_NATURALEZA'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Naturaleza'
,p_column_type=>'STRING'
,p_static_id=>'DED_NATURALEZA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530369040288037)
,p_db_column_name=>'DED_DEBE'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Debe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DED_DEBE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530477975288037)
,p_db_column_name=>'DED_HABER'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Haber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DED_HABER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530571902288037)
,p_db_column_name=>'DED_VALOR_CAMBIO'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Valor Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DED_VALOR_CAMBIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530682366288040)
,p_db_column_name=>'DED_DEBE_ALT'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Debe Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DED_DEBE_ALT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530752221288041)
,p_db_column_name=>'DED_HABER_ALT'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Haber Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DED_HABER_ALT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530873461288041)
,p_db_column_name=>'DED_FECHA_DOC'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'DED_FECHA_DOC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193530952908288041)
,p_db_column_name=>'DED_TIPO_DOC'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_static_id=>'DED_TIPO_DOC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193531062309288041)
,p_db_column_name=>'DED_DOCUMENTO'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DED_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193531176553288042)
,p_db_column_name=>'DED_OBSERVACIONES'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_static_id=>'DED_OBSERVACIONES'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14193531263140288042)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75320'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'DED_ASIENTO:DED_SUBSISTEMA:DED_FECHA:DED_ESTADO:DED_TIPO:DED_CONTABILIDAD:DED_MONEDA:DED_LINEA:DED_EMP_CUENTA:DED_CUENTA:DED_DESC_CTA:DED_DEPARTAMENTO:DED_DESC_DEPTO:DED_NATURALEZA:DED_DEBE:DED_HABER:DED_VALOR_CAMBIO:DED_DEBE_ALT:DED_HABER_ALT:DED_FE'
||'CHA_DOC:DED_TIPO_DOC:DED_DOCUMENTO:DED_OBSERVACIONES'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168168707625672451)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14193527654636288012)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193527876506288016)
,p_name=>'P14_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14193527654636288012)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193528076292288017)
,p_name=>'P14_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14193527654636288012)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193528268117288018)
,p_name=>'P14_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14193527654636288012)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
