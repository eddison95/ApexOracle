prompt --application/pages/page_00180
begin
--   Manifest
--     PAGE: 00180
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>180
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'APD - General'
,p_step_title=>'APD General'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'MBACASE'
,p_last_upd_yyyymmddhh24miss=>'20210520092006'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13885243520764718666)
,p_plug_name=>'APD General '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13885251791691673189)
,p_plug_name=>'APD - General'
,p_parent_plug_id=>wwv_flow_api.id(13885243520764718666)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    a.apr_id                        apr_id,',
'    a.apr_numero                    apr_numero,',
'    b.apc_codigo                    clase,',
'    b.apc_descripcion               descripcion,',
'    e.apt_codigo                    tipo_transaccion,',
'    e.apt_descripcion               descripcion_tipo_transaccion,',
'    a.apr_descripcion               descripcion_transaccion,',
'    a.apr_cta_cuenta_ori            cuenta_costo_original,',
'    c.descripcion                   descripcion_cuenta,',
'    a.apr_dep_departamento_ori      departamento,',
'    d.dep_descripcion               descripcion_departamento,',
'    a.apr_fecha_inicial             fecha_inicio,',
'    a.apr_meses_vida                meses_vida,',
'    a.apr_monto                     monto,',
'    a.apr_tipo_cambio               tipo_cambio,',
'    a.apr_amortizacion_mensual      amortizacion_mensual,',
'    a.apr_fecha_final               fecha_final,',
'    e.apt_codigo                    tipo_amortizacion_mensual,',
'    e.apt_descripcion               descripcion_amortizacion_mensual,',
'    f.apt_codigo                    tipo_amortizacion_anticipado,',
'    f.apt_descripcion               descripcion_amortizacion_anticipado,',
'    a.apr_observaciones             observaciones,',
'    a.apr_detalle                   detalle,',
'    a.apr_amortizacion_acumulada    amortizacion_acumulada,',
'    a.apr_saldo                     saldo,',
'    a.apr_fecha_ult_amortizacion    fecha_ultima_amortizacion,',
'    a.apr_meses_vida_restante       meses_vida_rescate,',
'    a.apr_excluir_amortizacion      excluir_amortizacion,',
'    a.apr_estado                    estado,',
'    e.apt_supertipo                 Super_tipo,',
'    gnl_valor_cambio_n_nx(a.apr_fecha_inicial,c.mon_moneda,c.TIP_TIPO_CAMBIO)valor_cambio',
'FROM',
'    apd_registro_tb_nx          a,',
'    apd_clase_tb_nx             b,',
'    cgl_cuenta_tr_nx            c,',
'    fac_departamento_tb_nx      d,',
'    apd_tipo_transaccion_tb_nx  e,',
'    apd_tipo_transaccion_tb_nx  f',
'WHERE',
'        INSTR ('':''||:P180_EMPRESA||'':'','':''||apr_emp_empresa||'':'') > 0',
'    AND e.apt_supertipo != ''E''',
'    AND e.apt_supertipo != ''I''',
'    AND a.apr_apc_id = b.apc_id',
'    AND a.apr_cta_empresa_ori = c.emp_empresa',
'    AND a.apr_cta_cuenta_ori = c.cuenta',
'    AND a.apr_cta_empresa_ori = d.dep_emp_empresa',
'    AND a.apr_dep_departamento_ori = d.dep_departamento',
'    AND a.apr_apt_mensual = e.apt_id',
'    AND a.apr_apt_anticipada = e.apt_id',
'    AND a.apr_apt_mensual = f.apt_id',
'    AND a.apr_apt_anticipada = f.apt_id',
'    ORDER BY a.apr_id '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P180_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13885251919301673190)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ESALAS'
,p_internal_uid=>28529175868333803
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885251964359673191)
,p_db_column_name=>'APR_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Apr Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885252082450673192)
,p_db_column_name=>'APR_NUMERO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Apr Numero'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215069522630025)
,p_db_column_name=>'CLASE'
,p_display_order=>30
,p_column_identifier=>'BG'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215163614630026)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>40
,p_column_identifier=>'BH'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215236185630027)
,p_db_column_name=>'TIPO_TRANSACCION'
,p_display_order=>50
,p_column_identifier=>'BI'
,p_column_label=>'Tipo Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215339203630028)
,p_db_column_name=>'DESCRIPCION_TIPO_TRANSACCION'
,p_display_order=>60
,p_column_identifier=>'BJ'
,p_column_label=>'Descripcion Tipo Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215391350630029)
,p_db_column_name=>'DESCRIPCION_TRANSACCION'
,p_display_order=>70
,p_column_identifier=>'BK'
,p_column_label=>'Descripcion Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215514971630030)
,p_db_column_name=>'CUENTA_COSTO_ORIGINAL'
,p_display_order=>80
,p_column_identifier=>'BL'
,p_column_label=>'Cuenta Costo Original'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215604321630031)
,p_db_column_name=>'DESCRIPCION_CUENTA'
,p_display_order=>90
,p_column_identifier=>'BM'
,p_column_label=>'Descripcion Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215697398630032)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>100
,p_column_identifier=>'BN'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215884230630033)
,p_db_column_name=>'DESCRIPCION_DEPARTAMENTO'
,p_display_order=>110
,p_column_identifier=>'BO'
,p_column_label=>'Descripcion Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885215884953630034)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>120
,p_column_identifier=>'BP'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216050174630035)
,p_db_column_name=>'MESES_VIDA'
,p_display_order=>130
,p_column_identifier=>'BQ'
,p_column_label=>'Meses Vida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216155991630036)
,p_db_column_name=>'MONTO'
,p_display_order=>140
,p_column_identifier=>'BR'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216252215630037)
,p_db_column_name=>'TIPO_CAMBIO'
,p_display_order=>150
,p_column_identifier=>'BS'
,p_column_label=>'Tipo Cambio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216370288630038)
,p_db_column_name=>'AMORTIZACION_MENSUAL'
,p_display_order=>160
,p_column_identifier=>'BT'
,p_column_label=>'Amortizacion Mensual'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216430245630039)
,p_db_column_name=>'FECHA_FINAL'
,p_display_order=>170
,p_column_identifier=>'BU'
,p_column_label=>'Fecha Final'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216546144630040)
,p_db_column_name=>'TIPO_AMORTIZACION_MENSUAL'
,p_display_order=>180
,p_column_identifier=>'BV'
,p_column_label=>'Tipo Amortizacion Mensual'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216587651630041)
,p_db_column_name=>'DESCRIPCION_AMORTIZACION_MENSUAL'
,p_display_order=>190
,p_column_identifier=>'BW'
,p_column_label=>'Descripcion Amortizacion Mensual'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216741310630042)
,p_db_column_name=>'TIPO_AMORTIZACION_ANTICIPADO'
,p_display_order=>200
,p_column_identifier=>'BX'
,p_column_label=>'Tipo Amortizacion Anticipado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216819089630043)
,p_db_column_name=>'DESCRIPCION_AMORTIZACION_ANTICIPADO'
,p_display_order=>210
,p_column_identifier=>'BY'
,p_column_label=>'Descripcion Amortizacion Anticipado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885216944596630044)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>220
,p_column_identifier=>'BZ'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217031378630045)
,p_db_column_name=>'DETALLE'
,p_display_order=>230
,p_column_identifier=>'CA'
,p_column_label=>'Detalle'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217142580630046)
,p_db_column_name=>'AMORTIZACION_ACUMULADA'
,p_display_order=>240
,p_column_identifier=>'CB'
,p_column_label=>'Amortizacion Acumulada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217210617630047)
,p_db_column_name=>'SALDO'
,p_display_order=>250
,p_column_identifier=>'CC'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217335199630048)
,p_db_column_name=>'FECHA_ULTIMA_AMORTIZACION'
,p_display_order=>260
,p_column_identifier=>'CD'
,p_column_label=>'Fecha Ultima Amortizacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217411913630049)
,p_db_column_name=>'MESES_VIDA_RESCATE'
,p_display_order=>270
,p_column_identifier=>'CE'
,p_column_label=>'Meses Vida Rescate'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217523124630050)
,p_db_column_name=>'EXCLUIR_AMORTIZACION'
,p_display_order=>280
,p_column_identifier=>'CF'
,p_column_label=>'Excluir Amortizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217628878630051)
,p_db_column_name=>'ESTADO'
,p_display_order=>290
,p_column_identifier=>'CG'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217711952630052)
,p_db_column_name=>'SUPER_TIPO'
,p_display_order=>300
,p_column_identifier=>'CH'
,p_column_label=>'Super Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885218258490630057)
,p_db_column_name=>'VALOR_CAMBIO'
,p_display_order=>310
,p_column_identifier=>'CK'
,p_column_label=>'Valor Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13885266533116677572)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'285438'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'APR_ID:APR_NUMERO:CLASE:DESCRIPCION:TIPO_TRANSACCION:DESCRIPCION_TIPO_TRANSACCION:ESTADO:SUPER_TIPO:MONTO:AMORTIZACION_MENSUAL:DESCRIPCION_TRANSACCION:AMORTIZACION_ACUMULADA:CUENTA_COSTO_ORIGINAL:DESCRIPCION_CUENTA:DEPARTAMENTO:DESCRIPCION_DEPARTAMEN'
||'TO:FECHA_INICIO:FECHA_FINAL:SALDO:TIPO_CAMBIO:VALOR_CAMBIO:FECHA_ULTIMA_AMORTIZACION:MESES_VIDA:MESES_VIDA_RESCATE:EXCLUIR_AMORTIZACION:TIPO_AMORTIZACION_MENSUAL:DESCRIPCION_AMORTIZACION_MENSUAL:TIPO_AMORTIZACION_ANTICIPADO:DESCRIPCION_AMORTIZACION_A'
||'NTICIPADO:OBSERVACIONES:DETALLE:'
,p_sum_columns_on_break=>'MONTO:AMORTIZACION_MENSUAL:AMORTIZACION_ACUMULADA:SALDO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13885251720968673188)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(13885243520764718666)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13885243445232718665)
,p_name=>'P180_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13885243520764718666)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
