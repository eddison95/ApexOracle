prompt --application/pages/page_00146
begin
--   Manifest
--     PAGE: 00146
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>146
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('INV - Listas precios por Art\00EDculos')
,p_step_title=>unistr('Listas precios por Art\00EDculos')
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14122500919803840410)
,p_plug_name=>unistr('Lista Precios por Art\00EDculos')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14122502586179840414)
,p_plug_name=>unistr('Lista Precios Art\00EDculos')
,p_parent_plug_id=>wwv_flow_api.id(14122500919803840410)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 25/04/2019 03:00:44 p.m. (QP5 v5.115.810.9015) */',
'SELECT   lp.LPO_EMP_EMPRESA,',
'         lp.LPO_LISTA,',
'         lp.LPO_DESCRIPCION,',
'         lp.LPO_MON_MONEDA,',
'         lp.LPO_TIP_TIPO_CAMBIO,',
'         lp.LPO_TIPO_LISTA,',
'         DECODE (lp.LPO_TIPO_BASE,',
'                 ''N'',',
'                 ''N/A'',',
'                 ''F'',',
'                 ''FOB'',',
'                 ''C'',',
'                 ''Costo'',',
'                 ''U'',',
'                 ''Ultimo'',',
'                 ''A'',',
'                 ''Adquis'',',
'                 ''B'',',
'                 ''Local'',',
'                 ''L'',',
'                 ''Lista'')',
'            LPO_TIPO_BASE,',
'         DECODE (lp.LPO_TIPO_CALCULO,',
'                 ''N'',',
'                 ''N/A'',',
'                 ''U'',',
'                 ''Up'',',
'                 ''D'',',
'                 ''Down'',',
'                 ''F'',',
'                 ''Fact'')',
'            LPO_TIPO_CALCULO,',
'         lp.LPO_REDONDEO_COMERCIAL,',
'         p.PCO_ATO_ARTICULO,',
'         inv_descrip_art_v_nx (P.PCO_EMP_EMPRESA, p.PCO_ATO_ARTICULO)',
'            DSP_ATO_DESCRIPCION,',
'         p.PCO_PRECIO,',
'         p.PCO_PORCENTAJE,',
'         p.PCO_FACTOR1,',
'         p.PCO_FACTOR2,',
'         p.PCO_FACTOR3,',
'         DECODE (p.PCO_TIPO_BASE,',
'                 ''N'',',
'                 ''N/A'',',
'                 ''F'',',
'                 ''FOB'',',
'                 ''C'',',
'                 ''Costo'',',
'                 ''U'',',
'                 ''Ultimo'',',
'                 ''A'',',
'                 ''Adquis'',',
'                 ''B'',',
'                 ''Local'',',
'                 ''L'',',
'                 ''Lista'')',
'            PCO_TIPO_BASE,',
'         DECODE (p.PCO_TIPO_CALCULO,',
'                 ''N'',',
'                 ''N/A'',',
'                 ''U'',',
'                 ''Up'',',
'                 ''D'',',
'                 ''Down'',',
'                 ''F'',',
'                 ''Fact'')',
'            PCO_TIPO_CALCULO,',
'         p.PCO_GASTOS_INSCRIP,',
'         p.PCO_GASTOS_ADIC,',
'         a.*,',
'         i.ATO_FMA_FAMILIA FAMILIA,',
'         inv_desc_fam_art_v_nx (i.ATO_EMP_EMPRESA, i.ATO_ARTICULO)',
'            DESC_FAMILIA,',
'         i.ATO_OBSERVACIONES OBSERVACIONES,',
'         i.ATO_MOD_MODELO MODELO,',
'         i.ATO_MAR_MARCA MARCA,',
'         i.ATO_PLU CODIGO_BARRAS,',
'         i.ATO_COSTO_FOB COSTO_FOB,',
'         i.ATO_COSTO_ESTANDAR COSTO_ESTANDAR,',
'         DECODE (i.ATO_BLOQUEADO_COMPRA,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            BLOQUEADO_COMPRA,',
'         DECODE (i.ATO_BLOQUEADO_VENTA,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            BLOQUEADO_VENTA,',
'         i.ATO_ATO_REEMPLAZA REEMPLAZA,',
'         i.ATO_ATO_REEMPLAZO REEMPLAZO,',
'         i.ATO_MAXIMO_DESCUENTO MAXIMO_DESCUENTO,',
'         DECODE (i.ATO_MODIFICAR_PRECIO,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            MODIFICAR_PRECIO,',
'         DECODE (i.ATO_GRAVADO,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            GRAVADO,',
'         DECODE (i.ATO_MODIFICA_DESCRIPCION,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            MODIFICA_DESCRIPCION,',
'         DECODE (i.ATO_BAJO_MARGEN,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            BAJO_MARGEN,',
'         DECODE (i.ATO_DESCONTINUADO,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            DESCONTINUADO,',
'         i.ATO_CATEGORIA CATEGORIA,',
'         DECODE (i.ATO_TUS_TIPO_USO,',
'                 ''1'',',
'                 ''ACCESORIOS'',',
'                 ''2'',',
'                 ''CABLES'',',
'                 ''3'',',
'                 ''CARROCERIA'',',
'                 ''4'',',
'                 ''COMBUSTIBLES'',',
'                 ''5'',',
'                 ''ELECTRICO'',',
'                 ''6'',',
'                 ''MOTOR'',',
'                 ''7'',',
'                 ''OTROS'',',
'                 ''8'',',
'                 ''TRANSMICION'',',
'                 ''9'',',
'                 ''REPUESTOS'',',
'                 ''10'',',
'                 ''CAJONES'',',
'                 ''11'',',
'                 ''CASCOS'',',
'                 ''12'',',
'                 ''CAPAS'',',
'                 ''13'',',
'                 ''LLANTAS'',',
'                 ''14'',',
'                 ''LINEA BLANCA'')',
'            TIPO_USO,',
'         DECODE (i.ATO_GPR_GRUPO_PRODUCTO,',
'                 ''1'',',
'                 ''AA'',',
'                 ''2'',',
'                 ''AB'',',
'                 ''3'',',
'                 ''AC'',',
'                 ''4'',',
'                 ''BA'',',
'                 ''5'',',
'                 ''BB'',',
'                 ''6'',',
'                 ''BC'',',
'                 ''7'',',
'                 ''CA'',',
'                 ''8'',',
'                 ''CB'',',
'                 ''9'',',
'                 ''CC'')',
'            GRUPO_PRODUCTO,',
'         DECODE (i.ATO_CLAVE,',
'                 ''S'',',
'                 ''SI'',',
'                 ''N'',',
'                 ''NO'')',
'            CLAVE,',
'         DECODE (i.ATO_ITEMIZADO,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            ITEMIZADO,',
'         i.ATO_TIEMPO_ENTREGA TIEMPO_ENTREGA,',
'         TRUNC (i.ATO_FECHA_PRIMER_INGRESO) FECHA_INGRESO,',
'         ATO_DESCRIPCION_ALTERNA DESCRIPCION_ALTERNA,',
'         ATO_CANTIDAD_MAQUINA CANTIDAD_MAQUINA,',
'         ATO_PARTE_FABRICANTE PARTE_FABRICANTE,',
'         ATO_PAA_PARTIDA PARTIDA,',
'         ATO_CANTIDAD_MINIMA CANTIDAD_MINIMA,',
'         ATO_CANTIDAD_MAXIMA CANTIDAD_MAXIMA,',
'         ATO_PEDIDO_MINIMO PEDIDO_MINIMO,',
'         DECODE (i.ATO_FLAG_TOMA_FISICA,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            FLAG_TOMA_FISICA,',
'         DECODE (i.ATO_AJUSTA_INFLACION,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            AJUSTA_INFLACION,',
'         ATO_BLOQUEADO_COMPRA_POR BLOQUEADO_COMPRA_POR,',
'         ATO_FECHA_BLOQUEO_COMPRA FECHA_BLOQUEO_COMPRA,',
'         ATO_BLOQUEADO_VENTA_POR BLOQUEADO_VENTA_POR,',
'         ATO_FECHA_BLOQUEO_VENTA FECHA_BLOQUEO_VENTA,',
'         ATO_NUMERO_MESES_INVENTARIO MESES_INVENTARIO,',
'         ATO_ROTACION_SIMPLE ROTACION_SIMPLE,',
'         ATO_CREADO_POR CREADO_POR,',
'         ATO_FECHA_CREACION FECHA_CREACION,',
'         ATO_MODIFICADO_POR MODIFICADO_POR,',
'         ATO_REG_SANITARIO REG_SANITARIO,',
'         ATO_FECHA_VEN_REG_SANITAR VEN_REG_SANITARIO,',
'         ATO_FECHA_DESCONTINUADO FECHA_DESCONTINUADO,',
'         ATO_NUMERO_DIAS_INVENTARIO NUMERO_DIAS_INVENTARIO,',
'         ATO_TAM_TAMANO TAMANO,',
'         ATO_CLR_COLOR COLOR,',
'         ATO_CLASIFICACION_ABC CLASIFICACION_ABC,',
'         DECODE (i.ATO_LOCAL_EXTERNO,',
'                 ''L'',',
'                 ''LOCAL'',',
'                 ''E'',',
'                 ''EXTERNO'')',
'            LOCAL_EXTERNO,',
'         ATO_TIPO_COMBUSTIBLE TIPO_COMBUSTIBLE,',
'         ATO_CILINDRAJE CILINDRAJE,',
'         ATO_NUMERO_CILINDROS NUMERO_CILINDROS,',
'         ATO_TIPO_TRACCION TIPO_TRACCION,',
'         ATO_TIPO_CARROCERIA TIPO_CARROCERIA,',
'         ATO_TIPO_ESTILO TIPO_ESTILO,',
'         ATO_CATEGORIA_CAR CATEGORIA_CAR,',
'         ATO_TIPO_SERVICIO TIPO_SERVICIO,',
'         ATO_BASE_MENSUAL BASE_MENSUAL,',
'         ATO_PAIS_ORIGEN PAIS_ORIGEN,',
'         DECODE (i.ATO_IND_COMBO,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            INDICA_COMBO,',
'         DECODE (i.ATO_IND_DESPIECE,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            IND_DESPIECE,',
'         DECODE (i.ATO_IND_OBSERVACIONES,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            IND_OBSERVACIONES,',
'         DECODE (i.ATO_FRACCIONABLE,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            FRACCIONABLE,',
'         DECODE (i.ATO_SIN_GESTION_ESTUDIANTE,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            SIN_GESTION_ESTUDIANTE,',
'         DECODE (i.ATO_PERMITE_DESCUENTO,',
'                 ''N'',',
'                 ''NO'',',
'                 ''S'',',
'                 ''SI'')',
'            PERMITE_DESCUENTO',
'  FROM   INV_LISTA_PRECIOS_TB_NX lp,',
'         INV_PRECIO_TB_NX p,',
'         INV_ARTICULO_LOCALIZACION_TB_N a,',
'         INV_ARTICULO_TB_NX i',
' WHERE       INSTR ('':'' || :P146_EMPRESA || '':'',',
'                    '':'' || lp.LPO_EMP_EMPRESA || '':'') > 0',
'         AND lp.LPO_EMP_EMPRESA = P.PCO_EMP_EMPRESA',
'         AND lp.LPO_LISTA = p.PCO_LPO_LISTA',
'         AND aln_Emp_Empresa(+) = p.PCO_EMP_EMPRESA',
'         AND aln_ato_articulo(+) = p.PCO_ATO_ARTICULO',
'         AND p.PCO_EMP_EMPRESA = i.ATO_EMP_EMPRESA',
'         AND p.PCO_ATO_ARTICULO = i.ATO_ARTICULO',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P146_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14122502941631840416)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>59483211191624157
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088379081165516216)
,p_db_column_name=>'LPO_EMP_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'CR'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088379475157516217)
,p_db_column_name=>'LPO_LISTA'
,p_display_order=>20
,p_column_identifier=>'CS'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088379834660516217)
,p_db_column_name=>'LPO_DESCRIPCION'
,p_display_order=>30
,p_column_identifier=>'CT'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088380311574516218)
,p_db_column_name=>'LPO_MON_MONEDA'
,p_display_order=>40
,p_column_identifier=>'CU'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088380660070516219)
,p_db_column_name=>'LPO_TIP_TIPO_CAMBIO'
,p_display_order=>50
,p_column_identifier=>'CV'
,p_column_label=>'T. Cambio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088381076023516220)
,p_db_column_name=>'LPO_TIPO_LISTA'
,p_display_order=>60
,p_column_identifier=>'CW'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088381511438516220)
,p_db_column_name=>'LPO_TIPO_BASE'
,p_display_order=>70
,p_column_identifier=>'CX'
,p_column_label=>'T. Base'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088381879201516221)
,p_db_column_name=>'LPO_TIPO_CALCULO'
,p_display_order=>80
,p_column_identifier=>'CY'
,p_column_label=>'T. Calculo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088382277467516222)
,p_db_column_name=>'LPO_REDONDEO_COMERCIAL'
,p_display_order=>90
,p_column_identifier=>'CZ'
,p_column_label=>'Redondeo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088382679187516223)
,p_db_column_name=>'PCO_ATO_ARTICULO'
,p_display_order=>100
,p_column_identifier=>'DA'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088383076052516223)
,p_db_column_name=>'DSP_ATO_DESCRIPCION'
,p_display_order=>110
,p_column_identifier=>'DB'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088383507621516224)
,p_db_column_name=>'PCO_PRECIO'
,p_display_order=>120
,p_column_identifier=>'DC'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088383910907516225)
,p_db_column_name=>'PCO_PORCENTAJE'
,p_display_order=>130
,p_column_identifier=>'DD'
,p_column_label=>'Porcentaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088384262722516226)
,p_db_column_name=>'PCO_FACTOR1'
,p_display_order=>140
,p_column_identifier=>'DE'
,p_column_label=>'Factor1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088384711072516226)
,p_db_column_name=>'PCO_FACTOR2'
,p_display_order=>150
,p_column_identifier=>'DF'
,p_column_label=>'Factor2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088385121705516228)
,p_db_column_name=>'PCO_FACTOR3'
,p_display_order=>160
,p_column_identifier=>'DG'
,p_column_label=>'Factor3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088385437576516229)
,p_db_column_name=>'PCO_TIPO_BASE'
,p_display_order=>170
,p_column_identifier=>'DH'
,p_column_label=>'T. Base'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088385836550516230)
,p_db_column_name=>'PCO_TIPO_CALCULO'
,p_display_order=>180
,p_column_identifier=>'DI'
,p_column_label=>'T. Calculo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088378273846516214)
,p_db_column_name=>'PCO_GASTOS_INSCRIP'
,p_display_order=>190
,p_column_identifier=>'DJ'
,p_column_label=>'Gastos Inscripcion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088378661141516215)
,p_db_column_name=>'PCO_GASTOS_ADIC'
,p_display_order=>200
,p_column_identifier=>'DK'
,p_column_label=>'Gastos Adicional'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087235427156160901)
,p_db_column_name=>'ALN_EMP_EMPRESA'
,p_display_order=>210
,p_column_identifier=>'DL'
,p_column_label=>'Aln emp empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087235471048160902)
,p_db_column_name=>'ALN_LCN_LOCALIZACION'
,p_display_order=>220
,p_column_identifier=>'DM'
,p_column_label=>unistr('Localizaci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087235562896160903)
,p_db_column_name=>'ALN_ATO_ARTICULO'
,p_display_order=>230
,p_column_identifier=>'DN'
,p_column_label=>'Aln ato articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087235727888160904)
,p_db_column_name=>'ALN_CANTIDAD_TOTAL'
,p_display_order=>240
,p_column_identifier=>'DO'
,p_column_label=>'Aln cantidad total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087235793328160905)
,p_db_column_name=>'ALN_CANTIDAD_TRANSITO'
,p_display_order=>250
,p_column_identifier=>'DP'
,p_column_label=>'Aln cantidad transito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087235892891160906)
,p_db_column_name=>'ALN_CANTIDAD_TRANSITO_INTERNO'
,p_display_order=>260
,p_column_identifier=>'DQ'
,p_column_label=>'Aln cantidad transito interno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087236006130160907)
,p_db_column_name=>'ALN_CANTIDAD_PEDIDA'
,p_display_order=>270
,p_column_identifier=>'DR'
,p_column_label=>'Aln cantidad pedida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087236049555160908)
,p_db_column_name=>'ALN_CANTIDAD_RESERVADA'
,p_display_order=>280
,p_column_identifier=>'DS'
,p_column_label=>'Aln cantidad reservada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087236156442160909)
,p_db_column_name=>'ALN_CANTIDAD_PRESTADA'
,p_display_order=>290
,p_column_identifier=>'DT'
,p_column_label=>'Aln cantidad prestada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088387511666158160)
,p_db_column_name=>'ALN_CANTIDAD_USO_INTERNO'
,p_display_order=>300
,p_column_identifier=>'DU'
,p_column_label=>'Aln cantidad uso interno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088387606379158161)
,p_db_column_name=>'ALN_CANTIDAD_CONSIGNACION'
,p_display_order=>310
,p_column_identifier=>'DV'
,p_column_label=>'Aln cantidad consignacion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088387654947158162)
,p_db_column_name=>'ALN_CANTIDAD_FACTURADA'
,p_display_order=>320
,p_column_identifier=>'DW'
,p_column_label=>'Aln cantidad facturada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088387756953158163)
,p_db_column_name=>'ALN_ULTIMO_COSTO'
,p_display_order=>330
,p_column_identifier=>'DX'
,p_column_label=>'Ultimo Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088387834285158164)
,p_db_column_name=>'ALN_ULTIMO_COSTO_ALT'
,p_display_order=>340
,p_column_identifier=>'DY'
,p_column_label=>'Ultimo Costo Alt.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088387986133158165)
,p_db_column_name=>'ALN_FECHA_ULTIMO_COSTO'
,p_display_order=>350
,p_column_identifier=>'DZ'
,p_column_label=>'Aln fecha ultimo costo'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388051513158166)
,p_db_column_name=>'ALN_FECHA_ULTIMA_VENTA'
,p_display_order=>360
,p_column_identifier=>'EA'
,p_column_label=>'Aln fecha ultima venta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388230265158167)
,p_db_column_name=>'ALN_COSTO_UNITARIO'
,p_display_order=>370
,p_column_identifier=>'EB'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388256937158168)
,p_db_column_name=>'ALN_COSTO_UNITARIO_ALT'
,p_display_order=>380
,p_column_identifier=>'EC'
,p_column_label=>'Costo Unitario Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388380657158169)
,p_db_column_name=>'ALN_COSTO_UNITARIO_CORP'
,p_display_order=>390
,p_column_identifier=>'ED'
,p_column_label=>'Aln costo unitario corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388463122158170)
,p_db_column_name=>'ALN_COSTO_UNITARIO_CORP_ALT'
,p_display_order=>400
,p_column_identifier=>'EE'
,p_column_label=>'Costo Unitario Corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388578410158171)
,p_db_column_name=>'ALN_COSTO_UNITARIO_ANT'
,p_display_order=>410
,p_column_identifier=>'EF'
,p_column_label=>'Aln costo unitario ant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388659496158172)
,p_db_column_name=>'ALN_COSTO_UNITARIO_ANT_ALT'
,p_display_order=>420
,p_column_identifier=>'EG'
,p_column_label=>'Aln costo unitario ant alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388827275158173)
,p_db_column_name=>'ALN_COSTO_UNITARIO_ANT_CORP'
,p_display_order=>430
,p_column_identifier=>'EH'
,p_column_label=>'Aln costo unitario ant corp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088388913834158174)
,p_db_column_name=>'ALN_COSTO_UNITARIO_ANT_CORP_AL'
,p_display_order=>440
,p_column_identifier=>'EI'
,p_column_label=>'Aln costo unitario ant corp al'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389020539158175)
,p_db_column_name=>'ALN_FECHA_CAMBIO_COSTO'
,p_display_order=>450
,p_column_identifier=>'EJ'
,p_column_label=>'Aln fecha cambio costo'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389093273158176)
,p_db_column_name=>'ALN_UBICACION'
,p_display_order=>460
,p_column_identifier=>'EK'
,p_column_label=>'Aln ubicacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389217040158177)
,p_db_column_name=>'ALN_BLOQUEADO_TOMA'
,p_display_order=>470
,p_column_identifier=>'EL'
,p_column_label=>'Aln bloqueado toma'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389305697158178)
,p_db_column_name=>'ALN_REALIZADA_TOMA_ANUAL'
,p_display_order=>480
,p_column_identifier=>'EM'
,p_column_label=>'Aln realizada toma anual'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389370596158179)
,p_db_column_name=>'ALN_COSTO_AJC_UNITARIO'
,p_display_order=>490
,p_column_identifier=>'EN'
,p_column_label=>'Aln costo ajc unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389500013158180)
,p_db_column_name=>'ALN_COSTO_AJC_UNITARIO_ALT'
,p_display_order=>500
,p_column_identifier=>'EO'
,p_column_label=>'Aln costo ajc unitario alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389605753158181)
,p_db_column_name=>'ALN_COSTO_AJC_UNITARIO_ANT'
,p_display_order=>510
,p_column_identifier=>'EP'
,p_column_label=>'Aln costo ajc unitario ant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389682335158182)
,p_db_column_name=>'ALN_COSTO_AJC_UNITARIO_ALT_ANT'
,p_display_order=>520
,p_column_identifier=>'EQ'
,p_column_label=>'Aln costo ajc unitario alt ant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389756709158183)
,p_db_column_name=>'ALN_CLASE'
,p_display_order=>530
,p_column_identifier=>'ER'
,p_column_label=>'Aln clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389909065158184)
,p_db_column_name=>'ALN_PROM_VENTA_DIARIA'
,p_display_order=>540
,p_column_identifier=>'ES'
,p_column_label=>'Aln prom venta diaria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088389960509158185)
,p_db_column_name=>'ALN_DIAS_EXISTENCIA_BODEGA'
,p_display_order=>550
,p_column_identifier=>'ET'
,p_column_label=>'Aln dias existencia bodega'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390095990158186)
,p_db_column_name=>'ALN_DIAS_EXISTENCIA_TRANSITO'
,p_display_order=>560
,p_column_identifier=>'EU'
,p_column_label=>'Aln dias existencia transito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390180450158187)
,p_db_column_name=>'ALN_INV_MIN_EN_DIAS'
,p_display_order=>570
,p_column_identifier=>'EV'
,p_column_label=>'Aln inv min en dias'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390231637158188)
,p_db_column_name=>'ALN_INV_MAX_EN_DIAS_INT'
,p_display_order=>580
,p_column_identifier=>'EW'
,p_column_label=>'Aln inv max en dias int'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390366110158189)
,p_db_column_name=>'ALN_SEM_DIAS_VALIDOS'
,p_display_order=>590
,p_column_identifier=>'EX'
,p_column_label=>'Aln sem dias validos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390455632158190)
,p_db_column_name=>'ALN_DESVIACION_ESTANDAR'
,p_display_order=>600
,p_column_identifier=>'EY'
,p_column_label=>'Aln desviacion estandar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390554897158191)
,p_db_column_name=>'ALN_CANTIDAD_MINIMA'
,p_display_order=>610
,p_column_identifier=>'EZ'
,p_column_label=>'Aln cantidad minima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390635235158192)
,p_db_column_name=>'ALN_CANTIDAD_MAXIMA'
,p_display_order=>620
,p_column_identifier=>'FA'
,p_column_label=>'Aln cantidad maxima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390796782158193)
,p_db_column_name=>'ALN_NUMERO_MESES_INVENTARIO'
,p_display_order=>630
,p_column_identifier=>'FB'
,p_column_label=>'Aln numero meses inventario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390860804158194)
,p_db_column_name=>'ALN_FORECAST'
,p_display_order=>640
,p_column_identifier=>'FC'
,p_column_label=>'Aln forecast'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088390952368158195)
,p_db_column_name=>'ALN_STOCK_MESES'
,p_display_order=>650
,p_column_identifier=>'FD'
,p_column_label=>'Aln stock meses'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088391082966158196)
,p_db_column_name=>'ALN_CANTIDAD_BLOQUEADA'
,p_display_order=>660
,p_column_identifier=>'FE'
,p_column_label=>'Aln cantidad bloqueada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088391224063158197)
,p_db_column_name=>'ALN_IND_ATO_EXHIB'
,p_display_order=>670
,p_column_identifier=>'FF'
,p_column_label=>'Aln ind ato exhib'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088391251801158198)
,p_db_column_name=>'ALN_CANTIDAD_MINIMA_EXH'
,p_display_order=>680
,p_column_identifier=>'FG'
,p_column_label=>'Aln cantidad minima exh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14088391350329158199)
,p_db_column_name=>'ALN_CANTIDAD_MAXINA_EXH'
,p_display_order=>690
,p_column_identifier=>'FH'
,p_column_label=>'Aln cantidad maxina exh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013662433240602)
,p_db_column_name=>'FAMILIA'
,p_display_order=>700
,p_column_identifier=>'FI'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013764161240603)
,p_db_column_name=>'DESC_FAMILIA'
,p_display_order=>710
,p_column_identifier=>'FJ'
,p_column_label=>'Desc familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013925371240604)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>720
,p_column_identifier=>'FK'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013936226240605)
,p_db_column_name=>'MODELO'
,p_display_order=>730
,p_column_identifier=>'FL'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065014120359240606)
,p_db_column_name=>'MARCA'
,p_display_order=>740
,p_column_identifier=>'FM'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065014131042240607)
,p_db_column_name=>'CODIGO_BARRAS'
,p_display_order=>750
,p_column_identifier=>'FN'
,p_column_label=>'Codigo barras'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065014325034240608)
,p_db_column_name=>'COSTO_FOB'
,p_display_order=>760
,p_column_identifier=>'FO'
,p_column_label=>'Costo fob'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065014373859240609)
,p_db_column_name=>'COSTO_ESTANDAR'
,p_display_order=>770
,p_column_identifier=>'FP'
,p_column_label=>'Costo estandar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065039870000335260)
,p_db_column_name=>'BLOQUEADO_COMPRA'
,p_display_order=>780
,p_column_identifier=>'FQ'
,p_column_label=>'Bloqueado compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040018215335261)
,p_db_column_name=>'BLOQUEADO_VENTA'
,p_display_order=>790
,p_column_identifier=>'FR'
,p_column_label=>'Bloqueado venta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040108726335262)
,p_db_column_name=>'REEMPLAZA'
,p_display_order=>800
,p_column_identifier=>'FS'
,p_column_label=>'Reemplaza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040200405335263)
,p_db_column_name=>'REEMPLAZO'
,p_display_order=>810
,p_column_identifier=>'FT'
,p_column_label=>'Reemplazo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040279925335264)
,p_db_column_name=>'MAXIMO_DESCUENTO'
,p_display_order=>820
,p_column_identifier=>'FU'
,p_column_label=>'Maximo descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040347308335265)
,p_db_column_name=>'MODIFICAR_PRECIO'
,p_display_order=>830
,p_column_identifier=>'FV'
,p_column_label=>'Modificar precio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040503631335266)
,p_db_column_name=>'GRAVADO'
,p_display_order=>840
,p_column_identifier=>'FW'
,p_column_label=>'Gravado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040609875335267)
,p_db_column_name=>'MODIFICA_DESCRIPCION'
,p_display_order=>850
,p_column_identifier=>'FX'
,p_column_label=>'Modifica descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040687195335268)
,p_db_column_name=>'BAJO_MARGEN'
,p_display_order=>860
,p_column_identifier=>'FY'
,p_column_label=>'Bajo margen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040749165335269)
,p_db_column_name=>'DESCONTINUADO'
,p_display_order=>870
,p_column_identifier=>'FZ'
,p_column_label=>'Descontinuado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065040852986335270)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>880
,p_column_identifier=>'GA'
,p_column_label=>'Categoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041011201335271)
,p_db_column_name=>'TIPO_USO'
,p_display_order=>890
,p_column_identifier=>'GB'
,p_column_label=>'Tipo uso'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041113562335272)
,p_db_column_name=>'GRUPO_PRODUCTO'
,p_display_order=>900
,p_column_identifier=>'GC'
,p_column_label=>'Grupo producto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041174984335273)
,p_db_column_name=>'CLAVE'
,p_display_order=>910
,p_column_identifier=>'GD'
,p_column_label=>'Clave'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041243406335274)
,p_db_column_name=>'ITEMIZADO'
,p_display_order=>920
,p_column_identifier=>'GE'
,p_column_label=>'Itemizado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041367604335275)
,p_db_column_name=>'TIEMPO_ENTREGA'
,p_display_order=>930
,p_column_identifier=>'GF'
,p_column_label=>'Tiempo entrega'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041457988335276)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>940
,p_column_identifier=>'GG'
,p_column_label=>'Fecha ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041542018335277)
,p_db_column_name=>'DESCRIPCION_ALTERNA'
,p_display_order=>950
,p_column_identifier=>'GH'
,p_column_label=>'Descripcion alterna'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041725957335278)
,p_db_column_name=>'CANTIDAD_MAQUINA'
,p_display_order=>960
,p_column_identifier=>'GI'
,p_column_label=>'Cantidad maquina'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041751247335279)
,p_db_column_name=>'PARTE_FABRICANTE'
,p_display_order=>970
,p_column_identifier=>'GJ'
,p_column_label=>'Parte fabricante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041924265335280)
,p_db_column_name=>'PARTIDA'
,p_display_order=>980
,p_column_identifier=>'GK'
,p_column_label=>'Partida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065041961416335281)
,p_db_column_name=>'CANTIDAD_MINIMA'
,p_display_order=>990
,p_column_identifier=>'GL'
,p_column_label=>'Cantidad minima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042121306335282)
,p_db_column_name=>'CANTIDAD_MAXIMA'
,p_display_order=>1000
,p_column_identifier=>'GM'
,p_column_label=>'Cantidad maxima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042172231335283)
,p_db_column_name=>'PEDIDO_MINIMO'
,p_display_order=>1010
,p_column_identifier=>'GN'
,p_column_label=>'Pedido minimo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042293487335284)
,p_db_column_name=>'FLAG_TOMA_FISICA'
,p_display_order=>1020
,p_column_identifier=>'GO'
,p_column_label=>'Flag toma fisica'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042419039335285)
,p_db_column_name=>'AJUSTA_INFLACION'
,p_display_order=>1030
,p_column_identifier=>'GP'
,p_column_label=>'Ajusta inflacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042448038335286)
,p_db_column_name=>'BLOQUEADO_COMPRA_POR'
,p_display_order=>1040
,p_column_identifier=>'GQ'
,p_column_label=>'Bloqueado compra por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042620884335287)
,p_db_column_name=>'FECHA_BLOQUEO_COMPRA'
,p_display_order=>1050
,p_column_identifier=>'GR'
,p_column_label=>'Fecha bloqueo compra'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042653183335288)
,p_db_column_name=>'BLOQUEADO_VENTA_POR'
,p_display_order=>1060
,p_column_identifier=>'GS'
,p_column_label=>'Bloqueado venta por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042813432335289)
,p_db_column_name=>'FECHA_BLOQUEO_VENTA'
,p_display_order=>1070
,p_column_identifier=>'GT'
,p_column_label=>'Fecha bloqueo venta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042853368335290)
,p_db_column_name=>'MESES_INVENTARIO'
,p_display_order=>1080
,p_column_identifier=>'GU'
,p_column_label=>'Meses inventario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065042978099335291)
,p_db_column_name=>'ROTACION_SIMPLE'
,p_display_order=>1090
,p_column_identifier=>'GV'
,p_column_label=>'Rotacion simple'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043096091335292)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>1100
,p_column_identifier=>'GW'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043188857335293)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>1110
,p_column_identifier=>'GX'
,p_column_label=>'Fecha creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043262862335294)
,p_db_column_name=>'MODIFICADO_POR'
,p_display_order=>1120
,p_column_identifier=>'GY'
,p_column_label=>'Modificado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043371605335295)
,p_db_column_name=>'REG_SANITARIO'
,p_display_order=>1130
,p_column_identifier=>'GZ'
,p_column_label=>'Reg sanitario'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043495231335296)
,p_db_column_name=>'VEN_REG_SANITARIO'
,p_display_order=>1140
,p_column_identifier=>'HA'
,p_column_label=>'Ven reg sanitario'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043571461335297)
,p_db_column_name=>'FECHA_DESCONTINUADO'
,p_display_order=>1150
,p_column_identifier=>'HB'
,p_column_label=>'Fecha descontinuado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043633488335298)
,p_db_column_name=>'NUMERO_DIAS_INVENTARIO'
,p_display_order=>1160
,p_column_identifier=>'HC'
,p_column_label=>'Numero dias inventario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043761508335299)
,p_db_column_name=>'TAMANO'
,p_display_order=>1170
,p_column_identifier=>'HD'
,p_column_label=>'Tamano'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043882567335300)
,p_db_column_name=>'COLOR'
,p_display_order=>1180
,p_column_identifier=>'HE'
,p_column_label=>'Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065043987847335301)
,p_db_column_name=>'CLASIFICACION_ABC'
,p_display_order=>1190
,p_column_identifier=>'HF'
,p_column_label=>'Clasificacion abc'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044042798335302)
,p_db_column_name=>'LOCAL_EXTERNO'
,p_display_order=>1200
,p_column_identifier=>'HG'
,p_column_label=>'Local externo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044149578335303)
,p_db_column_name=>'TIPO_COMBUSTIBLE'
,p_display_order=>1210
,p_column_identifier=>'HH'
,p_column_label=>'Tipo combustible'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044282997335304)
,p_db_column_name=>'CILINDRAJE'
,p_display_order=>1220
,p_column_identifier=>'HI'
,p_column_label=>'Cilindraje'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044350773335305)
,p_db_column_name=>'NUMERO_CILINDROS'
,p_display_order=>1230
,p_column_identifier=>'HJ'
,p_column_label=>'Numero cilindros'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044469041335306)
,p_db_column_name=>'TIPO_TRACCION'
,p_display_order=>1240
,p_column_identifier=>'HK'
,p_column_label=>'Tipo traccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044547414335307)
,p_db_column_name=>'TIPO_CARROCERIA'
,p_display_order=>1250
,p_column_identifier=>'HL'
,p_column_label=>'Tipo carroceria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044633541335308)
,p_db_column_name=>'TIPO_ESTILO'
,p_display_order=>1260
,p_column_identifier=>'HM'
,p_column_label=>'Tipo estilo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044794229335309)
,p_db_column_name=>'CATEGORIA_CAR'
,p_display_order=>1270
,p_column_identifier=>'HN'
,p_column_label=>'Categoria car'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065044840407335260)
,p_db_column_name=>'TIPO_SERVICIO'
,p_display_order=>1280
,p_column_identifier=>'HO'
,p_column_label=>'Tipo servicio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065045007016335261)
,p_db_column_name=>'BASE_MENSUAL'
,p_display_order=>1290
,p_column_identifier=>'HP'
,p_column_label=>'Base mensual'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065045038315335262)
,p_db_column_name=>'PAIS_ORIGEN'
,p_display_order=>1300
,p_column_identifier=>'HQ'
,p_column_label=>'Pais origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065045159290335263)
,p_db_column_name=>'INDICA_COMBO'
,p_display_order=>1310
,p_column_identifier=>'HR'
,p_column_label=>'Indica combo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065045231906335264)
,p_db_column_name=>'IND_DESPIECE'
,p_display_order=>1320
,p_column_identifier=>'HS'
,p_column_label=>'Ind despiece'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065045371003335265)
,p_db_column_name=>'IND_OBSERVACIONES'
,p_display_order=>1330
,p_column_identifier=>'HT'
,p_column_label=>'Ind observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065045474803335266)
,p_db_column_name=>'FRACCIONABLE'
,p_display_order=>1340
,p_column_identifier=>'HU'
,p_column_label=>'Fraccionable'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065045608590335267)
,p_db_column_name=>'SIN_GESTION_ESTUDIANTE'
,p_display_order=>1350
,p_column_identifier=>'HV'
,p_column_label=>'Sin gestion estudiante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065045697584335268)
,p_db_column_name=>'PERMITE_DESCUENTO'
,p_display_order=>1360
,p_column_identifier=>'HW'
,p_column_label=>'Permite descuento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14122512278298840435)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'253665'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LPO_EMP_EMPRESA:LPO_LISTA:LPO_DESCRIPCION:LPO_MON_MONEDA:LPO_TIP_TIPO_CAMBIO:LPO_TIPO_LISTA:LPO_TIPO_BASE:LPO_TIPO_CALCULO:LPO_REDONDEO_COMERCIAL:PCO_ATO_ARTICULO:DSP_ATO_DESCRIPCION:PCO_PRECIO:ALN_LCN_LOCALIZACION:ALN_ULTIMO_COSTO:ALN_ULTIMO_COSTO_A'
||'LT:PCO_PORCENTAJE:PCO_FACTOR1:PCO_FACTOR2:PCO_FACTOR3:PCO_TIPO_BASE:PCO_TIPO_CALCULO:PCO_GASTOS_INSCRIP:PCO_GASTOS_ADIC::FAMILIA:DESC_FAMILIA:OBSERVACIONES:MODELO:MARCA:CODIGO_BARRAS:COSTO_FOB:COSTO_ESTANDAR:BLOQUEADO_COMPRA:BLOQUEADO_VENTA:REEMPLAZA'
||':REEMPLAZO:MAXIMO_DESCUENTO:MODIFICAR_PRECIO:GRAVADO:MODIFICA_DESCRIPCION:BAJO_MARGEN:DESCONTINUADO:CATEGORIA:TIPO_USO:GRUPO_PRODUCTO:CLAVE:ITEMIZADO:TIEMPO_ENTREGA:FECHA_INGRESO:DESCRIPCION_ALTERNA:CANTIDAD_MAQUINA:PARTE_FABRICANTE:PARTIDA:CANTIDAD_'
||'MINIMA:CANTIDAD_MAXIMA:PEDIDO_MINIMO:FLAG_TOMA_FISICA:AJUSTA_INFLACION:BLOQUEADO_COMPRA_POR:FECHA_BLOQUEO_COMPRA:BLOQUEADO_VENTA_POR:FECHA_BLOQUEO_VENTA:MESES_INVENTARIO:ROTACION_SIMPLE:CREADO_POR:FECHA_CREACION:MODIFICADO_POR:REG_SANITARIO:VEN_REG_S'
||'ANITARIO:FECHA_DESCONTINUADO:NUMERO_DIAS_INVENTARIO:TAMANO:COLOR:CLASIFICACION_ABC:LOCAL_EXTERNO:TIPO_COMBUSTIBLE:CILINDRAJE:NUMERO_CILINDROS:TIPO_TRACCION:TIPO_CARROCERIA:TIPO_ESTILO:CATEGORIA_CAR:TIPO_SERVICIO:BASE_MENSUAL:PAIS_ORIGEN:INDICA_COMBO:'
||'IND_DESPIECE:IND_OBSERVACIONES:FRACCIONABLE:SIN_GESTION_ESTUDIANTE:PERMITE_DESCUENTO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14088377172966516209)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14122500919803840410)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14088377567373516210)
,p_name=>'P146_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14122500919803840410)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
