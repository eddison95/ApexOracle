prompt --application/pages/page_00183
begin
--   Manifest
--     PAGE: 00183
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>183
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Comision Ventas'
,p_step_title=>'Comision Ventas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20210531170159'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14170286634421052617)
,p_plug_name=>'Comisiones'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14170282738140968159)
,p_plug_name=>'Comisiones'
,p_parent_plug_id=>wwv_flow_api.id(14170286634421052617)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.tra_emp_empresa empresa, pec_periodo periodo_comision, pec_ano anio_comision, pec_fecha_inicial fecha_inicial_comision, ',
'pec_fecha_final fecha_final_comision, c.tra_ven_vendedor codigo_vendedor, gnl_nombre_vendedor_vi(',
'  c.tra_emp_empresa',
' ,c.tra_ven_vendedor',
') nombre_vendedor,',
'tra_ttr_tipo tipo_transaccion,',
'tra_transaccion transaccion_factura,',
'tra_factura numero_factura, ',
'tra_tipo tipo_factura,',
'tra_fecha fecha_factura,',
'tra_mon_moneda moneda_factura,',
'tra_cli_mon_moneda moneda_cliente,',
'tra_cli_cliente cliente,',
'cxc_nombre_cli_v_nx(',
'  tra_emp_empresa',
' ,tra_cli_cliente',
' ,tra_cli_mon_moneda',
') nombre_cliente,',
'tra_lcn_localizacion localizacion_factura,',
'tra_dep_departamento depto_factura,',
'tra_subtotal subtotal_fact,',
'tra_descuento descuento_factura,',
'tra_impuesto_ventas impuesto_factura,',
'tra_otros_impuestos otros_impuestos_factura,',
'tra_flete flete_factura,',
'tra_total total_factura,',
'CASE WHEN tra_status = ''A'' THEN ''APLICADA'' WHEN tra_status = ''P'' THEN ''PROCESADA'' WHEN tra_status = ''C'' THEN ''CREADA'' ELSE ''SIN ESTADO'' END estado_factura,',
'tra_valor_cambio valor_cambio_factura,',
'tra_fecha_vencimiento fecha_vencimiento,',
'cmi_id id_comision,',
'cmi_comision codigo_comision,',
'cmi_descripcion desc_comision,',
'tra_dep_departamento depto_comision,',
'cmf_monto_base monto_base_comision,',
'cmf_monto_calculado monto_calculado_comision,',
'cmf_saldo saldo_comision,',
'cmf_monto_causado monto_causado,',
'cmn_monto_base monto_nota_comision,',
'CASE WHEN cmf_status = ''V'' THEN ''VIGENTE'' WHEN cmf_status = ''L'' THEN ''LIQUIDADO'' WHEN cmf_status = ''E'' THEN ''ENTRADA'' ELSE ''PAGADO'' END estado_comision,',
'cmf_monto_calculado/cmf_monto_base *100 porcentaje_comision,',
'CASE WHEN ncd_tipo = 1 THEN ''TOTAL''  WHEN ncd_tipo = 2 THEN ''PARCIAL BUEN ESTADO''  WHEN ncd_tipo =  3 THEN ''PARCIAL MAL ESTADO''  WHEN ncd_tipo =  4 THEN ''DIFERENCIA EN EL DESCUENTO''',
' WHEN ncd_tipo =  5 THEN ''DIFERENCIA EN EL PRECIO'' ELSE ''ESPECIAL'' END tipo_nota_credito,',
'ncd_transaccion transaccion_nota_credito,',
'ncd_nota nota_credito,',
'ncd_fecha fecha_nota,',
'ncd_impuesto_ventas imp_vta_nota,',
'(select SUM(dnc_cantidad * dnc_precio_local) FROM FAC_DETALLE_NOTA_CR_DB_TB_NX WHERE dnc_ncd_transaccion = ncd_transaccion ) subtotal_nota,',
'(select SUM(dnc_cantidad * dnc_descuento) FROM FAC_DETALLE_NOTA_CR_DB_TB_NX WHERE dnc_ncd_transaccion = ncd_transaccion ) descuento_nota,',
'ncd_monto total_nota_credito,',
'rec_numero_recibo recibo,',
'rec_fecha fecha_recibo,',
'CASE WHEN rec_tipo_cuenta =''C'' THEN ''CUENTA CORRIENTE''  WHEN rec_tipo_cuenta =''F'' THEN ''FINANCIAMIENTOS''  WHEN rec_tipo_cuenta =''A'' THEN ''ANTICIPO RESERVACION''',
'WHEN rec_tipo_cuenta =''E'' THEN ''EFECTOS''  ELSE ''FACTOREO'' END tipo_recibo, rec_documento documento_Recibo, ref.ref_monto monto_recibo',
'from fac_comision_factura_tb_nx a, fac_comision_tb_nx,',
'fac_periodo_comision_tb_nx b, fac_factura_tb_nx c, fac_factura_nota_tb_nx d,',
'fac_notas_cr_db_tb_nx e, cxc_transaccion_tb_nx padre , cxc_referencia_tb_nx ref, cxc_transaccion_tb_nx hijas,',
'cxc_recibo_caja_tb_nx rec, fac_comision_nota_tb_nx com',
'WHERE cmf_tra_transaccion = tra_transaccion ',
'AND pec_id = cmf_pec_id AND tra_transaccion = cmf_tra_transaccion',
'AND cmi_id = cmf_cmi_id ',
'AND padre.trx_tra_transaccion(+)  = tra_transaccion',
'AND ref.ref_trx_transaccion(+) = padre.trx_transaccion',
'AND ref.ref_trx_transaccion_hijas = hijas.trx_transaccion(+)',
'AND hijas.trx_rec_numero_recibo = rec.rec_numero_recibo(+)  ',
'AND hijas.trx_emp_empresa = rec.rec_emp_empresa(+) ',
'AND NVL(rec.rec_status,''CON'') NOT IN (''X'')',
'AND NVL(cxc_signo_tran_v_nx(',
'  hijas.trx_emp_empresa',
' , hijas.trx_ttc_tipo',
'),''D'')= ''D''',
'AND fnt_tra_transaccion(+) = tra_transaccion ',
'AND fnt_ncd_transaccion = ncd_transaccion(+)',
'AND cmn_ncd_transaccion(+) = ncd_transaccion',
'AND INSTR ('':''||:P183_EMPRESA||'':'','':''||tra_emp_empresa||'':'') > 0',
'AND pec_id = NVL(:P183_PERIODO,pec_id)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P183_EMPRESA'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14170282859565968159)
,p_name=>'Comisiones'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'CANDERSON'
,p_internal_uid=>287460875169372436
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217034233661557)
,p_db_column_name=>'EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885222191248661561)
,p_db_column_name=>'CLIENTE'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885223452804661562)
,p_db_column_name=>'RECIBO'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Recibo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'RECIBO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899584670096822628)
,p_db_column_name=>'PERIODO_COMISION'
,p_display_order=>32
,p_column_identifier=>'W'
,p_column_label=>'Periodo Comision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899584698795822629)
,p_db_column_name=>'ANIO_COMISION'
,p_display_order=>42
,p_column_identifier=>'X'
,p_column_label=>unistr('A\00F1o Comision')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899584882042822630)
,p_db_column_name=>'FECHA_INICIAL_COMISION'
,p_display_order=>52
,p_column_identifier=>'Y'
,p_column_label=>'Fecha Inicial Comision'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899584962058822631)
,p_db_column_name=>'FECHA_FINAL_COMISION'
,p_display_order=>62
,p_column_identifier=>'Z'
,p_column_label=>'Fecha Final Comision'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585023376822632)
,p_db_column_name=>'CODIGO_VENDEDOR'
,p_display_order=>72
,p_column_identifier=>'AA'
,p_column_label=>'Codigo Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585140632822633)
,p_db_column_name=>'NOMBRE_VENDEDOR'
,p_display_order=>82
,p_column_identifier=>'AB'
,p_column_label=>'Nombre Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585205609822634)
,p_db_column_name=>'TIPO_TRANSACCION'
,p_display_order=>92
,p_column_identifier=>'AC'
,p_column_label=>'Tipo Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585358190822635)
,p_db_column_name=>'TRANSACCION_FACTURA'
,p_display_order=>102
,p_column_identifier=>'AD'
,p_column_label=>'Transaccion Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585409347822636)
,p_db_column_name=>'NUMERO_FACTURA'
,p_display_order=>112
,p_column_identifier=>'AE'
,p_column_label=>'Numero Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585492158822637)
,p_db_column_name=>'TIPO_FACTURA'
,p_display_order=>122
,p_column_identifier=>'AF'
,p_column_label=>'Tipo Factura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585599883822638)
,p_db_column_name=>'FECHA_FACTURA'
,p_display_order=>132
,p_column_identifier=>'AG'
,p_column_label=>'Fecha Factura'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585707947822639)
,p_db_column_name=>'MONEDA_FACTURA'
,p_display_order=>142
,p_column_identifier=>'AH'
,p_column_label=>'Moneda Factura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585843362822640)
,p_db_column_name=>'MONEDA_CLIENTE'
,p_display_order=>152
,p_column_identifier=>'AI'
,p_column_label=>'Moneda Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899585924748822641)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>162
,p_column_identifier=>'AJ'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586053453822642)
,p_db_column_name=>'LOCALIZACION_FACTURA'
,p_display_order=>172
,p_column_identifier=>'AK'
,p_column_label=>'Localizacion Factura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586181159822643)
,p_db_column_name=>'DEPTO_FACTURA'
,p_display_order=>182
,p_column_identifier=>'AL'
,p_column_label=>'Depto Factura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899589000056822672)
,p_db_column_name=>'VALOR_CAMBIO_FACTURA'
,p_display_order=>192
,p_column_identifier=>'BM'
,p_column_label=>'Valor Cambio Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586257790822644)
,p_db_column_name=>'SUBTOTAL_FACT'
,p_display_order=>202
,p_column_identifier=>'AM'
,p_column_label=>'Subtotal Fact'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586373647822645)
,p_db_column_name=>'DESCUENTO_FACTURA'
,p_display_order=>212
,p_column_identifier=>'AN'
,p_column_label=>'Descuento Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586439254822646)
,p_db_column_name=>'IMPUESTO_FACTURA'
,p_display_order=>222
,p_column_identifier=>'AO'
,p_column_label=>'Impuesto Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586557640822647)
,p_db_column_name=>'OTROS_IMPUESTOS_FACTURA'
,p_display_order=>232
,p_column_identifier=>'AP'
,p_column_label=>'Otros Impuestos Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586631777822648)
,p_db_column_name=>'FLETE_FACTURA'
,p_display_order=>242
,p_column_identifier=>'AQ'
,p_column_label=>'Flete Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586764447822649)
,p_db_column_name=>'TOTAL_FACTURA'
,p_display_order=>252
,p_column_identifier=>'AR'
,p_column_label=>'Total Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586795098822650)
,p_db_column_name=>'ESTADO_FACTURA'
,p_display_order=>262
,p_column_identifier=>'AS'
,p_column_label=>'Estado Factura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899586896410822651)
,p_db_column_name=>'FECHA_VENCIMIENTO'
,p_display_order=>272
,p_column_identifier=>'AT'
,p_column_label=>'Fecha Vencimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899587079076822652)
,p_db_column_name=>'ID_COMISION'
,p_display_order=>282
,p_column_identifier=>'AU'
,p_column_label=>'Id Comision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899587177460822653)
,p_db_column_name=>'CODIGO_COMISION'
,p_display_order=>292
,p_column_identifier=>'AV'
,p_column_label=>'Codigo Comision'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899587227798822654)
,p_db_column_name=>'DESC_COMISION'
,p_display_order=>302
,p_column_identifier=>'AW'
,p_column_label=>'Desc Comision'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899587396001822656)
,p_db_column_name=>'MONTO_BASE_COMISION'
,p_display_order=>322
,p_column_identifier=>'AY'
,p_column_label=>'Monto Base Comision Fac'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899587515723822657)
,p_db_column_name=>'MONTO_CALCULADO_COMISION'
,p_display_order=>332
,p_column_identifier=>'AZ'
,p_column_label=>'Monto Calculado Comision Fac'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899587590832822658)
,p_db_column_name=>'MONTO_CAUSADO'
,p_display_order=>342
,p_column_identifier=>'BA'
,p_column_label=>'Monto Causado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885279974972655324)
,p_db_column_name=>'PORCENTAJE_COMISION'
,p_display_order=>352
,p_column_identifier=>'BO'
,p_column_label=>'Porcentaje Comision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899587792544822660)
,p_db_column_name=>'ESTADO_COMISION'
,p_display_order=>372
,p_column_identifier=>'BC'
,p_column_label=>'Estado Comision'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899588046142822662)
,p_db_column_name=>'TIPO_NOTA_CREDITO'
,p_display_order=>382
,p_column_identifier=>'BE'
,p_column_label=>'Tipo Nota Credito'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899588141706822663)
,p_db_column_name=>'TRANSACCION_NOTA_CREDITO'
,p_display_order=>392
,p_column_identifier=>'BF'
,p_column_label=>'Transaccion Nota Credito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899588265619822664)
,p_db_column_name=>'NOTA_CREDITO'
,p_display_order=>402
,p_column_identifier=>'BG'
,p_column_label=>'Nota Credito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885280059478655325)
,p_db_column_name=>'SUBTOTAL_NOTA'
,p_display_order=>412
,p_column_identifier=>'BP'
,p_column_label=>'Subtotal Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899588471520822666)
,p_db_column_name=>'IMP_VTA_NOTA'
,p_display_order=>422
,p_column_identifier=>'BI'
,p_column_label=>'Imp Vta Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885280103739655326)
,p_db_column_name=>'DESCUENTO_NOTA'
,p_display_order=>432
,p_column_identifier=>'BQ'
,p_column_label=>'Descuento Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885280233950655327)
,p_db_column_name=>'TOTAL_NOTA_CREDITO'
,p_display_order=>442
,p_column_identifier=>'BR'
,p_column_label=>'Total Nota Credito'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899588495731822667)
,p_db_column_name=>'TIPO_RECIBO'
,p_display_order=>452
,p_column_identifier=>'BJ'
,p_column_label=>'Tipo Recibo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899588661102822668)
,p_db_column_name=>'DOCUMENTO_RECIBO'
,p_display_order=>462
,p_column_identifier=>'BK'
,p_column_label=>'Documento Recibo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899588748297822669)
,p_db_column_name=>'MONTO_RECIBO'
,p_display_order=>472
,p_column_identifier=>'BL'
,p_column_label=>'Monto Recibo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13899589133946822673)
,p_db_column_name=>'DEPTO_COMISION'
,p_display_order=>482
,p_column_identifier=>'BN'
,p_column_label=>'Depto Comision'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885280309998655328)
,p_db_column_name=>'FECHA_NOTA'
,p_display_order=>492
,p_column_identifier=>'BS'
,p_column_label=>'Fecha Nota'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885280444370655329)
,p_db_column_name=>'FECHA_RECIBO'
,p_display_order=>502
,p_column_identifier=>'BT'
,p_column_label=>'Fecha Recibo'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885280538346655330)
,p_db_column_name=>'MONTO_NOTA_COMISION'
,p_display_order=>512
,p_column_identifier=>'BU'
,p_column_label=>'Monto Nota Comision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885280588788655331)
,p_db_column_name=>'SALDO_COMISION'
,p_display_order=>522
,p_column_identifier=>'BV'
,p_column_label=>'Saldo Comision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14170284138089968468)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'24022'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>'EMPRESA:PERIODO_COMISION:ANIO_COMISION:FECHA_INICIAL_COMISION:FECHA_FINAL_COMISION:CODIGO_VENDEDOR:NOMBRE_VENDEDOR:TIPO_TRANSACCION:TRANSACCION_FACTURA:NUMERO_FACTURA:TIPO_FACTURA:FECHA_FACTURA:MONEDA_FACTURA:CLIENTE:NOMBRE_CLIENTE:MONEDA_CLIENTE:LOC'
||'ALIZACION_FACTURA:DEPTO_FACTURA:VALOR_CAMBIO_FACTURA:SUBTOTAL_FACT:DESCUENTO_FACTURA:IMPUESTO_FACTURA:OTROS_IMPUESTOS_FACTURA:FLETE_FACTURA:TOTAL_FACTURA:ESTADO_FACTURA:FECHA_VENCIMIENTO:ID_COMISION:CODIGO_COMISION:DESC_COMISION:DEPTO_COMISION:MONTO_'
||'BASE_COMISION:MONTO_CALCULADO_COMISION:MONTO_NOTA_COMISION:SALDO_COMISION:MONTO_CAUSADO:PORCENTAJE_COMISION:ESTADO_COMISION:NOTA_CREDITO:FECHA_NOTA:TIPO_NOTA_CREDITO:TRANSACCION_NOTA_CREDITO:SUBTOTAL_NOTA:DESCUENTO_NOTA:IMP_VTA_NOTA:TOTAL_NOTA_CREDIT'
||'O:RECIBO:FECHA_RECIBO:TIPO_RECIBO:DOCUMENTO_RECIBO:MONTO_RECIBO:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13885215092173661550)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14170286634421052617)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13885215574231661552)
,p_name=>'P183_EMPRESA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14170286634421052617)
,p_item_default=>'NULL'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13899588825311822670)
,p_name=>'P183_PERIODO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14170286634421052617)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT ''ID: ''|| pec_periodo || '' / A\00D1O: ''||pec_ano||'' / FECHA INICIO: ''||pec_fecha_inicial || '' / FECHA FINAL: ''||pec_fecha_final,pec_id '),
'FROM fac_periodo_comision_tb_nx',
'WHERE INSTR ('':''||:P183_EMPRESA||'':'','':''||pec_emp_empresa||'':'') > 0'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P183_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13885224606189661568)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ejecutar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'fac_comision_articulo_pr_nx (:P183_EMPRESA,to_date(:P183_INICIO,''DD/MM/RRRR''),to_date(:P183_FIN,''DD/MM/RRRR''));',
'commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error.'
,p_process_when_button_id=>wwv_flow_api.id(13885215092173661550)
,p_process_when_type=>'NEVER'
,p_process_success_message=>'Done.'
);
wwv_flow_api.component_end;
end;
/
