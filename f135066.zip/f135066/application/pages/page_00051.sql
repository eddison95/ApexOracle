prompt --application/pages/page_00051
begin
--   Manifest
--     PAGE: 00051
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>51
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('FAC \2013 Comisiones')
,p_step_title=>'Comisiones'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164102'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167894498610986806)
,p_plug_name=>'Comisiones'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167890602330902348)
,p_plug_name=>'Comisiones'
,p_parent_plug_id=>wwv_flow_api.id(14167894498610986806)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT fca_emp_empresa                                                  empresa,',
'       Trunc(fca_fecha_cobro)',
'       fecha_cobro,',
'       fca_ato_articulo                                                 articulo,',
'       Inv_descrip_art_v_nx (fca_emp_empresa, fca_ato_articulo)',
'       descripcion,',
'       fca_cob_codigo',
'       cod_cobrador,',
'       Cxc_nombre_cobrador_v_nx (fca_emp_empresa, fca_cob_codigo)       cobrador,',
'       Inv_familia_art_v_nx (fca_emp_empresa, fca_ato_articulo)',
'       familia,',
'       Inv_desc_fam_art_v_nx (fca_emp_empresa, fca_ato_articulo)',
'       desc_familia,',
'       Inv_obt_clasif_prin_art_v_nx (fca_emp_empresa, fca_ato_articulo)',
'       tipo_articulo,',
'       fca_monto                                                        monto,',
'       tra_valor_cambio',
'       valor_cambio,',
'       fca_tra_transaccion',
'       transaccion_fac,',
'       tra_cli_cliente',
'       codigo_cliente,',
'       tra_cli_mon_moneda                                               moneda,',
'       tra_nombre                                                       cliente,',
'       Gnl_nombre_vendedor_vi (tra_emp_empresa, tra_ven_vendedor)       vendedor,',
'       tra_factura',
'       factura,',
'       fca_rec_numero_recibo                                            recibo',
'FROM   fac_comision_articulo_tb_nx,',
'       fac_factura_tb_nx',
'WHERE  fca_fecha_cobro BETWEEN :p51_inicio AND To_date(:p51_fin',
'                                                       ||'' 23:59'',',
'                                               ''dd/mm/rrrr hh24:mi''',
'                                                      )',
'       AND tra_transaccion = fca_tra_transaccion',
'       AND INSTR ('':'' || :P51_EMPRESA || '':'', '':'' || fca_emp_empresa || '':'') > 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P51_EMPRESA'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14167890723755902348)
,p_name=>'Comisiones'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'CANDERSON'
,p_internal_uid=>10776830344403048
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167890905497902371)
,p_db_column_name=>'EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167891006268902379)
,p_db_column_name=>'FECHA_COBRO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fecha Cobro'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA_COBRO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167891121093902380)
,p_db_column_name=>'ARTICULO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
,p_static_id=>'ARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167891224642902380)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167891497436902381)
,p_db_column_name=>'FAMILIA'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
,p_static_id=>'FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167891808330902382)
,p_db_column_name=>'MONTO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'MONTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167896321278023348)
,p_db_column_name=>'COD_COBRADOR'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Cod Cobrador'
,p_column_type=>'STRING'
,p_static_id=>'COD_COBRADOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167896422528023348)
,p_db_column_name=>'COBRADOR'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Cobrador'
,p_column_type=>'STRING'
,p_static_id=>'COBRADOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167896493625023349)
,p_db_column_name=>'DESC_FAMILIA'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Desc Familia'
,p_column_type=>'STRING'
,p_static_id=>'DESC_FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167896596093023349)
,p_db_column_name=>'TIPO_ARTICULO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Tipo Articulo'
,p_column_type=>'STRING'
,p_static_id=>'TIPO_ARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167896716197023349)
,p_db_column_name=>'TRANSACCION_FAC'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Transaccion Fac'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TRANSACCION_FAC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168062409230069083)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CODIGO_CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168062503662069094)
,p_db_column_name=>'MONEDA'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168062599799069096)
,p_db_column_name=>'CLIENTE'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168078414179179536)
,p_db_column_name=>'VENDEDOR'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'VENDEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168078521525179550)
,p_db_column_name=>'FACTURA'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'FACTURA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168078595275179551)
,p_db_column_name=>'RECIBO'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Recibo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'RECIBO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168213012953514974)
,p_db_column_name=>'VALOR_CAMBIO'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Valor Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'VALOR_CAMBIO'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14167892002279902657)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'107782'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:FECHA_COBRO:ARTICULO:DESCRIPCION:MONTO:COD_COBRADOR:COBRADOR:DESC_FAMILIA:TIPO_ARTICULO:TRANSACCION_FAC:CLIENTE:VENDEDOR:FACTURA:RECIBO:VALOR_CAMBIO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168167195310624810)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14167894498610986806)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167894895631986816)
,p_name=>'P51_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14167894498610986806)
,p_prompt=>'Inicio'
,p_source=>'SELECT SYSDATE FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167895101516986816)
,p_name=>'P51_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14167894498610986806)
,p_prompt=>'Fin'
,p_source=>'SELECT SYSDATE FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167895316130986817)
,p_name=>'P51_EMPRESA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14167894498610986806)
,p_item_default=>'NULL'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14167908608231484364)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ejecutar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'fac_comision_articulo_pr_nx (:P51_EMPRESA,to_date(:P51_INICIO,''DD/MM/RRRR''),to_date(:P51_FIN,''DD/MM/RRRR''));',
'commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error.'
,p_process_when_button_id=>wwv_flow_api.id(14168167195310624810)
,p_process_when_type=>'NEVER'
,p_process_success_message=>'Done.'
);
wwv_flow_api.component_end;
end;
/
