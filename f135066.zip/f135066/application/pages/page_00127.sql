prompt --application/pages/page_00127
begin
--   Manifest
--     PAGE: 00127
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>127
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GAC-Informe de cursos por profesor'
,p_step_title=>'Informe de cursos por profesor'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14120084089994907855)
,p_plug_name=>'Informe de cursos por profesor'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14120082109512907758)
,p_plug_name=>'Informe de cursos por profesor'
,p_region_name=>'Antiguedad de Saldos'
,p_parent_plug_id=>wwv_flow_api.id(14120084089994907855)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 25/09/2017 03:35:13 p.m. (QP5 v5.115.810.9015) */',
'  SELECT   GAP_PERSONA AS ID_Persona,',
'           RAZON_SOCIAL AS Nombre_Persona,',
'           GNL_PERSONA_TR_NX.PFE_PROFESION AS Profesion,',
'           DECODE (TIPO_DOCUMENTO,',
'                   1,',
'                   ''Identificacion Tributaria'',',
'                   2,',
'                   ''Cedula de Cuidadania'',',
'                   3,',
'                   ''Cedula de Residencia'',',
'                   4,',
'                   ''Tarjeta de Identidad'',',
'                   5,',
'                   ''Registro Unico Contribuyentes'',',
'                   6,',
'                   ''Pasaporte'',',
'                   7,',
'                   ''Cedula de Identidad'',',
'                   8,',
'                   ''Registro Federal de Causantes'')',
'              AS Tipo_Documento,',
'           GNL_PERSONA_TR_NX.DOCUMENTO AS Documento,',
'           DECODE (PER_GRD_GRADO_ACADEMICO,',
'                   1,',
'                   ''PRIMARIA'',',
'                   2,',
'                   ''SECUNDARIA'',',
'                   3,',
'                   ''DIPLOMADO'',',
'                   4,',
'                   ''BACHILLERATO'',',
'                   5,',
'                   ''BACHILLERATO INCOMPLETO'',',
'                   6,',
'                   ''LICENCIATURA'',',
'                   7,',
'                   ''LICENCIATURA INCOMPLETA'',',
'                   8,',
'                   ''MAESTRIA'',',
'                   9,',
'                   ''MAESTRIA INCOMPLETA'',',
'                   10,',
'                   ''DOCTORADO'',',
'                   11,',
'                   ''DOCTORADO INCOMPLETO'',',
'                   12,',
'                   ''ESPECIALIDAD'',',
'                   NULL,',
'                   ''N/A'')',
'              AS Grado_Academico,',
'           DAP_OAC_LCN_LOCALIZACION AS Sede,',
'           DAP_OAC_SLO_SEGMENTO AS Decanatura,',
'           DAP_OAC_ULA_SLO_SEGMENTO AS Programa,',
'           DAP_OAC_ULA_ANTIGUEDAD AS Generacion,',
'           DAP_DOA_ATO_ARTICULO AS Materia,',
'           DAP_ESTADO AS Estado',
'    FROM   GAC_ADMI_PROFESORES_TB_NX,',
'           GNL_PERSONA_TR_NX,',
'           GNL_PROFESION_TB_NX,',
'           GAC_DET_ADMI_PROFESORES_TB_NX',
'   WHERE   INSTR ('':'' || :P127_EMPRESA || '':'', '':'' || DAP_EMP_EMPRESA || '':'') >',
'              0',
'           AND GAP_PERSONA = PERSONA',
'           AND GNL_PERSONA_TR_NX.PFE_PROFESION =',
'                 GNL_PROFESION_TB_NX.PFE_PROFESION',
'           AND GAP_ID = DAP_GAP_ID',
'ORDER BY   GAP_PERSONA',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P127_EMPRESA'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14120082310032907766)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>57062579592691507
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066686009536493392)
,p_db_column_name=>'GENERACION'
,p_display_order=>130
,p_column_identifier=>'DQ'
,p_column_label=>'Generacion'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066810990610758166)
,p_db_column_name=>'ID_PERSONA'
,p_display_order=>140
,p_column_identifier=>'EA'
,p_column_label=>'Id Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811040983758167)
,p_db_column_name=>'NOMBRE_PERSONA'
,p_display_order=>150
,p_column_identifier=>'EB'
,p_column_label=>'Nombre Persona'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811156078758168)
,p_db_column_name=>'PROFESION'
,p_display_order=>160
,p_column_identifier=>'EC'
,p_column_label=>'Profesion'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811340997758170)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>180
,p_column_identifier=>'EE'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811443835758171)
,p_db_column_name=>'GRADO_ACADEMICO'
,p_display_order=>190
,p_column_identifier=>'EF'
,p_column_label=>'Grado Academico'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811540471758172)
,p_db_column_name=>'SEDE'
,p_display_order=>200
,p_column_identifier=>'EG'
,p_column_label=>'Sede'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811727698758173)
,p_db_column_name=>'DECANATURA'
,p_display_order=>210
,p_column_identifier=>'EH'
,p_column_label=>'Decanatura'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811740354758174)
,p_db_column_name=>'PROGRAMA'
,p_display_order=>220
,p_column_identifier=>'EI'
,p_column_label=>'Programa'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811916427758175)
,p_db_column_name=>'MATERIA'
,p_display_order=>230
,p_column_identifier=>'EJ'
,p_column_label=>'Materia'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066811972161758176)
,p_db_column_name=>'ESTADO'
,p_display_order=>240
,p_column_identifier=>'EK'
,p_column_label=>unistr('Condici\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067158158967098282)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>250
,p_column_identifier=>'EL'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14120083885788907839)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'36596'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ID_PERSONA:NOMBRE_PERSONA:PROFESION:TIPO_DOCUMENTO:DOCUMENTO:GRADO_ACADEMICO:SEDE:DECANATURA:PROGRAMA:GENERACION:MATERIA:ESTADO:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14066680456063697316)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14120084089994907855)
,p_button_name=>'P127_CONSULTAR'
,p_button_static_id=>'65_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066680892996697325)
,p_name=>'P127_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14120084089994907855)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'   order by EMPRESA',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
