prompt --application/pages/page_00137
begin
--   Manifest
--     PAGE: 00137
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>137
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'COM - Transito de Inventario'
,p_step_title=>'COM - Transito de Inventario'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165418'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14119362294093813840)
,p_plug_name=>'Transito Inventario'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14002685507606081590)
,p_plug_name=>'Detalle Itemizado'
,p_parent_plug_id=>wwv_flow_api.id(14119362294093813840)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT c001 empresa,',
'       c002 orden,',
'       c003 fecha,',
'       c004 orden_interna,',
'       c005 proveedor,',
'       c006 tdocumento,',
'       c007 documento,',
'       c008 tipo,',
'       c009 estado,',
'       c010 esquema,',
'       c011 categoria,',
'       c012 actividad,',
'       c013 departamento,',
'       c014 dor_linea,',
'       c015 articulo,',
'       c016 descripcion,',
'       c017 marca,',
'       c018 modelo,',
'       c019 familia,',
'       c020 serial,',
'       to_number(c021) cantidad,',
'       to_number(c022) costo,',
'       to_number(c023) costo_alt,',
'       c024 despacho,',
'       c025 ddf_linea,',
'       to_number(c026) cant_entrega,',
'       to_number(c027) costo_entrega,',
'       to_number(c028) costo_ent_alt,',
'       to_number(c029) costo_entrega_total',
'FROM   apex_collections',
'WHERE  collection_name = ''F_MBACASE5_P137''',
'ORDER  BY c001,',
'          c002,',
'          c014;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P137_EMPRESA IS NOT NULL AND :P137_TIPO = ''I'''
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14002685609655081591)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>37575904078537546
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14003605976187811871)
,p_name=>'Orden'
,p_display_sequence=>10
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14003606044617811872)
,p_name=>'Detalle'
,p_display_sequence=>20
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14003606139804811873)
,p_name=>'Item'
,p_display_sequence=>30
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14003606261795811874)
,p_name=>'Pedido'
,p_display_sequence=>40
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14003606388619811875)
,p_name=>'Entregado'
,p_display_sequence=>50
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002685739216081592)
,p_db_column_name=>'EMPRESA'
,p_display_order=>10
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002685883709081593)
,p_db_column_name=>'ORDEN'
,p_display_order=>20
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'B'
,p_column_label=>'Orden'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002685982072081594)
,p_db_column_name=>'FECHA'
,p_display_order=>30
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'C'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002686090701081595)
,p_db_column_name=>'ORDEN_INTERNA'
,p_display_order=>40
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'D'
,p_column_label=>'Orden interna'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003603435190811846)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>50
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003603601727811847)
,p_db_column_name=>'TDOCUMENTO'
,p_display_order=>60
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'F'
,p_column_label=>'Tdocumento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003603689841811848)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>70
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'G'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003603746938811849)
,p_db_column_name=>'TIPO'
,p_display_order=>80
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'H'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003603812054811850)
,p_db_column_name=>'ESTADO'
,p_display_order=>90
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'I'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604004034811851)
,p_db_column_name=>'ESQUEMA'
,p_display_order=>100
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'J'
,p_column_label=>'Esquema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604048698811852)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>110
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'K'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604136844811853)
,p_db_column_name=>'ACTIVIDAD'
,p_display_order=>120
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'L'
,p_column_label=>'Actividad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604246086811854)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>130
,p_group_id=>wwv_flow_api.id(14003605976187811871)
,p_column_identifier=>'M'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604314956811855)
,p_db_column_name=>'DOR_LINEA'
,p_display_order=>140
,p_group_id=>wwv_flow_api.id(14003606044617811872)
,p_column_identifier=>'N'
,p_column_label=>'Linea Orden'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604456379811856)
,p_db_column_name=>'ARTICULO'
,p_display_order=>150
,p_group_id=>wwv_flow_api.id(14003606044617811872)
,p_column_identifier=>'O'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604543942811857)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>160
,p_group_id=>wwv_flow_api.id(14003606044617811872)
,p_column_identifier=>'P'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604698798811858)
,p_db_column_name=>'MARCA'
,p_display_order=>170
,p_group_id=>wwv_flow_api.id(14003606044617811872)
,p_column_identifier=>'Q'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604760861811859)
,p_db_column_name=>'MODELO'
,p_display_order=>180
,p_group_id=>wwv_flow_api.id(14003606044617811872)
,p_column_identifier=>'R'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604812612811860)
,p_db_column_name=>'FAMILIA'
,p_display_order=>190
,p_group_id=>wwv_flow_api.id(14003606044617811872)
,p_column_identifier=>'S'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003604943092811861)
,p_db_column_name=>'SERIAL'
,p_display_order=>200
,p_group_id=>wwv_flow_api.id(14003606139804811873)
,p_column_identifier=>'T'
,p_column_label=>'Serial'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003607156438811883)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>210
,p_group_id=>wwv_flow_api.id(14003606261795811874)
,p_column_identifier=>'AD'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003607221319811884)
,p_db_column_name=>'COSTO'
,p_display_order=>220
,p_group_id=>wwv_flow_api.id(14003606261795811874)
,p_column_identifier=>'AE'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003607329079811885)
,p_db_column_name=>'COSTO_ALT'
,p_display_order=>230
,p_group_id=>wwv_flow_api.id(14003606261795811874)
,p_column_identifier=>'AF'
,p_column_label=>'Costo Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003605387684811865)
,p_db_column_name=>'DESPACHO'
,p_display_order=>240
,p_group_id=>wwv_flow_api.id(14003606261795811874)
,p_column_identifier=>'X'
,p_column_label=>'Despacho'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003605430300811866)
,p_db_column_name=>'DDF_LINEA'
,p_display_order=>250
,p_group_id=>wwv_flow_api.id(14003606261795811874)
,p_column_identifier=>'Y'
,p_column_label=>'Linea Despacho'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003607434352811886)
,p_db_column_name=>'CANT_ENTREGA'
,p_display_order=>260
,p_group_id=>wwv_flow_api.id(14003606388619811875)
,p_column_identifier=>'AG'
,p_column_label=>'Cant. Entregada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003607527824811887)
,p_db_column_name=>'COSTO_ENTREGA'
,p_display_order=>270
,p_group_id=>wwv_flow_api.id(14003606388619811875)
,p_column_identifier=>'AH'
,p_column_label=>'Costo Entregado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003607676180811888)
,p_db_column_name=>'COSTO_ENT_ALT'
,p_display_order=>280
,p_group_id=>wwv_flow_api.id(14003606388619811875)
,p_column_identifier=>'AI'
,p_column_label=>'Costo Entregado Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003607749664811889)
,p_db_column_name=>'COSTO_ENTREGA_TOTAL'
,p_display_order=>290
,p_group_id=>wwv_flow_api.id(14003606388619811875)
,p_column_identifier=>'AJ'
,p_column_label=>'Costo Entregado Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14003619089101827289)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'385094'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>'EMPRESA:ORDEN:FECHA:ORDEN_INTERNA:PROVEEDOR:TDOCUMENTO:DOCUMENTO:TIPO:ESTADO:ESQUEMA:CATEGORIA:ACTIVIDAD:DEPARTAMENTO:DOR_LINEA:ARTICULO:DESCRIPCION:MARCA:MODELO:FAMILIA:SERIAL:CANTIDAD:COSTO:COSTO_ALT:DESPACHO:DDF_LINEA:CANT_ENTREGA:COSTO_ENTREGA:CO'
||'STO_ENT_ALT:COSTO_ENTREGA_TOTAL:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14119364589538813905)
,p_plug_name=>'Detalle Estandar'
,p_parent_plug_id=>wwv_flow_api.id(14119362294093813840)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT c001 empresa,',
'       c002 orden,',
'       c003 fecha,',
'       c004 orden_interna,',
'       c005 proveedor,',
'       c006 tdocumento,',
'       c007 documento,',
'       c008 tipo,',
'       c009 estado,',
'       c010 esquema,',
'       c011 categoria,',
'       c012 actividad,',
'       c013 departamento,',
'       c014 dor_linea,',
'       c015 articulo,',
'       c016 descripcion,',
'       c017 marca,',
'       c018 modelo,',
'       c019 familia,',
'       to_number(c020) cantidad,',
'       to_number(c021) costo,',
'       to_number(c022) costo_alt,',
'       c023 despacho,',
'       c024 ddf_linea,',
'       to_number(c025) cant_entrega,',
'       to_number(c026) costo_entrega,',
'       to_number(c027) costo_ent_alt,',
'       to_number(c028) costo_entrega_total',
'FROM   apex_collections',
'WHERE  collection_name = ''F_MBACASE5_P137''',
'ORDER  BY c001,',
'          c002,',
'          c014;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P137_EMPRESA IS NOT NULL AND :P137_TIPO = ''E'''
,p_plug_display_when_cond2=>'PLSQL'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14119365047302813911)
,p_name=>'Compras'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>56345316862597652
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14002685141869081586)
,p_name=>'Orden'
,p_display_sequence=>10
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14002685300531081587)
,p_name=>'Detalle'
,p_display_sequence=>20
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14002685068665081585)
,p_name=>'Pedido'
,p_display_sequence=>30
);
wwv_flow_api.create_worksheet_col_group(
 p_id=>wwv_flow_api.id(14002685352620081588)
,p_name=>'Entregado'
,p_display_sequence=>40
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087233165107160879)
,p_db_column_name=>'EMPRESA'
,p_display_order=>130
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'DJ'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14048921506472972857)
,p_db_column_name=>'ORDEN'
,p_display_order=>140
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'DV'
,p_column_label=>'Orden'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14048921788400972860)
,p_db_column_name=>'FECHA'
,p_display_order=>150
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'DY'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
,p_format_mask=>'DD/MM/RRRR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002682765486081562)
,p_db_column_name=>'ORDEN_INTERNA'
,p_display_order=>160
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'EO'
,p_column_label=>'Orden interna'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049382992240895019)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>180
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'EH'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002682892007081563)
,p_db_column_name=>'TDOCUMENTO'
,p_display_order=>190
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'EP'
,p_column_label=>'Tdocumento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002682912711081564)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>200
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'EQ'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683010502081565)
,p_db_column_name=>'TIPO'
,p_display_order=>210
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'ER'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683138130081566)
,p_db_column_name=>'ESTADO'
,p_display_order=>220
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'ES'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683281152081567)
,p_db_column_name=>'ESQUEMA'
,p_display_order=>230
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'ET'
,p_column_label=>'Esquema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683321405081568)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>240
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'EU'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683468421081569)
,p_db_column_name=>'ACTIVIDAD'
,p_display_order=>250
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'EV'
,p_column_label=>'Actividad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683516962081570)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>260
,p_group_id=>wwv_flow_api.id(14002685141869081586)
,p_column_identifier=>'EW'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683627715081571)
,p_db_column_name=>'DOR_LINEA'
,p_display_order=>270
,p_group_id=>wwv_flow_api.id(14002685300531081587)
,p_column_identifier=>'EX'
,p_column_label=>'Linea Orden'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087233391938160881)
,p_db_column_name=>'ARTICULO'
,p_display_order=>280
,p_group_id=>wwv_flow_api.id(14002685300531081587)
,p_column_identifier=>'DL'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683787628081572)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>290
,p_group_id=>wwv_flow_api.id(14002685300531081587)
,p_column_identifier=>'EY'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683880381081573)
,p_db_column_name=>'MARCA'
,p_display_order=>300
,p_group_id=>wwv_flow_api.id(14002685300531081587)
,p_column_identifier=>'EZ'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002683997567081574)
,p_db_column_name=>'MODELO'
,p_display_order=>310
,p_group_id=>wwv_flow_api.id(14002685300531081587)
,p_column_identifier=>'FA'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002684029481081575)
,p_db_column_name=>'FAMILIA'
,p_display_order=>320
,p_group_id=>wwv_flow_api.id(14002685300531081587)
,p_column_identifier=>'FB'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003606485493811876)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>330
,p_group_id=>wwv_flow_api.id(14002685068665081585)
,p_column_identifier=>'FL'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003606531536811877)
,p_db_column_name=>'COSTO'
,p_display_order=>340
,p_group_id=>wwv_flow_api.id(14002685068665081585)
,p_column_identifier=>'FM'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003606645135811878)
,p_db_column_name=>'COSTO_ALT'
,p_display_order=>350
,p_group_id=>wwv_flow_api.id(14002685068665081585)
,p_column_identifier=>'FN'
,p_column_label=>'Costo Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002684440134081579)
,p_db_column_name=>'DESPACHO'
,p_display_order=>360
,p_group_id=>wwv_flow_api.id(14002685068665081585)
,p_column_identifier=>'FF'
,p_column_label=>'Despacho'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14002684522015081580)
,p_db_column_name=>'DDF_LINEA'
,p_display_order=>370
,p_group_id=>wwv_flow_api.id(14002685068665081585)
,p_column_identifier=>'FG'
,p_column_label=>'Linea Despacho'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003606759521811879)
,p_db_column_name=>'CANT_ENTREGA'
,p_display_order=>380
,p_group_id=>wwv_flow_api.id(14002685352620081588)
,p_column_identifier=>'FO'
,p_column_label=>'Cant. Entregada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003606853628811880)
,p_db_column_name=>'COSTO_ENTREGA'
,p_display_order=>390
,p_group_id=>wwv_flow_api.id(14002685352620081588)
,p_column_identifier=>'FP'
,p_column_label=>'Costo Entregado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003606994580811881)
,p_db_column_name=>'COSTO_ENT_ALT'
,p_display_order=>400
,p_group_id=>wwv_flow_api.id(14002685352620081588)
,p_column_identifier=>'FQ'
,p_column_label=>'Costo Entregado Alt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003607081600811882)
,p_db_column_name=>'COSTO_ENTREGA_TOTAL'
,p_display_order=>410
,p_group_id=>wwv_flow_api.id(14002685352620081588)
,p_column_identifier=>'FR'
,p_column_label=>'Costo Entregado Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14119370234281813988)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'247298'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_view_mode=>'REPORT'
,p_report_columns=>'EMPRESA:ORDEN:FECHA:ORDEN_INTERNA:PROVEEDOR:TDOCUMENTO:DOCUMENTO:TIPO:ESTADO:ESQUEMA:CATEGORIA:ACTIVIDAD:DEPARTAMENTO:DOR_LINEA:ARTICULO:DESCRIPCION:MARCA:MODELO:FAMILIA:CANTIDAD:COSTO:COSTO_ALT:DESPACHO:DDF_LINEA:CANT_ENTREGA:COSTO_ENTREGA:COSTO_ENT'
||'_ALT:COSTO_ENTREGA_TOTAL:'
,p_sum_columns_on_break=>'CED_SUBTOTAL:CED_DESCUENTO:CED_IMPUESTO:CED_OTROS_IMPUESTOS:CED_TOTAL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14087737331749044021)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14119362294093813840)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14002682695726081561)
,p_name=>'P137_TIPO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14119362294093813840)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Estandar;E,Itemizado;I'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14087737819506044031)
,p_name=>'P137_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14119362294093813840)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14087738230100044047)
,p_name=>'P137_INICIO'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14119362294093813840)
,p_prompt=>'Inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'RETURN TRUNC (SYSDATE, ''MM'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14087738607717044047)
,p_name=>'P137_FIN'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14119362294093813840)
,p_prompt=>'Fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'SYSDATE'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14048921356849972856)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'estandar_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' DECLARE',
'    --Orden',
'    CURSOR c_ord IS',
'      SELECT ord_emp_empresa   empresa,',
'             ord_orden         orden,',
'             ord_fecha         fecha,',
'             ord_orden_interna orden_interna,',
'             ( Cxp_nombre_prov_v_nx(ord_emp_empresa, ord_pro_proveedor,',
'               ord_pro_mon_moneda)',
'               ||'' (''',
'               ||ord_pro_mon_moneda',
'               ||''-''',
'               ||ord_pro_proveedor',
'               ||'')'' )         proveedor,',
'             ord_doc_documento documento,',
'             ord_documento     tdocumento,',
'             ord_tipo          tipo,',
'             ord_status        estado,',
'             ( cec_descripcion',
'               ||'' (''',
'               ||ord_cec_esquema',
'               ||'')'' )         esquema,',
'             ord_cat_categoria categoria,',
'             ord_atv_actividad actividad,',
'             ( Fac_nombre_depto_v_nx(ord_dep_emp_empresa, ord_dep_departamento)',
'               ||'' (''',
'               ||ord_dep_departamento',
'               ||'')'' )         departamento',
'      FROM   com_orden_tb_nx,',
'             com_esquema_importacion_tb_nx',
'      WHERE  ord_tipo_orden = ''I''',
'             AND ord_status <> ''CRE''',
'             AND INSTR ('':'' || :P137_EMPRESA || '':'', '':'' || ord_emp_empresa || '':'') > 0',
'             AND (ord_fecha BETWEEN :P137_INICIO',
'             AND TO_DATE (:P137_FIN || '' 23:59'', ''dd/mm/rrrr hh24:mi''))',
'             AND ord_cec_emp_empresa = cec_emp_empresa',
'             AND ord_cec_esquema = cec_esquema',
'      ORDER  BY ord_emp_empresa;',
'    --Detalle',
'    CURSOR c_dor(',
'      empresa_c IN VARCHAR2,',
'      orden_c   IN VARCHAR2) IS',
'      SELECT dor_linea,',
'             dor_ato_articulo articulo,',
'             dor_descripcion  descripcion,',
'             ddf_cantidad     cantidad,',
'             ddf_dpc_despacho despacho,',
'             ddf_linea,',
'             ( Inv_descrip_marca_v_nx(ato_emp_empresa, ato_mar_marca)',
'               ||'' (''',
'               ||ato_mar_marca',
'               ||'')'' )        marca,',
'             ( Inv_descrip_modelo_v_nx(ato_mod_emp_empresa, ato_mod_modelo)',
'               ||'' (''',
'               ||ato_mod_modelo',
'               ||'')'' )        modelo,',
'             ( Inv_descrip_fam_v_nx(ato_emp_empresa, ato_fma_familia)',
'               ||'' (''',
'               ||ato_fma_familia',
'               ||'')'' )        familia',
'      FROM   com_detalle_orden_tb_nx,',
'             com_det_despacho_tb_nx,',
'             inv_articulo_tb_nx',
'      WHERE  dor_ord_emp_empresa = empresa_c',
'             AND dor_ord_orden = orden_c',
'             AND dor_ord_emp_empresa = ddf_dor_ord_emp_empresa',
'             AND dor_ord_orden = ddf_dor_ord_orden',
'             AND dor_linea = ddf_dor_linea',
'             AND dor_ord_emp_empresa = ato_emp_empresa',
'             AND dor_ato_articulo = ato_articulo',
'             AND dor_status = ''CR''',
'             AND ato_itemizado = ''N'';',
'    --Costo',
'    CURSOR c_ded(',
'      despacho_c  IN NUMBER,',
'      ddf_linea_c IN NUMBER) IS',
'      SELECT SUM(ded_costo_unitario * ded_cantidad_etapa) costo,',
'             ced_pro_mon_moneda                           moneda',
'      FROM   com_etapa_despacho_tb_nx,',
'             com_det_etapa_despacho_tb_nx,',
'             com_tipo_etapa_tb_nx',
'      WHERE  ced_etapa = ded_ced_etapa',
'             AND (ced_fecha BETWEEN :P137_INICIO',
'             AND TO_DATE (:P137_FIN || '' 23:59'', ''dd/mm/rrrr hh24:mi''))      ',
'             AND ded_dpc_despacho = despacho_c',
'             AND ded_ddf_linea = ddf_linea_c',
'             AND ded_emp_empresa = tet_emp_empresa',
'             AND ded_tet_tipo = tet_tipo',
'             AND tet_accion = ''F''',
'             AND ced_status <> ''C''',
'      GROUP  BY ced_pro_mon_moneda;',
'    --Entregado',
'    CURSOR c_rec(',
'      despacho_c  IN NUMBER,',
'      ddf_linea_c IN NUMBER) IS',
'      SELECT SUM(deg_cantidad_recibida),',
'             SUM(deg_costo * deg_cantidad_recibida)',
'      FROM   com_entrega_tb_nx,',
'             com_det_entrega_tb_nx',
'      WHERE  ent_entrega = deg_ent_entrega',
'             AND (ent_fecha BETWEEN :P137_INICIO',
'             AND TO_DATE (:P137_FIN || '' 23:59'', ''dd/mm/rrrr hh24:mi''))      ',
'             AND deg_ddf_dpc_despacho = despacho_c',
'             AND deg_ddf_linea = ddf_linea_c;',
'    CURSOR c_deg(',
'      despacho_c  IN NUMBER,',
'      ddf_linea_c IN NUMBER) IS',
'      SELECT SUM(epf_costo * epf_cantidad)     costo,',
'             SUM(epf_costo_alt * epf_cantidad) costo_alt,',
'             b.ded_moneda_proveedor            moneda',
'      FROM   com_entrega_tb_nx,',
'             com_det_entrega_tb_nx,',
'             com_etapa_despacho_tb_nx,',
'             com_det_etapa_despacho_tb_nx a,',
'             com_det_etapa_despacho_tb_nx b,',
'             com_det_etapa_tarifa_tb_nx',
'      WHERE  ent_entrega = deg_ent_entrega',
'             AND (ent_fecha BETWEEN :P137_INICIO',
'             AND TO_DATE (:P137_FIN || '' 23:59'', ''dd/mm/rrrr hh24:mi''))      ',
'             AND deg_ddf_dpc_despacho = despacho_c',
'             AND deg_ddf_linea = ddf_linea_c',
'             AND a.ded_dpc_despacho = b.ded_dpc_despacho',
'             AND a.ded_ddf_linea = b.ded_ddf_linea',
'             AND a.ded_particion = b.ded_particion',
'             AND a.ded_ced_etapa = ced_etapa',
'             AND deg_ddf_dpc_despacho = b.ded_dpc_despacho',
'             AND deg_ddf_linea = b.ded_ddf_linea',
'             AND epf_ded_id = b.ded_id',
'             AND epf_particion = b.ded_particion',
'             AND deg_ded_id = a.ded_id',
'             AND ced_manejo_etapa = ''E''',
'      GROUP  BY b.ded_moneda_proveedor;',
'    empresa_v       gnl_empresa_tr_nx.empresa%TYPE := ''.'';',
'    mon_base_v      gnl_moneda_tr_nx.moneda%TYPE;',
'    mon_conv_v      gnl_moneda_tr_nx.moneda%TYPE;',
'    costo_v         com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'    costo_alt_v     com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'    cantidad_ent_v  com_det_despacho_tb_nx.ddf_cantidad%TYPE;',
'    costo_ent_v     com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'    costo_ent_alt_v com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'    costo_ent_tot_v com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'BEGIN',
'    apex_collection.Create_or_truncate_collection (''F_MBACASE5_P137'');',
'',
'    FOR ord IN c_ord LOOP',
'        IF ord.empresa <> empresa_v THEN',
'          empresa_v := ord.empresa;',
'',
'          mon_base_v := Gnl_parametro_emp_v_nx(empresa_v, ''CGL'', ''MONEDA'');',
'',
'          IF ( mon_base_v IS NULL ) THEN',
'            gnx.Err(''GNL-23000'', ''CGL - MONEDA'');',
'          END IF;',
'',
'          mon_conv_v := Gnl_parametro_emp_v_nx(empresa_v, ''GNL'',',
'                        ''MONEDA CONVERSION''',
'                        );',
'',
'          IF ( mon_conv_v IS NULL ) THEN',
'            gnx.Err(''GNL-23000'', ''GNL - MONEDA CONVERSION'');',
'          END IF;',
'        END IF;',
'',
'        FOR dor IN c_dor(ord.empresa, ord.orden)LOOP',
'            costo_v := 0;',
'',
'            costo_alt_v := 0;',
'',
'            costo_ent_v := 0;',
'',
'            costo_ent_alt_v := 0;',
'',
'            cantidad_ent_v := 0;',
'',
'            FOR ded IN c_ded(dor.despacho, dor.ddf_linea)LOOP',
'                IF ded.moneda = mon_base_v THEN',
'                  costo_v := costo_v + ded.costo;',
'                ELSE',
'                  costo_alt_v := costo_alt_v + ded.costo;',
'                END IF;',
'            END LOOP;',
'',
'            FOR deg IN c_deg(dor.despacho, dor.ddf_linea)LOOP',
'                IF deg.moneda = mon_base_v THEN',
'                  costo_ent_v := costo_ent_v + deg.costo;',
'                ELSE',
'                  costo_ent_alt_v := costo_ent_alt_v + deg.costo_alt;',
'                END IF;',
'            END LOOP;',
'',
'            OPEN c_rec(dor.despacho, dor.ddf_linea);',
'',
'            FETCH c_rec INTO cantidad_ent_v, costo_ent_tot_v;',
'',
'            CLOSE c_rec;',
'',
'            cantidad_ent_v := Nvl(cantidad_ent_v, 0);',
'',
'            costo_ent_tot_v := Nvl(costo_ent_tot_v, 0);',
'',
'            IF cantidad_ent_v = 0 THEN',
'              costo_ent_v := 0;',
'',
'              costo_ent_alt_v := 0;',
'            END IF;',
'',
'            IF dor.cantidad > cantidad_ent_v',
'               AND ( costo_v > 0',
'                      OR costo_alt_v > 0 ) THEN',
'              apex_collection.Add_member (''F_MBACASE5_P137'', ord.empresa, ord.orden,',
'              ord.fecha,',
'              ord.orden_interna, ord.proveedor, ord.documento, ord.tdocumento,',
'              ord.tipo,',
'              ord.estado,',
'              ord.esquema, ord.categoria, ord.actividad, ord.departamento,',
'              dor.dor_linea,',
'              dor.articulo, dor.descripcion, dor.marca, dor.modelo, dor.familia,',
'              dor.cantidad,',
'              costo_v,',
'              costo_alt_v, dor.despacho, dor.ddf_linea, cantidad_ent_v,',
'              costo_ent_v,',
'              costo_ent_alt_v, costo_ent_tot_v);',
'            END IF;',
'        END LOOP; --dor',
'    END LOOP; --ord',
'END;  '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14087737331749044021)
,p_process_when=>'P137_TIPO'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'E'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14002685444188081589)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'itemizado_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' DECLARE',
'    --Orden',
'    CURSOR c_ord IS',
'      SELECT ord_emp_empresa   empresa,',
'             ord_orden         orden,',
'             ord_fecha         fecha,',
'             ord_orden_interna orden_interna,',
'             ( Cxp_nombre_prov_v_nx(ord_emp_empresa, ord_pro_proveedor,',
'               ord_pro_mon_moneda)',
'               ||'' (''',
'               ||ord_pro_mon_moneda',
'               ||''-''',
'               ||ord_pro_proveedor',
'               ||'')'' )         proveedor,',
'             ord_doc_documento documento,',
'             ord_documento     tdocumento,',
'             ord_tipo          tipo,',
'             ord_status        estado,',
'             ( cec_descripcion',
'               ||'' (''',
'               ||ord_cec_esquema',
'               ||'')'' )         esquema,',
'             ord_cat_categoria categoria,',
'             ord_atv_actividad actividad,',
'             ( Fac_nombre_depto_v_nx(ord_dep_emp_empresa, ord_dep_departamento)',
'               ||'' (''',
'               ||ord_dep_departamento',
'               ||'')'' )         departamento',
'      FROM   com_orden_tb_nx,',
'             com_esquema_importacion_tb_nx',
'      WHERE  ord_tipo_orden = ''I''',
'             AND ord_status <> ''CRE''',
'             AND INSTR ('':'' || :P137_EMPRESA || '':'', '':'' || ord_emp_empresa || '':'') > 0',
'             AND (ord_fecha BETWEEN :P137_INICIO',
'             AND  TO_DATE (:P137_FIN || '' 23:59'', ''dd/mm/rrrr hh24:mi''))',
'             AND ord_cec_emp_empresa = cec_emp_empresa',
'             AND ord_cec_esquema = cec_esquema',
'      ORDER  BY ord_emp_empresa;',
'    --Detalle',
'    CURSOR c_dor(',
'      empresa_c IN VARCHAR2,',
'      orden_c   IN VARCHAR2) IS',
'      SELECT dor_linea,',
'             dor_ato_articulo articulo,',
'             dor_descripcion  descripcion,',
'             doi_cantidad     cantidad,',
'             ddf_dpc_despacho despacho,',
'             ddf_linea,',
'             ( Inv_descrip_marca_v_nx(ato_emp_empresa, ato_mar_marca)',
'               ||'' (''',
'               ||ato_mar_marca',
'               ||'')'' )        marca,',
'             ( Inv_descrip_modelo_v_nx(ato_mod_emp_empresa, ato_mod_modelo)',
'               ||'' (''',
'               ||ato_mod_modelo',
'               ||'')'' )        modelo,',
'             ( Inv_descrip_fam_v_nx(ato_emp_empresa, ato_fma_familia)',
'               ||'' (''',
'               ||ato_fma_familia',
'               ||'')'' )        familia,',
'             doi_id,',
'             doi_serial       serial',
'      FROM   com_detalle_orden_tb_nx,',
'             com_det_despacho_tb_nx,',
'             inv_articulo_tb_nx,',
'             com_item_tb_nx',
'      WHERE  dor_ord_emp_empresa = empresa_c',
'             AND dor_ord_orden = orden_c',
'             AND dor_ord_emp_empresa = ddf_dor_ord_emp_empresa',
'             AND dor_ord_orden = ddf_dor_ord_orden',
'             AND dor_linea = ddf_dor_linea',
'             AND dor_ord_emp_empresa = ato_emp_empresa',
'             AND dor_ato_articulo = ato_articulo',
'             AND dor_status = ''CR''',
'             AND ato_itemizado = ''S''',
'             AND dor_ord_emp_empresa = doi_emp_empresa',
'             AND dor_ord_orden = doi_ord_orden',
'             AND dor_linea = doi_dor_linea;',
'    --Costo',
'    CURSOR c_ded(',
'      despacho_c  IN NUMBER,',
'      ddf_linea_c IN NUMBER,',
'      doi_id_c    IN NUMBER) IS',
'      SELECT SUM(CASE ced_aumenta_costo',
'                   WHEN ''N'' THEN dei_costo *-1',
'                   ELSE dei_costo',
'                 END)     costo,',
'             ced_pro_mon_moneda moneda',
'      FROM   com_etapa_despacho_tb_nx,',
'             com_det_etapa_item_tb_vi,',
'             com_tipo_etapa_tb_nx',
'      WHERE  ced_etapa = dei_ced_etapa',
'             AND (ced_fecha BETWEEN :P137_INICIO',
'             AND  TO_DATE (:P137_FIN || '' 23:59'', ''dd/mm/rrrr hh24:mi''))',
'             AND dei_dpc_despacho = despacho_c',
'             AND dei_ddf_linea = ddf_linea_c',
'             AND dei_emp_empresa = tet_emp_empresa',
'             AND dei_tet_tipo = tet_tipo',
'             AND dei_doi_id = doi_id_c',
'             AND tet_accion = ''F''',
'             AND ced_status <> ''C''',
'      GROUP  BY ced_pro_mon_moneda;',
'    --Entregado',
'    CURSOR c_rec(',
'      despacho_c  IN NUMBER,',
'      ddf_linea_c IN NUMBER,',
'      doi_id_c    IN NUMBER) IS',
'      SELECT SUM(deg_cantidad_recibida),',
'             SUM(deg_costo * deg_cantidad_recibida)',
'      FROM   com_entrega_tb_nx,',
'             com_det_entrega_tb_nx,',
'             com_item_entrega_tb_nx',
'      WHERE  ent_entrega = deg_ent_entrega',
'             AND (ent_fecha BETWEEN :P137_INICIO',
'             AND  TO_DATE (:P137_FIN || '' 23:59'', ''dd/mm/rrrr hh24:mi''))',
'             AND deg_ddf_dpc_despacho = despacho_c',
'             AND deg_ddf_linea = ddf_linea_c',
'             AND deg_ent_entrega = dig_ent_entrega',
'             AND deg_linea = dig_deg_linea',
'             AND dig_doi_id = doi_id_c;',
'    CURSOR c_deg(',
'      despacho_c  IN NUMBER,',
'      ddf_linea_c IN NUMBER,',
'      doi_id_c    IN NUMBER) IS',
'      SELECT SUM(CASE ced_aumenta_costo',
'                   WHEN ''N'' THEN dei_costo *-1',
'                   ELSE dei_costo',
'                 END)           costo,',
'             ced_pro_mon_moneda moneda',
'      FROM   com_entrega_tb_nx,',
'             com_det_entrega_tb_nx,',
'             com_etapa_despacho_tb_nx,',
'             com_det_etapa_item_tb_vi,',
'             com_item_entrega_tb_nx',
'      WHERE  ent_entrega = deg_ent_entrega',
'             AND (ent_fecha BETWEEN :P137_INICIO',
'             AND  TO_DATE (:P137_FIN || '' 23:59'', ''dd/mm/rrrr hh24:mi''))',
'             AND deg_ddf_dpc_despacho = despacho_c',
'             AND deg_ddf_linea = ddf_linea_c',
'             AND dig_doi_id = doi_id_c',
'             AND dei_ced_etapa = ced_etapa',
'             AND deg_ent_entrega = dig_ent_entrega',
'             AND deg_linea = dig_deg_linea',
'             AND dig_doi_id = dei_doi_id',
'      GROUP  BY ced_pro_mon_moneda;',
'    empresa_v       gnl_empresa_tr_nx.empresa%TYPE := ''.'';',
'    mon_base_v      gnl_moneda_tr_nx.moneda%TYPE;',
'    mon_conv_v      gnl_moneda_tr_nx.moneda%TYPE;',
'    costo_v         com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'    costo_alt_v     com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'    cantidad_ent_v  com_det_despacho_tb_nx.ddf_cantidad%TYPE;',
'    costo_ent_v     com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'    costo_ent_alt_v com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'    costo_ent_tot_v com_detalle_orden_tb_nx.dor_costo_fob%TYPE;',
'BEGIN',
'    apex_collection.Create_or_truncate_collection (''F_MBACASE5_P137'');',
'',
'    FOR ord IN c_ord LOOP',
'        IF ord.empresa <> empresa_v THEN',
'          empresa_v := ord.empresa;',
'',
'          mon_base_v := Gnl_parametro_emp_v_nx(empresa_v, ''CGL'', ''MONEDA'');',
'',
'          IF ( mon_base_v IS NULL ) THEN',
'            gnx.Err(''GNL-23000'', ''CGL - MONEDA'');',
'          END IF;',
'',
'          mon_conv_v := Gnl_parametro_emp_v_nx(empresa_v, ''GNL'',',
'                        ''MONEDA CONVERSION''',
'                        );',
'',
'          IF ( mon_conv_v IS NULL ) THEN',
'            gnx.Err(''GNL-23000'', ''GNL - MONEDA CONVERSION'');',
'          END IF;',
'        END IF;',
'',
'        FOR dor IN c_dor(ord.empresa, ord.orden)LOOP',
'            costo_v := 0;',
'',
'            costo_alt_v := 0;',
'',
'            costo_ent_v := 0;',
'',
'            costo_ent_alt_v := 0;',
'',
'            cantidad_ent_v := 0;',
'',
'            FOR ded IN c_ded(dor.despacho, dor.ddf_linea, dor.doi_id)LOOP',
'                IF ded.moneda = mon_base_v THEN',
'                  costo_v := costo_v + ded.costo;',
'                ELSE',
'                  costo_alt_v := costo_alt_v + ded.costo;',
'                END IF;',
'            END LOOP;',
'',
'            FOR deg IN c_deg(dor.despacho, dor.ddf_linea, dor.doi_id)LOOP',
'                IF deg.moneda = mon_base_v THEN',
'                  costo_ent_v := costo_ent_v + deg.costo;',
'                ELSE',
'                  costo_ent_alt_v := costo_ent_alt_v + deg.costo;',
'                END IF;',
'            END LOOP;',
'',
'            OPEN c_rec(dor.despacho, dor.ddf_linea, dor.doi_id);',
'',
'            FETCH c_rec INTO cantidad_ent_v, costo_ent_tot_v;',
'',
'            CLOSE c_rec;',
'',
'            cantidad_ent_v := Nvl(cantidad_ent_v, 0);',
'',
'            costo_ent_tot_v := Nvl(costo_ent_tot_v, 0);',
'',
'            IF cantidad_ent_v = 0 THEN',
'              costo_ent_v := 0;',
'',
'              costo_ent_alt_v := 0;',
'            END IF;',
'',
'            IF dor.cantidad > cantidad_ent_v',
'               AND ( costo_v > 0',
'                      OR costo_alt_v > 0 ) THEN',
'              apex_collection.Add_member (''F_MBACASE5_P137'', ord.empresa, ord.orden,',
'              ord.fecha,',
'              ord.orden_interna, ord.proveedor, ord.documento, ord.tdocumento,',
'              ord.tipo,',
'              ord.estado,',
'              ord.esquema, ord.categoria, ord.actividad, ord.departamento,',
'              dor.dor_linea,',
'              dor.articulo, dor.descripcion, dor.marca, dor.modelo, dor.familia,',
'              dor.serial,',
'              dor.cantidad, costo_v, costo_alt_v, dor.despacho, dor.ddf_linea,',
'              cantidad_ent_v,',
'              costo_ent_v, costo_ent_alt_v, costo_ent_tot_v);',
'            END IF;',
'        END LOOP; --dor',
'    END LOOP; --ord',
'END;  '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14087737331749044021)
,p_process_when=>'P137_TIPO'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'I'
);
null;
wwv_flow_api.component_end;
end;
/
