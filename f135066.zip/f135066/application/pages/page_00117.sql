prompt --application/pages/page_00117
begin
--   Manifest
--     PAGE: 00117
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>117
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'INV - Lista Precio Itemizados'
,p_step_title=>'Lista Precio Itemizados'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14097144555548540473)
,p_plug_name=>'Lista Precio Itemizados'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14097146221924540477)
,p_plug_name=>'Lista Precio Itemizados'
,p_parent_plug_id=>wwv_flow_api.id(14097144555548540473)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 17/01/2017 04:13:50 p.m. (QP5 v5.115.810.9015) */',
'SELECT   lp.LPO_EMP_EMPRESA,',
'         lp.LPO_LISTA,',
'         lp.LPO_DESCRIPCION,',
'         lp.LPO_MON_MONEDA,',
'         lp.LPO_TIP_TIPO_CAMBIO,',
'         lp.LPO_TIPO_LISTA,',
'         DECODE (lp.LPO_TIPO_BASE,',
'                 ''N'',',
'                 ''N/A'',',
'                 ''F'',',
'                 ''FOB'',',
'                 ''C'',',
'                 ''Costo'',',
'                 ''U'',',
'                 ''Ultimo'',',
'                 ''A'',',
'                 ''Adquis'',',
'                 ''B'',',
'                 ''Local'',',
'                 ''L'',',
'                 ''Lista'')',
'            LPO_TIPO_BASE,',
'         DECODE (lp.LPO_TIPO_CALCULO,',
'                 ''N'',',
'                 ''N/A'',',
'                 ''U'',',
'                 ''Up'',',
'                 ''D'',',
'                 ''Down'',',
'                 ''F'',',
'                 ''Fact'')',
'            LPO_TIPO_CALCULO,',
'         lp.LPO_REDONDEO_COMERCIAL,',
'         p.PCO_ATO_ARTICULO,',
'         inv_descrip_art_v_nx (P.PCO_EMP_EMPRESA, p.PCO_ATO_ARTICULO)',
'            DSP_ATO_DESCRIPCION,',
'         p.PCO_PRECIO,',
'         p.PCO_PORCENTAJE,',
'         p.PCO_FACTOR1,',
'         p.PCO_FACTOR2,',
'         p.PCO_FACTOR3,',
'         DECODE (p.PCO_TIPO_BASE,',
'                 ''N'',',
'                 ''N/A'',',
'                 ''F'',',
'                 ''FOB'',',
'                 ''C'',',
'                 ''Costo'',',
'                 ''U'',',
'                 ''Ultimo'',',
'                 ''A'',',
'                 ''Adquis'',',
'                 ''B'',',
'                 ''Local'',',
'                 ''L'',',
'                 ''Lista'')',
'            PCO_TIPO_BASE,',
'         DECODE (p.PCO_TIPO_CALCULO,',
'                 ''N'',',
'                 ''N/A'',',
'                 ''U'',',
'                 ''Up'',',
'                 ''D'',',
'                 ''Down'',',
'                 ''F'',',
'                 ''Fact'')',
'            PCO_TIPO_CALCULO,',
'         p.PCO_GASTOS_INSCRIP,',
'         p.PCO_GASTOS_ADIC',
'  FROM   INV_LISTA_PRECIOS_TB_NX lp, INV_PRECIO_TB_NX p',
' WHERE       INSTR ('':'' || :P117_EMPRESA || '':'',',
'                    '':'' || lp.LPO_EMP_EMPRESA || '':'') > 0',
'         AND lp.LPO_EMP_EMPRESA = P.PCO_EMP_EMPRESA',
'         AND lp.LPO_LISTA = p.PCO_LPO_LISTA'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P117_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14097146577376540479)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>9402852604651385
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097146714900540480)
,p_db_column_name=>'LPO_EMP_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'CR'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097147103587540481)
,p_db_column_name=>'LPO_LISTA'
,p_display_order=>20
,p_column_identifier=>'CS'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097147521263540481)
,p_db_column_name=>'LPO_DESCRIPCION'
,p_display_order=>30
,p_column_identifier=>'CT'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097147879961540483)
,p_db_column_name=>'LPO_MON_MONEDA'
,p_display_order=>40
,p_column_identifier=>'CU'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097148258041540484)
,p_db_column_name=>'LPO_TIP_TIPO_CAMBIO'
,p_display_order=>50
,p_column_identifier=>'CV'
,p_column_label=>'T. Cambio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097148647211540485)
,p_db_column_name=>'LPO_TIPO_LISTA'
,p_display_order=>60
,p_column_identifier=>'CW'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097149052450540485)
,p_db_column_name=>'LPO_TIPO_BASE'
,p_display_order=>70
,p_column_identifier=>'CX'
,p_column_label=>'T. Base'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097149519452540486)
,p_db_column_name=>'LPO_TIPO_CALCULO'
,p_display_order=>80
,p_column_identifier=>'CY'
,p_column_label=>'T. Calculo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097149910954540487)
,p_db_column_name=>'LPO_REDONDEO_COMERCIAL'
,p_display_order=>90
,p_column_identifier=>'CZ'
,p_column_label=>'Redondeo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097150312413540487)
,p_db_column_name=>'PCO_ATO_ARTICULO'
,p_display_order=>100
,p_column_identifier=>'DA'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097150716841540488)
,p_db_column_name=>'DSP_ATO_DESCRIPCION'
,p_display_order=>110
,p_column_identifier=>'DB'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097151084059540489)
,p_db_column_name=>'PCO_PRECIO'
,p_display_order=>120
,p_column_identifier=>'DC'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097151491136540489)
,p_db_column_name=>'PCO_PORCENTAJE'
,p_display_order=>130
,p_column_identifier=>'DD'
,p_column_label=>'Porcentaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097151858300540490)
,p_db_column_name=>'PCO_FACTOR1'
,p_display_order=>140
,p_column_identifier=>'DE'
,p_column_label=>'Factor1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097152238040540491)
,p_db_column_name=>'PCO_FACTOR2'
,p_display_order=>150
,p_column_identifier=>'DF'
,p_column_label=>'Factor2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097152662969540491)
,p_db_column_name=>'PCO_FACTOR3'
,p_display_order=>160
,p_column_identifier=>'DG'
,p_column_label=>'Factor3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097153120665540493)
,p_db_column_name=>'PCO_TIPO_BASE'
,p_display_order=>170
,p_column_identifier=>'DH'
,p_column_label=>'T. Base'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097153475496540494)
,p_db_column_name=>'PCO_TIPO_CALCULO'
,p_display_order=>180
,p_column_identifier=>'DI'
,p_column_label=>'T. Calculo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097118629096535309)
,p_db_column_name=>'PCO_GASTOS_INSCRIP'
,p_display_order=>190
,p_column_identifier=>'DJ'
,p_column_label=>'Gastos Inscripcion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097118768616535310)
,p_db_column_name=>'PCO_GASTOS_ADIC'
,p_display_order=>200
,p_column_identifier=>'DK'
,p_column_label=>'Gastos Adicional'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14097155914043540498)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'94122'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LPO_EMP_EMPRESA:LPO_LISTA:LPO_DESCRIPCION:LPO_MON_MONEDA:LPO_TIP_TIPO_CAMBIO:LPO_TIPO_LISTA:LPO_TIPO_BASE:LPO_TIPO_CALCULO:LPO_REDONDEO_COMERCIAL:PCO_ATO_ARTICULO:DSP_ATO_DESCRIPCION:PCO_PRECIO:PCO_PORCENTAJE:PCO_FACTOR1:PCO_FACTOR2:PCO_FACTOR3:PCO_T'
||'IPO_BASE:PCO_TIPO_CALCULO:PCO_GASTOS_INSCRIP:PCO_GASTOS_ADIC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14097144948642540474)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14097144555548540473)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14097145352145540475)
,p_name=>'P117_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14097144555548540473)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
