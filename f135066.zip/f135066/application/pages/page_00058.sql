prompt --application/pages/page_00058
begin
--   Manifest
--     PAGE: 00058
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>58
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('TAL \2013 Ordenes de Servicio')
,p_step_title=>'Ordenes de Servicio'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164213'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14153728980282399628)
,p_plug_name=>'Ordenes de Servicio'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14153725072298399607)
,p_plug_name=>'Ordenes de Servicio'
,p_parent_plug_id=>wwv_flow_api.id(14153728980282399628)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 17/01/2017 04:28:17 p.m. (QP5 v5.115.810.9015) */',
'SELECT   ord_emp_empresa empresa,',
'         ord_orden,',
'         TRUNC (ord_fecha) ord_fecha,',
'         TRUNC (cit_fecha_recepcion) cit_fecha_recepcion,',
'         ord_estado,',
'         ord_placa,',
'         ord_serial,',
'         ord_motor,',
'         ord_chasis,',
'         ord_cli_codigo,',
'         ord_cli_moneda,',
'         ord_cliente,',
'         ord_marca,',
'         ord_modelo,',
'         ord_segmento,',
'         ord_asesor,',
'         ord_cat_categoria,',
'         ord_cit_cita,',
'         ord_semaforo,',
'         TRUNC (ord_fecha_entrega) ord_fecha_entrega,',
'         ord_contacto,',
'         ord_lcn_localizacion,',
'         TRUNC (ord_fecha_cierre) ord_fecha_cierre,',
'         ord_tco_cono,',
'         ord_nombre,',
'         ord_cedula,',
'         ord_sin_cliente,',
'         ord_sin_moneda,',
'         ord_aseguradora,',
'         ord_sin_caso,',
'         ord_sin_poliza,',
'         ord_sin_tipo,',
'         ord_sin_deducible,',
'         ord_tipo_proceso,',
'         ord_estado_avaluo,',
'         ord_anno,',
'         ord_motivo,',
'         ord_cliente_espera,',
'         ord_devolver_repuestos,',
'         ord_lpo_lista,',
'         ord_porc_desc_serv,',
'         ord_porc_desc_rep,',
'         ord_dist_recorrida,',
'         ord_anotaciones,',
'         TRUNC (ord_fecha_compromiso) ord_fecha_compromiso,',
'         ord_vis_consecutivo,',
'         TAL_BITACORA_ORDEN_D_NX (ord_emp_empresa,',
'                                  ord_orden,',
'                                  ''AVALUO APROBADO'')',
'            estadoAprobado,',
'         TAL_BITACORA_ORDEN_D_NX (ord_emp_empresa,',
'                                  ord_orden,',
'                                  ''AVALUO ENVIADO'')',
'            estadoEnviado,',
'            ord_creado_por,',
'            ord_fecha_creacion ',
'  FROM   TAL_ORDEN_SERVICIO_VW_NX',
' WHERE   INSTR ('':'' || :p58_empresa || '':'', '':'' || ord_emp_empresa || '':'') >',
'            0',
'         AND ord_fecha BETWEEN :p58_inicio',
'                           AND  TO_DATE (:p58_fin || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P58_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14153725275420399610)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>11281014219125568
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726263799399617)
,p_db_column_name=>'ORD_ORDEN'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ORD_ORDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726373394399618)
,p_db_column_name=>'ORD_FECHA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'ORD_FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094457860580116434)
,p_db_column_name=>'ORD_MOTIVO'
,p_display_order=>23
,p_column_identifier=>'AM'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726493720399618)
,p_db_column_name=>'ORD_ESTADO'
,p_display_order=>33
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_static_id=>'ORD_ESTADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726571928399618)
,p_db_column_name=>'ORD_PLACA'
,p_display_order=>43
,p_column_identifier=>'E'
,p_column_label=>'Placa'
,p_column_type=>'STRING'
,p_static_id=>'ORD_PLACA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726689014399619)
,p_db_column_name=>'ORD_SERIAL'
,p_display_order=>53
,p_column_identifier=>'F'
,p_column_label=>'Serie'
,p_column_type=>'STRING'
,p_static_id=>'ORD_SERIAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726793384399619)
,p_db_column_name=>'ORD_MOTOR'
,p_display_order=>63
,p_column_identifier=>'G'
,p_column_label=>'Motor'
,p_column_type=>'STRING'
,p_static_id=>'ORD_MOTOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726890701399619)
,p_db_column_name=>'ORD_CHASIS'
,p_display_order=>73
,p_column_identifier=>'H'
,p_column_label=>'Chasis'
,p_column_type=>'STRING'
,p_static_id=>'ORD_CHASIS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727279175399621)
,p_db_column_name=>'ORD_MARCA'
,p_display_order=>83
,p_column_identifier=>'L'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_static_id=>'ORD_MARCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727379650399621)
,p_db_column_name=>'ORD_MODELO'
,p_display_order=>93
,p_column_identifier=>'M'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
,p_static_id=>'ORD_MODELO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727472546399621)
,p_db_column_name=>'ORD_SEGMENTO'
,p_display_order=>103
,p_column_identifier=>'N'
,p_column_label=>'Segmento'
,p_column_type=>'STRING'
,p_static_id=>'ORD_SEGMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094457799485116433)
,p_db_column_name=>'ORD_ANNO'
,p_display_order=>113
,p_column_identifier=>'AL'
,p_column_label=>'Anno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726963534399620)
,p_db_column_name=>'ORD_CLI_CODIGO'
,p_display_order=>123
,p_column_identifier=>'I'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
,p_static_id=>'ORD_CLI_CODIGO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727085681399620)
,p_db_column_name=>'ORD_CLI_MONEDA'
,p_display_order=>133
,p_column_identifier=>'J'
,p_column_label=>'Moneda Cliente'
,p_column_type=>'STRING'
,p_static_id=>'ORD_CLI_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727165224399620)
,p_db_column_name=>'ORD_CLIENTE'
,p_display_order=>143
,p_column_identifier=>'K'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'ORD_CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727692870399622)
,p_db_column_name=>'ORD_CAT_CATEGORIA'
,p_display_order=>153
,p_column_identifier=>'P'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
,p_static_id=>'ORD_CAT_CATEGORIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727791998399622)
,p_db_column_name=>'ORD_CIT_CITA'
,p_display_order=>163
,p_column_identifier=>'Q'
,p_column_label=>'Cita'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ORD_CIT_CITA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727870977399623)
,p_db_column_name=>'ORD_SEMAFORO'
,p_display_order=>173
,p_column_identifier=>'R'
,p_column_label=>'Semaforo'
,p_column_type=>'STRING'
,p_static_id=>'ORD_SEMAFORO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153727963846399623)
,p_db_column_name=>'ORD_FECHA_ENTREGA'
,p_display_order=>183
,p_column_identifier=>'S'
,p_column_label=>'Fecha Entrega'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'ORD_FECHA_ENTREGA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153728091798399623)
,p_db_column_name=>'ORD_CONTACTO'
,p_display_order=>193
,p_column_identifier=>'T'
,p_column_label=>'Contacto'
,p_column_type=>'STRING'
,p_static_id=>'ORD_CONTACTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153728179989399623)
,p_db_column_name=>'ORD_LCN_LOCALIZACION'
,p_display_order=>203
,p_column_identifier=>'U'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
,p_static_id=>'ORD_LCN_LOCALIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153728271984399624)
,p_db_column_name=>'ORD_FECHA_CIERRE'
,p_display_order=>213
,p_column_identifier=>'V'
,p_column_label=>'Fecha Cierre'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'ORD_FECHA_CIERRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153728388968399624)
,p_db_column_name=>'ORD_TCO_CONO'
,p_display_order=>223
,p_column_identifier=>'W'
,p_column_label=>'Cono'
,p_column_type=>'STRING'
,p_static_id=>'ORD_TCO_CONO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153728491738399624)
,p_db_column_name=>'ORD_NOMBRE'
,p_display_order=>233
,p_column_identifier=>'X'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'ORD_NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153728587870399625)
,p_db_column_name=>'ORD_CEDULA'
,p_display_order=>243
,p_column_identifier=>'Y'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_static_id=>'ORD_CEDULA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153728668840399625)
,p_db_column_name=>'ORD_SIN_CLIENTE'
,p_display_order=>253
,p_column_identifier=>'Z'
,p_column_label=>'Codigo Aseguradora'
,p_column_type=>'STRING'
,p_static_id=>'ORD_SIN_CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153725488757399615)
,p_db_column_name=>'ORD_SIN_MONEDA'
,p_display_order=>263
,p_column_identifier=>'AA'
,p_column_label=>'Moneda Aseguradora'
,p_column_type=>'STRING'
,p_static_id=>'ORD_SIN_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153725573168399615)
,p_db_column_name=>'ORD_ASEGURADORA'
,p_display_order=>273
,p_column_identifier=>'AB'
,p_column_label=>'Aseguradora'
,p_column_type=>'STRING'
,p_static_id=>'ORD_ASEGURADORA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153725676855399615)
,p_db_column_name=>'ORD_SIN_CASO'
,p_display_order=>283
,p_column_identifier=>'AC'
,p_column_label=>'Caso'
,p_column_type=>'STRING'
,p_static_id=>'ORD_SIN_CASO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153725775049399616)
,p_db_column_name=>'ORD_SIN_POLIZA'
,p_display_order=>293
,p_column_identifier=>'AD'
,p_column_label=>'Poliza'
,p_column_type=>'STRING'
,p_static_id=>'ORD_SIN_POLIZA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153725873037399616)
,p_db_column_name=>'ORD_SIN_TIPO'
,p_display_order=>303
,p_column_identifier=>'AE'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'ORD_SIN_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153725982671399616)
,p_db_column_name=>'ORD_SIN_DEDUCIBLE'
,p_display_order=>313
,p_column_identifier=>'AF'
,p_column_label=>'Deducible'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ORD_SIN_DEDUCIBLE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726068970399617)
,p_db_column_name=>'ORD_TIPO_PROCESO'
,p_display_order=>323
,p_column_identifier=>'AG'
,p_column_label=>'Proceso'
,p_column_type=>'STRING'
,p_static_id=>'ORD_TIPO_PROCESO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14153726185509399617)
,p_db_column_name=>'ORD_ESTADO_AVALUO'
,p_display_order=>333
,p_column_identifier=>'AH'
,p_column_label=>'Estado Avaluo'
,p_column_type=>'STRING'
,p_static_id=>'ORD_ESTADO_AVALUO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094457636707116432)
,p_db_column_name=>'ORD_ASESOR'
,p_display_order=>343
,p_column_identifier=>'AK'
,p_column_label=>'Asesor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094458001372116435)
,p_db_column_name=>'ORD_CLIENTE_ESPERA'
,p_display_order=>353
,p_column_identifier=>'AN'
,p_column_label=>'Cliente Espera'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094458072968116436)
,p_db_column_name=>'ORD_DEVOLVER_REPUESTOS'
,p_display_order=>363
,p_column_identifier=>'AO'
,p_column_label=>'Devolver Repuestos'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094458215660116437)
,p_db_column_name=>'ORD_LPO_LISTA'
,p_display_order=>373
,p_column_identifier=>'AP'
,p_column_label=>'Lista Precios'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094458257530116438)
,p_db_column_name=>'ORD_PORC_DESC_SERV'
,p_display_order=>383
,p_column_identifier=>'AQ'
,p_column_label=>'% Desc Serv'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094458399748116439)
,p_db_column_name=>'ORD_PORC_DESC_REP'
,p_display_order=>393
,p_column_identifier=>'AR'
,p_column_label=>'% Desc Rep'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094458481053116440)
,p_db_column_name=>'ORD_DIST_RECORRIDA'
,p_display_order=>403
,p_column_identifier=>'AS'
,p_column_label=>'Dist Recorrida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094458578106116441)
,p_db_column_name=>'ORD_ANOTACIONES'
,p_display_order=>413
,p_column_identifier=>'AT'
,p_column_label=>'Anotaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569318787602509)
,p_db_column_name=>'ORD_FECHA_COMPROMISO'
,p_display_order=>423
,p_column_identifier=>'AU'
,p_column_label=>'F. Compromiso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569412253602510)
,p_db_column_name=>'ORD_VIS_CONSECUTIVO'
,p_display_order=>433
,p_column_identifier=>'AV'
,p_column_label=>'# Visita'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569477242602511)
,p_db_column_name=>'ESTADOAPROBADO'
,p_display_order=>443
,p_column_identifier=>'AW'
,p_column_label=>'F. Avaluo Aprobado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569577030602512)
,p_db_column_name=>'ESTADOENVIADO'
,p_display_order=>453
,p_column_identifier=>'AX'
,p_column_label=>'F. Avaluo Enviado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569966656602516)
,p_db_column_name=>'CIT_FECHA_RECEPCION'
,p_display_order=>463
,p_column_identifier=>'AY'
,p_column_label=>'F. Recepcion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900206674642709)
,p_db_column_name=>'EMPRESA'
,p_display_order=>473
,p_column_identifier=>'AZ'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583822169100327)
,p_db_column_name=>'ORD_CREADO_POR'
,p_display_order=>483
,p_column_identifier=>'BA'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583957285100328)
,p_db_column_name=>'ORD_FECHA_CREACION'
,p_display_order=>493
,p_column_identifier=>'BB'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14153728764021399625)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'112846'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1
,p_report_columns=>'EMPRESA:ORD_ORDEN:ORD_FECHA:CIT_FECHA_RECEPCION:ORD_MOTIVO:ORD_ESTADO:ORD_PLACA:ORD_SERIAL:ORD_MOTOR:ORD_CHASIS:ORD_MARCA:ORD_MODELO:ORD_SEGMENTO:ORD_ANNO:ORD_CLI_CODIGO:ORD_CLI_MONEDA:ORD_CLIENTE:ORD_CAT_CATEGORIA:ORD_CIT_CITA:ORD_SEMAFORO:ORD_FECHA'
||'_ENTREGA:ORD_CONTACTO:ORD_LCN_LOCALIZACION:ORD_FECHA_CIERRE:ORD_TCO_CONO:ORD_NOMBRE:ORD_CEDULA:ORD_SIN_CLIENTE:ORD_SIN_MONEDA:ORD_ASEGURADORA:ORD_SIN_CASO:ORD_SIN_POLIZA:ORD_SIN_TIPO:ORD_SIN_DEDUCIBLE:ORD_TIPO_PROCESO:ORD_ESTADO_AVALUO:ORD_ASESOR:ORD'
||'_CLIENTE_ESPERA:ORD_DEVOLVER_REPUESTOS:ORD_LPO_LISTA:ORD_PORC_DESC_SERV:ORD_PORC_DESC_REP:ORD_DIST_RECORRIDA:ORD_ANOTACIONES:ORD_FECHA_COMPROMISO:ORD_VIS_CONSECUTIVO:ESTADOENVIADO:ESTADOAPROBADO::ORD_CREADO_POR:ORD_FECHA_CREACION'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14153729192835399628)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14153728980282399628)
,p_button_name=>'P58_CONSULTAR'
,p_button_static_id=>'P58_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14153729391152399630)
,p_name=>'P58_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14153728980282399628)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14153729575019399631)
,p_name=>'P58_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14153728980282399628)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14153729771215399631)
,p_name=>'P58_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14153728980282399628)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
