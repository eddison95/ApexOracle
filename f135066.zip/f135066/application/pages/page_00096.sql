prompt --application/pages/page_00096
begin
--   Manifest
--     PAGE: 00096
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>96
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CRM - Productos'
,p_step_title=>'Productos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164802'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096898461214652204)
,p_plug_name=>'Productos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095688371218192625)
,p_plug_name=>'Productos'
,p_parent_plug_id=>wwv_flow_api.id(14096898461214652204)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 22/02/2017 01:52:03 p.m. (QP5 v5.115.810.9015) */',
'SELECT   PRODUCTS.ID AS ID,',
'         PRODUCTS.CODE AS CODE,',
'         PRODUCTS.NAME AS NAME,',
'         PRODUCTS.IND_ACTIVE AS IND_ACTIVE,',
'         PRODUCTS.MARK AS MARK,',
'         PRODUCTS.MODEL AS MODEL,',
'         PRODUCTS.CLASS AS CLASS,',
'         PRODUCTS.VERSION AS VERSION,',
'         PRODUCTS.FUEL AS FUEL,',
'         PRODUCTS.DESCRIPTION AS DESCRIPTION,',
'         PRODUCTS.CYLINDER_QUANTITY AS CYLINDER_QUANTITY,',
'         PRODUCTS.USE AS USE,',
'         PRODUCTS.CATEGORY AS CATEGORY,',
'         PRODUCTS.TRACTION AS TRACTION,',
'         PRODUCTS.CUBIC_CAPACITY AS CUBIC_CAPACITY,',
'         PRODUCTS.BODYWORK AS BODYWORK,',
'         PRODUCTS.SERVICE AS SERVICE,',
'         PRODUCTS.STYLE AS STYLE,',
'         PRODUCTS.IND_EXPENSES_TAXES AS IND_EXPENSES_TAXES,',
'         PRODUCTS.COMPANY AS COMPANY',
'  FROM   PRODUCTS PRODUCTS',
' WHERE   INSTR ('':'' || :P96_EMPRESA || '':'', '':'' || PRODUCTS.COMPANY || '':'') >',
'            0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P96_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095688772862192626)
,p_name=>'Ventas Diarias'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>7945048090303532
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095688898669192626)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'CI'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095689303135192627)
,p_db_column_name=>'ID'
,p_display_order=>90
,p_column_identifier=>'CJ'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095695666378192640)
,p_db_column_name=>'COMPANY'
,p_display_order=>300
,p_column_identifier=>'DJ'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635571527928918)
,p_db_column_name=>'CODE'
,p_display_order=>310
,p_column_identifier=>'DO'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635692800928919)
,p_db_column_name=>'IND_ACTIVE'
,p_display_order=>320
,p_column_identifier=>'DP'
,p_column_label=>'Activo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635744705928920)
,p_db_column_name=>'MARK'
,p_display_order=>330
,p_column_identifier=>'DQ'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635915101928921)
,p_db_column_name=>'MODEL'
,p_display_order=>340
,p_column_identifier=>'DR'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095635965241928922)
,p_db_column_name=>'CLASS'
,p_display_order=>350
,p_column_identifier=>'DS'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636044765928923)
,p_db_column_name=>'VERSION'
,p_display_order=>360
,p_column_identifier=>'DT'
,p_column_label=>'Version'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636199855928924)
,p_db_column_name=>'FUEL'
,p_display_order=>370
,p_column_identifier=>'DU'
,p_column_label=>'Combustible'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636243718928925)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>380
,p_column_identifier=>'DV'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636419081928926)
,p_db_column_name=>'CYLINDER_QUANTITY'
,p_display_order=>390
,p_column_identifier=>'DW'
,p_column_label=>'Cilindraje'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636425514928927)
,p_db_column_name=>'USE'
,p_display_order=>400
,p_column_identifier=>'DX'
,p_column_label=>'Uso'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636595732928928)
,p_db_column_name=>'CATEGORY'
,p_display_order=>410
,p_column_identifier=>'DY'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636657375928929)
,p_db_column_name=>'TRACTION'
,p_display_order=>420
,p_column_identifier=>'DZ'
,p_column_label=>'Traccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636732999928930)
,p_db_column_name=>'CUBIC_CAPACITY'
,p_display_order=>430
,p_column_identifier=>'EA'
,p_column_label=>'Capacidad Cubica'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636839211928931)
,p_db_column_name=>'BODYWORK'
,p_display_order=>440
,p_column_identifier=>'EB'
,p_column_label=>'Bodywork'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095636992342928932)
,p_db_column_name=>'SERVICE'
,p_display_order=>450
,p_column_identifier=>'EC'
,p_column_label=>'Servicio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095637060485928933)
,p_db_column_name=>'STYLE'
,p_display_order=>460
,p_column_identifier=>'ED'
,p_column_label=>'Estilo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095637185063928934)
,p_db_column_name=>'IND_EXPENSES_TAXES'
,p_display_order=>470
,p_column_identifier=>'EE'
,p_column_label=>'Gastos Impuestos'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095697575753192646)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'79539'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'COMPANY:ID:NAME:CODE:DESCRIPTION:MARK:MODEL:CLASS:VERSION:FUEL:TRACTION:CUBIC_CAPACITY:CYLINDER_QUANTITY:CATEGORY:BODYWORK:STYLE:IND_ACTIVE:USE:SERVICE:IND_EXPENSES_TAXES:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096898754653652205)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14096898461214652204)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096899127419652206)
,p_name=>'P96_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096898461214652204)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
