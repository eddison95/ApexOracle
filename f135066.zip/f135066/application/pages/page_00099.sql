prompt --application/pages/page_00099
begin
--   Manifest
--     PAGE: 00099
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>99
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'TAL - Indicadores Graficos'
,p_step_title=>'Indicadores Graficos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164844'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095902841154681803)
,p_plug_name=>'Indicadores Graficos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096108724116408037)
,p_plug_name=>'Indicadores de Gestion'
,p_parent_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14001921025065738660)
,p_name=>'Ventas de Taller'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>160
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    *',
'FROM',
'    (',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':112:''',
'                                  || :app_session',
'                                  || ''::::P112_EMPRESA,P112_LOCALIZACION,P112_INICIO,P112_FIN,P112_VENTAS:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',T'')       detalle,',
'            ''BLACK''    color,',
'            ''Totales''  indicador,',
'            to_number(:P99_VTA_TOTAL) valor,',
'            NULL       porcentaje,',
'            1          orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':112:''',
'                                  || :app_session',
'                                  || ''::::P112_EMPRESA,P112_LOCALIZACION,P112_INICIO,P112_FIN,P112_VENTAS:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',P'')            detalle,',
'            ''BLUE''          color,',
'            ''Particulares''  indicador,',
'            particulares valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_VTA_TOTAL, particulares',
'            ) porcentaje,',
'            2               orden',
'        FROM',
'            (SELECT tal_ind_taller_nx.sum_ventas_p_f(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            ) particulares FROM DUAL)',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':112:''',
'                                  || :app_session',
'                                  || ''::::P112_EMPRESA,P112_LOCALIZACION,P112_INICIO,P112_FIN,P112_VENTAS:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',A'')            detalle,',
'            ''BLUE''          color,',
'            ''Aseguradoras''  indicador,',
'            aseguradoras valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_VTA_TOTAL, aseguradoras',
'            ) porcentaje,',
'            3               orden',
'        FROM',
'            (SELECT tal_ind_taller_nx.sum_ventas_a_f(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            ) aseguradoras FROM DUAL)',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':112:''',
'                                  || :app_session',
'                                  || ''::::P112_EMPRESA,P112_LOCALIZACION,P112_INICIO,P112_FIN,P112_VENTAS:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',O'')       detalle,',
'            ''GREEN''    color,',
'            ''Contado''  indicador,',
'            to_number(:P99_VTA_CONTADO) valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_VTA_TOTAL, :P99_VTA_CONTADO',
'            ) porcentaje,',
'            4          orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':112:''',
'                                  || :app_session',
'                                  || ''::::P112_EMPRESA,P112_LOCALIZACION,P112_INICIO,P112_FIN,P112_VENTAS:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',E'')       detalle,',
'            ''GREEN''    color,',
'            ''Credito''  indicador,',
'            to_number(:P99_VTA_CREDITO) valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_VTA_TOTAL, :P99_VTA_CREDITO',
'            ) porcentaje,',
'            5          orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':112:''',
'                                  || :app_session',
'                                  || ''::::P112_EMPRESA,P112_LOCALIZACION,P112_INICIO,P112_FIN,P112_VENTAS:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',I'')        detalle,',
'            ''GREEN''     color,',
'            ''Internas''  indicador,',
'            to_number(:P99_VTA_INTERNAS) valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_VTA_TOTAL, :P99_VTA_INTERNAS',
'            ) porcentaje,',
'            5           orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':112:''',
'                                  || :app_session',
'                                  || ''::::P112_EMPRESA,P112_LOCALIZACION,P112_INICIO,P112_FIN,P112_VENTAS:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',R'')         detalle,',
'            ''PURPLE''     color,',
'            ''Repuestos''  indicador,',
'            to_number(:P99_VTA_REPUESTOS) valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_VTA_TOTAL, :P99_VTA_REPUESTOS',
'            ) porcentaje,',
'            6            orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':112:''',
'                                  || :app_session',
'                                  || ''::::P112_EMPRESA,P112_LOCALIZACION,P112_INICIO,P112_FIN,P112_VENTAS:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',S'')         detalle,',
'            ''PURPLE''     color,',
'            ''Servicios''  indicador,',
'            to_number(:P99_VTA_SERVICIOS) valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_VTA_TOTAL, :P99_VTA_SERVICIOS',
'            ) porcentaje,',
'            7            orden',
'        FROM',
'            dual',
'    )',
'ORDER BY',
'    orden'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001921455877738664)
,p_query_column_id=>1
,p_column_alias=>'DETALLE'
,p_column_display_sequence=>1
,p_column_heading=>'Detalle'
,p_column_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:RP::'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001921618426738666)
,p_query_column_id=>2
,p_column_alias=>'COLOR'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001921121382738661)
,p_query_column_id=>3
,p_column_alias=>'INDICADOR'
,p_column_display_sequence=>2
,p_column_heading=>'Indicador'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#INDICADOR#</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001921234430738662)
,p_query_column_id=>4
,p_column_alias=>'VALOR'
,p_column_display_sequence=>3
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#VALOR#</span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001921351069738663)
,p_query_column_id=>5
,p_column_alias=>'PORCENTAJE'
,p_column_display_sequence=>4
,p_column_heading=>'%'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#PORCENTAJE#</span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001921526653738665)
,p_query_column_id=>6
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14001921764139738667)
,p_name=>'Unidades Facturadas'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>140
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    *',
'FROM',
'    (',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':111:''',
'                                  || :app_session',
'                                  || ''::::P111_EMPRESA,P111_LOCALIZACION,P111_INICIO,P111_FIN,P111_UNIDADES:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',T'')       detalle,',
'            ''BLACK''    color,',
'            ''Totales''  indicador,',
'            to_number(:P99_UNID_TOTAL) valor,',
'            NULL       porcentaje,',
'            1          orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':111:''',
'                                  || :app_session',
'                                  || ''::::P111_EMPRESA,P111_LOCALIZACION,P111_INICIO,P111_FIN,P111_UNIDADES:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',P'')            detalle,',
'            ''BLUE''          color,',
'            ''Particulares''  indicador,',
'            particulares valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_UNID_TOTAL, particulares',
'            ) porcentaje,',
'            2               orden',
'        FROM',
'            (SELECT tal_ind_taller_nx.unid_fact_particular_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            ) particulares FROM DUAL)',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':111:''',
'                                  || :app_session',
'                                  || ''::::P111_EMPRESA,P111_LOCALIZACION,P111_INICIO,P111_FIN,P111_UNIDADES:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',A'')            detalle,',
'            ''BLUE''          color,',
'            ''Aseguradoras''  indicador,',
'            aseguradoras valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_UNID_TOTAL, aseguradoras',
'            ) porcentaje,',
'            3               orden',
'        FROM',
'            (SELECT tal_ind_taller_nx.unid_fact_aseg_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            ) aseguradoras FROM DUAL)',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':111:''',
'                                  || :app_session',
'                                  || ''::::P111_EMPRESA,P111_LOCALIZACION,P111_INICIO,P111_FIN,P111_UNIDADES:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',O'')       detalle,',
'            ''GREEN''    color,',
'            ''Contado''  indicador,',
'            contado valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_UNID_TOTAL, contado',
'            ) porcentaje,',
'            4          orden',
'        FROM',
'            (SELECT tal_ind_taller_nx.unid_fact_cc_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                ''CON'',',
'                :p99_inicio,',
'                :p99_fin',
'            ) contado FROM DUAL)',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':111:''',
'                                  || :app_session',
'                                  || ''::::P111_EMPRESA,P111_LOCALIZACION,P111_INICIO,P111_FIN,P111_UNIDADES:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',E'')       detalle,',
'            ''GREEN''    color,',
'            ''Credito''  indicador,',
'            credito valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_UNID_TOTAL, credito',
'            ) porcentaje,',
'            5          orden',
'        FROM',
'            (SELECT tal_ind_taller_nx.unid_fact_cc_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                ''CRE'',',
'                :p99_inicio,',
'                :p99_fin',
'            ) credito FROM DUAL)',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':111:''',
'                                  || :app_session',
'                                  || ''::::P111_EMPRESA,P111_LOCALIZACION,P111_INICIO,P111_FIN,P111_UNIDADES:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',I'')        detalle,',
'            ''GREEN''     color,',
'            ''Internas''  indicador,',
'            internas valor,',
'            tal_ind_taller_nx.porcentajes_v(',
'                :P99_UNID_TOTAL, internas',
'            ) porcentaje,',
'            5           orden',
'        FROM',
'            (SELECT tal_ind_taller_nx.unid_fact_cc_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                ''NIT'',',
'                :p99_inicio,',
'                :p99_fin',
'            ) internas FROM DUAL)',
'    )',
'ORDER BY',
'    orden'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001921825863738668)
,p_query_column_id=>1
,p_column_alias=>'DETALLE'
,p_column_display_sequence=>1
,p_column_heading=>'Detalle'
,p_column_link=>'#DETALLE#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001921994993738669)
,p_query_column_id=>2
,p_column_alias=>'COLOR'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001922057732738670)
,p_query_column_id=>3
,p_column_alias=>'INDICADOR'
,p_column_display_sequence=>3
,p_column_heading=>'Indicador'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#INDICADOR#</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001922152582738671)
,p_query_column_id=>4
,p_column_alias=>'VALOR'
,p_column_display_sequence=>4
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#VALOR#</span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001922300594738672)
,p_query_column_id=>5
,p_column_alias=>'PORCENTAJE'
,p_column_display_sequence=>5
,p_column_heading=>'%'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#PORCENTAJE#</span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001922337143738673)
,p_query_column_id=>6
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14001922734283738677)
,p_plug_name=>'Productividad'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14001922867432738678)
,p_region_id=>wwv_flow_api.id(14001922734283738677)
,p_chart_type=>'dial'
,p_height=>'200'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_text_type=>'number'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>180
,p_gauge_angle_extent=>180
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14001923000765738679)
,p_chart_id=>wwv_flow_api.id(14001922867432738678)
,p_seq=>10
,p_name=>'Nuevo'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN :P99_HRS_DISPONIBLES > 0 THEN',
'            (:P99_HRS_TRABAJADAS / :P99_HRS_DISPONIBLES) * 100',
'        ELSE',
'            0',
'    END valor,',
'    100 valorm',
'FROM DUAL'))
,p_items_value_column_name=>'VALOR'
,p_items_max_value=>'VALORM'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14002373413234407555)
,p_plug_name=>'Nuevo'
,p_parent_plug_id=>wwv_flow_api.id(14001922734283738677)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960771903852591905)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>'htp.p(''<span style="width:100%;text-align:center">Horas Trabajadas / Horas Totales Disponibles</span>'');'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14001923263764738682)
,p_plug_name=>'Eficiencia del Taller'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14001923313301738683)
,p_region_id=>wwv_flow_api.id(14001923263764738682)
,p_chart_type=>'dial'
,p_height=>'200'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_text_type=>'number'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>180
,p_gauge_angle_extent=>180
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14001923454606738684)
,p_chart_id=>wwv_flow_api.id(14001923313301738683)
,p_seq=>10
,p_name=>'Nuevo'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN :P99_HRS_DISPONIBLES > 0 THEN',
'            (:P99_HRS_FACTURADAS / :P99_HRS_DISPONIBLES) * 100',
'        ELSE',
'            0',
'    END valor,',
'    100 valorm',
'FROM DUAL'))
,p_items_value_column_name=>'VALOR'
,p_items_max_value=>'VALORM'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14002373559919407556)
,p_plug_name=>'Nuevo'
,p_parent_plug_id=>wwv_flow_api.id(14001923263764738682)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960771903852591905)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'htp.p(''<span style="width:100%;text-align:center">Horas Facturadas / Horas Totales Disponibles</span>'');'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14001923518585738685)
,p_plug_name=>'Eficacia Operativa'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14001923688085738686)
,p_region_id=>wwv_flow_api.id(14001923518585738685)
,p_chart_type=>'dial'
,p_height=>'200'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_text_type=>'number'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>180
,p_gauge_angle_extent=>180
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14001923779784738687)
,p_chart_id=>wwv_flow_api.id(14001923688085738686)
,p_seq=>10
,p_name=>'Nuevo'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN :P99_HRS_TRABAJADAS > 0 THEN',
'            (:P99_HRS_FACTURADAS / :P99_HRS_TRABAJADAS) * 100',
'        ELSE',
'            0',
'    END valor,',
'    100 valorm',
'FROM DUAL'))
,p_items_value_column_name=>'VALOR'
,p_items_max_value=>'VALORM'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14002373702388407557)
,p_plug_name=>'Nuevo'
,p_parent_plug_id=>wwv_flow_api.id(14001923518585738685)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960771903852591905)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'htp.p(''<span style="width:100%;text-align:center">Horas Facturadas / Horas Trabajadas</span>'');'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14001923894065738688)
,p_name=>'Factor Efectividad M/O'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN :P99_HRS_TRABAJADAS > 0 THEN',
'            :P99_VTA_SERVICIOS / :P99_HRS_TRABAJADAS',
'        ELSE',
'            0',
'    END col1',
'FROM DUAL'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960809052823591918)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14001924399019738693)
,p_query_column_id=>1
,p_column_alias=>'COL1'
,p_column_display_sequence=>1
,p_column_heading=>'Monto Trabajado / Horas Trabajadas'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'<span style="font-weight:bold;color:green;">#COL1#</span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14002372533415407546)
,p_name=>'Proporcion de Repuestos sobre M/O'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN :P99_VTA_SERVICIOS > 0 THEN',
'            to_char(',
'                (:P99_VTA_REPUESTOS / :P99_VTA_SERVICIOS) * 100, ''990''',
'            )',
'            || ''%''',
'        ELSE',
'            ''0''',
'    END col1',
'FROM DUAL'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960809052823591918)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002372625051407547)
,p_query_column_id=>1
,p_column_alias=>'COL1'
,p_column_display_sequence=>1
,p_column_heading=>'Venta de Repuestos / Venta Mano Obra'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:green;">#COL1#</span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14002372969042407550)
,p_name=>'Retrabajos y Garantias'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE',
'        WHEN :P99_VTA_CONTADO + :P99_VTA_CREDITO > 0 THEN',
'            to_char(',
'                (:P99_VTA_INTERNAS /(:P99_VTA_CONTADO + :P99_VTA_CREDITO) * 100), ''990''',
'            )',
'            || ''%''',
'        ELSE',
'            ''0''',
'    END col1',
'FROM DUAL'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960809052823591918)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002373105336407551)
,p_query_column_id=>1
,p_column_alias=>'COL1'
,p_column_display_sequence=>1
,p_column_heading=>'Montos no Facturados / Montos Facturados'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:green;">#COL1#</span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14002373804261407558)
,p_name=>'Detalle Avaluos'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>180
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    *',
'FROM',
'    (',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':103:''',
'                                  || :app_session',
'                                  || ''::::P103_EMPRESA,P103_LOCALIZACION,P103_INICIO,P103_FIN,P103_ESTADO:''                                  ',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',AP'') detalle,',
'            ''BLACK''                                                                                                 color,',
'            ''Pendientes''                                                                                            indicador,',
'            tal_ind_taller_nx.conta_avaluosp_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            )              valor,',
'            1                                                                                                       orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':103:''',
'                                  || :app_session',
'                                  || ''::::P103_EMPRESA,P103_LOCALIZACION,P103_INICIO,P103_FIN,P103_ESTADO:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',AE'') detalle,',
'            ''BLACK''                                                                                                                   color,',
'            ''Enviados''                                                                                                                indicador,',
'            tal_ind_taller_nx.conta_avaluos_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin,',
'                ''AVALUO ENVIADO''',
'            )               valor,',
'            2                                                                                                                         orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':103:''',
'                                  || :app_session',
'                                  || ''::::P103_EMPRESA,P103_LOCALIZACION,P103_INICIO,P103_FIN,P103_ESTADO:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',AA'') detalle,',
'            ''BLACK''                                                                                                                    color,',
'            ''Autorizados''                                                                                                              indicador,',
'            tal_ind_taller_nx.conta_avaluos_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin,',
'                ''AVALUO APROBADO''',
'            )               valor,',
'            3                                                                                                                          orden',
'        FROM',
'            dual',
'    )',
'ORDER BY',
'    orden'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002373863510407559)
,p_query_column_id=>1
,p_column_alias=>'DETALLE'
,p_column_display_sequence=>1
,p_column_heading=>'Detalle'
,p_column_link=>'#DETALLE#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002373979575407560)
,p_query_column_id=>2
,p_column_alias=>'COLOR'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002374073993407561)
,p_query_column_id=>3
,p_column_alias=>'INDICADOR'
,p_column_display_sequence=>3
,p_column_heading=>'Indicador'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#INDICADOR#</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002374154090407562)
,p_query_column_id=>4
,p_column_alias=>'VALOR'
,p_column_display_sequence=>4
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#VALOR#</span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002374282748407563)
,p_query_column_id=>5
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14002374375363407564)
,p_name=>'Procesos Taller'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>120
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    *',
'FROM',
'    (',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':104:''',
'                                  || :app_session',
'                                  || ''::::P104_EMPRESA,P104_LOCALIZACION,P104_INICIO,P104_FIN:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )) detalle,',
'            ''BLACK''                                                                           color,',
'            ''Visitas Recibidas''                                                               indicador,',
'            tal_ind_taller_nx.conta_visitas_n(',
'                :p99_empresa, ',
'                :p99_inicio,',
'                :p99_fin',
'            )            valor,',
'            1                                                                                 orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':105:''',
'                                  || :app_session',
'                                  || ''::::P105_EMPRESA,P105_LOCALIZACION,P105_INICIO,P105_FIN:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )) detalle,',
'            ''BLACK''                                                                                              color,',
'            ''Proformas Generadas''                                                                                indicador,',
'            tal_ind_taller_nx.conta_profs_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            )               valor,',
'            2                                                                                                    orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':106:''',
'                                  || :app_session',
'                                  || ''::::P106_EMPRESA,P106_LOCALIZACION,P106_INICIO,P106_FIN:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )) detalle,',
'            ''BLACK''                                                                                                      color,',
'            ''Citas Programadas''                                                                                          indicador,',
'            tal_ind_taller_nx.conta_cits_programs_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            )              valor,',
'            3                                                                                                            orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':107:''',
'                                  || :app_session',
'                                  || ''::::P107_EMPRESA,P107_LOCALIZACION,P107_INICIO,P107_FIN:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )) detalle,',
'            ''BLACK''                                                                                                        color,',
'            ''Ordenes Creadas''                                                                                              indicador,',
'            tal_ind_taller_nx.conta_ordenes_creadas_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            )               valor,',
'            4                                                                                                              orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':108:''',
'                                  || :app_session',
'                                  || ''::::P108_EMPRESA,P108_LOCALIZACION,P108_INICIO,P108_FIN,P108_VEHICULOS:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',R'') detalle,',
'            ''BLACK''                                                                                                      color,',
'            ''Vehiculos Recibidos''                                                                                        indicador,',
'            tal_ind_taller_nx.conta_veh_recibidos_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            )              valor,',
'            5                                                                                                            orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':108:''',
'                                  || :app_session',
'                                  || ''::::P108_EMPRESA,P108_LOCALIZACION,P108_INICIO,P108_FIN,P108_VEHICULOS:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',T'') detalle,',
'            ''BLACK''                                                                                                   color,',
'            ''Vehiculos en Taller''                                                                                     indicador,',
'            tal_ind_taller_nx.conta_veh_taller_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            )               valor,',
'            6                                                                                                         orden',
'        FROM',
'            dual',
'    )',
'ORDER BY',
'    orden'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002374462912407565)
,p_query_column_id=>1
,p_column_alias=>'DETALLE'
,p_column_display_sequence=>1
,p_column_heading=>'Detalle'
,p_column_link=>'#DETALLE#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002374572098407566)
,p_query_column_id=>2
,p_column_alias=>'COLOR'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002374642486407567)
,p_query_column_id=>3
,p_column_alias=>'INDICADOR'
,p_column_display_sequence=>3
,p_column_heading=>'Indicador'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#INDICADOR#</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002374721873407568)
,p_query_column_id=>4
,p_column_alias=>'VALOR'
,p_column_display_sequence=>4
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#VALOR#</span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002374862966407569)
,p_query_column_id=>5
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14002374981442407570)
,p_name=>'Detalle Casos'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>190
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    *',
'FROM',
'    (',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':109:''',
'                                  || :app_session',
'                                  || ''::::P109_EMPRESA,P109_LOCALIZACION,P109_INICIO,P109_FIN,P109_CASOS:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',R'') detalle,',
'            ''BLACK''         color,',
'            '' Registrados''  indicador,',
'            tal_ind_taller_nx.conta_casos_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin,',
'                ''R''',
'            ) valor,',
'            1               orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':109:''',
'                                  || :app_session',
'                                  || ''::::P109_EMPRESA,P109_LOCALIZACION,P109_INICIO,P109_FIN,P109_CASOS:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',V'') detalle,',
'            ''BLACK''      color,',
'            ''Valorados''  indicador,',
'            tal_ind_taller_nx.conta_casos_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin,',
'                ''V''',
'            ) valor,',
'            2            orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':109:''',
'                                  || :app_session',
'                                  || ''::::P109_EMPRESA,P109_LOCALIZACION,P109_INICIO,P109_FIN,P109_CASOS:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',C'') detalle,',
'            ''BLACK''      color,',
'            ''Cotizados''  indicador,',
'            tal_ind_taller_nx.conta_casos_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin,',
'                ''A''',
'            ) valor,',
'            3            orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':109:''',
'                                  || :app_session',
'                                  || ''::::P109_EMPRESA,P109_LOCALIZACION,P109_INICIO,P109_FIN,P109_CASOS:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',A'') detalle,',
'            ''BLACK''      color,',
'            ''Aceptados''  indicador,',
'            tal_ind_taller_nx.conta_casos_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin,',
'                ''A''',
'            ) valor,',
'            4            orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':109:''',
'                                  || :app_session',
'                                  || ''::::P109_EMPRESA,P109_LOCALIZACION,P109_INICIO,P109_FIN,P109_CASOS:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',D'') detalle,',
'            ''BLACK''       color,',
'            ''Declinados''  indicador,',
'            tal_ind_taller_nx.conta_casosr_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin',
'            ) valor,',
'            5             orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            apex_util.prepare_url(''f?p=''',
'                                  || :app_id',
'                                  || '':109:''',
'                                  || :app_session',
'                                  || ''::::P109_EMPRESA,P109_LOCALIZACION,P109_INICIO,P109_FIN,P109_CASOS:''',
'                                  || :p99_empresa',
'                                  || '',''',
'                                  || :p99_localizacion',
'                                  || '',''',
'                                  || replace(',
'                :p99_inicio, ''/''',
'            )',
'                                  || '',''',
'                                  || replace(',
'                :p99_fin, ''/''',
'            )',
'                                  || '',E'') detalle,',
'            ''BLACK''         color,',
'            ''Desestimados''  indicador,',
'            tal_ind_taller_nx.conta_casos_n(',
'                :p99_empresa,',
'                :p99_localizacion, ',
'                :p99_inicio,',
'                :p99_fin,',
'                ''T''',
'            ) valor,',
'            6               orden',
'        FROM',
'            dual',
'    )',
'ORDER BY',
'    orden'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002375024552407571)
,p_query_column_id=>1
,p_column_alias=>'DETALLE'
,p_column_display_sequence=>1
,p_column_heading=>'Detalle'
,p_column_link=>'#DETALLE#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002375107501407572)
,p_query_column_id=>2
,p_column_alias=>'COLOR'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002375219243407573)
,p_query_column_id=>3
,p_column_alias=>'INDICADOR'
,p_column_display_sequence=>3
,p_column_heading=>'Indicador'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#INDICADOR#</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002375340112407574)
,p_query_column_id=>4
,p_column_alias=>'VALOR'
,p_column_display_sequence=>4
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#VALOR#</span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002375441978407575)
,p_query_column_id=>5
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14002375667933407577)
,p_name=>'Control por Horas'
,p_parent_plug_id=>wwv_flow_api.id(14096108724116408037)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>170
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    *',
'FROM',
'    (',
'        SELECT',
'            NULL        detalle,',
'            ''BLACK''     color,',
'            ''Tecnicos''  indicador,',
'            (',
'                SELECT',
'                    COUNT(*)',
'                FROM',
'                    tal_empleados_tb_nx,',
'                    tal_especialidad_tb_nx',
'                WHERE',
'                        emp_emp_empresa = :p99_empresa',
'                    AND emp_lcn_localizacion = :p99_localizacion',
'                    AND emp_estado = ''A''',
'                    AND emp_emp_empresa = esp_emp_empresa',
'                    AND emp_especialidad = esp_especialidad',
'                    AND emp_puesto = ''MEC''',
'            ) valor,',
'            1           orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            NULL           detalle,',
'            ''BLACK''        color,',
'            ''Disponibles''  indicador,',
'            to_number(:P99_HRS_DISPONIBLES) valor,',
'            2              orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            NULL          detalle,',
'            ''BLACK''       color,',
'            ''Trabajadas''  indicador,',
'            to_number(:P99_HRS_TRABAJADAS) valor,',
'            3             orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            NULL       detalle,',
'            ''BLACK''    color,',
'            ''Ociosas''  indicador,',
'            to_number(:P99_HRS_DISPONIBLES - :P99_HRS_TRABAJADAS) valor,',
'            4          orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            NULL          detalle,',
'            ''BLACK''       color,',
'            ''Facturadas''  indicador,',
'            to_number(:P99_HRS_FACTURADAS) valor,',
'            5             orden',
'        FROM',
'            dual',
'        UNION ALL',
'        SELECT',
'            NULL        detalle,',
'            ''BLACK''     color,',
'            ''Internas''  indicador,       ',
'            tal_ind_taller_nx.horas_int_f(',
'                :p99_empresa, ',
'                :p99_localizacion,',
'                :p99_inicio,',
'                :p99_fin',
'            ) valor,',
'            6           orden',
'        FROM',
'            dual',
'    )',
'ORDER BY',
'    orden'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002376072630407581)
,p_query_column_id=>1
,p_column_alias=>'DETALLE'
,p_column_display_sequence=>1
,p_column_heading=>'Detalle'
,p_column_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:RP::'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002376255901407583)
,p_query_column_id=>2
,p_column_alias=>'COLOR'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002375784185407578)
,p_query_column_id=>3
,p_column_alias=>'INDICADOR'
,p_column_display_sequence=>2
,p_column_heading=>'Indicador'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#INDICADOR#</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002375811496407579)
,p_query_column_id=>4
,p_column_alias=>'VALOR'
,p_column_display_sequence=>3
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_html_expression=>'<span style="font-weight:bold;color:#COLOR#;">#VALOR#</span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14002376136893407582)
,p_query_column_id=>5
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14095903278619681820)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003607871394811890)
,p_name=>'P99_HRS_TRABAJADAS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.horas_trab_f(:p99_empresa, :p99_localizacion, :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003607932100811891)
,p_name=>'P99_HRS_DISPONIBLES'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.horas_disp_f(:p99_empresa, :p99_localizacion, :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003608135220811893)
,p_name=>'P99_HRS_FACTURADAS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.horas_fac_f(:p99_empresa, :p99_localizacion, :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003608282158811894)
,p_name=>'P99_VTA_SERVICIOS'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.sum_ventas_ser_f(:p99_empresa, :p99_localizacion, :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003608323771811895)
,p_name=>'P99_VTA_REPUESTOS'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.sum_ventas_rep_f(:p99_empresa, :p99_localizacion, :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003671036355267346)
,p_name=>'P99_VTA_CONTADO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.sum_ventas_cc_f(:p99_empresa, :p99_localizacion, ''CON'', :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003671150182267347)
,p_name=>'P99_VTA_CREDITO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.sum_ventas_cc_f(:p99_empresa, :p99_localizacion, ''CRE'', :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003671228281267348)
,p_name=>'P99_VTA_INTERNAS'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.sum_ventas_cc_f(:p99_empresa, :p99_localizacion, ''NIT'', :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003671306324267349)
,p_name=>'P99_VTA_TOTAL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.sum_ventas_f(:p99_empresa, :p99_localizacion, :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003671451956267350)
,p_name=>'P99_UNID_TOTAL'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_use_cache_before_default=>'NO'
,p_source=>'return tal_ind_taller_nx.unid_fact_totales_n(:p99_empresa, :p99_localizacion, :p99_inicio, :p99_fin)'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P99_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095903546141681832)
,p_name=>'P99_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095903967482681847)
,p_name=>'P99_INICIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095904412637681847)
,p_name=>'P99_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096213156412091806)
,p_name=>'P99_LOCALIZACION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14095902841154681803)
,p_prompt=>'Sucursal'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (inv_descrip_loca_v_nx(ord_emp_empresa, ord_lcn_localizacion)||'' - ''||ord_lcn_localizacion) as d,',
'       ord_lcn_localizacion as r',
'FROM   tal_orden_servicio_vw_nx',
'WHERE  ord_emp_empresa = :P99_EMPRESA',
'GROUP  BY ord_emp_empresa, ord_lcn_localizacion',
'ORDER  BY ord_lcn_localizacion  '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Todas--'
,p_lov_cascade_parent_items=>'P99_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
