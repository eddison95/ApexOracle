prompt --application/pages/page_00170
begin
--   Manifest
--     PAGE: 00170
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>170
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Alistamiento'
,p_step_title=>'FAC - Alistamiento'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170102'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14203895421252671992)
,p_plug_name=>'Alistamientos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14203893632742661497)
,p_plug_name=>'Alistamientos'
,p_parent_plug_id=>wwv_flow_api.id(14203895421252671992)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT tra_transaccion,',
'       tra_fecha,',
'       tra_factura,',
'       tra_ven_vendedor,',
'       Fac_nom_vend_v_nx(tra_emp_empresa, tra_ven_vendedor)',
'       tra_ven_nombre,',
'       tra_cli_cliente,',
'       tra_nombre,',
'       Fac_estado_alisto_factura_v_nx(tra_emp_empresa, tra_transaccion)',
'       tra_alis_estado,',
'       det_ato_articulo,',
'       det_descripcion,',
'       det_cantidad,',
'       ( det_cantidad - det_cantidad_alisto )',
'       det_Saldo,',
'       tra_lcn_localizacion,',
'       Inv_descrip_loca_v_nx(tra_emp_empresa, tra_lcn_localizacion)',
'       tra_lcn_descripcion,',
'       CASE det_alistado',
'         WHEN 1 THEN ''SI''',
'         ELSE ''NO''',
'       END',
'       det_alistado,',
'       (SELECT Max(ali_id)',
'        FROM   fac_alisto_tb_nx,',
'               fac_detalle_alisto_tb_nx',
'        WHERE  ali_id = dal_ali_id',
'               AND ali_tra_transaccion = tra_transaccion',
'               AND dal_det_linea = det_linea)',
'       det_ali_id,',
'       (SELECT Max(ali_consecutivo)',
'        FROM   fac_alisto_tb_nx,',
'               fac_detalle_alisto_tb_nx',
'        WHERE  ali_id = dal_ali_id',
'               AND ali_tra_transaccion = tra_transaccion',
'               AND dal_det_linea = det_linea)',
'       det_ali_con,',
'       det_cantidad_alisto,',
'       det_alistado_por,',
'       det_fecha_alistado',
'FROM   fac_factura_tb_nx,',
'       fac_detalle_factura_tb_nx',
'WHERE  Instr ('':''',
'              || :P170_EMPRESA',
'              || '':'', '':''',
'                      || tra_emp_empresa',
'                      || '':'') > 0',
'       AND tra_transaccion = det_tra_transaccion',
'       AND tra_fecha BETWEEN :p170_inicio AND To_date (:p170_fin',
'                                                       || '' 23:59'',',
'                                              ''dd/mm/rrrr hh24:mi'')  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P170_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14203893716743661497)
,p_name=>'Reporte de Inventarios'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>238784011167117452
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000847066565807356)
,p_db_column_name=>'TRA_FECHA'
,p_display_order=>10
,p_column_identifier=>'AJ'
,p_column_label=>'F. Factura'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000847353157807359)
,p_db_column_name=>'TRA_TRANSACCION'
,p_display_order=>20
,p_column_identifier=>'AK'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000847433081807360)
,p_db_column_name=>'TRA_FACTURA'
,p_display_order=>30
,p_column_identifier=>'AL'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000847546616807361)
,p_db_column_name=>'TRA_VEN_VENDEDOR'
,p_display_order=>40
,p_column_identifier=>'AM'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000847609690807362)
,p_db_column_name=>'TRA_VEN_NOMBRE'
,p_display_order=>50
,p_column_identifier=>'AN'
,p_column_label=>'V. Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000847727970807363)
,p_db_column_name=>'TRA_CLI_CLIENTE'
,p_display_order=>60
,p_column_identifier=>'AO'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000847809644807364)
,p_db_column_name=>'TRA_NOMBRE'
,p_display_order=>70
,p_column_identifier=>'AP'
,p_column_label=>'C. Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848003193807365)
,p_db_column_name=>'TRA_ALIS_ESTADO'
,p_display_order=>80
,p_column_identifier=>'AQ'
,p_column_label=>'Estado Alis.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848068838807366)
,p_db_column_name=>'DET_ATO_ARTICULO'
,p_display_order=>90
,p_column_identifier=>'AR'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848201998807367)
,p_db_column_name=>'DET_DESCRIPCION'
,p_display_order=>100
,p_column_identifier=>'AS'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848281001807368)
,p_db_column_name=>'DET_CANTIDAD'
,p_display_order=>110
,p_column_identifier=>'AT'
,p_column_label=>'Cant. Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848356367807369)
,p_db_column_name=>'DET_SALDO'
,p_display_order=>120
,p_column_identifier=>'AU'
,p_column_label=>'Cant. Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848450532807370)
,p_db_column_name=>'TRA_LCN_LOCALIZACION'
,p_display_order=>130
,p_column_identifier=>'AV'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848586176807371)
,p_db_column_name=>'TRA_LCN_DESCRIPCION'
,p_display_order=>140
,p_column_identifier=>'AW'
,p_column_label=>'L. Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848675955807372)
,p_db_column_name=>'DET_ALISTADO'
,p_display_order=>150
,p_column_identifier=>'AX'
,p_column_label=>'Alistado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848728547807373)
,p_db_column_name=>'DET_ALI_ID'
,p_display_order=>160
,p_column_identifier=>'AY'
,p_column_label=>'Id Alistamiento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848871373807374)
,p_db_column_name=>'DET_ALI_CON'
,p_display_order=>170
,p_column_identifier=>'AZ'
,p_column_label=>'Consecutivo Alistamiento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000848927972807375)
,p_db_column_name=>'DET_CANTIDAD_ALISTO'
,p_display_order=>180
,p_column_identifier=>'BA'
,p_column_label=>'Cant. Alisto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000849073791807376)
,p_db_column_name=>'DET_ALISTADO_POR'
,p_display_order=>190
,p_column_identifier=>'BB'
,p_column_label=>'Alistado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000849148496807377)
,p_db_column_name=>'DET_FECHA_ALISTADO'
,p_display_order=>200
,p_column_identifier=>'BC'
,p_column_label=>'F. Alistado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14203894919043661846)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'360234'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>':TRA_FECHA:TRA_TRANSACCION:TRA_FACTURA:TRA_VEN_VENDEDOR:TRA_VEN_NOMBRE:TRA_CLI_CLIENTE:TRA_NOMBRE:TRA_ALIS_ESTADO:DET_ATO_ARTICULO:DET_DESCRIPCION:DET_CANTIDAD:DET_SALDO:TRA_LCN_LOCALIZACION:TRA_LCN_DESCRIPCION:DET_ALISTADO:DET_ALI_ID:DET_ALI_CON:DET'
||'_CANTIDAD_ALISTO:DET_ALISTADO_POR:DET_FECHA_ALISTADO'
,p_sort_column_1=>'ARTICULO'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14001121324339040298)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14203895421252671992)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000847106148807357)
,p_name=>'P170_INICIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14203895421252671992)
,p_prompt=>'Inicio'
,p_source=>'SELECT SYSDATE FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000847278535807358)
,p_name=>'P170_FIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14203895421252671992)
,p_prompt=>'Fin'
,p_source=>'SELECT SYSDATE FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14001122065744040332)
,p_name=>'P170_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14203895421252671992)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
