prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CGL \2013 Asientos')
,p_step_title=>'Asientos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163318'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193516557057230906)
,p_plug_name=>'Asientos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193513976625230896)
,p_plug_name=>'Asientos'
,p_parent_plug_id=>wwv_flow_api.id(14193516557057230906)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   c.det_empresa,',
'         c.det_asiento,',
'         c.det_subsistema,',
'         TRUNC (c.det_fecha) det_fecha,',
'         DECODE (c.det_estado,',
'                 1,',
'                 ''Subsistema'',',
'                 2,',
'                 ''Por Aplicar'',',
'                 3,',
'                 ''Autorizado'',',
'                 4,',
'                 ''Libros'',',
'                 5,',
'                 ''Historico'')',
'            det_estado,',
'         DECODE (c.det_tipo,',
'                 1,',
'                 ''Normal'',',
'                 2,',
'                 ''Automatico'',',
'                 3,',
'                 ''Subsistema'',',
'                 4,',
'                 ''Fijo'',',
'                 5,',
'                 ''Cierre Anual'')',
'            det_tipo,',
'         DECODE (c.det_contabilidad,',
'                 1,',
'                 ''Ambas'',',
'                 2,',
'                 ''Fiscal'',',
'                 3,',
'                 ''Corporativa'')',
'            det_contabilidad,',
'         DECODE (c.det_moneda,',
'                 1,',
'                 ''Ambas'',',
'                 2,',
'                 ''Local'',',
'                 3,',
'                 ''Alterna'')',
'            det_moneda,',
'         c.det_linea,',
'         c.det_emp_cuenta,',
'         c.det_cuenta,',
'         c.det_desc_cta,',
'         c.det_naturaleza,',
'         c.det_debe,',
'         c.det_haber,',
'         c.det_valor_cambio,',
'         c.det_debe_alt,',
'         c.det_haber_alt,',
'         c.det_fecha_doc,',
'         c.det_tipo_doc,',
'         c.det_documento,',
'         c.det_observaciones,',
'         c.det_creado_por,',
'         c.det_revisado_por,',
'         c.det_fecha_revision,',
'         c.det_aplicado_por,',
'         c.det_fecha_aplique,',
'         (SELECT LISTAGG(das_transaccion, '','')',
'                 WITHIN GROUP (ORDER BY das_transaccion) ',
'          FROM cgl_det_asiento_tran_vw_nx',
'          WHERE det_asiento= das_asto_asiento',
'          AND det_empresa= das_emp_empresa',
'          AND det_linea = das_consecutivo) das_transaccion',
'  FROM   cgl_detalle_asiento_vw_nx c',
' WHERE   INSTR ('':'' || :P12_EMPRESA || '':'', '':'' || det_empresa || '':'') > 0',
'         AND det_fecha BETWEEN :P12_INICIO',
'                           AND  TO_DATE (:P12_FIN || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P12_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14193514184170230898)
,p_name=>'Consulta de Asientos'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>7514832051045221
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193514252344230898)
,p_db_column_name=>'DET_ASIENTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Asiento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DET_ASIENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193514381623230899)
,p_db_column_name=>'DET_SUBSISTEMA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Subsistema'
,p_column_type=>'STRING'
,p_static_id=>'DET_SUBSISTEMA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193514468464230899)
,p_db_column_name=>'DET_FECHA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'DET_FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193514576372230900)
,p_db_column_name=>'DET_LINEA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DET_LINEA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193514676583230900)
,p_db_column_name=>'DET_EMP_CUENTA'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Empresa Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'DET_EMP_CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193514766650230900)
,p_db_column_name=>'DET_CUENTA'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'DET_CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193514876649230901)
,p_db_column_name=>'DET_DESC_CTA'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DET_DESC_CTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193514973511230901)
,p_db_column_name=>'DET_NATURALEZA'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Naturaleza'
,p_column_type=>'STRING'
,p_static_id=>'DET_NATURALEZA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515056171230901)
,p_db_column_name=>'DET_DEBE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Debe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DET_DEBE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515167820230902)
,p_db_column_name=>'DET_HABER'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Haber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DET_HABER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515282343230902)
,p_db_column_name=>'DET_VALOR_CAMBIO'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Valor Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DET_VALOR_CAMBIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515372808230902)
,p_db_column_name=>'DET_DEBE_ALT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Debe Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DET_DEBE_ALT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515473624230902)
,p_db_column_name=>'DET_HABER_ALT'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Haber Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DET_HABER_ALT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515569536230903)
,p_db_column_name=>'DET_FECHA_DOC'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'DET_FECHA_DOC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515681159230903)
,p_db_column_name=>'DET_TIPO_DOC'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_static_id=>'DET_TIPO_DOC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515861872230904)
,p_db_column_name=>'DET_OBSERVACIONES'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_static_id=>'DET_OBSERVACIONES'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193515984045230904)
,p_db_column_name=>'DET_MONEDA'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'DET_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193516071001230904)
,p_db_column_name=>'DET_CONTABILIDAD'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Contabilidad'
,p_column_type=>'STRING'
,p_static_id=>'DET_CONTABILIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193516171799230904)
,p_db_column_name=>'DET_ESTADO'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_static_id=>'DET_ESTADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193516258816230905)
,p_db_column_name=>'DET_TIPO'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'DET_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098671502162192136)
,p_db_column_name=>'DET_EMPRESA'
,p_display_order=>36
,p_column_identifier=>'AA'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583270305100321)
,p_db_column_name=>'DET_CREADO_POR'
,p_display_order=>46
,p_column_identifier=>'AB'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583334727100322)
,p_db_column_name=>'DET_REVISADO_POR'
,p_display_order=>56
,p_column_identifier=>'AC'
,p_column_label=>'Revisado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583488856100323)
,p_db_column_name=>'DET_FECHA_REVISION'
,p_display_order=>66
,p_column_identifier=>'AD'
,p_column_label=>'F. Revision'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583589096100324)
,p_db_column_name=>'DET_APLICADO_POR'
,p_display_order=>76
,p_column_identifier=>'AE'
,p_column_label=>'Aplicado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082583696343100325)
,p_db_column_name=>'DET_FECHA_APLIQUE'
,p_display_order=>86
,p_column_identifier=>'AF'
,p_column_label=>'F. Aplique'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058208989243913586)
,p_db_column_name=>'DET_DOCUMENTO'
,p_display_order=>96
,p_column_identifier=>'AG'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998662000378293191)
,p_db_column_name=>'DAS_TRANSACCION'
,p_display_order=>106
,p_column_identifier=>'AI'
,p_column_label=>'Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14193516379009230905)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75171'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'DET_EMPRESA:DET_ASIENTO:DET_SUBSISTEMA:DET_FECHA:DET_ESTADO:DET_TIPO:DET_CONTABILIDAD:DET_MONEDA:DET_LINEA:DET_EMP_CUENTA:DET_CUENTA:DET_DESC_CTA:DET_NATURALEZA:DET_DEBE:DET_HABER:DET_VALOR_CAMBIO:DET_DEBE_ALT:DET_HABER_ALT:DET_FECHA_DOC:DET_TIPO_DOC'
||':DET_OBSERVACIONES:DET_CREADO_POR:DET_REVISADO_POR:DET_FECHA_REVISION:DET_APLICADO_POR:DET_FECHA_APLIQUE:DET_DOCUMENTO:DAS_TRANSACCION:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168168415820668739)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14193516557057230906)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193516783328230906)
,p_name=>'P12_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14193516557057230906)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193516968876230911)
,p_name=>'P12_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14193516557057230906)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193517174022230915)
,p_name=>'P12_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14193516557057230906)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
