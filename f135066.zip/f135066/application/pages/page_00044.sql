prompt --application/pages/page_00044
begin
--   Manifest
--     PAGE: 00044
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>44
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Listado de Pedidos'
,p_step_title=>'Listado de Pedidos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163943'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14168097116079520203)
,p_plug_name=>'Listado de Pedidos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14168098314831520212)
,p_plug_name=>'Listado de Pedidos'
,p_parent_plug_id=>wwv_flow_api.id(14168097116079520203)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT	enc_emp_empresa empresa,',
'			enc_consulta pedido,',
'			TRUNC (enc_fecha) fecha,',
'			enc_mon_moneda moneda,',
'			enc_cli_cliente cliente,',
'			enc_nombre nombre_cliente,',
'			enc_lpo_lista lista_precio,',
'			enc_lcn_localizacion localizacion,',
'			enc_orden_compra ORDEN_COMPRA,',
'            enc_observaciones,',
'			enc_status estado,',
'			enc_ven_vendedor vendedor,',
'			gnl_nombre_vendedor_vi (enc_emp_empresa, enc_ven_vendedor)',
'				nombre_vendedor,',
'			(SELECT	 SUM( ( (deo_precio * deo_cantidad) + deo_impuesto)',
'							  - deo_descuento)',
'				FROM	 fac_detalle_consulta_tb_nx',
'			  WHERE	 deo_enc_consulta = enc_consulta)',
'				total',
'  FROM	fac_consulta_tb_nx',
'  WHERE ENC_FECHA BETWEEN :P44_INICIO AND to_date(:P44_FIN||'' 23:59'', ''dd/mm/rrrr hh24:mi'')',
'  AND   INSTR ('':'' || :P44_EMPRESA || '':'', '':'' || ENC_EMP_EMPRESA || '':'') > 0',
'  AND   ENC_CONSULTA = NVL(:P44_TRANSACCION, ENC_CONSULTA)',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P44_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14168098495683520214)
,p_name=>'Maestro Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.:RP:P44_TRANSACCION:#PEDIDO#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10984602272020914
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168103098849647723)
,p_db_column_name=>'PEDIDO'
,p_display_order=>10
,p_column_identifier=>'O'
,p_column_label=>'Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PEDIDO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168099003231520221)
,p_db_column_name=>'VENDEDOR'
,p_display_order=>20
,p_column_identifier=>'E'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'VENDEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168099115142520222)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
,p_static_id=>'LOCALIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168099222361520222)
,p_db_column_name=>'FECHA'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168099813538520224)
,p_db_column_name=>'TOTAL'
,p_display_order=>50
,p_column_identifier=>'M'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'TOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168103016964647721)
,p_db_column_name=>'EMPRESA'
,p_display_order=>60
,p_column_identifier=>'N'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168103219769647723)
,p_db_column_name=>'MONEDA'
,p_display_order=>70
,p_column_identifier=>'P'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168103296154647723)
,p_db_column_name=>'CLIENTE'
,p_display_order=>80
,p_column_identifier=>'Q'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168103414390647724)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>90
,p_column_identifier=>'R'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE_CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168103501378647724)
,p_db_column_name=>'LISTA_PRECIO'
,p_display_order=>100
,p_column_identifier=>'S'
,p_column_label=>'Lista Precio'
,p_column_type=>'STRING'
,p_static_id=>'LISTA_PRECIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168103696964647725)
,p_db_column_name=>'ESTADO'
,p_display_order=>110
,p_column_identifier=>'U'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_static_id=>'ESTADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168104200789655128)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>130
,p_column_identifier=>'W'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_static_id=>'ORDEN_COMPRA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086451901601262472)
,p_db_column_name=>'NOMBRE_VENDEDOR'
,p_display_order=>140
,p_column_identifier=>'X'
,p_column_label=>'Nombre Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001217395277589487)
,p_db_column_name=>'ENC_OBSERVACIONES'
,p_display_order=>150
,p_column_identifier=>'Y'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14168100013155520225)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'109862'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>'EMPRESA:PEDIDO:FECHA:VENDEDOR:NOMBRE_VENDEDOR:LOCALIZACION:TOTAL:MONEDA:CLIENTE:NOMBRE_CLIENTE:LISTA_PRECIO:ORDEN_COMPRA:ESTADO::ENC_OBSERVACIONES'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14168100209076520228)
,p_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_api.id(14168098314831520212)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT	deo_enc_consulta pedido,',
'			deo_lcn_localizacion localizacion,',
'			deo_ato_articulo articulo,',
'			inv_descrip_art_v_nx (deo_emp_empresa, deo_ato_articulo) descripcion,',
'			deo_cantidad cantidad,',
'			deo_precio precio,',
'			(deo_cantidad * deo_precio) subtotal,',
'			deo_descuento porcentaje_descuento,',
'			(deo_precio * deo_descuento / 100) descuento,',
'			deo_impuesto impuesto,',
'			( ( (deo_precio * deo_cantidad) + deo_impuesto) - deo_descuento)',
'				total',
'  FROM	fac_detalle_consulta_tb_nx',
'  WHERE DEO_ENC_CONSULTA = :P44_TRANSACCION'))
,p_display_when_condition=>'P44_TRANSACCION'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_footer=>'</div>'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_prn_output_show_link=>'Y'
,p_prn_output_link_text=>'Print'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>320
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168104404203699138)
,p_query_column_id=>1
,p_column_alias=>'PEDIDO'
,p_column_display_sequence=>8
,p_column_heading=>'Pedido'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168104517004699139)
,p_query_column_id=>2
,p_column_alias=>'LOCALIZACION'
,p_column_display_sequence=>9
,p_column_heading=>'Localizacion'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168101022072520231)
,p_query_column_id=>3
,p_column_alias=>'ARTICULO'
,p_column_display_sequence=>1
,p_column_heading=>'Articulo'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168101095702520231)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_column_heading=>'Descripcion'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168101507418520232)
,p_query_column_id=>5
,p_column_alias=>'CANTIDAD'
,p_column_display_sequence=>3
,p_column_heading=>'Cantidad'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168104604554699139)
,p_query_column_id=>6
,p_column_alias=>'PRECIO'
,p_column_display_sequence=>10
,p_column_heading=>'Precio'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168101907175520232)
,p_query_column_id=>7
,p_column_alias=>'SUBTOTAL'
,p_column_display_sequence=>5
,p_column_heading=>'Subtotal'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168108623304070090)
,p_query_column_id=>8
,p_column_alias=>'PORCENTAJE_DESCUENTO'
,p_column_display_sequence=>11
,p_column_heading=>'Porcentaje Descuento'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168101808413520232)
,p_query_column_id=>9
,p_column_alias=>'DESCUENTO'
,p_column_display_sequence=>4
,p_column_heading=>'Descuento'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G990'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168102017430520232)
,p_query_column_id=>10
,p_column_alias=>'IMPUESTO'
,p_column_display_sequence=>6
,p_column_heading=>'Impuesto'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14168102116712520232)
,p_query_column_id=>11
,p_column_alias=>'TOTAL'
,p_column_display_sequence=>7
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_print_col_width=>'7'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168179723951850634)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14168097116079520203)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14086451823106262471)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14168098314831520212)
,p_button_name=>'RESTABLECER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Restablecer'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.:RP,44::'
,p_button_condition=>'P44_TRANSACCION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168097301741520208)
,p_name=>'P44_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14168097116079520203)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168097498269520209)
,p_name=>'P44_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14168097116079520203)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168097697810520209)
,p_name=>'P44_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14168097116079520203)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168098112008520210)
,p_name=>'P44_TRANSACCION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14168097116079520203)
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
