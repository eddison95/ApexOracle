prompt --application/pages/page_00157
begin
--   Manifest
--     PAGE: 00157
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>157
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CGL - Libro de Ventas y Compras Encabezado'
,p_step_title=>'CGL - Libro de Ventas y Compras Encabezado'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165848'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14110499112188157590)
,p_plug_name=>'Libro de Impuestos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14110480107363975147)
,p_plug_name=>'Libro de Impuestos'
,p_parent_plug_id=>wwv_flow_api.id(14110499112188157590)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   c001 libro,',
'         TO_NUMBER(c002) subtotal1,',
'         c003 empresa,',
'         c004 fecha_documento,',
'         c005 subsistema,',
'         c006 tipo_transaccion,',
'         c007 codigo,',
'         c008 persona,',
'         c009 nombre,',
'         c010 numero_documento,',
'         c011 departamento,',
'         c012 nombre_depto,',
'         c013 trx_transaccion,',
'         c014 tra_transaccion,',
'         c015 ncd_transaccion,',
'         c016 tsn_transaccion,',
'         c017 ced_etapa,',
'         c018 ced_entrega,',
'         c019 tsp_transaccion,',
'         c020 fecha_transaccion,',
'         TO_NUMBER (c021) base,',
'         TO_NUMBER (c022) exento,',
'         TO_NUMBER (c023) exoneradas,',
'         TO_NUMBER (c024) subtotal,',
'         TO_NUMBER (c025) descuento,',
'         TO_NUMBER (c026) impuesto,',
'         TO_NUMBER (c027) otros_impuestos,',
'         TO_NUMBER (c028) retencion,',
'         TO_NUMBER (c029) total,',
'         c030 actividad_economica,',
'         TO_NUMBER (c031) lic_iva_descontable,',
'         TO_NUMBER (c032) lic_iva_no_desc_costo,',
'         TO_NUMBER (c033) lic_iva_no_desc_gasto,',
'         TO_NUMBER (c034) liv_iva_general,',
'         TO_NUMBER (c035) liv_iva_red_n1,',
'         TO_NUMBER (c036) liv_iva_red_n2,',
'         TO_NUMBER (c037) liv_iva_red_n3,',
'         TO_NUMBER (c038) liv_retencion_iva,',
'         TO_NUMBER (c039) liv_iva_no_cobrado,',
'         TO_NUMBER (c040) tarifa_1,',
'         TO_NUMBER (c041) tarifa_2,',
'         TO_NUMBER (c042) tarifa_3,',
'         TO_NUMBER (c043) tarifa_4,',
'         TO_NUMBER (c044) tarifa_5,',
'         TO_NUMBER (c045) tarifa_6,',
'         TO_NUMBER (c046) tarifa_7,',
'         TO_NUMBER (c047) tarifa_8,',
'         TO_NUMBER(c048) flete,',
'         c049 cedula',
'  FROM   APEX_collections',
' WHERE   collection_name = ''LIBROS'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P157_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14110480176359975148)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>63888326231501236
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058945563369497255)
,p_db_column_name=>'EMPRESA'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058947981674497265)
,p_db_column_name=>'NOMBRE'
,p_display_order=>80
,p_column_identifier=>'X'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058946806231497260)
,p_db_column_name=>'TIPO_TRANSACCION'
,p_display_order=>210
,p_column_identifier=>'F'
,p_column_label=>'T. Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058946446824497258)
,p_db_column_name=>'SUBSISTEMA'
,p_display_order=>220
,p_column_identifier=>'E'
,p_column_label=>'Subsistema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058928525963497168)
,p_db_column_name=>'LIBRO'
,p_display_order=>230
,p_column_identifier=>'Z'
,p_column_label=>'Libro'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058929298837497172)
,p_db_column_name=>'CODIGO'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058929957429497179)
,p_db_column_name=>'NUMERO_DOCUMENTO'
,p_display_order=>270
,p_column_identifier=>'AD'
,p_column_label=>'Numero documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058930377378497181)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>280
,p_column_identifier=>'AE'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058932384503497192)
,p_db_column_name=>'BASE'
,p_display_order=>430
,p_column_identifier=>'BI'
,p_column_label=>'Base'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058932844984497194)
,p_db_column_name=>'EXENTO'
,p_display_order=>440
,p_column_identifier=>'BJ'
,p_column_label=>'Exento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058933217634497196)
,p_db_column_name=>'EXONERADAS'
,p_display_order=>450
,p_column_identifier=>'BK'
,p_column_label=>'Exoneradas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058933572257497199)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>460
,p_column_identifier=>'BL'
,p_column_label=>'Venta Bruta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058934026177497202)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>470
,p_column_identifier=>'BM'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058934419938497203)
,p_db_column_name=>'IMPUESTO'
,p_display_order=>480
,p_column_identifier=>'BN'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058934799773497205)
,p_db_column_name=>'OTROS_IMPUESTOS'
,p_display_order=>490
,p_column_identifier=>'BO'
,p_column_label=>'Otros impuestos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058935158581497206)
,p_db_column_name=>'RETENCION'
,p_display_order=>500
,p_column_identifier=>'BP'
,p_column_label=>'Retencion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058935567553497207)
,p_db_column_name=>'TOTAL'
,p_display_order=>510
,p_column_identifier=>'BQ'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058939245895497226)
,p_db_column_name=>'LIC_IVA_DESCONTABLE'
,p_display_order=>610
,p_column_identifier=>'CH'
,p_column_label=>'IVA Descontable'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058939647022497228)
,p_db_column_name=>'LIC_IVA_NO_DESC_COSTO'
,p_display_order=>620
,p_column_identifier=>'CI'
,p_column_label=>'IVA No Descontable Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058940367680497232)
,p_db_column_name=>'LIV_IVA_GENERAL'
,p_display_order=>640
,p_column_identifier=>'CK'
,p_column_label=>'IVA General'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058940779911497234)
,p_db_column_name=>'LIV_IVA_RED_N1'
,p_display_order=>650
,p_column_identifier=>'CL'
,p_column_label=>'Tarifa Reducida 4%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058941173312497236)
,p_db_column_name=>'LIV_IVA_RED_N2'
,p_display_order=>660
,p_column_identifier=>'CM'
,p_column_label=>'Tarifa Reducida 2%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058941554094497237)
,p_db_column_name=>'LIV_IVA_RED_N3'
,p_display_order=>670
,p_column_identifier=>'CN'
,p_column_label=>'Tarifa Reducida 1% o Transitorio 0%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058942015109497239)
,p_db_column_name=>'LIV_RETENCION_IVA'
,p_display_order=>680
,p_column_identifier=>'CO'
,p_column_label=>unistr('Retenci\00F3n IVA')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058942411678497241)
,p_db_column_name=>'LIV_IVA_NO_COBRADO'
,p_display_order=>690
,p_column_identifier=>'CP'
,p_column_label=>'IVA No Cobrado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058945233667497252)
,p_db_column_name=>'ACTIVIDAD_ECONOMICA'
,p_display_order=>760
,p_column_identifier=>'CW'
,p_column_label=>unistr('Actividad Econ\00F3mica')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049615163743523633)
,p_db_column_name=>'FECHA_DOCUMENTO'
,p_display_order=>810
,p_column_identifier=>'DD'
,p_column_label=>'Fecha documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049615306051523634)
,p_db_column_name=>'PERSONA'
,p_display_order=>820
,p_column_identifier=>'DE'
,p_column_label=>'Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049615380961523635)
,p_db_column_name=>'TRX_TRANSACCION'
,p_display_order=>830
,p_column_identifier=>'DF'
,p_column_label=>'Trx transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049615523775523636)
,p_db_column_name=>'TRA_TRANSACCION'
,p_display_order=>840
,p_column_identifier=>'DG'
,p_column_label=>'Tra transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049615615301523637)
,p_db_column_name=>'NCD_TRANSACCION'
,p_display_order=>850
,p_column_identifier=>'DH'
,p_column_label=>'Ncd transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049615669961523638)
,p_db_column_name=>'TSN_TRANSACCION'
,p_display_order=>860
,p_column_identifier=>'DI'
,p_column_label=>'Tsn transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049615770274523639)
,p_db_column_name=>'CED_ETAPA'
,p_display_order=>870
,p_column_identifier=>'DJ'
,p_column_label=>'Ced etapa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049615918292523640)
,p_db_column_name=>'CED_ENTREGA'
,p_display_order=>880
,p_column_identifier=>'DK'
,p_column_label=>'Ced entrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049616080751523642)
,p_db_column_name=>'TSP_TRANSACCION'
,p_display_order=>900
,p_column_identifier=>'DM'
,p_column_label=>'Tsp transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049616238330523643)
,p_db_column_name=>'FECHA_TRANSACCION'
,p_display_order=>910
,p_column_identifier=>'DN'
,p_column_label=>'Fecha transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049616566822523647)
,p_db_column_name=>'NOMBRE_DEPTO'
,p_display_order=>950
,p_column_identifier=>'DR'
,p_column_label=>'Nombre depto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049617638680523657)
,p_db_column_name=>'LIC_IVA_NO_DESC_GASTO'
,p_display_order=>1050
,p_column_identifier=>'EB'
,p_column_label=>'Lic iva no desc gasto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049617713554523658)
,p_db_column_name=>'TARIFA_1'
,p_display_order=>1060
,p_column_identifier=>'EC'
,p_column_label=>'Tarifa 0% (Exento)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049617765995523659)
,p_db_column_name=>'TARIFA_2'
,p_display_order=>1070
,p_column_identifier=>'ED'
,p_column_label=>'Tarifa reducida 1%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049617924341523660)
,p_db_column_name=>'TARIFA_3'
,p_display_order=>1080
,p_column_identifier=>'EE'
,p_column_label=>'Tarifa reducida 2%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049618045568523661)
,p_db_column_name=>'TARIFA_4'
,p_display_order=>1090
,p_column_identifier=>'EF'
,p_column_label=>'Tarifa reducida 4%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049618144489523662)
,p_db_column_name=>'TARIFA_5'
,p_display_order=>1100
,p_column_identifier=>'EG'
,p_column_label=>'Transitorio 0%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049792366415111913)
,p_db_column_name=>'TARIFA_6'
,p_display_order=>1110
,p_column_identifier=>'EH'
,p_column_label=>'Transitorio 4%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049792455508111914)
,p_db_column_name=>'TARIFA_7'
,p_display_order=>1120
,p_column_identifier=>'EI'
,p_column_label=>'Transitorio 8%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049792562204111915)
,p_db_column_name=>'TARIFA_8'
,p_display_order=>1130
,p_column_identifier=>'EJ'
,p_column_label=>'Tarifa general 13%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049792715257111916)
,p_db_column_name=>'FLETE'
,p_display_order=>1140
,p_column_identifier=>'EK'
,p_column_label=>'Flete'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049792796432111917)
,p_db_column_name=>'CEDULA'
,p_display_order=>1150
,p_column_identifier=>'EL'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049792972641111919)
,p_db_column_name=>'SUBTOTAL1'
,p_display_order=>1160
,p_column_identifier=>'EN'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14110537071833182538)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'123565'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMPRESA:NOMBRE:TIPO_TRANSACCION:SUBSISTEMA:LIBRO:CODIGO:NUMERO_DOCUMENTO:DEPARTAMENTO:IND_SUBIND_MONEDA:BASE:EXENTO:EXONERADAS:SUBDESCUENTO:IMPUESTO_IMPUESTOS:RETENCION:TOTAL:LIC_IVA_DESCONTABLE:LIC_IVA_NO_DESC_COSTO:LIV_IVA_GENERAL:LIV_IVA_RED_N1:LI'
||'V_IVA_RED_N2:LIV_IVA_RED_N3:LIV_RETENCION_IVA:LIV_IVA_NO_COBRADO:ACTIVIDAD_ECONOMICA:NOMBRE_DEPTO:TARIFA_1:TARIFA_2:TARIFA_3:TARIFA_4:TARIFA_5:TARIFA_6:TARIFA_7:TARIFA_8:FLETE:CEDULA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14058948985877497292)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14110499112188157590)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14058949446331497292)
,p_name=>'P157_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14110499112188157590)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14058949812770497294)
,p_name=>'P157_INICIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14110499112188157590)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14058950184572497294)
,p_name=>'P157_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14110499112188157590)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14049615036560523631)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'llena_reporte'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'cgl_libros_rep_pr_nx(',
'   :P157_EMPRESA,',
'   :P157_INICIO,',
'   :P157_FIN',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
