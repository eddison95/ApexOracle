prompt --application/pages/page_00094
begin
--   Manifest
--     PAGE: 00094
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>94
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CRM - Etapas por Oportunidad'
,p_step_title=>'Etapas por Oportunidad'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164744'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096895035181614124)
,p_plug_name=>'Etapas por Oportunidad'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095627455518871760)
,p_plug_name=>'Etapas por Oportunidad'
,p_parent_plug_id=>wwv_flow_api.id(14096895035181614124)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 16/02/2017 04:36:45 p.m. (QP5 v5.115.810.9015) */',
'SELECT   COMPANY,',
'         FOLLOW_UPS.ID AS ID,',
'         OPPORTUNITIES.NAME AS OPPORTUNITY,',
'         FOLLOW_UPS.SECUENCE AS SECUENCE,',
'         FOLLOW_UPS.NAME AS NAME,',
'         FOLLOW_UPS.DESCRIPTION AS DESCRIPTION,',
'         FOLLOW_UPS.COMMENTS AS COMMENTS,',
'         TRUNC (FOLLOW_UPS.CREATED) AS CREATED,',
'         TRUNC (FOLLOW_UPS.MODIFIED) AS MODIFIED,',
'         FOLLOW_UPS.PREDECESSOR AS PREDECESSOR,',
'         FOLLOW_UPS.PREDECESSOR_REQUIRED AS PREDECESSOR_REQUIRED,',
'         DECODE (FOLLOW_UPS.STATUS,',
'                 1,',
'                 ''Finalizada'',',
'                 2,',
'                 ''Iniciada'',',
'                 3,',
'                 ''No Iniciada'')',
'            AS STATUS,',
'         TRUNC (FOLLOW_UPS.START_DATE) AS START_DATE,',
'         TRUNC (FOLLOW_UPS.END_DATE) AS END_DATE,',
'         FOLLOW_UPS.ORIGINAL_SECUENCE AS ORIGINAL_SECUENCE,',
'         FOLLOW_UPS.ORDERS AS ORDERS,',
'         FOLLOW_UPS.REQUIRED AS REQUIRED,',
'         DECODE (OPPORTUNITIES.STATUS,',
'                 1,',
'                 ''En Proceso'',',
'                 2,',
'                 ''Ganada'',',
'                 3,',
'                 ''Perdida'',',
'                 4,',
'                 ''Desierta'',',
'                 5,',
unistr('                 ''Cr\00E9dito en Estudio'','),
'                 8,',
'                 ''Precalificado'',',
'                 7,',
unistr('                 ''Cr\00E9dito Rechazado'','),
'                 6,',
unistr('                 ''Cr\00E9dito Condicionado'','),
'                 9,',
unistr('                 ''Cr\00E9dito Aprobado'')'),
'            AS STATUS_OPPORTUNITIES,',
'            ORGANIZATIONS.NAME',
'         || '' ''',
'         || ORGANIZATIONS.FIRST_NAME',
'         || '' ''',
'         || ORGANIZATIONS.LAST_NAME',
'            CUENTA,',
'         ADVERTISING_ORIGIN.NAME ENTERO_PRODUCTO,',
'         REFERRALS.NAME ORIG_OPPORT',
'  FROM   FOLLOW_UPS FOLLOW_UPS,',
'         OPPORTUNITIES OPPORTUNITIES,',
'         ORGANIZATIONS ORGANIZATIONS,',
'         ADVERTISING_ORIGIN ADVERTISING_ORIGIN,',
'         REFERRALS REFERRALS',
' WHERE       INSTR ('':'' || :P94_EMPRESA || '':'', '':'' || COMPANY || '':'') > 0',
'         AND FOLLOW_UPS.OPPORTUNITY = OPPORTUNITIES.ID',
'         AND OPPORTUNITIES.ORGANIZATION = ORGANIZATIONS.ID',
'         AND OPPORTUNITIES.ADVERTISING_ORIGIN = ADVERTISING_ORIGIN.ID',
'         AND OPPORTUNITIES.REFERRAL = REFERRALS.ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P94_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095627895526871761)
,p_name=>'Ventas Diarias'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>7884170754982667
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095630337918871772)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'CI'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095629602198871771)
,p_db_column_name=>'CREATED'
,p_display_order=>80
,p_column_identifier=>'CF'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498585627481437)
,p_db_column_name=>'ID'
,p_display_order=>90
,p_column_identifier=>'CJ'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498688932481438)
,p_db_column_name=>'OPPORTUNITY'
,p_display_order=>100
,p_column_identifier=>'CK'
,p_column_label=>'Oportunidad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498783296481439)
,p_db_column_name=>'SECUENCE'
,p_display_order=>110
,p_column_identifier=>'CL'
,p_column_label=>'Secuencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498851466481440)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>120
,p_column_identifier=>'CM'
,p_column_label=>'Descripcion'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498950128481441)
,p_db_column_name=>'COMMENTS'
,p_display_order=>130
,p_column_identifier=>'CN'
,p_column_label=>'Comentarios'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095499061496481442)
,p_db_column_name=>'MODIFIED'
,p_display_order=>140
,p_column_identifier=>'CO'
,p_column_label=>'F. Modificacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095499168228481443)
,p_db_column_name=>'PREDECESSOR'
,p_display_order=>150
,p_column_identifier=>'CP'
,p_column_label=>'Predecesor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095499301470481444)
,p_db_column_name=>'PREDECESSOR_REQUIRED'
,p_display_order=>160
,p_column_identifier=>'CQ'
,p_column_label=>'Predecesor Requerido'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095633275672928895)
,p_db_column_name=>'STATUS'
,p_display_order=>170
,p_column_identifier=>'CR'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095633333647928896)
,p_db_column_name=>'START_DATE'
,p_display_order=>180
,p_column_identifier=>'CS'
,p_column_label=>'F. Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095633491053928897)
,p_db_column_name=>'END_DATE'
,p_display_order=>190
,p_column_identifier=>'CT'
,p_column_label=>'F. Final'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095633592374928898)
,p_db_column_name=>'ORIGINAL_SECUENCE'
,p_display_order=>200
,p_column_identifier=>'CU'
,p_column_label=>'Secuencia Original'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095633638441928899)
,p_db_column_name=>'ORDERS'
,p_display_order=>210
,p_column_identifier=>'CV'
,p_column_label=>'Ordenes'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095633821606928900)
,p_db_column_name=>'REQUIRED'
,p_display_order=>220
,p_column_identifier=>'CW'
,p_column_label=>'Requerido'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669689914192118)
,p_db_column_name=>'COMPANY'
,p_display_order=>230
,p_column_identifier=>'CX'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669799126192119)
,p_db_column_name=>'STATUS_OPPORTUNITIES'
,p_display_order=>240
,p_column_identifier=>'CY'
,p_column_label=>'Estado Oportunidad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669874505192120)
,p_db_column_name=>'CUENTA'
,p_display_order=>250
,p_column_identifier=>'CZ'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669932659192121)
,p_db_column_name=>'ENTERO_PRODUCTO'
,p_display_order=>260
,p_column_identifier=>'DA'
,p_column_label=>unistr('Descubri\00F3 el Producto por:')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098670034315192122)
,p_db_column_name=>'ORIG_OPPORT'
,p_display_order=>270
,p_column_identifier=>'DB'
,p_column_label=>'Orig. Oportunidad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095630767119871773)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'78871'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'COMPANY:ID:SECUENCE:ORIGINAL_SECUENCE:NAME:DESCRIPTION:OPPORTUNITY:COMMENTS:CREATED:MODIFIED:START_DATE:END_DATE:STATUS:PREDECESSOR:PREDECESSOR_REQUIRED:ORDERS:REQUIRED:CUENTA:STATUS_OPPORTUNITIES:ENTERO_PRODUCTO:ORIG_OPPORT:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096895334262614125)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14096895035181614124)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096895802302614126)
,p_name=>'P94_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096895035181614124)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
