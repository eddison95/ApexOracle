prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>24
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CXC \2013 Snapshot Saldos')
,p_step_title=>'Snapshot Saldos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'MBACASE'
,p_last_upd_yyyymmddhh24miss=>'20201221125714'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193586665435227194)
,p_plug_name=>'Snapshot Saldos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13932075977512672445)
,p_plug_name=>'Detalle Recibos de Pago'
,p_parent_plug_id=>wwv_flow_api.id(14193586665435227194)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select solicitud,padre,num_doc,documento,fecha,cuota,TO_NUMBER(monto_total) monto_total, mora_cobrada, STATUS, ',
'TO_NUMBER(DECODE (STATUS, ''P'', monto_total, 0)) MONTO_PENDIENTES ',
'from CXC_ESTADO_CUENTA_FIN_VW_NX',
'where padre <> 0',
'and cuota is null',
'and status in (''P'',''L'')',
'AND solicitud= :P24_SOLICITUD',
'ORDER BY padre'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="margin-top: 20px;">',
unistr('    <p style="font-weight:bold;">Detalle Cancelaci\00F3n Cuotas </p>'),
'        ',
'    </div>'))
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13932076101840672446)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>4486174995801742
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932076199120672447)
,p_db_column_name=>'SOLICITUD'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Solicitud'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932076308870672448)
,p_db_column_name=>'PADRE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Padre'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932076377201672449)
,p_db_column_name=>'NUM_DOC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Num Doc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932076430924672450)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932076528950672451)
,p_db_column_name=>'FECHA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932076673712672452)
,p_db_column_name=>'CUOTA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cuota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932076891756672454)
,p_db_column_name=>'MORA_COBRADA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Mora Cobrada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932124521249244305)
,p_db_column_name=>'STATUS'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932076735197672453)
,p_db_column_name=>'MONTO_TOTAL'
,p_display_order=>100
,p_column_identifier=>'G'
,p_column_label=>'Monto Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932124553050244306)
,p_db_column_name=>'MONTO_PENDIENTES'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Monto Pendientes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13932133434459245498)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'45436'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SOLICITUD:PADRE:NUM_DOC:DOCUMENTO:FECHA:CUOTA:MORA_COBRADA:STATUS:MONTO_TOTAL:MONTO_PENDIENTES:'
,p_sum_columns_on_break=>'MONTO_TOTAL:MONTO_PENDIENTES'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193584271410227176)
,p_plug_name=>'Snapshot Saldos'
,p_parent_plug_id=>wwv_flow_api.id(14193586665435227194)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' /* Formatted on 27/03/2017 02:51:18 p.m. (QP5 v5.115.810.9015) */',
'SELECT  ''consultar'' consulta,',
'         C.SNP_ID,',
'         C.SNP_EMP_EMPRESA,',
'         TRUNC (C.SNP_FECHA_CREACION) SNP_FECHA_CREACION,',
'         C.SNP_TRX_TRANSACCION,',
'         DECODE (C.SNP_TIPO_CUENTA,',
'                 ''C'',',
'                 ''CORRIENTE'',',
'                 ''A'',',
'                 ''ANTICIPOS'',',
'                 ''E'',',
'                 ''EFECTOS'',',
'                 ''F'',',
'                 ''FINANCIAMIENTO'')',
'            t_cuenta,',
'         C.SNP_TTC_TIPO,',
'         C.SNP_TTC_SIGNO,',
'         C.SNP_MONTO,',
'         C.SNP_SALDO,',
'         C.SNP_MONTO_MORA,',
'         C.SNP_PPG_SOLICITUD,',
'         C.SNP_PPG_CUOTA,',
'         C.SNP_PPG_MONTO_PRINCIPAL,',
'         C.SNP_PPG_SALDO_PRINCIPAL,',
'         C.SNP_PPG_MONTO_INTERES,',
'         C.SNP_PPG_SALDO_INTERES,',
'         C.SNP_PPG_MONTO_MORA,',
'         TO_NUMBER(C.SNP_PPG_MONTO_PRINCIPAL+ C.SNP_PPG_MONTO_INTERES) monto_cuota,',
'         cxc_nombre_cli_v_nx (B.trx_emp_empresa,',
'                              B.trx_cli_cliente,',
'                              B.trx_cli_mon_moneda)',
'            nombre,',
'         cxc_clase_cli_v_nx (B.trx_emp_empresa,',
'                             B.trx_cli_cliente,',
'                             B.trx_cli_mon_moneda)',
'            clase,',
'        scr_solicitud solicitud,',
'        (CASE scr_status_final WHEN ''N'' THEN ''NA''',
'        WHEN ''S'' THEN ''SUSPENSO''',
'        WHEN ''A'' THEN ''APROBADA''',
'        WHEN ''R'' THEN ''RECHAZADA''',
'        ELSE ''LIQUIDADA'' END) estado_financiamiento,',
'         (select SUM(monto_total)  ',
'from CXC_ESTADO_CUENTA_FIN_VW_NX',
'where padre <> 0',
'and cuota is null',
'and status in (''P'') ',
'AND solicitud= D.scr_solicitud AND empresa = C.SNP_EMP_EMPRESA',
'AND padre = C.SNP_PPG_CUOTA',
'       AND TRUNC(fecha) <= TRUNC (C.SNP_FECHA_CREACION) ) abono,',
'        (',
'                select SUM(saldo_total)  ',
'            from CXC_ESTADO_CUENTA_FIN_VW_NX',
'            where padre <> 0',
'            --and cuota is null',
'            and status in (''P'') ',
'            AND cuota IS NOT NULL',
'AND solicitud= D.scr_solicitud AND empresa = C.SNP_EMP_EMPRESA',
'AND padre = C.SNP_PPG_CUOTA ',
'        ) +  NVL((select SUM(monto_total  )',
'from CXC_ESTADO_CUENTA_FIN_VW_NX',
'where padre <> 0',
'and cuota is null',
'and status in (''P'') ',
'AND solicitud= D.scr_solicitud AND empresa = C.SNP_EMP_EMPRESA',
'AND padre = C.SNP_PPG_CUOTA',
'       AND TRUNC(fecha) > TRUNC (C.SNP_FECHA_CREACION) ),0)  por_aplicar',
'  FROM   CXC_SNAPSHOT_SALDOS_TB_NX C,',
'         cxc_transaccion_tb_nx B,',
'         cxc_cliente_tb_nx X,',
'         cxc_solicitud_y_cxc_tb_nx D',
'         WHERE       INSTR ('':'' || :P24_EMPRESA || '':'',',
'                    '':'' || C.SNP_EMP_EMPRESA || '':'') > 0',
'         AND C.SNP_EMP_EMPRESA = B.TRX_EMP_EMPRESA(+)',
'         AND C.SNP_TRX_TRANSACCION = B.TRX_TRANSACCION(+)',
'         AND B.TRX_CLI_CLIENTE = X.CLI_CLIENTE(+)',
'         AND B.TRX_CLI_MON_MONEDA = X.CLI_MON_MONEDA(+)',
'         AND B.TRX_EMP_EMPRESA = X.CLI_EMP_EMPRESA(+)',
'         AND C.SNP_FECHA_CREACION BETWEEN :P24_INICIO',
'                                      AND  TO_DATE (:P24_FIN || '' 23:59'',',
'                                                    ''dd/mm/rrrr hh24:mi'')',
'         AND scr_trx_transaccion = trx_transaccion'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P24_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="margin-top: 20px;">',
'    <p style="font-weight:bold;">Transacciones de Financiamiento </p>'))
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14193584472394227177)
,p_name=>'Reporte Snapshot Saldos'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>7585120275041500
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932075628934672442)
,p_db_column_name=>'CONSULTA'
,p_display_order=>10
,p_column_identifier=>'AS'
,p_column_label=>'Consulta'
,p_column_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP:P24_SOLICITUD:#SOLICITUD#'
,p_column_linktext=>' <span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>' class="orderReportButton t-Button t-Button--simple t-Button--hot t-Button--stretch" data-order-id="#TRX_SOLICITUD#" type="button"  P142_SOLICITUD #CONSULTA#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097416474140365616)
,p_db_column_name=>'SNP_ID'
,p_display_order=>20
,p_column_identifier=>'U'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097416596451365617)
,p_db_column_name=>'SNP_EMP_EMPRESA'
,p_display_order=>30
,p_column_identifier=>'V'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097416665621365618)
,p_db_column_name=>'SNP_FECHA_CREACION'
,p_display_order=>40
,p_column_identifier=>'W'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097416772630365619)
,p_db_column_name=>'SNP_TRX_TRANSACCION'
,p_display_order=>50
,p_column_identifier=>'X'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097416832460365620)
,p_db_column_name=>'T_CUENTA'
,p_display_order=>60
,p_column_identifier=>'Y'
,p_column_label=>'T. Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097416957525365621)
,p_db_column_name=>'SNP_TTC_TIPO'
,p_display_order=>70
,p_column_identifier=>'Z'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417080824365622)
,p_db_column_name=>'SNP_TTC_SIGNO'
,p_display_order=>80
,p_column_identifier=>'AA'
,p_column_label=>'Signo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417224501365623)
,p_db_column_name=>'SNP_MONTO'
,p_display_order=>90
,p_column_identifier=>'AB'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417323674365624)
,p_db_column_name=>'SNP_SALDO'
,p_display_order=>100
,p_column_identifier=>'AC'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417341952365625)
,p_db_column_name=>'SNP_MONTO_MORA'
,p_display_order=>110
,p_column_identifier=>'AD'
,p_column_label=>'Monto Mora'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417460155365626)
,p_db_column_name=>'SNP_PPG_SOLICITUD'
,p_display_order=>120
,p_column_identifier=>'AE'
,p_column_label=>'Solicitud'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417552285365627)
,p_db_column_name=>'SNP_PPG_CUOTA'
,p_display_order=>130
,p_column_identifier=>'AF'
,p_column_label=>'Cuota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417673924365628)
,p_db_column_name=>'SNP_PPG_MONTO_PRINCIPAL'
,p_display_order=>140
,p_column_identifier=>'AG'
,p_column_label=>'Monto Principal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417767582365629)
,p_db_column_name=>'SNP_PPG_SALDO_PRINCIPAL'
,p_display_order=>150
,p_column_identifier=>'AH'
,p_column_label=>'Saldo Principal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417868438365630)
,p_db_column_name=>'SNP_PPG_MONTO_INTERES'
,p_display_order=>160
,p_column_identifier=>'AI'
,p_column_label=>'Monto Interes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097417941872365631)
,p_db_column_name=>'SNP_PPG_SALDO_INTERES'
,p_display_order=>170
,p_column_identifier=>'AJ'
,p_column_label=>'Saldo Interes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097418110366365632)
,p_db_column_name=>'SNP_PPG_MONTO_MORA'
,p_display_order=>180
,p_column_identifier=>'AK'
,p_column_label=>'Monto Mora'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097479187027436413)
,p_db_column_name=>'NOMBRE'
,p_display_order=>190
,p_column_identifier=>'AL'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097479316138436414)
,p_db_column_name=>'CLASE'
,p_display_order=>200
,p_column_identifier=>'AM'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13938436842141286729)
,p_db_column_name=>'SOLICITUD'
,p_display_order=>210
,p_column_identifier=>'AN'
,p_column_label=>'Solicitud'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13938436961752286730)
,p_db_column_name=>'ESTADO_FINANCIAMIENTO'
,p_display_order=>220
,p_column_identifier=>'AO'
,p_column_label=>'Estado Financiamiento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932075497235672440)
,p_db_column_name=>'MONTO_CUOTA'
,p_display_order=>230
,p_column_identifier=>'AQ'
,p_column_label=>'Monto Cuota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932124697519244307)
,p_db_column_name=>'ABONO'
,p_display_order=>240
,p_column_identifier=>'AT'
,p_column_label=>'Abono'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932075535922672441)
,p_db_column_name=>'POR_APLICAR'
,p_display_order=>250
,p_column_identifier=>'AR'
,p_column_label=>'Saldo Por Aplicar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14193586269596227193)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75870'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'SNP_ID:SNP_EMP_EMPRESA:SNP_FECHA_CREACION:SNP_TRX_TRANSACCION:T_CUENTA:SNP_TTC_TIPO:SNP_TTC_SIGNO:SNP_MONTO:SNP_SALDO:SNP_MONTO_MORA:SNP_PPG_SALDO_PRINCIPAL:SNP_PPG_MONTO_INTERES:SNP_PPG_SALDO_INTERES:SNP_PPG_MONTO_MORA:NOMBRE:CLASE:SOLICITUD:ESTADO_'
||'FINANCIAMIENTO:MONTO_CUOTA:ABONO:POR_APLICAR:APXWS_CC_001:CONSULTA:'
,p_sum_columns_on_break=>'POR_APLICAR'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168175706676779285)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14193586665435227194)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13932075762709672443)
,p_name=>'P24_SOLICITUD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14193586665435227194)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193586860759227194)
,p_name=>'P24_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14193586665435227194)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193587060640227195)
,p_name=>'P24_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14193586665435227194)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193587281663227195)
,p_name=>'P24_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14193586665435227194)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
