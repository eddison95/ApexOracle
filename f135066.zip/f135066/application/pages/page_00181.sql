prompt --application/pages/page_00181
begin
--   Manifest
--     PAGE: 00181
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>181
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'APD - Eventos '
,p_step_title=>'APD - Eventos '
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'MBACASE'
,p_last_upd_yyyymmddhh24miss=>'20210511144757'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13885254915076673220)
,p_plug_name=>'APD Eventos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13885255219817673223)
,p_plug_name=>'APD - Eventos'
,p_parent_plug_id=>wwv_flow_api.id(13885254915076673220)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    a.apa_apr_id           registro,',
'    b.apt_codigo           tipo,',
'    a.apa_id               evento,',
'    a.apa_fecha            fecha,',
'    a.apa_genera_kernel    gen_krn,',
'    a.apa_estado           estado,',
'    a.apa_monto            monto,',
'    a.apa_descripcion      descripcion,',
'    c.apr_descripcion      descripcion_FECHA,',
'    c.apr_numero           numero_registro,',
'    d.apc_codigo           clase,',
'    b.apt_supertipo        Super_tipo,',
'    gnl_valor_cambio_n_nx(a.apa_fecha,e.mon_moneda,e.TIP_TIPO_CAMBIO)valor_cambio',
'FROM',
'    apd_amortizacion_tb_nx      a,',
'    apd_tipo_transaccion_tb_nx  b,',
'    apd_registro_tb_nx          c,',
'    apd_clase_tb_nx             d,',
'    cgl_cuenta_tr_nx            e',
'WHERE  INSTR ('':''||:P181_EMPRESA||'':'','':''||apa_emp_empresa||'':'') > 0',
'AND a.apa_emp_empresa = e.emp_empresa',
'    AND a.apa_apr_id = c.apr_id',
'    AND a.apa_apt_id = b.apt_id',
'    AND  b.apt_supertipo != ''E''',
'    AND  b.apt_supertipo != ''I'' ',
'    AND c.apr_apc_id = d.apc_id',
'    AND c.apr_cta_empresa_ori = e.emp_empresa',
'    AND c.apr_cta_cuenta_ori = e.cuenta',
'    ORDER BY a.apa_apr_id,a.apa_id ',
'    ',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P181_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13885255265461673224)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ESALAS'
,p_internal_uid=>28532522028333837
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885255380850673225)
,p_db_column_name=>'REGISTRO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Registro'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885255451177673226)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885255640363673227)
,p_db_column_name=>'EVENTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Evento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885255689903673228)
,p_db_column_name=>'FECHA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885255781408673229)
,p_db_column_name=>'GEN_KRN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Gen Krn'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885255907720673230)
,p_db_column_name=>'ESTADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885255996198673231)
,p_db_column_name=>'MONTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885256050485673232)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885256231067673233)
,p_db_column_name=>'DESCRIPCION_FECHA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Descripcion Fecha'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885256301977673234)
,p_db_column_name=>'NUMERO_REGISTRO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Numero Registro'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885256390974673235)
,p_db_column_name=>'CLASE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217856661630053)
,p_db_column_name=>'SUPER_TIPO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Super Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885218666423630061)
,p_db_column_name=>'VALOR_CAMBIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Valor Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13885294699752729091)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'285720'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'REGISTRO:NUMERO_REGISTRO:DESCRIPCION:CLASE:TIPO:ESTADO:SUPER_TIPO:MONTO:EVENTO:FECHA:DESCRIPCION_FECHA:GEN_KRN:VALOR_CAMBIO:'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'MONTO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13885255091227673222)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(13885254915076673220)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13885254958404673221)
,p_name=>'P181_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13885254915076673220)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
