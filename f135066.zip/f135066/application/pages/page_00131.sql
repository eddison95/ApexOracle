prompt --application/pages/page_00131
begin
--   Manifest
--     PAGE: 00131
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>131
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GAC-Transacciones de Facturas'
,p_step_title=>'GAC-Transacciones de Facturas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165320'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098864466041557024)
,p_plug_name=>'Transacciones de facturas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098859012937556626)
,p_plug_name=>'Transacciones de facturas'
,p_region_name=>' Transacciones GAC'
,p_parent_plug_id=>wwv_flow_api.id(14098864466041557024)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 25/09/2017 04:27:31 p.m. (QP5 v5.115.810.9015) */',
'SELECT   GSP_EMP_EMPRESA,',
'         GSP_TRANSACCION,',
'         TRUNC (GSP_FECHA_TRANSACCION) fecha,',
'         GSP_DOCUMENTO,',
'         TRUNC (GSP_FECHA_DOCUMENTO) fecha_doc,',
'         GSP_TTP_TIPO,',
'         GSP_MONTO AS MONTO,',
'         GSP_SALDO AS SALDO,',
'         GDE_OBSERVACIONES AS OBSERVACIONES,',
'         GSP_PRO_MON_MONEDA AS MONEDA,',
'         GSP_PRO_PROVEEDOR,',
'         RAZON_SOCIAL AS NOMBRE,',
'         GDE_FECHA_CREACION AS FECHA_CREACION',
'  FROM   GAC_CXP_TRANSACCION_TB_NX,',
'         GAC_CXP_DET_TRANSACCION_TB_NX,',
'         GNL_PERSONA_TR_NX',
' WHERE   INSTR ('':'' || :P131_EMPRESA || '':'', '':'' || GSP_EMP_EMPRESA || '':'') >',
'            0',
'         AND GSP_FECHA_TRANSACCION BETWEEN :P131_INICIO',
'                                       AND  TO_DATE (:P131_FIN || '' 23:59'',',
'                                                     ''dd/mm/rrrr hh24:mi'')',
'         AND GSP_TRANSACCION = GDE_TSP_TRANSACCION',
'         AND PERSONA = GSP_PRO_PROVEEDOR',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P131_EMPRESA'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14098859254448556673)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>35839524008340414
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066872490083196650)
,p_db_column_name=>'FECHA'
,p_display_order=>20
,p_column_identifier=>'R'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066874070112196653)
,p_db_column_name=>'MONTO'
,p_display_order=>70
,p_column_identifier=>'W'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066874503220196654)
,p_db_column_name=>'SALDO'
,p_display_order=>80
,p_column_identifier=>'X'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066875252920196656)
,p_db_column_name=>'MONEDA'
,p_display_order=>100
,p_column_identifier=>'Z'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066870874463196645)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>150
,p_column_identifier=>'AG'
,p_column_label=>'Fecha de Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MM-YYYY HH:MIPM'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066814379784758200)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>180
,p_column_identifier=>'AJ'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067022258175954462)
,p_db_column_name=>'FECHA_DOC'
,p_display_order=>200
,p_column_identifier=>'AL'
,p_column_label=>'Fecha Doc'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067022723938954466)
,p_db_column_name=>'NOMBRE'
,p_display_order=>240
,p_column_identifier=>'AP'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067158459359098285)
,p_db_column_name=>'GSP_EMP_EMPRESA'
,p_display_order=>250
,p_column_identifier=>'AQ'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067158578153098286)
,p_db_column_name=>'GSP_TRANSACCION'
,p_display_order=>260
,p_column_identifier=>'AR'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067158724898098287)
,p_db_column_name=>'GSP_DOCUMENTO'
,p_display_order=>270
,p_column_identifier=>'AS'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067158828734098288)
,p_db_column_name=>'GSP_TTP_TIPO'
,p_display_order=>280
,p_column_identifier=>'AT'
,p_column_label=>'Tipo Doc'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067158896428098289)
,p_db_column_name=>'GSP_PRO_PROVEEDOR'
,p_display_order=>290
,p_column_identifier=>'AU'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14098864034456556948)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'38563'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'GSP_EMP_EMPRESA:GSP_TRANSACCION:FECHA:GSP_DOCUMENTO:GSP_TTP_TIPO:FECHA_DOC:MONEDA:MONTO:SALDO:GSP_PRO_PROVEEDOR:NOMBRE:OBSERVACIONES:FECHA_CREACION:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14066876795077196669)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14098864466041557024)
,p_button_name=>'CONSULTAR'
,p_button_static_id=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066877160256196671)
,p_name=>'P131_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14098864466041557024)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066877562160196673)
,p_name=>'P131_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14098864466041557024)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066878022558196676)
,p_name=>'P131_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14098864466041557024)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
