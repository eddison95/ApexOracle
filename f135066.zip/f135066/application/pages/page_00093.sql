prompt --application/pages/page_00093
begin
--   Manifest
--     PAGE: 00093
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>93
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CRM - Clientes'
,p_step_title=>'Clientes'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164736'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096892917713513796)
,p_plug_name=>'Clientes'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095570406559879726)
,p_plug_name=>'Clientes'
,p_parent_plug_id=>wwv_flow_api.id(14096892917713513796)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 16/02/2017 09:40:58 a.m. (QP5 v5.115.810.9015) */',
'  SELECT   SALESMAN.EMPRESA,',
'           (   ORGANIZATIONS.NAME',
'            || '' ''',
'            || ORGANIZATIONS.FIRST_NAME',
'            || '' ''',
'            || ORGANIZATIONS.LAST_NAME)',
'              AS NAME,',
'           ORGANIZATIONS.ADDRESS1 AS ADDRESS,',
'           ORGANIZATIONS.OCCUPATION AS OCCUPATION,',
'           DECODE (ORGANIZATIONS.GENDER,',
'                   ''M'',',
'                   ''Masculino'',',
'                   ''F'',',
'                   ''Femenino'')',
'              AS GENDER,',
'           TRUNC (ORGANIZATIONS.BIRTH_DATE) AS BIRTH_DATE,',
'           TRUNC (ORGANIZATIONS.CREATED) AS CREATED,',
'           SALESMAN.NAME SALESMAN_NAME,',
'           ORGANIZATIONS.CELULAR CELULAR,',
'           ORGANIZATIONS.EMAIL EMAIL,',
'           TRUNC(ORGANIZATIONS.LAST_CHANGE) LAST_CHANGE,',
'           ORGANIZATIONS.MBA_CODE CODIGO_MBACASE,',
'	   identification IDENTIFICACION,',
'	   DECODE (document_type',
'				 , ''F''',
'				 , ''FISICO''',
'				 , ''J''',
'				 , ''JURIDICO''',
'				 , ''R''',
'				 , ''RESIDENCIA''',
'				 , ''P''',
'				 , ''PASAPORTE''',
'				  )',
'			 TIPO_DOCUMENTO',
'    FROM   ORGANIZATIONS ORGANIZATIONS, SALESMAN',
'   WHERE   INSTR ('':'' || :P93_EMPRESA || '':'', '':'' || SALESMAN.EMPRESA || '':'') >',
'              0',
'           AND USER_CREATE = SALESMAN.ID',
'ORDER BY   1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P93_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095570740351879748)
,p_name=>'Ventas Diarias'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>7827015579990654
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095497132671481423)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'CI'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095496447219481416)
,p_db_column_name=>'ADDRESS'
,p_display_order=>40
,p_column_identifier=>'CB'
,p_column_label=>unistr('Direcci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095496590892481417)
,p_db_column_name=>'OCCUPATION'
,p_display_order=>50
,p_column_identifier=>'CC'
,p_column_label=>'Ocupacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095496634165481418)
,p_db_column_name=>'GENDER'
,p_display_order=>60
,p_column_identifier=>'CD'
,p_column_label=>'Genero'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095496821464481419)
,p_db_column_name=>'BIRTH_DATE'
,p_display_order=>70
,p_column_identifier=>'CE'
,p_column_label=>'Fecha Nacimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095496921773481420)
,p_db_column_name=>'CREATED'
,p_display_order=>80
,p_column_identifier=>'CF'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095496930494481421)
,p_db_column_name=>'SALESMAN_NAME'
,p_display_order=>90
,p_column_identifier=>'CG'
,p_column_label=>'Nombre Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098668946389192111)
,p_db_column_name=>'EMPRESA'
,p_display_order=>100
,p_column_identifier=>'CJ'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669042943192112)
,p_db_column_name=>'CELULAR'
,p_display_order=>110
,p_column_identifier=>'CK'
,p_column_label=>'Celular'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669195298192113)
,p_db_column_name=>'EMAIL'
,p_display_order=>120
,p_column_identifier=>'CL'
,p_column_label=>'Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669302427192114)
,p_db_column_name=>'LAST_CHANGE'
,p_display_order=>130
,p_column_identifier=>'CM'
,p_column_label=>'F. Ultimo Segimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669399660192115)
,p_db_column_name=>'CODIGO_MBACASE'
,p_display_order=>140
,p_column_identifier=>'CN'
,p_column_label=>'Codigo MBACASE'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086274605945786973)
,p_db_column_name=>'IDENTIFICACION'
,p_display_order=>150
,p_column_identifier=>'CQ'
,p_column_label=>'Identificacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086274646367786974)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>160
,p_column_identifier=>'CR'
,p_column_label=>'Tipo documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095574045764879809)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'78304'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:NAME:SALESMAN_NAME:GENDER:BIRTH_DATE:EMAIL:CELULAR:LAST_CHANGE:CODIGO_MBACASE:OCCUPATION:ADDRESS:CREATED::IDENTIFICACION:TIPO_DOCUMENTO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096893188951513799)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14096892917713513796)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096893617126513800)
,p_name=>'P93_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096892917713513796)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
