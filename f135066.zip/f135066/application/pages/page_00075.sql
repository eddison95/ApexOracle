prompt --application/pages/page_00075
begin
--   Manifest
--     PAGE: 00075
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>75
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'KJE - Hojas Caja Activas'
,p_step_title=>'Hojas Caja Activas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104160601'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094445081165287785)
,p_plug_name=>'Hojas Caja Activas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094447810950293195)
,p_plug_name=>'Hojas Cajas Activas'
,p_parent_plug_id=>wwv_flow_api.id(14094445081165287785)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT c001, c002, c003, c004, c005, c006, c007, c008, c009, c010, c011, c012',
'FROM APEX_collections',
'WHERE collection_name = ''HOJA_CAJA'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P75_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14094447857369293196)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>6704132597404102
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094447979836293197)
,p_db_column_name=>'C001'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Hoja'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094448124180293198)
,p_db_column_name=>'C002'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
,p_format_mask=>'DD/MM/RRRR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094448145420293199)
,p_db_column_name=>'C003'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094448253660293200)
,p_db_column_name=>'C004'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Caja'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094448415716293201)
,p_db_column_name=>'C005'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094448483188293202)
,p_db_column_name=>'C006'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cajero'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094448556761293203)
,p_db_column_name=>'C007'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094448680410293204)
,p_db_column_name=>'C008'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Liquidar CRC'
,p_column_type=>'STRING'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094448816149293205)
,p_db_column_name=>'C009'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Liquidar USD'
,p_column_type=>'STRING'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098965835837251908)
,p_db_column_name=>'C010'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083901148328692908)
,p_db_column_name=>'C011'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Error'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083901215066692909)
,p_db_column_name=>'C012'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'C012'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14094470979727386382)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'67273'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C001:C002:C003:C004:C005:C006:C007:C008:C009:C010:C011:'
,p_sort_column_1=>'C011'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14094445440345287786)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14094445081165287785)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094445874671287787)
,p_name=>'P75_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14094445081165287785)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14094448897789293206)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'genera_reporte_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 08/08/2017 05:16:57 p.m. (QP5 v5.115.810.9015) */',
'DECLARE',
'	CURSOR hoj',
'	IS',
'		SELECT hcj_emp_empresa hcj_empresa',
'			  , hcj_hoja_caja hcj_hoja',
'			  , hcj_fecha_hoja hcj_fecha',
'			  , hcj_dep_departamento hcj_departamento',
'			  , hcj_caj_caja hcj_caja',
'			  , DECODE (hcj_status,',
'							''C'', ''Creado'',',
'							''A'', ''Aprobada'',',
'							''E'', ''Cerrada'',',
'							''L'', ''Liquidada'',',
'							''Sin Definir''',
'						  )',
'					 hcj_estado',
'			  , hcj_ucj_user_id hcj_cajero',
'			  , gnl_username_v_nx (hcj_ucj_user_id) hcj_nombre',
'		FROM kje_hoja_caja_tb_nx',
'		WHERE INSTR (	 '':''',
'						 || :p75_empresa',
'						 || '':'',    '':''',
'									|| hcj_emp_empresa',
'									|| '':'') > 0',
'				AND hcj_status NOT IN (''C'', ''L'');',
'',
'	CURSOR liquidacion (',
'		empresa_c	IN 			  VARCHAR2',
'	 , hoja_c		IN 			  NUMBER',
'	)',
'	IS',
'		SELECT kcl_mon_moneda moneda',
'			  , SUM (kcl_monto) efectivo',
'			  , SUM (kcl_traslados) traslados',
'		FROM kje_calculo_liquidacion_tb_nx',
'		WHERE 	 kcl_emp_empresa = empresa_c',
'				AND kcl_hcj_hoja_caja = hoja_c',
'				AND kcl_mpg_modo IN (''E'', ''G'')',
'		GROUP BY kcl_mon_moneda;',
'',
'	cierre_alt_v	kje_transaccion_tb_nx.trk_monto%TYPE;',
'	total_alt_v 	kje_traslados_tb_nx.tkj_monto%TYPE;',
'	cierre_crc_v	kje_transaccion_tb_nx.trk_monto%TYPE;',
'	total_crc_v 	kje_traslados_tb_nx.tkj_monto%TYPE;',
'	mon_base_v		gnl_moneda_tr_nx.moneda%TYPE;',
'	mon_alt_v		gnl_moneda_tr_nx.moneda%TYPE;',
'BEGIN',
'	--   mon_base_v := gnl_parametro_emp_v_nx (:P75_EMPRESA, ''CGL'', ''MONEDA'');',
'	--   mon_alt_v :=',
'	-- 	gnl_parametro_emp_v_nx (:P75_EMPRESA, ''GNL'', ''MONEDA CONVERSION'');',
'	apex_collection.create_or_truncate_collection (''HOJA_CAJA'');',
'',
'	FOR h IN hoj',
'	LOOP',
'		BEGIN',
'			mon_base_v := gnl_parametro_emp_v_nx (h.hcj_empresa, ''CGL'', ''MONEDA'');',
'			mon_alt_v :=',
'				gnl_parametro_emp_v_nx (h.hcj_empresa',
'											 , ''GNL''',
'											 , ''MONEDA CONVERSION''',
'											  );',
'			kje_calculo_liquidacion_pr_nx (h.hcj_empresa, h.hcj_hoja);',
'			cierre_alt_v := 0;',
'			total_alt_v := 0;',
'			cierre_crc_v := 0;',
'			total_crc_v := 0;',
'',
'			FOR liq IN liquidacion (h.hcj_empresa, h.hcj_hoja)',
'			LOOP',
'				IF liq.moneda = mon_base_v THEN',
'					cierre_crc_v :=',
'						kje_monto_hoja_n_nx (h.hcj_empresa',
'												 , h.hcj_hoja',
'												 , liq.moneda',
'												 , ''C''',
'												  );',
'					total_crc_v :=',
'						(liq.efectivo',
'						 + liq.traslados)',
'						- NVL (cierre_crc_v, 0);',
'				ELSIF liq.moneda = mon_alt_v THEN',
'					cierre_alt_v :=',
'						kje_monto_hoja_n_nx (h.hcj_empresa',
'												 , h.hcj_hoja',
'												 , liq.moneda',
'												 , ''C''',
'												  );',
'					total_alt_v :=',
'						(liq.efectivo',
'						 + liq.traslados)',
'						- NVL (cierre_alt_v, 0);',
'				END IF;',
'			END LOOP;',
'',
'			apex_collection.add_member (',
'				''HOJA_CAJA''',
'			 , h.hcj_hoja',
'			 , h.hcj_fecha',
'			 , h.hcj_departamento',
'			 , h.hcj_caja',
'			 , h.hcj_estado',
'			 , h.hcj_cajero',
'			 , h.hcj_nombre',
'			 , TO_CHAR (total_crc_v, ''999G999G999G990D99'')',
'			 , TO_CHAR (total_alt_v, ''999G999G999G990D99'')',
'			 , h.hcj_empresa',
'			);',
'		EXCEPTION',
'			WHEN OTHERS THEN',
'				apex_collection.add_member (',
'					''HOJA_CAJA''',
'				 , h.hcj_hoja',
'				 , h.hcj_fecha',
'				 , h.hcj_departamento',
'				 , h.hcj_caja',
'				 , h.hcj_estado',
'				 , h.hcj_cajero',
'				 , h.hcj_nombre',
'				 , TO_CHAR (total_crc_v, ''999G999G999G990D99'')',
'				 , TO_CHAR (total_alt_v, ''999G999G999G990D99'')',
'				 , h.hcj_empresa',
'                                 , ''Error: ''|| SQLERRM',
'				);',
'		END;',
'	END LOOP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14094445440345287786)
);
wwv_flow_api.component_end;
end;
/
