prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'Principal'
,p_step_title=>'Principal'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Header-logo {',
'    float: left;',
'    white-space: nowrap;',
'    overflow: hidden;',
'    text-overflow: ellipsis;',
'        width: 200px;',
'    height: 65px;',
'}',
'',
'',
'.t-Header-logo-link img {',
'    max-height: 80px;',
'    display: block;',
'    height: auto;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14051962854835374868)
,p_plug_name=>'Empresa'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM   nss_autorizacion_usuario_tb_nx aus,',
'       gnl_usuario_empresa_tb_nx USE,',
'       gnl_usuarios_tb_nx usu',
'WHERE  aus.subsistema = ''APX''',
'       AND aus.autorizacion = ''GP1''',
'       AND aus.use_id = USE.use_id',
'       AND USE.use_usu_user_id = usu.user_id',
'       AND usu.username = :app_user'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14052466932131054577)
,p_plug_name=>'Mensual'
,p_parent_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P1_TIPO'
,p_plug_display_when_cond2=>'1'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14052467050471054578)
,p_region_id=>wwv_flow_api.id(14052466932131054577)
,p_chart_type=>'line'
,p_title=>'Ventas Mensuales'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052578891699878229)
,p_chart_id=>wwv_flow_api.id(14052467050471054578)
,p_seq=>10
,p_name=>'Actual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT To_char(SYSDATE, ''RRRR'') serie,',
'       c001                     mes,',
'       NVL(n001,0)              monto',
'FROM   apex_collections',
'WHERE  collection_name = ''F_MBACASE5:P1:ACTM''',
'ORDER  BY TO_NUMBER(c001)  '))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_items_label_column_name=>'MES'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052579197001878232)
,p_chart_id=>wwv_flow_api.id(14052467050471054578)
,p_seq=>20
,p_name=>'Anterior'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT To_char(SYSDATE, ''RRRR'') - 1 serie,',
'       c001                         mes,',
'       NVL(n001,0)                  monto',
'FROM   apex_collections',
'WHERE  collection_name = ''F_MBACASE5:P1:ANTM''',
'ORDER  BY TO_NUMBER(c001)  '))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_items_label_column_name=>'MES'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052579015324878231)
,p_chart_id=>wwv_flow_api.id(14052467050471054578)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052578961132878230)
,p_chart_id=>wwv_flow_api.id(14052467050471054578)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14052580144475878242)
,p_plug_name=>'Anual'
,p_parent_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P1_TIPO'
,p_plug_display_when_cond2=>'1'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14052580227577878243)
,p_region_id=>wwv_flow_api.id(14052580144475878242)
,p_chart_type=>'bar'
,p_title=>'Mensual Acumulado'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052580486634878245)
,p_chart_id=>wwv_flow_api.id(14052580227577878243)
,p_seq=>10
,p_name=>'Actual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT To_char(SYSDATE, ''RRRR'') serie,',
'       c001                     mes,',
'       NVL(n001,0)              monto',
'FROM   apex_collections',
'WHERE  collection_name = ''F_MBACASE5:P1:ACTA''',
'ORDER  BY TO_NUMBER(c001)  '))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_items_label_column_name=>'MES'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052580324565878244)
,p_chart_id=>wwv_flow_api.id(14052580227577878243)
,p_seq=>20
,p_name=>'Anterior'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT To_char(SYSDATE, ''RRRR'') - 1 serie,',
'       c001                         mes,',
'       NVL(n001,0)                  monto',
'FROM   apex_collections',
'WHERE  collection_name = ''F_MBACASE5:P1:ANTA''',
'ORDER  BY TO_NUMBER(c001)  '))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_items_label_column_name=>'MES'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052580738128878248)
,p_chart_id=>wwv_flow_api.id(14052580227577878243)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052580804514878249)
,p_chart_id=>wwv_flow_api.id(14052580227577878243)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14052581111176878252)
,p_plug_name=>'Parametros'
,p_parent_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P1_TIPO'
,p_plug_display_when_cond2=>'1'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14051963019073374870)
,p_plug_name=>'Vendedor'
,p_parent_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_FRECUENCIA'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14051963222893374872)
,p_region_id=>wwv_flow_api.id(14051963019073374870)
,p_chart_type=>'bar'
,p_title=>'Ventas por Vendedor'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14051963324013374873)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_seq=>10
,p_name=>'Actual-Diario'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''DDMMRRRR'') serie,',
'    c001 vendedor,',
'    c002 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:D''',
'GROUP BY',
'    c001,',
'    c002',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'VENDEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'D'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14051963675864374876)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_seq=>30
,p_name=>'Anterior-Diario'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate - 1, ''DDMMRRRR'') serie,',
'    c001 vendedor,',
'    c002 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:D''',
'GROUP BY',
'    c001,',
'    c002',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'VENDEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'D'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052399777702299031)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_seq=>50
,p_name=>'Actual-Semanal'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate - 7, ''DDMMRRRR'') || ''+7'' serie,',
'    c001 vendedor,',
'    c002 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:S''',
'GROUP BY',
'    c001,',
'    c002',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'VENDEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'S'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052399864439299032)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_seq=>70
,p_name=>'Anterior-Semanal'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(sysdate - 7, -12), ''DDMMRRRR'') || ''+7'' serie,',
'    c001 vendedor,',
'    c002 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:S''',
'GROUP BY',
'    c001,',
'    c002',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'VENDEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'S'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052400128520299035)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_seq=>80
,p_name=>'Actual-Mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''MMRRRR'') serie,',
'    c001 vendedor,',
'    c002 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:M''',
'GROUP BY',
'    c001,',
'    c002',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'VENDEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'M'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052400293444299036)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_seq=>90
,p_name=>'Anterior-Mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(trunc(sysdate, ''MM''), -12), ''MMRRRR'') serie,',
'    c001 vendedor,',
'    c002 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:M''',
'GROUP BY',
'    c001,',
'    c002',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'VENDEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'M'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052399593455299029)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_seq=>100
,p_name=>'Actual-Anual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate,''RRRR'') serie,',
'    c001 vendedor,',
'    c002 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:A''',
'GROUP BY',
'    c001,',
'    c002',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'VENDEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'A'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052399665839299030)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_seq=>110
,p_name=>'Anterior-Anual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate,''RRRR'') - 1 serie,',
'    c001 vendedor,',
'    c002 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:A''',
'GROUP BY',
'    c001,',
'    c002',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'VENDEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'A'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14051963476357374874)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14051963529928374875)
,p_chart_id=>wwv_flow_api.id(14051963222893374872)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14052463297123054540)
,p_plug_name=>'Departamento'
,p_parent_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_FRECUENCIA'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14052463365899054541)
,p_region_id=>wwv_flow_api.id(14052463297123054540)
,p_chart_type=>'bar'
,p_title=>'Ventas por Departamento'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052463494080054542)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_seq=>10
,p_name=>'Actual-Diario'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''DDMMRRRR'') serie,',
'    c003 departamento,',
'    c004 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:D''',
'GROUP BY',
'    c003,',
'    c004',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'DEPARTAMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'D'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052463567314054543)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_seq=>20
,p_name=>'Anterior-Diario'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate - 1, ''DDMMRRRR'') serie,',
'    c003 departamento,',
'    c004 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:D''',
'GROUP BY',
'    c003,',
'    c004',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'DEPARTAMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'D'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052463875481054546)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_seq=>30
,p_name=>'Actual-Semanal'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate - 7, ''DDMMRRRR'') || ''+7'' serie,',
'    c003 departamento,',
'    c004 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:S''',
'GROUP BY',
'    c003,',
'    c004',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'DEPARTAMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'S'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052463909490054547)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_seq=>40
,p_name=>'Anterior-Semanal'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(sysdate-7, -12), ''DDMMRRRR'') || ''+7'' serie,',
'    c003 departamento,',
'    c004 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:S''',
'GROUP BY',
'    c003,',
'    c004',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'DEPARTAMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'S'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052464033330054548)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_seq=>50
,p_name=>'Actual-Mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''MMRRRR'') serie,',
'    c003 departamento,',
'    c004 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:M''',
'GROUP BY',
'    c003,',
'    c004',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'DEPARTAMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'M'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052464130556054549)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_seq=>60
,p_name=>'Anterior-Mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(trunc(sysdate, ''MM''), -12), ''MMRRRR'') serie,',
'    c003 departamento,',
'    c004 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:M''',
'GROUP BY',
'    c003,',
'    c004',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'DEPARTAMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'M'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052463620657054544)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_seq=>70
,p_name=>'Actual-Anual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate,''RRRR'') serie,',
'    c003 departamento,',
'    c004 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:A''',
'GROUP BY',
'    c003,',
'    c004',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'DEPARTAMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'A'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052463788178054545)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_seq=>80
,p_name=>'Anterior-Anual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''RRRR'')-1 serie,',
'    c003 departamento,',
'    c004 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:A''',
'GROUP BY',
'    c003,',
'    c004',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'DEPARTAMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'A'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052581952856878260)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052582087955878261)
,p_chart_id=>wwv_flow_api.id(14052463365899054541)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14052464446545054552)
,p_plug_name=>'Familia'
,p_parent_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_FRECUENCIA'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14052464565468054553)
,p_region_id=>wwv_flow_api.id(14052464446545054552)
,p_chart_type=>'bar'
,p_title=>'Ventas por Familia'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052464674051054554)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_seq=>10
,p_name=>'Actual-Diario'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''DDMMRRRR'') serie,',
'    c005 familia,',
'    c006 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:D''',
'GROUP BY',
'    c005,',
'    c006',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'FAMILIA'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'D'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052464733793054555)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_seq=>20
,p_name=>'Anterior-Diario'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate - 1, ''DDMMRRRR'') serie,',
'    c005 familia,',
'    c006 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:D''',
'GROUP BY',
'    c005,',
'    c006',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'FAMILIA'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'D'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052465007616054558)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_seq=>30
,p_name=>'Actual-Semanal'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate - 7, ''DDMMRRRR'') || ''+7'' serie,',
'    c005 familia,',
'    c006 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:S''',
'GROUP BY',
'    c005,',
'    c006',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'FAMILIA'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'S'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052465162516054559)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_seq=>40
,p_name=>'Anterior-Semanal'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(sysdate-7, -12), ''DDMMRRRR'') || ''+7'' serie,',
'    c005 familia,',
'    c006 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:S''',
'GROUP BY',
'    c005,',
'    c006',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'FAMILIA'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'S'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052465202981054560)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_seq=>50
,p_name=>'Actual-Mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''MMRRRR'') serie,',
'    c005 familia,',
'    c006 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:M''',
'GROUP BY',
'    c005,',
'    c006',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'FAMILIA'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'M'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052465357047054561)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_seq=>60
,p_name=>'Anterior-Mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(trunc(sysdate, ''MM''), -12), ''MMRRRR'') serie,',
'    c005 familia,',
'    c006 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:M''',
'GROUP BY',
'    c005,',
'    c006',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'FAMILIA'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'M'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052464849142054556)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_seq=>70
,p_name=>'Actual-Anual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate,''RRRR'') serie,',
'    c005 familia,',
'    c006 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:A''',
'GROUP BY',
'    c005,',
'    c006',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'FAMILIA'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'A'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052464980845054557)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_seq=>80
,p_name=>'Anterior-Anual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''RRRR'')-1 serie,',
'    c005 familia,',
'    c006 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:A''',
'GROUP BY',
'    c005,',
'    c006',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'FAMILIA'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'A'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052465587006054563)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052465429007054562)
,p_chart_id=>wwv_flow_api.id(14052464565468054553)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14052465651733054564)
,p_plug_name=>'Segmento'
,p_parent_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_FRECUENCIA'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(14052465718514054565)
,p_region_id=>wwv_flow_api.id(14052465651733054564)
,p_chart_type=>'bar'
,p_title=>'Ventas por Segmento'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052465866553054566)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_seq=>10
,p_name=>'Actual-Diario'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''DDMMRRRR'') serie,',
'    c007 segmento,',
'    c008 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:D''',
'GROUP BY',
'    c007,',
'    c008',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'SEGMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'D'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052465962645054567)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_seq=>20
,p_name=>'Anterior-Diario'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate - 1, ''DDMMRRRR'') serie,',
'    c007 segmento,',
'    c008 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:D''',
'GROUP BY',
'    c007,',
'    c008',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'SEGMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'D'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052466291614054570)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_seq=>30
,p_name=>'Actual-Semanal'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate - 7, ''DDMMRRRR'') || ''+7'' serie,',
'    c007 segmento,',
'    c008 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:S''',
'GROUP BY',
'    c007,',
'    c008',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'SEGMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'S'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052466304511054571)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_seq=>40
,p_name=>'Anterior-Semanal'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(sysdate-7, -12), ''DDMMRRRR'') || ''+7'' serie,',
'    c007 segmento,',
'    c008 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:S''',
'GROUP BY',
'    c007,',
'    c008',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'SEGMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'S'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052466456552054572)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_seq=>50
,p_name=>'Actual-Mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''MMRRRR'') serie,',
'    c007 segmento,',
'    c008 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:M''',
'GROUP BY',
'    c007,',
'    c008',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'SEGMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'M'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052466565091054573)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_seq=>60
,p_name=>'Anterior-Mensual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(trunc(sysdate, ''MM''), -12), ''MMRRRR'') serie,',
'    c007 segmento,',
'    c008 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:M''',
'GROUP BY',
'    c007,',
'    c008',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'SEGMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'M'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052466047995054568)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_seq=>70
,p_name=>'Actual-Anual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate,''RRRR'') serie,',
'    c007 segmento,',
'    c008 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ACT:A''',
'GROUP BY',
'    c007,',
'    c008',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'SEGMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'A'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(14052466179298054569)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_seq=>80
,p_name=>'Anterior-Anual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(sysdate, ''RRRR'')-1 serie,',
'    c007 segmento,',
'    c008 nombre,',
'    SUM(n001) monto',
'FROM apex_collections',
'WHERE collection_name = ''F_MBACASE5:P1:ANT:A''',
'GROUP BY',
'    c007,',
'    c008',
'ORDER BY',
'    2'))
,p_series_name_column_name=>'SERIE'
,p_items_value_column_name=>'MONTO'
,p_group_short_desc_column_name=>'NOMBRE'
,p_items_label_column_name=>'SEGMENTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P1_FRECUENCIA'
,p_display_when_condition2=>'A'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052581731290878258)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(14052581892938878259)
,p_chart_id=>wwv_flow_api.id(14052465718514054565)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14052581683202878257)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_button_name=>'CONSULTAR2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14052579642312878237)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_button_name=>'CONSULTAR1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Consultar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14051962940062374869)
,p_name=>'P1_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ( nombre',
'      || '' (''',
'      || empresa',
'      || '')'' ) AS d,',
'    empresa   AS r',
'FROM',
'    nss_usuario_empresa_vw_nx',
'WHERE',
'    username = :APP_USER',
'ORDER BY',
'    1'))
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14051963112467374871)
,p_name=>'P1_FRECUENCIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_prompt=>'Frecuencia'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Diario;D,Semanal;S,Mensual;M,Anual;A'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052399932732299033)
,p_name=>'P1_MONEDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT descripcion, valor',
'FROM   (SELECT ''Local (''||valor||'')'' descripcion, valor',
'        FROM   gnl_parametro_empresa_tb_nx',
'        WHERE  Instr ('':''',
'                      || :P1_EMPRESA',
'                      || '':'', '':''',
'                              || empresa',
'                              || '':'') > 0',
'               AND subsistema = ''CGL''',
'               AND parametro = ''MONEDA''',
'        UNION ALL',
'        SELECT ''Alterna (''||valor||'')'' descripcion, valor',
'        FROM   gnl_parametro_empresa_tb_nx',
'        WHERE  Instr ('':''',
'                      || :P1_EMPRESA',
'                      || '':'', '':''',
'                              || empresa',
'                              || '':'') > 0',
'               AND subsistema = ''GNL''',
'               AND parametro = ''MONEDA CONVERSION'')',
'GROUP  BY descripcion, valor ',
'ORDER BY valor'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P1_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052400042863299034)
,p_name=>'P1_DESCRIPCION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_prompt=>'Descripcion'
,p_source=>unistr('Incluye Facturas y Notas de Cr\00E9dito ya aplicadas. Los valores que se muestran son Netos: (Precio Unitario * Cantidad) - Descuento.')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P1_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052466842678054576)
,p_name=>'P1_TIPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Ventas;1'
,p_cHeight=>1
,p_display_when=>'P1_EMPRESA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052579727257878238)
,p_name=>'P1_MON_LOCAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052579808032878239)
,p_name=>'P1_MON_ALT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052581284371878253)
,p_name=>'P1_VENDEDOR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_prompt=>'Vendedor'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT fac_nom_vend_v_nx(ven_emp_empresa, ven_vendedor) ||'' (''||ven_vendedor||'')'' as d, ven_vendedor as r',
'FROM fac_vendedor_tb_nx',
'WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || ven_emp_empresa || '':'') > 0',
'GROUP BY ven_emp_empresa, ven_vendedor',
'ORDER BY ven_vendedor'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Todos--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052581390529878254)
,p_name=>'P1_DEPARTAMENTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_prompt=>'Departamento'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT fac_nombre_depto_v_nx(itv_emp_empresa,itv_dep_departamento) ||'' (''||itv_dep_departamento||'')'' as d, itv_dep_departamento as r',
'FROM fac_imp_tipo_venta_tb_nx',
'WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || itv_emp_empresa || '':'') > 0',
'GROUP BY itv_emp_empresa, itv_dep_departamento',
'ORDER BY itv_dep_departamento'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Todos--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052581399001878255)
,p_name=>'P1_FAMILIA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_prompt=>'Familia'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT fma_descripcion ||'' (''||fma_familia||'')'' as d, fma_familia as r',
'FROM inv_familia_tb_nx',
'WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || fma_emp_empresa || '':'') > 0',
'GROUP BY fma_familia, fma_descripcion',
'ORDER BY fma_familia'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Todos--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052581503628878256)
,p_name=>'P1_SEGMENTO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_prompt=>'Segmento'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT seg_descripcion ||'' (''||seg_segmento||'')'' as d, seg_segmento as r',
'FROM fac_segmento_mercado_tb_nx',
'GROUP BY seg_segmento, seg_descripcion',
'ORDER BY seg_segmento'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Todos--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052582510617878266)
,p_name=>'P1_TVENTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14052581111176878252)
,p_prompt=>'T. Venta'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Contado;CON,Credito;CRE'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Todos--'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052835267985567630)
,p_name=>'P1_TANO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_prompt=>'Analisis'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Fiscal;F,Natural;N'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052835465476567632)
,p_name=>'P1_ANO_ACT'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14052835519663567633)
,p_name=>'P1_ANO_ANT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14051962854835374868)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14052579546435878236)
,p_computation_sequence=>20
,p_computation_item=>'P1_EMPRESA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT empresa',
'FROM nss_usuario_empresa_vw_nx',
'WHERE username = :APP_USER'))
,p_compute_when=>'P1_EMPRESA'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14052579234887878233)
,p_computation_sequence=>30
,p_computation_item=>'P1_TIPO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'1'
,p_compute_when=>'P1_TIPO'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14052835348526567631)
,p_computation_sequence=>40
,p_computation_item=>'P1_TANO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'F'
,p_compute_when=>'P1_TANO'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14052579416340878235)
,p_computation_sequence=>50
,p_computation_item=>'P1_MONEDA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT valor',
'FROM gnl_parametro_empresa_tb_nx',
'WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || EMPRESA || '':'') > 0',
'AND subsistema = ''CGL''',
'AND parametro = ''MONEDA'';'))
,p_compute_when=>'P1_MONEDA'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14052579968129878240)
,p_computation_sequence=>60
,p_computation_item=>'P1_MON_LOCAL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT valor',
'FROM gnl_parametro_empresa_tb_nx',
'WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || EMPRESA || '':'') > 0',
'AND subsistema = ''CGL''',
'AND parametro = ''MONEDA'';'))
,p_compute_when=>'P1_EMPRESA'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14052580032266878241)
,p_computation_sequence=>70
,p_computation_item=>'P1_MON_ALT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT valor',
'FROM gnl_parametro_empresa_tb_nx',
'WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || EMPRESA || '':'') > 0',
'AND subsistema = ''GNL''',
'AND parametro = ''MONEDA CONVERSION'';'))
,p_compute_when=>'P1_EMPRESA'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14052835605505567634)
,p_computation_sequence=>80
,p_computation_item=>'P1_ANO_ACT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   fecha1_v date;',
'   fecha2_v date;   ',
'BEGIN',
'   IF :P1_TANO = ''N'' THEN',
'      return to_char(Trunc(SYSDATE, ''RRRR''), ''DDMMRRRR'')||'':''||To_char(SYSDATE, ''DDMMRRRR'');',
'   ELSE',
'      SELECT min(fecha_inicio)',
'      INTO fecha1_v',
'      FROM cgl_periodo_tr_nx',
'      WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || EMP_EMPRESA || '':'') > 0',
'      AND ano = to_char(SYSDATE, ''RRRR'')',
'      AND tipo IN (1,2);',
'      ',
'      fecha1_v := nvl(fecha1_v, to_char(Trunc(SYSDATE, ''RRRR''), ''DDMMRRRR''));',
'',
'      SELECT max(fecha_fin)',
'      INTO fecha2_v',
'      FROM cgl_periodo_tr_nx',
'      WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || EMP_EMPRESA || '':'') > 0',
'      AND ano = to_char(SYSDATE, ''RRRR'')',
'      AND tipo IN (1,2);',
'      ',
'      fecha2_v := nvl(fecha2_v, To_char(SYSDATE, ''DDMMRRRR''));',
'      ',
'      return to_char(fecha1_v, ''DDMMRRRR'')||'':''||To_char(fecha2_v, ''DDMMRRRR'');',
'   END IF;',
'   return null;',
'END;'))
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14052835729528567635)
,p_computation_sequence=>90
,p_computation_item=>'P1_ANO_ANT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   fecha1_v date;',
'   fecha2_v date;   ',
'BEGIN',
'   IF :P1_TANO = ''N'' THEN',
'      return to_char(Add_months(Trunc(SYSDATE, ''RRRR''), -12), ''DDMMRRRR'')||'':''||To_char(Trunc(SYSDATE, ''RRRR'') - 1, ''DDMMRRRR'');',
'   ELSE',
'      SELECT min(fecha_inicio)',
'      INTO fecha1_v',
'      FROM cgl_periodo_tr_nx',
'      WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || EMP_EMPRESA || '':'') > 0',
'      AND ano = to_char(SYSDATE, ''RRRR'')-1',
'      AND tipo IN (1,2);',
'      ',
'      fecha1_v := nvl(fecha1_v, to_char(Add_months(Trunc(SYSDATE, ''RRRR''), -12), ''DDMMRRRR''));',
'',
'      SELECT max(fecha_fin)',
'      INTO fecha2_v',
'      FROM cgl_periodo_tr_nx',
'      WHERE INSTR ('':'' || :P1_EMPRESA || '':'', '':'' || EMP_EMPRESA || '':'') > 0',
'      AND ano = to_char(SYSDATE, ''RRRR'')-1',
'      AND tipo IN (1,2);',
'      ',
'      fecha2_v := nvl(fecha2_v, To_char(Trunc(SYSDATE, ''RRRR'') - 1, ''DDMMRRRR''));',
'      ',
'      return to_char(fecha1_v, ''DDMMRRRR'')||'':''||To_char(fecha2_v, ''DDMMRRRR'');',
'   END IF;',
'   return null;',
'END;'))
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(13997152848913256656)
,p_computation_sequence=>100
,p_computation_item=>'P1_FRECUENCIA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'D'
,p_compute_when=>'P1_FRECUENCIA'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052582371043878264)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'acu_act_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    CURSOR c_reg IS',
'    SELECT',
'        mes,',
'        SUM(monto) monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                   empresa,',
'                to_char(',
'                    tra_fecha, ''MMRRRR''',
'                )      mes,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( tra_subtotal - tra_descuento )',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( tra_subtotal - tra_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( tra_subtotal - tra_descuento )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( tra_subtotal - tra_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_status <> ''C''',
'                AND tra_fecha BETWEEN to_date(',
'                    substr(',
'                        :p1_ano_act, 1,',
'                        8',
'                    ), ''DDMMRRRR''',
'                ) AND to_date(',
'                    substr(',
'                        :p1_ano_act, 10,',
'                        8',
'                    )',
'                    || '' 23:59'', ''DDMMRRRR HH24:MI''',
'                )',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                   empresa,',
'                to_char(',
'                    ncd_fecha, ''MMRRRR''',
'                )      mes,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * ncd_valor_cambio * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) / ncd_valor_cambio * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ncd_fecha BETWEEN to_date(',
'                    substr(',
'                        :p1_ano_act, 1,',
'                        8',
'                    ), ''DDMMRRRR''',
'                ) AND to_date(',
'                    substr(',
'                        :p1_ano_act, 10,',
'                        8',
'                    )',
'                    || '' 23:59'', ''DDMMRRRR HH24:MI''',
'                )',
'        )',
'    GROUP BY',
'        mes',
'    ORDER BY',
'        substr(',
'            mes, 3,',
'            4',
'        ),',
'        substr(',
'            mes, 1,',
'            2',
'        );',
'',
'    monto_v  NUMBER := 0;',
'    l_query  CLOB;',
'    id_v     NUMBER;',
'    mes_v    VARCHAR2(2);',
'BEGIN',
'    IF :p1_tano = ''N'' THEN',
'        l_query := ''SELECT ''''01'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''02'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''03'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''04'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''05'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''06'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''07'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''08'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''09'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''10'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''11'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''12'''' FROM DUAL'';',
'    ELSE',
'        l_query := ''SELECT periodo, to_char(fecha_inicio,''''MMRRRR'''') ''',
'                   || ''FROM cgl_periodo_tr_nx ''',
'                   || ''WHERE INSTR ('''':''',
'                   || :p1_empresa',
'                   || '':'''', '''':'''' || EMP_EMPRESA || '''':'''') > 0 ''',
'                   || ''AND ano = to_char(SYSDATE, ''''RRRR'''') ''',
'                   || ''AND tipo IN (1,2) ''',
'                   || ''AND cierre = ''''N'''' ''',
'                   || ''GROUP BY periodo, to_char(fecha_inicio,''''MMRRRR'''') ''',
'                   || ''ORDER BY 1,2'';',
'    END IF;',
'',
'    IF apex_collection.collection_exists(''F_MBACASE5:P1:ACTA'') THEN',
'        apex_collection.delete_collection(''F_MBACASE5:P1:ACTA'');',
'    END IF;',
'    apex_collection.create_collection_from_query(',
'        p_collection_name  => ''F_MBACASE5:P1:ACTA'',',
'        p_query            => l_query,',
'                                                 p_generate_md5     => ''NO''',
'    );',
'',
'    FOR a IN c_reg LOOP',
'        monto_v := monto_v + a.monto;',
'        IF :p1_tano = ''N'' THEN',
'            SELECT',
'                MIN(seq_id)',
'            INTO id_v',
'            FROM',
'                apex_collections',
'            WHERE',
'                    collection_name = ''F_MBACASE5:P1:ACTA''',
'                AND c001 = substr(',
'                    a.mes, 1,',
'                    2',
'                );',
'',
'            mes_v := substr(',
'                a.mes,',
'                1,',
'       2',
'            );',
'        ELSE',
'            SELECT',
'                MIN(seq_id),',
'                MIN(c001)',
'            INTO',
'                id_v,',
'                mes_v',
'            FROM',
'                apex_collections',
'            WHERE',
'                    collection_name = ''F_MBACASE5:P1:ACTA''',
'                AND c002 = a.mes;',
'',
'        END IF;',
'',
'        IF id_v IS NOT NULL THEN',
'            apex_collection.update_member(',
'                p_collection_name  => ''F_MBACASE5:P1:ACTA'',',
'                p_seq              => id_v,',
'                                          p_c001             => mes_v,',
'                                          p_n001             => monto_v',
'            );',
'        END IF;',
'',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_EMPRESA'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052582464223878265)
,p_process_sequence=>20
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'acu_ant_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    CURSOR c_reg IS',
'    SELECT',
'        mes,',
'        SUM(monto) monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                   empresa,',
'                to_char(',
'                    tra_fecha, ''MMRRRR''',
'                )      mes,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( tra_subtotal - tra_descuento )',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( tra_subtotal - tra_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( tra_subtotal - tra_descuento )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( tra_subtotal - tra_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_status <> ''C''',
'                AND tra_fecha BETWEEN to_date(',
'                    substr(',
'                        :p1_ano_ant, 1,',
'                        8',
'                    ), ''DDMMRRRR''',
'                ) AND to_date(',
'                    substr(',
'                        :p1_ano_ant, 10,',
'                        8',
'                    )',
'                    || '' 23:59'', ''DDMMRRRR HH24:MI''',
'                )',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                   empresa,',
'                to_char(',
'                    ncd_fecha, ''MMRRRR''',
'                )      mes,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * ncd_valor_cambio * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) / ncd_valor_cambio * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ncd_fecha BETWEEN to_date(',
'                    substr(',
'                        :p1_ano_ant, 1,',
'                        8',
'                    ), ''DDMMRRRR''',
'                ) AND to_date(',
'                    substr(',
'                        :p1_ano_ant, 10,',
'                        8',
'                    )',
'                    || '' 23:59'', ''DDMMRRRR HH24:MI''',
'                )',
'        )',
'    GROUP BY',
'        mes',
'    ORDER BY',
'        substr(',
'            mes, 3,',
'            4',
'        ),',
'        substr(',
'            mes, 1,',
'            2',
'        );',
'',
'    monto_v  NUMBER := 0;',
'    l_query  CLOB;',
'    id_v     NUMBER;',
'    mes_v    VARCHAR2(2);',
'BEGIN',
'    IF :p1_tano = ''N'' THEN',
'        l_query := ''SELECT ''''01'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''02'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''03'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''04'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''05'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''06'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''07'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''08'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''09'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''10'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''11'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''12'''' FROM DUAL'';',
'    ELSE',
'        l_query := ''SELECT periodo, to_char(fecha_inicio,''''MMRRRR'''') ''',
'                   || ''FROM cgl_periodo_tr_nx ''',
'                   || ''WHERE INSTR ('''':''',
'                   || :p1_empresa',
'                   || '':'''', '''':'''' || EMP_EMPRESA || '''':'''') > 0 ''',
'                   || ''AND ano = to_char(SYSDATE, ''''RRRR'''') -1 ''',
'                   || ''AND tipo IN (1,2) ''',
'                   || ''AND cierre = ''''N'''' ''',
'                   || ''GROUP BY periodo, to_char(fecha_inicio,''''MMRRRR'''') ''',
'                   || ''ORDER BY 1,2'';',
'    END IF;',
'',
'    IF apex_collection.collection_exists(''F_MBACASE5:P1:ANTA'') THEN',
'        apex_collection.delete_collection(''F_MBACASE5:P1:ANTA'');',
'    END IF;',
'    apex_collection.create_collection_from_query(',
'        p_collection_name  => ''F_MBACASE5:P1:ANTA'',',
'        p_query            => l_query,',
'                                                 p_generate_md5     => ''NO''',
'    );',
'',
'    FOR a IN c_reg LOOP',
'        monto_v := monto_v + a.monto;',
'        IF :p1_tano = ''N'' THEN',
'            SELECT',
'                MIN(seq_id)',
'            INTO id_v',
'            FROM',
'                apex_collections',
'            WHERE',
'                    collection_name = ''F_MBACASE5:P1:ANTA''',
'                AND c001 = substr(',
'                    a.mes, 1,',
'                    2',
'                );',
'',
'            mes_v := substr(',
'                a.mes,',
'                1,',
'       2',
'            );',
'        ELSE',
'            SELECT',
'                MIN(seq_id),',
'                MIN(c001)',
'            INTO',
'                id_v,',
'                mes_v',
'            FROM',
'                apex_collections',
'            WHERE',
'                    collection_name = ''F_MBACASE5:P1:ANTA''',
'                AND c002 = a.mes;',
'',
'        END IF;',
'',
'        IF id_v IS NOT NULL THEN',
'            apex_collection.update_member(',
'                p_collection_name  => ''F_MBACASE5:P1:ANTA'',',
'                p_seq              => id_v,',
'                                          p_c001             => mes_v,',
'                                          p_n001             => monto_v',
'            );',
'        END IF;',
'',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_EMPRESA'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13997152671445256654)
,p_process_sequence=>30
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'men_act_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    CURSOR c_reg IS',
'    SELECT',
'        mes,',
'        SUM(monto) monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                   empresa,',
'                to_char(',
'                    tra_fecha, ''MMRRRR''',
'                )      mes,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( tra_subtotal - tra_descuento )',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( tra_subtotal - tra_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( tra_subtotal - tra_descuento )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( tra_subtotal - tra_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_status <> ''C''',
'                AND tra_fecha BETWEEN to_date(',
'                    substr(',
'                        :p1_ano_act, 1,',
'                        8',
'                    ), ''DDMMRRRR''',
'                ) AND to_date(',
'                    substr(',
'                        :p1_ano_act, 10,',
'                        8',
'                    )',
'                    || '' 23:59'', ''DDMMRRRR HH24:MI''',
'                )',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                   empresa,',
'                to_char(',
'                    ncd_fecha, ''MMRRRR''',
'                )      mes,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * ncd_valor_cambio * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) / ncd_valor_cambio * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ncd_fecha BETWEEN to_date(',
'                    substr(',
'                        :p1_ano_act, 1,',
'                        8',
'                    ), ''DDMMRRRR''',
'                ) AND to_date(',
'                    substr(',
'                        :p1_ano_act, 10,',
'                        8',
'                    )',
'                    || '' 23:59'', ''DDMMRRRR HH24:MI''',
'                )',
'        )',
'    GROUP BY',
'        mes',
'    ORDER BY',
'        substr(',
'            mes, 3,',
'            4',
'        ),',
'        substr(',
'            mes, 1,',
'            2',
'        );',
'',
'    l_query  CLOB;',
'    id_v     NUMBER;',
'    mes_v    VARCHAR2(2);',
'BEGIN',
'    IF :p1_tano = ''N'' THEN',
'        l_query := ''SELECT ''''01'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''02'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''03'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''04'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''05'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''06'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''07'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''08'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''09'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''10'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''11'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''12'''' FROM DUAL'';',
'    ELSE',
'        l_query := ''SELECT periodo, to_char(fecha_inicio,''''MMRRRR'''') ''',
'                   || ''FROM cgl_periodo_tr_nx ''',
'                   || ''WHERE INSTR ('''':''',
'                   || :p1_empresa',
'                   || '':'''', '''':'''' || EMP_EMPRESA || '''':'''') > 0 ''',
'                   || ''AND ano = to_char(SYSDATE, ''''RRRR'''') ''',
'                   || ''AND tipo IN (1,2) ''',
'                   || ''AND cierre = ''''N'''' ''',
'                   || ''GROUP BY periodo, to_char(fecha_inicio,''''MMRRRR'''') ''',
'                   || ''ORDER BY 1,2'';',
'    END IF;',
'',
'    IF apex_collection.collection_exists(''F_MBACASE5:P1:ACTM'') THEN',
'        apex_collection.delete_collection(''F_MBACASE5:P1:ACTM'');',
'    END IF;',
'    apex_collection.create_collection_from_query(',
'        p_collection_name  => ''F_MBACASE5:P1:ACTM'',',
'        p_query            => l_query,',
'                                                 p_generate_md5     => ''NO''',
'    );',
'',
'    FOR a IN c_reg LOOP',
'        IF :p1_tano = ''N'' THEN',
'            SELECT',
'                MIN(seq_id)',
'            INTO id_v',
'            FROM',
'                apex_collections',
'            WHERE',
'                    collection_name = ''F_MBACASE5:P1:ACTM''',
'                AND c001 = substr(',
'                    a.mes, 1,',
'                    2',
'                );',
'',
'            mes_v := substr(',
'                a.mes,',
'                1,',
'       2',
'            );',
'        ELSE',
'            SELECT',
'                MIN(seq_id),',
'                MIN(c001)',
'            INTO',
'                id_v,',
'                mes_v',
'            FROM',
'                apex_collections',
'            WHERE',
'                    collection_name = ''F_MBACASE5:P1:ACTM''',
'                AND c002 = a.mes;',
'',
'        END IF;',
'',
'        IF id_v IS NOT NULL THEN',
'            apex_collection.update_member(',
'                p_collection_name  => ''F_MBACASE5:P1:ACTM'',',
'                p_seq              => id_v,',
'                                          p_c001             => mes_v,',
'                                          p_n001             => a.monto',
'            );',
'',
'        END IF;',
'',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_EMPRESA'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13997152748579256655)
,p_process_sequence=>40
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'men_ant_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    CURSOR c_reg IS',
'    SELECT',
'        mes,',
'        SUM(monto) monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                   empresa,',
'                to_char(',
'                    tra_fecha, ''MMRRRR''',
'                )      mes,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( tra_subtotal - tra_descuento )',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( tra_subtotal - tra_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( tra_subtotal - tra_descuento )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( tra_subtotal - tra_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_status <> ''C''',
'                AND tra_fecha BETWEEN to_date(',
'                    substr(',
'                        :p1_ano_ant, 1,',
'                        8',
'                    ), ''DDMMRRRR''',
'                ) AND to_date(',
'                    substr(',
'                        :p1_ano_ant, 10,',
'                        8',
'                    )',
'                    || '' 23:59'', ''DDMMRRRR HH24:MI''',
'                )',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                   empresa,',
'                to_char(',
'                    ncd_fecha, ''MMRRRR''',
'                )      mes,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * ncd_valor_cambio * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        (',
'                            SELECT',
'                                SUM(subtotal - descuento) / ncd_valor_cambio * - 1',
'                            FROM',
'                                fac_nc_detalle_art_serv_vw_nx',
'                            WHERE',
'                                transaccion = ncd_transaccion',
'                        )',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ncd_fecha BETWEEN to_date(',
'                    substr(',
'                        :p1_ano_ant, 1,',
'                        8',
'                    ), ''DDMMRRRR''',
'                ) AND to_date(',
'                    substr(',
'                        :p1_ano_ant, 10,',
'                        8',
'                    )',
'                    || '' 23:59'', ''DDMMRRRR HH24:MI''',
'                )',
'        )',
'    GROUP BY',
'        mes',
'    ORDER BY',
'        substr(',
'            mes, 3,',
'            4',
'        ),',
'        substr(',
'            mes, 1,',
'            2',
'        );',
'',
'    l_query  CLOB;',
'    id_v     NUMBER;',
'    mes_v    VARCHAR2(2);',
'BEGIN',
'    IF :p1_tano = ''N'' THEN',
'        l_query := ''SELECT ''''01'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''02'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''03'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''04'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''05'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''06'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''07'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''08'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''09'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''10'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''11'''' FROM DUAL ''',
'                   || ''UNION ALL SELECT ''''12'''' FROM DUAL'';',
'    ELSE',
'        l_query := ''SELECT periodo, to_char(fecha_inicio,''''MMRRRR'''') ''',
'                   || ''FROM cgl_periodo_tr_nx ''',
'                   || ''WHERE INSTR ('''':''',
'                   || :p1_empresa',
'                   || '':'''', '''':'''' || EMP_EMPRESA || '''':'''') > 0 ''',
'                   || ''AND ano = to_char(SYSDATE, ''''RRRR'''') -1 ''',
'                   || ''AND tipo IN (1,2) ''',
'                   || ''AND cierre = ''''N'''' ''',
'                   || ''GROUP BY periodo, to_char(fecha_inicio,''''MMRRRR'''') ''',
'                   || ''ORDER BY 1,2'';',
'    END IF;',
'',
'    IF apex_collection.collection_exists(''F_MBACASE5:P1:ANTM'') THEN',
'        apex_collection.delete_collection(''F_MBACASE5:P1:ANTM'');',
'    END IF;',
'    apex_collection.create_collection_from_query(',
'        p_collection_name  => ''F_MBACASE5:P1:ANTM'',',
'        p_query            => l_query,',
'                                                 p_generate_md5     => ''NO''',
'    );',
'',
'    FOR a IN c_reg LOOP',
'        IF :p1_tano = ''N'' THEN',
'            SELECT',
'                MIN(seq_id)',
'            INTO id_v',
'            FROM',
'                apex_collections',
'            WHERE',
'                    collection_name = ''F_MBACASE5:P1:ANTM''',
'                AND c001 = substr(',
'                    a.mes, 1,',
'                    2',
'                );',
'',
'            mes_v := substr(',
'                a.mes,',
'                1,',
'       2',
'            );',
'        ELSE',
'            SELECT',
'                MIN(seq_id),',
'                MIN(c001)',
'            INTO',
'                id_v,',
'                mes_v',
'            FROM',
'                apex_collections',
'            WHERE',
'                    collection_name = ''F_MBACASE5:P1:ANTM''',
'                AND c002 = a.mes;',
'',
'        END IF;',
'',
'        IF id_v IS NOT NULL THEN',
'            apex_collection.update_member(',
'                p_collection_name  => ''F_MBACASE5:P1:ANTM'',',
'                p_seq              => id_v,',
'                                          p_c001             => mes_v,',
'                                          p_n001             => a.monto',
'            );',
'',
'        END IF;',
'',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_EMPRESA'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052583337746878274)
,p_process_sequence=>50
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'diario_act_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    inicial_v date := trunc(sysdate);',
'    final_v date := to_date(to_char(sysdate, ''DDMMRRRR'') || '' 23:59'', ''DDMMRRRR HH24:MI'');',
'    ',
'    CURSOR c_reg IS',
'    SELECT',
'        vendedor,',
'        fac_nom_vend_v_nx(',
'            empresa, vendedor',
'        )              ven_nombre,',
'        departamento,',
'        fac_nombre_depto_v_nx(',
'            empresa, departamento',
'        )      dep_nombre,',
'        familia,',
'        inv_descrip_fam_v_nx(',
'            empresa, familia',
'        )            fam_nombre,',
'        segmento,',
'        fac_descrip_seg_v_nx(segmento)                    seg_nombre,',
'        SUM(monto)                                        monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    det_emp_empresa, det_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = det_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    des_emp_empresa, des_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_fact_serv_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = des_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    dnc_emp_empresa, dnc_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dnc_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    dns_emp_empresa, dns_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_serv_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dns_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v',
'        )',
'    WHERE',
'        ( :p1_familia IS NULL',
'          OR instr(',
'            '':''',
'            || :p1_familia',
'            || '':'', '':''',
'                    || familia',
'                    || '':''',
'        ) > 0 )',
'        AND ( :p1_segmento IS NULL',
'              OR instr(',
'            '':''',
'            || :p1_segmento',
'            || '':'', '':''',
'                    || segmento',
'                    || '':''',
'        ) > 0 )',
'    GROUP BY',
'        empresa,',
'        vendedor,',
'        departamento,',
'        familia,',
'        segmento;',
'',
'BEGIN',
'    apex_collection.create_or_truncate_collection(''F_MBACASE5:P1:ACT:D'');',
'    FOR a IN c_reg LOOP',
'        apex_collection.add_member(',
'            p_collection_name  => ''F_MBACASE5:P1:ACT:D'',',
'            p_c001             => a.vendedor,',
'                                   p_c002             => a.ven_nombre,',
'                                   p_c003             => a.departamento,',
'                                   p_c004             => a.dep_nombre,',
'                                   p_c005             => a.familia,',
'                                   p_c006             => a.fam_nombre,',
'                                   p_c007             => a.segmento,',
'                                   p_c008             => a.seg_nombre,',
'                                   p_n001             => a.monto',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_FRECUENCIA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'D'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052583454211878275)
,p_process_sequence=>60
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'diario_ant_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    inicial_v date := trunc(sysdate) - 1;',
'    final_v date := to_date(to_char(sysdate - 1, ''DDMMRRRR'') || '' 23:59'', ''DDMMRRRR HH24:MI'');',
'    ',
'    CURSOR c_reg IS',
'    SELECT',
'        vendedor,',
'        fac_nom_vend_v_nx(',
'            empresa, vendedor',
'        )              ven_nombre,',
'        departamento,',
'        fac_nombre_depto_v_nx(',
'            empresa, departamento',
'        )      dep_nombre,',
'        familia,',
'        inv_descrip_fam_v_nx(',
'            empresa, familia',
'        )            fam_nombre,',
'        segmento,',
'        fac_descrip_seg_v_nx(segmento)                    seg_nombre,',
'        SUM(monto)                                        monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    det_emp_empresa, det_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = det_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    des_emp_empresa, des_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_fact_serv_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = des_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN  inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    dnc_emp_empresa, dnc_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dnc_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN  inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    dns_emp_empresa, dns_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_serv_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dns_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN  inicial_v AND final_v',
'        )',
'    WHERE',
'        ( :p1_familia IS NULL',
'          OR instr(',
'            '':''',
'            || :p1_familia',
'            || '':'', '':''',
'                    || familia',
'                    || '':''',
'        ) > 0 )',
'        AND ( :p1_segmento IS NULL',
'              OR instr(',
'            '':''',
'            || :p1_segmento',
'            || '':'', '':''',
'                    || segmento',
'                    || '':''',
'        ) > 0 )',
'    GROUP BY',
'        empresa,',
'        vendedor,',
'        departamento,',
'        familia,',
'        segmento;',
'',
'BEGIN',
'    apex_collection.create_or_truncate_collection(''F_MBACASE5:P1:ANT:D'');',
'    FOR a IN c_reg LOOP',
'        apex_collection.add_member(',
'            p_collection_name  => ''F_MBACASE5:P1:ANT:D'',',
'            p_c001             => a.vendedor,',
'                                   p_c002             => a.ven_nombre,',
'                                   p_c003             => a.departamento,',
'                                   p_c004             => a.dep_nombre,',
'                                   p_c005             => a.familia,',
'                                   p_c006             => a.fam_nombre,',
'                                   p_c007             => a.segmento,',
'                                   p_c008             => a.seg_nombre,',
'                                   p_n001             => a.monto',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_FRECUENCIA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'D'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052583516720878276)
,p_process_sequence=>70
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'semana_act_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    inicial_v date := trunc(sysdate) - 7;',
'    final_v date := to_date(to_char(sysdate, ''DDMMRRRR'') || '' 23:59'', ''DDMMRRRR HH24:MI'');',
'    ',
'    CURSOR c_reg IS',
'    SELECT',
'        vendedor,',
'        fac_nom_vend_v_nx(',
'            empresa, vendedor',
'        )              ven_nombre,',
'        departamento,',
'        fac_nombre_depto_v_nx(',
'            empresa, departamento',
'        )      dep_nombre,',
'        familia,',
'        inv_descrip_fam_v_nx(',
'            empresa, familia',
'        )            fam_nombre,',
'        segmento,',
'        fac_descrip_seg_v_nx(segmento)                    seg_nombre,',
'        SUM(monto)                                        monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    det_emp_empresa, det_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = det_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN  inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    des_emp_empresa, des_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_fact_serv_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = des_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN  inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    dnc_emp_empresa, dnc_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dnc_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN  inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    dns_emp_empresa, dns_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_serv_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dns_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN  inicial_v AND final_v',
'        )',
'    WHERE',
'        ( :p1_familia IS NULL',
'          OR instr(',
'            '':''',
'            || :p1_familia',
'            || '':'', '':''',
'                    || familia',
'                    || '':''',
'        ) > 0 )',
'        AND ( :p1_segmento IS NULL',
'              OR instr(',
'            '':''',
'            || :p1_segmento',
'            || '':'', '':''',
'                    || segmento',
'                    || '':''',
'        ) > 0 )',
'    GROUP BY',
'        empresa,',
'        vendedor,',
'        departamento,',
'        familia,',
'        segmento;',
'',
'BEGIN',
'    apex_collection.create_or_truncate_collection(''F_MBACASE5:P1:ACT:S'');',
'    FOR a IN c_reg LOOP',
'        apex_collection.add_member(',
'            p_collection_name  => ''F_MBACASE5:P1:ACT:S'',',
'            p_c001             => a.vendedor,',
'                                   p_c002             => a.ven_nombre,',
'                                   p_c003             => a.departamento,',
'                                   p_c004             => a.dep_nombre,',
'                                   p_c005             => a.familia,',
'                                   p_c006             => a.fam_nombre,',
'                                   p_c007             => a.segmento,',
'                                   p_c008             => a.seg_nombre,',
'                                   p_n001             => a.monto',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_FRECUENCIA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'S'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052583696136878277)
,p_process_sequence=>80
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'semana_ant_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    inicial_v date := trunc(add_months(sysdate - 7, -12));',
'    final_v date := to_date(to_char(add_months(sysdate, -12), ''DDMMRRRR'') || '' 23:59'', ''DDMMRRRR HH24:MI'');',
'    ',
'    CURSOR c_reg IS',
'    SELECT',
'        vendedor,',
'        fac_nom_vend_v_nx(',
'            empresa, vendedor',
'        )              ven_nombre,',
'        departamento,',
'        fac_nombre_depto_v_nx(',
'            empresa, departamento',
'        )      dep_nombre,',
'        familia,',
'        inv_descrip_fam_v_nx(',
'            empresa, familia',
'        )            fam_nombre,',
'        segmento,',
'        fac_descrip_seg_v_nx(segmento)                    seg_nombre,',
'        SUM(monto)                                        monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    det_emp_empresa, det_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = det_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    des_emp_empresa, des_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_fact_serv_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = des_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN  inicial_v AND final_v           ',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    dnc_emp_empresa, dnc_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dnc_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN  inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    dns_emp_empresa, dns_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_serv_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dns_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN  inicial_v AND final_v           ',
'        )',
'    WHERE',
'        ( :p1_familia IS NULL',
'          OR instr(',
'            '':''',
'            || :p1_familia',
'            || '':'', '':''',
'                    || familia',
'                    || '':''',
'        ) > 0 )',
'        AND ( :p1_segmento IS NULL',
'              OR instr(',
'            '':''',
'            || :p1_segmento',
'            || '':'', '':''',
'                    || segmento',
'                    || '':''',
'        ) > 0 )',
'    GROUP BY',
'        empresa,',
'        vendedor,',
'        departamento,',
'        familia,',
'        segmento;',
'',
'BEGIN',
'    apex_collection.create_or_truncate_collection(''F_MBACASE5:P1:ANT:S'');',
'    FOR a IN c_reg LOOP',
'        apex_collection.add_member(',
'            p_collection_name  => ''F_MBACASE5:P1:ANT:S'',',
'            p_c001             => a.vendedor,',
'                                   p_c002             => a.ven_nombre,',
'                                   p_c003             => a.departamento,',
'                                   p_c004             => a.dep_nombre,',
'                                   p_c005             => a.familia,',
'                                   p_c006             => a.fam_nombre,',
'                                   p_c007             => a.segmento,',
'                                   p_c008             => a.seg_nombre,',
'                                   p_n001             => a.monto',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_FRECUENCIA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'S'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052583748990878278)
,p_process_sequence=>90
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'mensual_act_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    inicial_v date := trunc(sysdate, ''MM'');',
'    final_v date := to_date(to_char(sysdate, ''DDMMRRRR'') || '' 23:59'', ''DDMMRRRR HH24:MI'');',
'    ',
'    CURSOR c_reg IS',
'    SELECT',
'        vendedor,',
'        fac_nom_vend_v_nx(',
'            empresa, vendedor',
'        )              ven_nombre,',
'        departamento,',
'        fac_nombre_depto_v_nx(',
'            empresa, departamento',
'        )      dep_nombre,',
'        familia,',
'        inv_descrip_fam_v_nx(',
'            empresa, familia',
'        )            fam_nombre,',
'        segmento,',
'        fac_descrip_seg_v_nx(segmento)                    seg_nombre,',
'        SUM(monto)                                        monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    det_emp_empresa, det_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = det_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    des_emp_empresa, des_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_fact_serv_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = des_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v           ',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    dnc_emp_empresa, dnc_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dnc_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    dns_emp_empresa, dns_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_serv_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dns_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v            ',
'        )',
'    WHERE',
'        ( :p1_familia IS NULL',
'          OR instr(',
'            '':''',
'            || :p1_familia',
'            || '':'', '':''',
'                    || familia',
'                    || '':''',
'        ) > 0 )',
'        AND ( :p1_segmento IS NULL',
'              OR instr(',
'            '':''',
'            || :p1_segmento',
'            || '':'', '':''',
'                    || segmento',
'                    || '':''',
'        ) > 0 )',
'    GROUP BY',
'        empresa,',
'        vendedor,',
'        departamento,',
'        familia,',
'        segmento;',
'',
'BEGIN',
'    apex_collection.create_or_truncate_collection(''F_MBACASE5:P1:ACT:M'');',
'    FOR a IN c_reg LOOP',
'        apex_collection.add_member(',
'            p_collection_name  => ''F_MBACASE5:P1:ACT:M'',',
'            p_c001             => a.vendedor,',
'                                   p_c002             => a.ven_nombre,',
'                                   p_c003             => a.departamento,',
'                                   p_c004             => a.dep_nombre,',
'                                   p_c005             => a.familia,',
'                                   p_c006             => a.fam_nombre,',
'                                   p_c007             => a.segmento,',
'                                   p_c008             => a.seg_nombre,',
'                                   p_n001             => a.monto',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_FRECUENCIA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'M'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052835163397567629)
,p_process_sequence=>100
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'mensual_ant_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    inicial_v date := trunc(add_months(trunc(sysdate, ''MM''), -12));',
'    final_v date := to_date(to_char(sysdate, ''DDMMRRRR'') || '' 23:59'', ''DDMMRRRR HH24:MI'');',
'    ',
'    CURSOR c_reg IS',
'    SELECT',
'        vendedor,',
'        fac_nom_vend_v_nx(',
'            empresa, vendedor',
'        )              ven_nombre,',
'        departamento,',
'        fac_nombre_depto_v_nx(',
'            empresa, departamento',
'        )      dep_nombre,',
'        familia,',
'        inv_descrip_fam_v_nx(',
'            empresa, familia',
'        )            fam_nombre,',
'        segmento,',
'        fac_descrip_seg_v_nx(segmento)                    seg_nombre,',
'        SUM(monto)                                        monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    det_emp_empresa, det_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = det_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    des_emp_empresa, des_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_fact_serv_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = des_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v            ',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    dnc_emp_empresa, dnc_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dnc_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    dns_emp_empresa, dns_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_serv_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dns_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v',
'        )',
'    WHERE',
'        ( :p1_familia IS NULL',
'          OR instr(',
'            '':''',
'            || :p1_familia',
'            || '':'', '':''',
'                    || familia',
'                    || '':''',
'        ) > 0 )',
'        AND ( :p1_segmento IS NULL',
'              OR instr(',
'            '':''',
'            || :p1_segmento',
'            || '':'', '':''',
'                    || segmento',
'                    || '':''',
'        ) > 0 )',
'    GROUP BY',
'        empresa,',
'        vendedor,',
'        departamento,',
'        familia,',
'        segmento;',
'',
'BEGIN',
'    apex_collection.create_or_truncate_collection(''F_MBACASE5:P1:ANT:M'');',
'    FOR a IN c_reg LOOP',
'        apex_collection.add_member(',
'            p_collection_name  => ''F_MBACASE5:P1:ANT:M'',',
'            p_c001             => a.vendedor,',
'                                   p_c002             => a.ven_nombre,',
'                                   p_c003             => a.departamento,',
'                                   p_c004             => a.dep_nombre,',
'                                   p_c005             => a.familia,',
'                                   p_c006             => a.fam_nombre,',
'                                   p_c007             => a.segmento,',
'                                   p_c008             => a.seg_nombre,',
'                                   p_n001             => a.monto',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_FRECUENCIA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'M'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052582871639878269)
,p_process_sequence=>110
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'anual_act_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    inicial_v date := trunc(sysdate, ''RRRR'');',
'    final_v date := to_date(to_char(sysdate, ''DDMMRRRR'') || '' 23:59'', ''DDMMRRRR HH24:MI'');',
'    ',
'    CURSOR c_reg IS',
'    SELECT',
'        vendedor,',
'        fac_nom_vend_v_nx(',
'            empresa, vendedor',
'        )              ven_nombre,',
'        departamento,',
'        fac_nombre_depto_v_nx(',
'            empresa, departamento',
'        )      dep_nombre,',
'        familia,',
'        inv_descrip_fam_v_nx(',
'            empresa, familia',
'        )            fam_nombre,',
'        segmento,',
'        fac_descrip_seg_v_nx(segmento)                    seg_nombre,',
'        SUM(monto)                                        monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    det_emp_empresa, det_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = det_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    des_emp_empresa, des_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_fact_serv_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = des_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    dnc_emp_empresa, dnc_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dnc_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    dns_emp_empresa, dns_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_serv_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dns_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v          ',
'        )',
'    WHERE',
'        ( :p1_familia IS NULL',
'          OR instr(',
'            '':''',
'            || :p1_familia',
'            || '':'', '':''',
'                    || familia',
'                    || '':''',
'        ) > 0 )',
'        AND ( :p1_segmento IS NULL',
'              OR instr(',
'            '':''',
'            || :p1_segmento',
'            || '':'', '':''',
'                    || segmento',
'                    || '':''',
'        ) > 0 )',
'    GROUP BY',
'        empresa,',
'        vendedor,',
'        departamento,',
'        familia,',
'        segmento;',
'',
'BEGIN',
'    apex_collection.create_or_truncate_collection(''F_MBACASE5:P1:ACT:A'');',
'    FOR a IN c_reg LOOP',
'        apex_collection.add_member(',
'            p_collection_name  => ''F_MBACASE5:P1:ACT:A'',',
'            p_c001             => a.vendedor,',
'                                   p_c002             => a.ven_nombre,',
'                                   p_c003             => a.departamento,',
'                                   p_c004             => a.dep_nombre,',
'                                   p_c005             => a.familia,',
'                                   p_c006             => a.fam_nombre,',
'                                   p_c007             => a.segmento,',
'                                   p_c008             => a.seg_nombre,',
'                                   p_n001             => a.monto',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_FRECUENCIA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'A'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14052583278013878273)
,p_process_sequence=>120
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'anual_ant_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    inicial_v date := add_months(trunc(sysdate, ''RRRR''), -12);',
'    final_v date := to_date(to_char(trunc(sysdate, ''RRRR'') - 1, ''DDMMRRRR'') || '' 23:59'', ''DDMMRRRR HH24:MI'');',
'    ',
'    CURSOR c_reg IS',
'    SELECT',
'        vendedor,',
'        fac_nom_vend_v_nx(',
'            empresa, vendedor',
'        )              ven_nombre,',
'        departamento,',
'        fac_nombre_depto_v_nx(',
'            empresa, departamento',
'        )      dep_nombre,',
'        familia,',
'        inv_descrip_fam_v_nx(',
'            empresa, familia',
'        )            fam_nombre,',
'        segmento,',
'        fac_descrip_seg_v_nx(segmento)                    seg_nombre,',
'        SUM(monto)                                        monto',
'    FROM',
'        (',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    det_emp_empresa, det_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( det_precio_local * det_cantidad ) - det_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( det_precio_local * det_cantidad ) - det_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = det_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                tra_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                tra_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    des_emp_empresa, des_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    tra_cli_emp_empresa, tra_cli_cliente,',
'                    tra_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda = :p1_mon_local THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND tra_mon_moneda <> :p1_mon_local THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) * tra_valor_cambio',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda = :p1_mon_alt THEN',
'                        ( des_precio_local * des_cantidad ) - des_descuento',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND tra_mon_moneda <> :p1_mon_alt THEN',
'                        ( ( des_precio_local * des_cantidad ) - des_descuento ) / tra_valor_cambio',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_factura_tb_nx,',
'                fac_detalle_fact_serv_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || tra_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND tra_transaccion = des_tra_transaccion',
'                AND tra_status <> ''C''',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND tra_fecha BETWEEN inicial_v AND final_v            ',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                inv_familia_art_v_nx(',
'                    dnc_emp_empresa, dnc_ato_articulo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dnc_monto - dnc_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dnc_monto - dnc_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_cr_db_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dnc_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || tra_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v',
'            UNION ALL',
'            SELECT',
'                ncd_emp_empresa                                              empresa,',
'                tra_ven_vendedor                                             vendedor,',
'                ncd_dep_departamento                                         departamento,',
'                tal_familia_servicio_v_nx(',
'                    dns_emp_empresa, dns_ser_consecutivo',
'                )      familia,',
'                fac_seg_cliente_v_nx(',
'                    ncd_cli_emp_empresa, ncd_cli_cliente,',
'                    ncd_cli_mon_moneda',
'                ) segmento,',
'                CASE',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda = :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_local',
'                         AND ncd_mon_moneda <> :p1_mon_local THEN',
'                        ( dns_monto - dns_descuento ) * ncd_valor_cambio * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda = :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) * - 1',
'                    WHEN :p1_moneda = :p1_mon_alt',
'                         AND ncd_mon_moneda <> :p1_mon_alt THEN',
'                        ( dns_monto - dns_descuento ) / ncd_valor_cambio * - 1',
'                    ELSE',
'                        0',
'                END monto',
'            FROM',
'                fac_notas_cr_db_tb_nx,',
'                fac_detalle_nota_serv_tb_nx,',
'                fac_factura_nota_tb_nx,',
'                fac_factura_tb_nx',
'            WHERE',
'                    instr(',
'                    '':''',
'                    || :p1_empresa',
'                    || '':'', '':''',
'                            || ncd_emp_empresa',
'                            || '':''',
'                ) > 0',
'                AND ncd_transaccion = dns_ncd_transaccion',
'                AND ncd_transaccion = fnt_ncd_transaccion',
'                AND fnt_tra_transaccion = tra_transaccion',
'                AND ncd_status NOT IN (',
'                    ''C'',',
'                    ''R''',
'                )',
'                AND ( :p1_tventa IS NULL',
'                      OR tra_tipo = :p1_tventa )',
'                AND ( :p1_vendedor IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_vendedor',
'                    || '':'', '':''',
'                            || tra_ven_vendedor',
'                            || '':''',
'                ) > 0 )',
'                AND ( :p1_departamento IS NULL',
'                      OR instr(',
'                    '':''',
'                    || :p1_departamento',
'                    || '':'', '':''',
'                            || ncd_dep_departamento',
'                            || '':''',
'                ) > 0 )',
'                AND ncd_fecha BETWEEN inicial_v AND final_v            ',
'        )',
'    WHERE',
'        ( :p1_familia IS NULL',
'          OR instr(',
'            '':''',
'            || :p1_familia',
'            || '':'', '':''',
'                    || familia',
'                    || '':''',
'        ) > 0 )',
'        AND ( :p1_segmento IS NULL',
'              OR instr(',
'            '':''',
'            || :p1_segmento',
'            || '':'', '':''',
'                    || segmento',
'                    || '':''',
'        ) > 0 )',
'    GROUP BY',
'        empresa,',
'        vendedor,',
'        departamento,',
'        familia,',
'        segmento;',
'',
'BEGIN',
'    apex_collection.create_or_truncate_collection(''F_MBACASE5:P1:ANT:A'');',
'    FOR a IN c_reg LOOP',
'        apex_collection.add_member(',
'            p_collection_name  => ''F_MBACASE5:P1:ANT:A'',',
'            p_c001             => a.vendedor,',
'                                   p_c002             => a.ven_nombre,',
'                                   p_c003             => a.departamento,',
'                                   p_c004             => a.dep_nombre,',
'                                   p_c005             => a.familia,',
'                                   p_c006             => a.fam_nombre,',
'                                   p_c007             => a.segmento,',
'                                   p_c008             => a.seg_nombre,',
'                                   p_n001             => a.monto',
'        );',
'    END LOOP;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_FRECUENCIA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'A'
);
wwv_flow_api.component_end;
end;
/
