prompt --application/pages/page_00114
begin
--   Manifest
--     PAGE: 00114
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>114
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'INV - Estadistica de Ventas'
,p_step_title=>'Estadistica de Ventas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165102'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096644302591061684)
,p_plug_name=>'Estadistica de Ventas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096646527772061690)
,p_plug_name=>unistr('Estad\00EDstica de Ventas')
,p_parent_plug_id=>wwv_flow_api.id(14096644302591061684)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   ETA_EMP_EMPRESA EMPRESA,',
'         ETA_ALN_LCN_LOCALIZACION LOCALIZACION,',
'         ETA_ALN_ATO_ARTICULO ARTICULO,',
unistr('         ETA_ANO A\00D1O,'),
'         ETA_MES MES,',
'         ETA_COMPRAS_UN COMPRAS,',
'         ETA_DEVOLUCION_CLIENTE_UN DEV_CLIENTE,',
'         ETA_ENTRADA_TOMA_FISICA_UN ENTRADA_TOMA_FISICA,',
'         ETA_ENTRADA_TRASLADO_UN ENTRADA_TRASLADO,',
'         ETA_ENTRADA_DESPIECE_UN ENTRADA_DESPIECE,',
'         ETA_ENTRADA_PRESTAMO_UN ENTRADA_PRESTAMO,',
'         ETA_OTRAS_ENTRADAS_UN OTRAS_ENTRADAS,',
'         ETA_VENTAS_UN VENTAS,',
'         ETA_DEVOLUCION_PROV_UN DEV_PROV,',
'         ETA_SALIDA_TOMA_FISICA_UN SALIDA_TOMA_FISICA,',
'         ETA_SALIDA_TRASLADO_UN SALIDA_TRASLADO,',
'         ETA_SALIDA_DESPIECE_UN SALIDA_DESPIECE,',
'         ETA_SALIDA_PRESTAMO_UN SALIDA_PRESTAMO,',
'         ETA_OTRAS_SALIDAS_UN OTRAS_SALIDAS,',
'         ETA_VENTAS_MOV VENTAS_MOV,',
'         ETA_VENTAS_PERDIDAS_UN VENTAS_PERDIDAS,',
'         ETA_VENTAS_PERDIDAS_MOV VENTAS_PERDIDAS_MOV,',
'         ETA_VENTAS_REEMP_UN VENTAS_REEMP,',
'         ETA_VENTAS_REEMP_MOV VENTAS_REEMP_MOV,',
'         ETA_FORECAST FORECAST',
'  FROM   INV_ESTADISTICA_TB_NX',
' WHERE       ETA_EMP_EMPRESA = :P114_EMPRESA',
'         AND ETA_ANO = NVL (:P114_ANNO, ETA_ANO)',
'         AND ETA_MES = NVL (:P114_MES, ETA_MES);'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P114_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14096646933309061705)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>8903208537172611
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096724164150981395)
,p_db_column_name=>'EMPRESA'
,p_display_order=>10
,p_column_identifier=>'CU'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096724318551981396)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>20
,p_column_identifier=>'CV'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096724412891981397)
,p_db_column_name=>'ARTICULO'
,p_display_order=>30
,p_column_identifier=>'CW'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096724429514981398)
,p_db_column_name=>unistr('A\00D1O')
,p_display_order=>40
,p_column_identifier=>'CX'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096724604630981399)
,p_db_column_name=>'MES'
,p_display_order=>50
,p_column_identifier=>'CY'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096724668921981400)
,p_db_column_name=>'COMPRAS'
,p_display_order=>60
,p_column_identifier=>'CZ'
,p_column_label=>'Compras'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096724752907981401)
,p_db_column_name=>'DEV_CLIENTE'
,p_display_order=>70
,p_column_identifier=>'DA'
,p_column_label=>'Dev. Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096725285677981406)
,p_db_column_name=>'OTRAS_ENTRADAS'
,p_display_order=>120
,p_column_identifier=>'DF'
,p_column_label=>'Otras entradas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096725416791981407)
,p_db_column_name=>'VENTAS'
,p_display_order=>130
,p_column_identifier=>'DG'
,p_column_label=>'Ventas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096725478128981408)
,p_db_column_name=>'DEV_PROV'
,p_display_order=>140
,p_column_identifier=>'DH'
,p_column_label=>'Dev. Prov'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096725970269981413)
,p_db_column_name=>'OTRAS_SALIDAS'
,p_display_order=>190
,p_column_identifier=>'DM'
,p_column_label=>'Otras salidas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726095917981414)
,p_db_column_name=>'VENTAS_MOV'
,p_display_order=>200
,p_column_identifier=>'DN'
,p_column_label=>'Ventas Mov'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726195892981415)
,p_db_column_name=>'VENTAS_PERDIDAS'
,p_display_order=>210
,p_column_identifier=>'DO'
,p_column_label=>'Ventas Perdidas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726251534981416)
,p_db_column_name=>'VENTAS_PERDIDAS_MOV'
,p_display_order=>220
,p_column_identifier=>'DP'
,p_column_label=>'Ventas Perdidas mov'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726342201981417)
,p_db_column_name=>'VENTAS_REEMP'
,p_display_order=>230
,p_column_identifier=>'DQ'
,p_column_label=>'Ventas Reemp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726459011981418)
,p_db_column_name=>'VENTAS_REEMP_MOV'
,p_display_order=>240
,p_column_identifier=>'DR'
,p_column_label=>'Ventas Reemp Mov'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726589664981419)
,p_db_column_name=>'FORECAST'
,p_display_order=>250
,p_column_identifier=>'DS'
,p_column_label=>'Forecast'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726661498981420)
,p_db_column_name=>'ENTRADA_TOMA_FISICA'
,p_display_order=>260
,p_column_identifier=>'DT'
,p_column_label=>'Entrada Toma Fisica'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726778377981421)
,p_db_column_name=>'ENTRADA_TRASLADO'
,p_display_order=>270
,p_column_identifier=>'DU'
,p_column_label=>'Entrada Traslado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726891512981422)
,p_db_column_name=>'ENTRADA_DESPIECE'
,p_display_order=>280
,p_column_identifier=>'DV'
,p_column_label=>'Entrada Despiece'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096726948474981423)
,p_db_column_name=>'ENTRADA_PRESTAMO'
,p_display_order=>290
,p_column_identifier=>'DW'
,p_column_label=>'Entrada Prestamo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096727064031981424)
,p_db_column_name=>'SALIDA_TOMA_FISICA'
,p_display_order=>300
,p_column_identifier=>'DX'
,p_column_label=>'Salida Toma Fisica'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096727196681981425)
,p_db_column_name=>'SALIDA_TRASLADO'
,p_display_order=>310
,p_column_identifier=>'DY'
,p_column_label=>'Salida Traslado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096727247351981426)
,p_db_column_name=>'SALIDA_DESPIECE'
,p_display_order=>320
,p_column_identifier=>'DZ'
,p_column_label=>'Salida Despiece'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096727331446981427)
,p_db_column_name=>'SALIDA_PRESTAMO'
,p_display_order=>330
,p_column_identifier=>'EA'
,p_column_label=>'Salida Prestamo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14096654287486061721)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'89106'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>unistr('EMPRESA:LOCALIZACION:ARTICULO:A\00D1O:MES:COMPRAS:DEV_CLIENTE:OTRAS_ENTRADAS:VENTAS:DEV_PROV:OTRAS_SALIDAS:VENTAS_MOV:VENTAS_PERDIDAS:VENTAS_PERDIDAS_MOV:VENTAS_REEMP:VENTAS_REEMP_MOV:FORECAST:ENTRADA_TOMA_FISICA:ENTRADA_TRASLADO:ENTRADA_DESPIECE:ENTRADA')
||'_PRESTAMO:SALIDA_TOMA_FISICA:SALIDA_TRASLADO:SALIDA_DESPIECE:SALIDA_PRESTAMO:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096644578571061685)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14096644302591061684)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096644962427061686)
,p_name=>'P114_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14096644302591061684)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14099125324444152618)
,p_name=>'P114_MES'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14096644302591061684)
,p_prompt=>'Mes:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   DISTINCT ETA_MES MES, ETA_MES',
'  FROM   INV_ESTADISTICA_TB_NX',
' WHERE   ETA_EMP_EMPRESA = :P114_EMPRESA AND ETA_ANO = :P114_ANNO;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_lov_cascade_parent_items=>'P114_ANNO'
,p_ajax_items_to_submit=>'P114_ANNO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14099245204531969534)
,p_name=>'P114_ANNO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14096644302591061684)
,p_prompt=>unistr('A\00F1o:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   DISTINCT ETA_ANO ANNO, ETA_ANO',
'  FROM   INV_ESTADISTICA_TB_NX',
' WHERE   ETA_EMP_EMPRESA = :P114_EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_lov_cascade_parent_items=>'P114_EMPRESA'
,p_ajax_items_to_submit=>'P114_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
