prompt --application/pages/page_00167
begin
--   Manifest
--     PAGE: 00167
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>167
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Carrito Comercio Electronico'
,p_step_title=>'FAC - Carrito Comercio Electronico'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170031'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14201378543323944420)
,p_plug_name=>'Carrito Comercio Electronico'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13998634891437255910)
,p_plug_name=>'Carrito Comercio Electronico'
,p_parent_plug_id=>wwv_flow_api.id(14201378543323944420)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT can_cli_cliente,',
'       can_cli_moneda,',
'       can_cli_nombre,',
'       can_lpo_lista,',
'       can_lcn_localizacion,',
'       can_ato_articulo,',
'       can_ato_descripcion,',
'       can_cantidad,',
'       can_precio,',
'       can_descuento,',
'       ( can_cantidad * can_precio_neto )',
'       can_subtotal,',
'       ( can_cantidad * can_precio_neto ) * ( can_impuesto / 100 )',
'       can_impuesto,',
'       ( ( can_cantidad * can_precio_neto ) + (',
'         can_cantidad * can_precio_neto * (',
'         can_impuesto / 100 ) ) ) can_total,',
'       can_enc_consulta,',
'       can_creado_por,',
'       can_fecha_creacion,',
'       can_modificado_por,',
'       can_fecha_modificacion',
'FROM   (SELECT can_cli_cliente,',
'               can_cli_moneda,',
'               Cxc_nombre_cli_v_nx(can_cli_empresa, can_cli_cliente,',
'               can_cli_moneda)',
'                 CAN_CLI_NOMBRE,',
'               can_lpo_lista,',
'               can_lcn_localizacion,',
'               can_ato_articulo,',
'               Inv_descrip_art_v_nx(can_ato_empresa, can_ato_articulo)',
'                      can_ato_descripcion,',
'               can_cantidad,',
'               can_precio,',
'               ( can_precio * ( ( 100 - can_descuento ) / 100 ) )',
'               can_precio_neto,',
'               can_descuento,',
'               can_impuesto,',
'               can_enc_consulta,',
'               can_creado_por,',
'               can_fecha_creacion,',
'               can_modificado_por,',
'               can_fecha_modificacion',
'        FROM   fac_canasta_tb_nx',
'        WHERE  Instr ('':''',
'                      || :p167_empresa',
'                      || '':'', '':''',
'                              || can_emp_empresa',
'                              || '':'') > 0)  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13998634915399255910)
,p_name=>'FAC - Carrito Comercio Electronico'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>33525209822711865
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998636551474255949)
,p_db_column_name=>'CAN_CLI_CLIENTE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998636961304255950)
,p_db_column_name=>'CAN_CLI_MONEDA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998661039812293182)
,p_db_column_name=>'CAN_CLI_NOMBRE'
,p_display_order=>15
,p_column_identifier=>'S'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998637705937255951)
,p_db_column_name=>'CAN_LPO_LISTA'
,p_display_order=>25
,p_column_identifier=>'G'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998661170000293183)
,p_db_column_name=>'CAN_LCN_LOCALIZACION'
,p_display_order=>35
,p_column_identifier=>'T'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998638546640255951)
,p_db_column_name=>'CAN_ATO_ARTICULO'
,p_display_order=>45
,p_column_identifier=>'I'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998661607150293188)
,p_db_column_name=>'CAN_ATO_DESCRIPCION'
,p_display_order=>55
,p_column_identifier=>'Y'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998638985282255952)
,p_db_column_name=>'CAN_CANTIDAD'
,p_display_order=>65
,p_column_identifier=>'J'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998661368794293185)
,p_db_column_name=>'CAN_PRECIO'
,p_display_order=>75
,p_column_identifier=>'V'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998661446097293186)
,p_db_column_name=>'CAN_DESCUENTO'
,p_display_order=>85
,p_column_identifier=>'W'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998661801868293189)
,p_db_column_name=>'CAN_SUBTOTAL'
,p_display_order=>95
,p_column_identifier=>'Z'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998661527278293187)
,p_db_column_name=>'CAN_IMPUESTO'
,p_display_order=>105
,p_column_identifier=>'X'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998661859933293190)
,p_db_column_name=>'CAN_TOTAL'
,p_display_order=>115
,p_column_identifier=>'AA'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998639308249255952)
,p_db_column_name=>'CAN_ENC_CONSULTA'
,p_display_order=>125
,p_column_identifier=>'K'
,p_column_label=>'Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998639783052255952)
,p_db_column_name=>'CAN_CREADO_POR'
,p_display_order=>135
,p_column_identifier=>'L'
,p_column_label=>'Creado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998640185375255952)
,p_db_column_name=>'CAN_FECHA_CREACION'
,p_display_order=>145
,p_column_identifier=>'M'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998640510589255953)
,p_db_column_name=>'CAN_MODIFICADO_POR'
,p_display_order=>155
,p_column_identifier=>'N'
,p_column_label=>'Modificado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13998640996308255953)
,p_db_column_name=>'CAN_FECHA_MODIFICACION'
,p_display_order=>165
,p_column_identifier=>'O'
,p_column_label=>'F. Modificacion'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13998643198092262689)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'335335'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'CAN_CLI_CLIENTE:CAN_CLI_MONEDA:CAN_CLI_NOMBRE:CAN_LCN_LOCALIZACION:CAN_LPO_LISTA:CAN_ATO_ARTICULO:CAN_ATO_DESCRIPCION:CAN_CANTIDAD:CAN_PRECIO:CAN_DESCUENTO:CAN_SUBTOTAL:CAN_IMPUESTO:CAN_TOTAL:CAN_ENC_CONSULTA:CAN_CREADO_POR:CAN_FECHA_CREACION:CAN_MOD'
||'IFICADO_POR:CAN_FECHA_MODIFICACION:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13998646046983268070)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(14201378543323944420)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13998647294976268087)
,p_name=>'P167_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14201378543323944420)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13998648442607268090)
,p_name=>'P167_INICIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14201378543323944420)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13998648814948268090)
,p_name=>'P167_FIN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14201378543323944420)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
