prompt --application/pages/page_00034
begin
--   Manifest
--     PAGE: 00034
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>34
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('FAC \2013 Facturas')
,p_step_title=>'Facturas'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ESALAS'
,p_last_upd_yyyymmddhh24miss=>'20201229131704'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167842507257220398)
,p_plug_name=>'Facturas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167846811085372934)
,p_plug_name=>'Facturas'
,p_parent_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   tra_emp_empresa empresa,',
'         tra_transaccion transaccion,',
'         tra_cli_mon_moneda moneda,',
'         tra_cedula cedula,',
'         tra_cli_cliente cliente,',
'         tra_nombre nom_cliente,',
'         tra_factura factura,',
'         DECODE (tra_status,',
'                 ''C'',',
'                 ''CREADA'',',
'                 ''A'',',
'                 ''APLICADA'',',
'                 ''P'',',
'                 ''PROCESADA'')',
'            tra_estado,',
'         DECODE (tra_tipo,',
'                 ''CRE'',',
'                 ''CREDITO'',',
'                 ''CON'',',
'                 ''CONTADO'',',
'                 ''FIN'',',
'                 ''FINANCIAMIENTO'',',
'                 ''NIT'',',
'                 ''NOTA INTERNA'')',
'            tipo,',
'         tra_ord_orden orden_taller,',
'         tra_valor_cambio,',
'         tra_lpo_lista lista,',
'         tra_dep_departamento departamento,',
'         cgl_nombre_depto_v_nx (tra_emp_empresa, tra_dep_departamento)',
'            desc_departamento,',
'         tra_ven_vendedor,',
'         gnl_nombre_vendedor_vi (tra_emp_empresa, tra_ven_vendedor)',
'            nombre_vend,',
'         tra_lcn_localizacion localizacion,',
'         inv_descrip_loca_v_nx (tra_emp_empresa, tra_lcn_localizacion)',
'            desc_localizacion,',
'         TRUNC (tra_fecha) fecha,',
'         TRUNC (tra_fecha_vencimiento) fecha_vencimiento,',
'         tra_ttr_tipo tipo_transaccion,',
'         tra_doc_documento documento,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               tra_subtotal / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               tra_subtotal * tra_valor_cambio',
'         END',
'            subtotal,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               tra_descuento / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               tra_descuento * tra_valor_cambio',
'         END',
'            descuento,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               tra_impuesto_ventas',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               tra_impuesto_ventas',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               tra_impuesto_ventas',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               tra_impuesto_ventas / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               tra_impuesto_ventas * tra_valor_cambio',
'         END',
'            iva,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               tra_otros_impuestos',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               tra_otros_impuestos',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               tra_otros_impuestos * tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               tra_otros_impuestos / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               tra_otros_impuestos * tra_valor_cambio',
'         END',
'            tra_otros_impuestos,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               tra_flete',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               tra_flete',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               tra_flete',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               tra_flete / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               tra_flete * tra_valor_cambio',
'         END',
'            tra_flete,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               tra_total',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               tra_total',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               tra_total',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               tra_total / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               tra_total * tra_valor_cambio',
'         END',
'            total,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (pct_monto_transaccion)',
'                  FROM   fac_pago_contado_tb_nx',
'                 WHERE   pct_tra_transaccion = tra_transaccion)',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (pct_monto_transaccion)',
'                  FROM   fac_pago_contado_tb_nx',
'                 WHERE   pct_tra_transaccion = tra_transaccion)',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (pct_monto_transaccion)',
'                  FROM   fac_pago_contado_tb_nx',
'                 WHERE   pct_tra_transaccion = tra_transaccion)',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (pct_monto_transaccion)',
'                  FROM   fac_pago_contado_tb_nx',
'                 WHERE   pct_tra_transaccion = tra_transaccion)',
'               / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (pct_monto_transaccion)',
'                  FROM   fac_pago_contado_tb_nx',
'                 WHERE   pct_tra_transaccion = tra_transaccion)',
'               * tra_valor_cambio',
'         END',
'            tra_pagado,',
'         impreso_caja,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (ncd_monto)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (ncd_monto)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (ncd_monto)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (ncd_monto)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'               / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (ncd_monto)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'               * tra_valor_cambio',
'         END',
'            notas,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (ncd_impuesto_ventas)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (ncd_impuesto_ventas)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (ncd_impuesto_ventas)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (ncd_impuesto_ventas)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'               / tra_valor_cambio',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (ncd_impuesto_ventas)',
'                  FROM   fac_factura_nota_tb_nx, fac_notas_cr_db_tb_nx',
'                 WHERE       fnt_tra_transaccion = tra_transaccion',
'                         AND ncd_transaccion = fnt_ncd_transaccion',
'                         AND ncd_status NOT IN (''C'', ''R''))',
'               * tra_valor_cambio',
'         END',
'            nota_imp_ventas,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (NVL (det_costo_local_fiscal, 0))',
'                  FROM   fac_detalle_factura_tb_nx',
'                 WHERE   det_tra_transaccion = tra_transaccion)',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (NVL (det_costo_local_fiscal, 0))',
'                  FROM   fac_detalle_factura_tb_nx',
'                 WHERE   det_tra_transaccion = tra_transaccion)',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (NVL (det_costo_alterno_fiscal, 0))',
'                  FROM   fac_detalle_factura_tb_nx',
'                 WHERE   det_tra_transaccion = tra_transaccion)',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (NVL (det_costo_alterno_fiscal, 0))',
'                  FROM   fac_detalle_factura_tb_nx',
'                 WHERE   det_tra_transaccion = tra_transaccion)',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (NVL (det_costo_local_fiscal, 0))',
'                  FROM   fac_detalle_factura_tb_nx',
'                 WHERE   det_tra_transaccion = tra_transaccion)',
'         END',
'            costo_total,',
'         creado_por,',
'         tra_observaciones,',
'         TRA_COMPROBANTE_ELECTRONICO comprobante_electronico,',
'         CASE',
'            WHEN (:p34_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (det_precio_local * det_Cantidad - det_descuento)',
'                  FROM   FAC_DETALLE_FACTURA_TB_NX',
'                 WHERE   (DET_IMPUESTO_VENTAS = 0 AND DET_OTROS_IMPUESTOS = 0)',
'                         AND DET_EMP_EMPRESA = TRA_EMP_EMPRESA',
'                         AND DET_TRA_TRANSACCION = TRA_TRANSACCION)',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (det_precio_local * det_Cantidad - det_descuento)',
'                  FROM   FAC_DETALLE_FACTURA_TB_NX',
'                 WHERE   (DET_IMPUESTO_VENTAS = 0 AND DET_OTROS_IMPUESTOS = 0)',
'                         AND DET_EMP_EMPRESA = TRA_EMP_EMPRESA',
'                         AND DET_TRA_TRANSACCION = TRA_TRANSACCION)',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (det_precio_local * det_Cantidad - det_descuento)',
'                  FROM   FAC_DETALLE_FACTURA_TB_NX',
'                 WHERE   (DET_IMPUESTO_VENTAS = 0 AND DET_OTROS_IMPUESTOS = 0)',
'                         AND DET_EMP_EMPRESA = TRA_EMP_EMPRESA',
'                         AND DET_TRA_TRANSACCION = TRA_TRANSACCION)',
'            WHEN (tra_mon_moneda = :P34_LOCAL AND :p34_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (det_precio_local * det_Cantidad - det_descuento) / tra_valor_cambio',
'                  FROM   FAC_DETALLE_FACTURA_TB_NX',
'                 WHERE   (DET_IMPUESTO_VENTAS = 0 AND DET_OTROS_IMPUESTOS = 0)',
'                         AND DET_EMP_EMPRESA = TRA_EMP_EMPRESA',
'                         AND DET_TRA_TRANSACCION = TRA_TRANSACCION)',
'            WHEN (tra_mon_moneda = :P34_ALTERNA AND :p34_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (det_precio_local * det_Cantidad - det_descuento) * tra_valor_cambio',
'                  FROM   FAC_DETALLE_FACTURA_TB_NX',
'                 WHERE   (DET_IMPUESTO_VENTAS = 0 AND DET_OTROS_IMPUESTOS = 0)',
'                         AND DET_EMP_EMPRESA = TRA_EMP_EMPRESA',
'                         AND DET_TRA_TRANSACCION = TRA_TRANSACCION)',
'         END',
'            exento,',
'         (SELECT   Z.DESCRIPCION',
'            FROM   GNL_PERSONA_TR_NX P, GNL_ZONA_TR_NX Z, CXC_CLIENTE_TB_NX',
'           WHERE       P.ZON_ZONA = Z.ZONA',
'                   AND CLI_PER_PERSONA = PERSONA',
'                   AND CLI_CLIENTE = TRA_CLI_CLIENTE',
'                   AND CLI_MON_MONEDA = TRA_CLI_MON_MONEDA',
'                   AND CLI_EMP_EMPRESA = TRA_CLI_EMP_EMPRESA)',
'            ZONA,',
'              TRA_ORDEN_COMPRA,',
'            TRA_ENC_CONSULTA',
'  FROM   fac_factura_tb_nx',
' WHERE   tra_status != ''C''',
'         AND INSTR ('':'' || :p34_empresa || '':'',',
'                    '':'' || tra_emp_empresa || '':'') > 0',
'         AND tra_fecha BETWEEN :p34_inicio',
'                           AND  TO_DATE (:p34_fin || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'')',
'         AND tra_transaccion = NVL (:p34_transaccion, tra_transaccion);'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P34_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14167846907117372935)
,p_name=>'Maestro Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP:P34_TRANSACCION:#TRANSACCION#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10733013705873635
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167847100927372941)
,p_db_column_name=>'TRANSACCION'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167847223944372942)
,p_db_column_name=>'FACTURA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'FACTURA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094455308455116408)
,p_db_column_name=>'TIPO'
,p_display_order=>12
,p_column_identifier=>'R'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167847401141372943)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>32
,p_column_identifier=>'D'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_static_id=>'DEPARTAMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097119751108535320)
,p_db_column_name=>'DESC_DEPARTAMENTO'
,p_display_order=>42
,p_column_identifier=>'U'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167847597488372943)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>62
,p_column_identifier=>'F'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
,p_static_id=>'LOCALIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097119850318535321)
,p_db_column_name=>'DESC_LOCALIZACION'
,p_display_order=>72
,p_column_identifier=>'V'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167847712283372944)
,p_db_column_name=>'FECHA'
,p_display_order=>82
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167847808641372944)
,p_db_column_name=>'FECHA_VENCIMIENTO'
,p_display_order=>92
,p_column_identifier=>'H'
,p_column_label=>'F. Vencimiento'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA_VENCIMIENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167847996590372945)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>102
,p_column_identifier=>'J'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SUBTOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167848122471372945)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>112
,p_column_identifier=>'K'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DESCUENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167848196979372946)
,p_db_column_name=>'IVA'
,p_display_order=>122
,p_column_identifier=>'L'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'IVA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167848319114372946)
,p_db_column_name=>'TOTAL'
,p_display_order=>132
,p_column_identifier=>'M'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'TOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168015610209150346)
,p_db_column_name=>'COSTO_TOTAL'
,p_display_order=>142
,p_column_identifier=>'N'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'COSTO_TOTAL'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P34_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14113191560044721386)
,p_db_column_name=>'ORDEN_TALLER'
,p_display_order=>152
,p_column_identifier=>'P'
,p_column_label=>'Orden Taller'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ORDEN_TALLER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094455187409116407)
,p_db_column_name=>'MONEDA'
,p_display_order=>162
,p_column_identifier=>'Q'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094864857926014704)
,p_db_column_name=>'CEDULA'
,p_display_order=>172
,p_column_identifier=>'S'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094864994523014705)
,p_db_column_name=>'CLIENTE'
,p_display_order=>182
,p_column_identifier=>'T'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097479608423436417)
,p_db_column_name=>'EMPRESA'
,p_display_order=>192
,p_column_identifier=>'W'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097479653799436418)
,p_db_column_name=>'TRA_ESTADO'
,p_display_order=>202
,p_column_identifier=>'X'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097479797972436419)
,p_db_column_name=>'TRA_OTROS_IMPUESTOS'
,p_display_order=>212
,p_column_identifier=>'Y'
,p_column_label=>'Otros Impuestos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097479899750436420)
,p_db_column_name=>'TRA_FLETE'
,p_display_order=>222
,p_column_identifier=>'Z'
,p_column_label=>'Flete'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097479968025436421)
,p_db_column_name=>'TRA_PAGADO'
,p_display_order=>232
,p_column_identifier=>'AA'
,p_column_label=>'Pago Contado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480035591436422)
,p_db_column_name=>'NOTAS'
,p_display_order=>242
,p_column_identifier=>'AB'
,p_column_label=>'Total Notas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480138137436423)
,p_db_column_name=>'NOTA_IMP_VENTAS'
,p_display_order=>252
,p_column_identifier=>'AC'
,p_column_label=>'Impuesto Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480308763436424)
,p_db_column_name=>'NOM_CLIENTE'
,p_display_order=>262
,p_column_identifier=>'AD'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480338985436425)
,p_db_column_name=>'TRA_VALOR_CAMBIO'
,p_display_order=>272
,p_column_identifier=>'AE'
,p_column_label=>'T. Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480503478436426)
,p_db_column_name=>'LISTA'
,p_display_order=>282
,p_column_identifier=>'AF'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480534302436427)
,p_db_column_name=>'TRA_VEN_VENDEDOR'
,p_display_order=>292
,p_column_identifier=>'AG'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480706735436428)
,p_db_column_name=>'NOMBRE_VEND'
,p_display_order=>302
,p_column_identifier=>'AH'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480785668436429)
,p_db_column_name=>'TIPO_TRANSACCION'
,p_display_order=>312
,p_column_identifier=>'AI'
,p_column_label=>'T. Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480871134436430)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>322
,p_column_identifier=>'AJ'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097480954105436431)
,p_db_column_name=>'IMPRESO_CAJA'
,p_display_order=>332
,p_column_identifier=>'AK'
,p_column_label=>'Caja'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097901222923642719)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>342
,p_column_identifier=>'AL'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082672425631943306)
,p_db_column_name=>'TRA_OBSERVACIONES'
,p_display_order=>352
,p_column_identifier=>'AM'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084691471646360967)
,p_db_column_name=>'COMPROBANTE_ELECTRONICO'
,p_display_order=>362
,p_column_identifier=>'AN'
,p_column_label=>unistr('Comprobante electr\00F3nico')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084692416679360976)
,p_db_column_name=>'EXENTO'
,p_display_order=>372
,p_column_identifier=>'AO'
,p_column_label=>'Exento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084692643244360979)
,p_db_column_name=>'ZONA'
,p_display_order=>382
,p_column_identifier=>'AP'
,p_column_label=>'Zona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13927620333612715628)
,p_db_column_name=>'TRA_ORDEN_COMPRA'
,p_display_order=>392
,p_column_identifier=>'AQ'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13927620233792715627)
,p_db_column_name=>'TRA_ENC_CONSULTA'
,p_display_order=>402
,p_column_identifier=>'AR'
,p_column_label=>'Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14167848520089375465)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'107347'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:TRANSACCION:FACTURA:COMPROBANTE_ELECTRONICO:TRA_ESTADO:ORDEN_TALLER:FECHA:DEPARTAMENTO:DESC_DEPARTAMENTO:LOCALIZACION:DESC_LOCALIZACION:MONEDA:TRA_VALOR_CAMBIO:LISTA:TRA_VEN_VENDEDOR:NOMBRE_VEND:CLIENTE:CEDULA:NOM_CLIENTE:ZONA:TIPO:FECHA_VENC'
||'IMIENTO:TIPO_TRANSACCION:DOCUMENTO:SUBTOTAL:EXENTO:DESCUENTO:IVA:TRA_OTROS_IMPUESTOS:TRA_FLETE:TOTAL:TRA_PAGADO:IMPRESO_CAJA:NOTAS:NOTA_IMP_VENTAS:CREADO_POR:TRA_OBSERVACIONES::TRA_ORDEN_COMPRA:TRA_ENC_CONSULTA'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14167849019789403795)
,p_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_api.id(14167846811085372934)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 13/01/2017 11:04:35 a.m. (QP5 v5.115.810.9015) */',
'SELECT   tra_lcn_localizacion localizacion,',
'         inv_descrip_loca_v_nx (tra_emp_empresa, tra_lcn_localizacion) desc_localizacion,',
'         det_ato_articulo articulo,',
'         inv_descrip_art_v_nx (det_emp_empresa, det_ato_articulo) descripcion,',
'         inv_familia_art_v_nx (det_emp_empresa, det_ato_articulo) codigo_familia,',
'         inv_desc_fam_art_v_nx (det_emp_empresa, det_ato_articulo) familia,',
'         inv_obt_clasif_prin_art_v_nx (det_emp_empresa, det_ato_articulo) tipoarticulo,',
'         det_cantidad cantidad,',
'         DET_PRECIO_LOCAL precio_unitario,',
'         DET_PRECIO_LOCAL * DET_CANTIDAD subtotal,',
'         DET_DESCUENTO descuento,',
'         (DET_PRECIO_LOCAL * DET_CANTIDAD) * (DET_IMPUESTO_VENTAS / 100) impuesto,',
'         (DET_PRECIO_LOCAL * DET_CANTIDAD) * (DET_OTROS_IMPUESTOS / 100) otros_impuestos,',
'         DET_TOTAL,',
'         DET_COSTO_LOCAL_FISCAL,',
'         DET_COSTO_ALTERNO_FISCAL',
'  FROM   fac_factura_tb_nx a, fac_detalle_factura_tb_nx b',
' WHERE       a.tra_transaccion = b.det_tra_transaccion',
'         AND a.tra_status != ''C''',
'         AND det_tra_transaccion = :p34_transaccion',
'UNION ALL',
'SELECT   tra_lcn_localizacion localizacion,',
'         inv_descrip_loca_v_nx (tra_emp_empresa, tra_lcn_localizacion) desc_localizacion,',
'         TO_CHAR (des_ser_consecutivo) articulo,',
'         tal_desc_servicio_v_nx (des_emp_empresa, des_ser_consecutivo) descripcion,',
'         tal_familia_servicio_v_nx (des_emp_empresa, des_ser_consecutivo) codigo_familia,',
'         inv_descrip_fam_v_nx (des_emp_empresa,tal_familia_servicio_v_nx (des_emp_empresa, des_ser_consecutivo)) familia,',
'         NULL tipoarticulo,',
'         des_cantidad cantidad,',
'         DES_PRECIO_LOCAL precio_unitario,',
'         DES_PRECIO_LOCAL * DES_CANTIDAD subtotal,',
'         DES_DESCUENTO descuento,',
'         (DES_PRECIO_LOCAL * DES_CANTIDAD) * (DES_IMPUESTO_VENTAS / 100) impuesto,',
'         (DES_PRECIO_LOCAL * DES_CANTIDAD) * (DES_OTROS_IMPUESTOS / 100) otros_impuestos,',
'         DES_TOTAL,',
'         DES_COSTO_LOCAL_FISCAL,',
'         DES_COSTO_ALTERNO_FISCAL',
'  FROM   fac_factura_tb_nx a, fac_detalle_fact_serv_tb_nx b',
' WHERE       a.tra_transaccion = b.des_tra_transaccion',
'         AND a.tra_status != ''C''',
'         AND des_tra_transaccion = :p34_transaccion'))
,p_display_when_condition=>'P34_TRANSACCION'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_footer=>'</div>'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_prn_output_show_link=>'Y'
,p_prn_output_link_text=>'Print'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>320
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14097481118929436432)
,p_query_column_id=>1
,p_column_alias=>'LOCALIZACION'
,p_column_display_sequence=>1
,p_column_heading=>'Localizacion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14097481130863436433)
,p_query_column_id=>2
,p_column_alias=>'DESC_LOCALIZACION'
,p_column_display_sequence=>2
,p_column_heading=>'Desc. Localizacion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14094865290523014708)
,p_query_column_id=>3
,p_column_alias=>'ARTICULO'
,p_column_display_sequence=>3
,p_column_heading=>'Articulo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14094865409538014709)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>4
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14094865517618014710)
,p_query_column_id=>5
,p_column_alias=>'CODIGO_FAMILIA'
,p_column_display_sequence=>5
,p_column_heading=>'Familia'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14094865553956014711)
,p_query_column_id=>6
,p_column_alias=>'FAMILIA'
,p_column_display_sequence=>6
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14094865719922014712)
,p_query_column_id=>7
,p_column_alias=>'TIPOARTICULO'
,p_column_display_sequence=>7
,p_column_heading=>'Tipo Articulo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14094865729181014713)
,p_query_column_id=>8
,p_column_alias=>'CANTIDAD'
,p_column_display_sequence=>8
,p_column_heading=>'Cantidad'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14097481243162436434)
,p_query_column_id=>9
,p_column_alias=>'PRECIO_UNITARIO'
,p_column_display_sequence=>9
,p_column_heading=>'Precio Unitario'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14097481399759436435)
,p_query_column_id=>10
,p_column_alias=>'SUBTOTAL'
,p_column_display_sequence=>10
,p_column_heading=>'Subtotal'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167855215742562949)
,p_query_column_id=>11
,p_column_alias=>'DESCUENTO'
,p_column_display_sequence=>11
,p_column_heading=>'Descuento'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_print_col_width=>'5'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14094866107320014716)
,p_query_column_id=>12
,p_column_alias=>'IMPUESTO'
,p_column_display_sequence=>12
,p_column_heading=>'Impuesto'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14097481431869436436)
,p_query_column_id=>13
,p_column_alias=>'OTROS_IMPUESTOS'
,p_column_display_sequence=>13
,p_column_heading=>'Otros Impuestos'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14097481557614436437)
,p_query_column_id=>14
,p_column_alias=>'DET_TOTAL'
,p_column_display_sequence=>14
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14097481631030436438)
,p_query_column_id=>15
,p_column_alias=>'DET_COSTO_LOCAL_FISCAL'
,p_column_display_sequence=>15
,p_column_heading=>'Costo Local'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_when_condition=>'P34_AUTO_CCA'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14097481803308436439)
,p_query_column_id=>16
,p_column_alias=>'DET_COSTO_ALTERNO_FISCAL'
,p_column_display_sequence=>16
,p_column_heading=>'Costo Alterno'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_when_condition=>'P34_AUTO_CCA'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168161900889579073)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14086453197659262485)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14167846811085372934)
,p_button_name=>'RESTABLECER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Restablecer'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP,34::'
,p_button_condition=>'P34_TRANSACCION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966309392288995412)
,p_name=>'P34_LOCAL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P34_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   FROM DUAL',
'connect by regexp_substr(:P34_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966309476472995413)
,p_name=>'P34_ALTERNA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P34_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )   FROM DUAL',
'connect by regexp_substr(:P34_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098448515649499524)
,p_name=>'P34_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE       use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167842694435220409)
,p_name=>'P34_INICIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167842900179220414)
,p_name=>'P34_FIN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167843315385220416)
,p_name=>'P34_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167853424105425781)
,p_name=>'P34_TRANSACCION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168120813198982472)
,p_name=>'P34_MONEDA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14167842507257220398)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MONEDA'
,p_lov=>'.'||wwv_flow_api.id(13966336081955007059)||'.'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966306840596995387)
,p_validation_name=>'MONEDA_EMPRESAS'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P34_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P34_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P34_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P34_EMPRESA,''[^:]+'', 1, level) is not null;',
'     ',
'        ',
'IF (cantidad_local_v > 1 AND :P34_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
' ',
'IF (cantidad_alt_v > 1 AND :P34_MONEDA = ''A'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
'',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(14168161900889579073)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
