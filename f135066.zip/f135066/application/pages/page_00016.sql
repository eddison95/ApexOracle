prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>16
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CGL \2013 Balance de Comprobacion por Departamento')
,p_step_title=>'Balance Comprobacion por Departamento'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163417'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193541164536816516)
,p_plug_name=>'Balance Comprobacion por Departamento'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193542166837816527)
,p_plug_name=>'Balance Comprobacion por Departamento'
,p_parent_plug_id=>wwv_flow_api.id(14193541164536816516)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 23/02/2017 08:34:58 a.m. (QP5 v5.115.810.9015) */',
'SELECT   a.emp_empresa,',
'         a.cuenta,',
'         a.descripcion,',
'         DECODE (a.tipo,',
'                 1,',
'                 ''Mayor'',',
'                 2,',
'                 ''Detalle'')',
'            tipo,',
'         periodo,',
'         ano,',
'         TRUNC (fecha_inicio) fecha_inicio,',
'         TRUNC (fecha_fin) fecha_fin,',
'         (   sdf_dep_departamento',
'          || '' - ''',
'          || fac_nombre_depto_v_nx (a.emp_empresa, sdf_dep_departamento))',
'            departamento,',
'         sdf_inicial_local,',
'         sdf_debe_local,',
'         sdf_haber_local,',
'         sdf_final_local,',
'         sdf_inicial_alterno,',
'         sdf_debe_alterno,',
'         sdf_haber_alterno,',
'         sdf_final_alterno,',
'         sdf_saldo,',
'         ''Fiscal'' contabilidad',
'  FROM   cgl_cuenta_tr_nx a,',
'         cgl_saldo_depto_fiscal_tb_nx b,',
'         cgl_periodo_tr_nx c',
' WHERE       a.emp_empresa = b.sdf_emp_empresa',
'         AND a.cuenta = b.sdf_cta_cuenta',
'         AND b.sdf_emp_empresa = c.emp_empresa',
'         AND b.sdf_saf_peri_id = c.id',
'         AND INSTR ('':'' || :p16_empresa || '':'', '':'' || a.emp_empresa || '':'') >',
'               0',
'         AND c.id = :p16_periodo',
'         AND a.nivel <= :p16_nivel',
'         AND:p16_contabilidad IN (1, 2)',
'UNION ALL',
'SELECT   a.emp_empresa,',
'         a.cuenta,',
'         a.descripcion,',
'         DECODE (a.tipo,',
'                 1,',
'                 ''Mayor'',',
'                 2,',
'                 ''Detalle'')',
'            tipo,',
'         periodo,',
'         ano,',
'         TRUNC (fecha_inicio) fecha_inicio,',
'         TRUNC (fecha_fin) fecha_fin,',
'         (   sdc_dep_departamento',
'          || '' - ''',
'          || fac_nombre_depto_v_nx (a.emp_empresa, sdc_dep_departamento))',
'            departamento,',
'         sdc_inicial_local,',
'         sdc_debe_local,',
'         sdc_haber_local,',
'         sdc_final_local,',
'         sdc_inicial_alterno,',
'         sdc_debe_alterno,',
'         sdc_haber_alterno,',
'         sdc_final_alterno,',
'         sdc_saldo_fasb,',
'         ''Corporativo'' contabilidad',
'  FROM   cgl_cuenta_tr_nx a,',
'         cgl_saldo_depto_corp_tb_nx b,',
'         cgl_periodo_tr_nx c',
' WHERE       a.emp_empresa = b.sdc_emp_empresa',
'         AND a.cuenta = b.sdc_cta_cuenta',
'         AND b.sdc_emp_empresa = c.emp_empresa',
'         AND b.sdc_sac_peri_id = c.id',
'         AND INSTR ('':'' || :p16_empresa || '':'', '':'' || a.emp_empresa || '':'') >',
'               0',
'         AND c.id = :p16_periodo',
'         AND a.nivel <= :p16_nivel',
'         AND:p16_contabilidad IN (1, 3)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P16_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14193542379482816528)
,p_name=>'Consulta de Asientos'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>7543027363630851
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193542460602816528)
,p_db_column_name=>'CUENTA'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Cuenta'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193542552281816529)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Descripcion'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193542667424816529)
,p_db_column_name=>'TIPO'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_static_id=>'TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193542767447816529)
,p_db_column_name=>'PERIODO'
,p_display_order=>50
,p_column_identifier=>'L'
,p_column_label=>'Periodo'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PERIODO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193542863835816530)
,p_db_column_name=>'ANO'
,p_display_order=>60
,p_column_identifier=>'M'
,p_column_label=>'Ano'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ANO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14116035310386033815)
,p_db_column_name=>'CONTABILIDAD'
,p_display_order=>70
,p_column_identifier=>'X'
,p_column_label=>'Contabilidad'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_static_id=>'CONTABILIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193542978282816530)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>80
,p_column_identifier=>'N'
,p_column_label=>'Fecha Inicio'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA_INICIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193543079450816530)
,p_db_column_name=>'FECHA_FIN'
,p_display_order=>90
,p_column_identifier=>'O'
,p_column_label=>'Fecha Fin'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA_FIN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095128916891798807)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>100
,p_column_identifier=>'AR'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129021196798808)
,p_db_column_name=>'SDF_INICIAL_LOCAL'
,p_display_order=>110
,p_column_identifier=>'AS'
,p_column_label=>'Inicial Local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129033987798809)
,p_db_column_name=>'SDF_DEBE_LOCAL'
,p_display_order=>120
,p_column_identifier=>'AT'
,p_column_label=>'Debe Local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129260140798811)
,p_db_column_name=>'SDF_FINAL_LOCAL'
,p_display_order=>130
,p_column_identifier=>'AV'
,p_column_label=>'Final Local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129177278798810)
,p_db_column_name=>'SDF_HABER_LOCAL'
,p_display_order=>140
,p_column_identifier=>'AU'
,p_column_label=>'Haber Local'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129419024798812)
,p_db_column_name=>'SDF_INICIAL_ALTERNO'
,p_display_order=>150
,p_column_identifier=>'AW'
,p_column_label=>'Inicial Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129453240798813)
,p_db_column_name=>'SDF_DEBE_ALTERNO'
,p_display_order=>160
,p_column_identifier=>'AX'
,p_column_label=>'Debe Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129617166798814)
,p_db_column_name=>'SDF_HABER_ALTERNO'
,p_display_order=>170
,p_column_identifier=>'AY'
,p_column_label=>'Haber Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129628778798815)
,p_db_column_name=>'SDF_FINAL_ALTERNO'
,p_display_order=>180
,p_column_identifier=>'AZ'
,p_column_label=>'Final Alterno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095129815112798816)
,p_db_column_name=>'SDF_SALDO'
,p_display_order=>190
,p_column_identifier=>'BA'
,p_column_label=>'Fasb'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098671643811192138)
,p_db_column_name=>'EMP_EMPRESA'
,p_display_order=>200
,p_column_identifier=>'BB'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14193543964792816533)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75447'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMP_EMPRESA:CUENTA:DESCRIPCION:TIPO:CONTABILIDAD:PERIODO:ANO:FECHA_INICIO:FECHA_FIN:DEPARTAMENTO:SDF_INICIAL_LOCAL:SDF_DEBE_LOCAL:SDF_HABER_LOCAL:SDF_FINAL_LOCAL:SDF_INICIAL_ALTERNO:SDF_DEBE_ALTERNO:SDF_HABER_ALTERNO:SDF_FINAL_ALTERNO:SDF_SALDO:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168169711279685972)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14193541164536816516)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14116033782614985938)
,p_name=>'P16_CONTABILIDAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14193541164536816516)
,p_prompt=>'Contabilidad'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Fiscal;2,Corporativa;3,Ambos;1'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193541369273816520)
,p_name=>'P16_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14193541164536816516)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193541773748816521)
,p_name=>'P16_PERIODO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14193541164536816516)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (periodo||'' ''||ano||'' ''||fecha_inicio||'' ''||fecha_fin) descripcion, id',
'from cgl_periodo_tr_nx',
'where emp_empresa = :P16_EMPRESA',
'AND tipo = :P16_CONTABILIDAD',
'order by ano desc, periodo desc'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P16_EMPRESA'
,p_ajax_items_to_submit=>'P16_EMPRESA,P16_CONTABILIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193541964949816522)
,p_name=>'P16_NIVEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14193541164536816516)
,p_prompt=>'Nivel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
