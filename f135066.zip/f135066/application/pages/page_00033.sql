prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>33
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('INV \2013 Maestro de Articulos')
,p_step_title=>'Maestro de Articulos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'APEREIRA'
,p_last_upd_yyyymmddhh24miss=>'20210107180536'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096883920031821892)
,p_plug_name=>'Maestro de Articulos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14178141240357219375)
,p_plug_name=>'Maestro de Articulos'
,p_parent_plug_id=>wwv_flow_api.id(14096883920031821892)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    i.ato_emp_empresa                                                 empresa,',
'    i.ato_articulo                                                    articulo,',
'    i.ato_fma_familia                                                 familia,',
'    inv_desc_fam_art_v_nx(i.ato_emp_empresa, i.ato_articulo)         desc_familia,',
'    i.ato_descripcion                                                 descripcion,    ',
'    inv_obt_cabys_codid_v_nx (i.ato_emp_empresa,i.ato_cbs_id) codigo_cabys,',
'    Decode(cbs_ind_activo,''S'',''Activo'',''N'',''Inactivo'') EstadoCabys,',
'    i.ato_observaciones                                               observaciones,',
'    i.ato_mod_modelo                                                  modelo,',
'    i.ato_mar_marca                                                   marca,',
'    i.ato_plu                                                         codigo_barras,',
'    i.ato_costo_fob                                                   costo_fob,',
'    i.ato_costo_estandar                                              costo_estandar,',
'    decode(i.ato_bloqueado_compra, ''S'', ''SI'', ''N'', ''NO'') bloqueado_compra,',
'    decode(i.ato_bloqueado_venta, ''S'', ''SI'', ''N'', ''NO'') bloqueado_venta,',
'    i.ato_ato_reemplaza                                               reemplaza,',
'    i.ato_ato_reemplazo                                               reemplazo,',
'    i.ato_maximo_descuento                                            maximo_descuento,',
'    decode(i.ato_modificar_precio, ''S'', ''SI'', ''N'', ''NO'') modificar_precio,',
'    decode(i.ato_gravado, ''S'', ''SI'', ''N'', ''NO'') gravado,',
'    decode(i.ato_modifica_descripcion, ''S'', ''SI'', ''N'',',
'           ''NO'')                                                      modifica_descripcion,',
'    decode(i.ato_bajo_margen, ''S'', ''SI'', ''N'', ''NO'') bajo_margen,',
'    decode(i.ato_descontinuado, ''S'', ''SI'', ''N'', ''NO'') descontinuado,',
'    i.ato_categoria                                                   categoria,',
'    decode(i.ato_tus_tipo_uso, ''1'', ''ACCESORIOS'', ''2'',',
'           ''CABLES'',',
'           ''3'',',
'           ''CARROCERIA'',',
'           ''4'',',
'           ''COMBUSTIBLES'',',
'           ''5'',',
'           ''ELECTRICO'',',
'           ''6'',',
'           ''MOTOR'',',
'           ''7'',',
'           ''OTROS'',',
'           ''8'',',
'           ''TRANSMICION'',',
'           ''9'',',
'           ''REPUESTOS'',',
'           ''10'',',
'           ''CAJONES'',',
'           ''11'',',
'           ''CASCOS'',',
'           ''12'',',
'           ''CAPAS'',',
'           ''13'',',
'           ''LLANTAS'',',
'           ''14'',',
'           ''LINEA BLANCA'')                                            tipo_uso,',
'    decode(i.ato_gpr_grupo_producto, ''1'', ''AA'', ''2'', ''AB'',',
'           ''3'',',
'           ''AC'',',
'           ''4'',',
'           ''BA'',',
'           ''5'',',
'           ''BB'',',
'           ''6'',',
'           ''BC'',',
'           ''7'',',
'           ''CA'',',
'           ''8'',',
'           ''CB'',',
'           ''9'',',
'           ''CC'')                                                      grupo_producto,',
'    decode(i.ato_clave, ''S'', ''SI'', ''N'', ''NO'') clave,',
'    decode(i.ato_itemizado, ''N'', ''NO'', ''S'', ''SI'') itemizado,',
'    i.ato_tiempo_entrega                                              tiempo_entrega,',
'    trunc(i.ato_fecha_primer_ingreso)                                fecha_ingreso,',
'    ato_descripcion_alterna                                           descripcion_alterna,',
'    ato_cantidad_maquina                                              cantidad_maquina,',
'    ato_parte_fabricante                                              parte_fabricante,',
'    ato_paa_partida                                                   partida,',
'    ato_cantidad_minima                                               cantidad_minima,',
'    ato_cantidad_maxima                                               cantidad_maxima,',
'    ato_pedido_minimo                                                 pedido_minimo,',
'    decode(i.ato_flag_toma_fisica, ''N'', ''NO'', ''S'', ''SI'') flag_toma_fisica,',
'    decode(i.ato_ajusta_inflacion, ''N'', ''NO'', ''S'', ''SI'') ajusta_inflacion,',
'    ato_bloqueado_compra_por                                          bloqueado_compra_por,',
'    ato_fecha_bloqueo_compra                                          fecha_bloqueo_compra,',
'    ato_bloqueado_venta_por                                           bloqueado_venta_por,',
'    ato_fecha_bloqueo_venta                                           fecha_bloqueo_venta,',
'    ato_numero_meses_inventario                                       meses_inventario,',
'    ato_rotacion_simple                                               rotacion_simple,',
'    ato_creado_por                                                    creado_por,',
'    ato_fecha_creacion                                                fecha_creacion,',
'    ato_modificado_por                                                modificado_por,',
'    ato_reg_sanitario                                                 reg_sanitario,',
'    ato_fecha_ven_reg_sanitar                                         ven_reg_sanitario,',
'    ato_fecha_descontinuado                                           fecha_descontinuado,',
'    ato_numero_dias_inventario                                        numero_dias_inventario,',
'    ato_tam_tamano                                                    tamano,',
'    ato_clr_color                                                     color,',
'    ato_clasificacion_abc                                             clasificacion_abc,',
'    decode(i.ato_local_externo, ''L'', ''LOCAL'', ''E'',',
'           ''EXTERNO'')                                                 local_externo,',
'    ato_tipo_combustible                                              tipo_combustible,',
'    ato_cilindraje                                                    cilindraje,',
'    ato_numero_cilindros                                              numero_cilindros,',
'    ato_tipo_traccion                                                 tipo_traccion,',
'    ato_tipo_carroceria                                               tipo_carroceria,',
'    ato_tipo_estilo                                                   tipo_estilo,',
'    ato_categoria_car                                                 categoria_car,',
'    ato_tipo_servicio                                                 tipo_servicio,',
'    ato_base_mensual                                                  base_mensual,',
'    ato_pais_origen                                                   pais_origen,',
'    decode(i.ato_ind_combo, ''N'', ''NO'', ''S'', ''SI'') indica_combo,',
'    decode(i.ato_ind_despiece, ''N'', ''NO'', ''S'', ''SI'') ind_despiece,',
'    decode(i.ato_ind_observaciones, ''N'', ''NO'', ''S'', ''SI'') ind_observaciones,',
'    decode(i.ato_fraccionable, ''N'', ''NO'', ''S'', ''SI'') fraccionable,',
'    decode(i.ato_sin_gestion_estudiante, ''N'', ''NO'', ''S'',',
'           ''SI'')                                                      sin_gestion_estudiante,',
'    decode(i.ato_permite_descuento, ''N'', ''NO'', ''S'', ''SI'') permite_descuento',
'FROM',
'    inv_articulo_tb_nx i, inv_catalogo_cabys_tb_nx',
'WHERE',
'    ato_emp_empresa = :p33_empresa and ',
'    ato_cbs_id = cbs_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P33_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14178141324300219375)
,p_name=>'Maestro de Articulos'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>10402809686095050
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097729872779647112)
,p_db_column_name=>'EMPRESA'
,p_display_order=>10
,p_column_identifier=>'AB'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097729975272647113)
,p_db_column_name=>'ARTICULO'
,p_display_order=>20
,p_column_identifier=>'AC'
,p_column_label=>unistr('C\00F3digo Art\00EDculo')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730101541647114)
,p_db_column_name=>'FAMILIA'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730203018647115)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>40
,p_column_identifier=>'AE'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962846040288640323)
,p_db_column_name=>'CODIGO_CABYS'
,p_display_order=>50
,p_column_identifier=>'CV'
,p_column_label=>'Codigo Cabys'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730243157647116)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>60
,p_column_identifier=>'AF'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730365421647117)
,p_db_column_name=>'MODELO'
,p_display_order=>70
,p_column_identifier=>'AG'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730514066647118)
,p_db_column_name=>'MARCA'
,p_display_order=>80
,p_column_identifier=>'AH'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730575979647119)
,p_db_column_name=>'CODIGO_BARRAS'
,p_display_order=>90
,p_column_identifier=>'AI'
,p_column_label=>'Codigo Barras'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730651451647120)
,p_db_column_name=>'COSTO_FOB'
,p_display_order=>100
,p_column_identifier=>'AJ'
,p_column_label=>'Costo FOB'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P33_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730793747647121)
,p_db_column_name=>'COSTO_ESTANDAR'
,p_display_order=>110
,p_column_identifier=>'AK'
,p_column_label=>'Costo Estandar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P33_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730858332647122)
,p_db_column_name=>'BLOQUEADO_COMPRA'
,p_display_order=>120
,p_column_identifier=>'AL'
,p_column_label=>'Bloqueado Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097730961157647123)
,p_db_column_name=>'BLOQUEADO_VENTA'
,p_display_order=>130
,p_column_identifier=>'AM'
,p_column_label=>'Bloqueado Venta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731086267647124)
,p_db_column_name=>'REEMPLAZA'
,p_display_order=>140
,p_column_identifier=>'AN'
,p_column_label=>'Reemplaza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731135076647125)
,p_db_column_name=>'REEMPLAZO'
,p_display_order=>150
,p_column_identifier=>'AO'
,p_column_label=>'Reemplazo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731312861647126)
,p_db_column_name=>'MAXIMO_DESCUENTO'
,p_display_order=>160
,p_column_identifier=>'AP'
,p_column_label=>'Maximo Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731373223647127)
,p_db_column_name=>'MODIFICAR_PRECIO'
,p_display_order=>170
,p_column_identifier=>'AQ'
,p_column_label=>'Modificar Precio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731460636647128)
,p_db_column_name=>'GRAVADO'
,p_display_order=>180
,p_column_identifier=>'AR'
,p_column_label=>'Gravado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731561634647129)
,p_db_column_name=>'MODIFICA_DESCRIPCION'
,p_display_order=>190
,p_column_identifier=>'AS'
,p_column_label=>'Modifica Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731718467647130)
,p_db_column_name=>'BAJO_MARGEN'
,p_display_order=>200
,p_column_identifier=>'AT'
,p_column_label=>'Bajo Margen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731802037647131)
,p_db_column_name=>'DESCONTINUADO'
,p_display_order=>210
,p_column_identifier=>'AU'
,p_column_label=>'Descontinuado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097731861623647132)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>220
,p_column_identifier=>'AV'
,p_column_label=>'Categoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732156223647135)
,p_db_column_name=>'CLAVE'
,p_display_order=>230
,p_column_identifier=>'AY'
,p_column_label=>'Clave'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732267554647136)
,p_db_column_name=>'ITEMIZADO'
,p_display_order=>240
,p_column_identifier=>'AZ'
,p_column_label=>'Itemizado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732357666647137)
,p_db_column_name=>'TIEMPO_ENTREGA'
,p_display_order=>250
,p_column_identifier=>'BA'
,p_column_label=>'Tiempo Entrega'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732506010647138)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>260
,p_column_identifier=>'BB'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732621391647139)
,p_db_column_name=>'DESC_FAMILIA'
,p_display_order=>270
,p_column_identifier=>'BC'
,p_column_label=>'Desc familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732702772647140)
,p_db_column_name=>'TIPO_USO'
,p_display_order=>280
,p_column_identifier=>'BD'
,p_column_label=>'Tipo uso'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732781026647141)
,p_db_column_name=>'GRUPO_PRODUCTO'
,p_display_order=>290
,p_column_identifier=>'BE'
,p_column_label=>'Grupo producto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065009440807240560)
,p_db_column_name=>'DESCRIPCION_ALTERNA'
,p_display_order=>300
,p_column_identifier=>'BF'
,p_column_label=>'Descripcion alterna'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065009601352240561)
,p_db_column_name=>'CANTIDAD_MAQUINA'
,p_display_order=>310
,p_column_identifier=>'BG'
,p_column_label=>'Cantidad maquina'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065009680943240562)
,p_db_column_name=>'PARTE_FABRICANTE'
,p_display_order=>320
,p_column_identifier=>'BH'
,p_column_label=>'Parte fabricante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065009748222240563)
,p_db_column_name=>'PARTIDA'
,p_display_order=>330
,p_column_identifier=>'BI'
,p_column_label=>'Partida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065009919582240564)
,p_db_column_name=>'CANTIDAD_MINIMA'
,p_display_order=>340
,p_column_identifier=>'BJ'
,p_column_label=>'Cantidad minima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065009984948240565)
,p_db_column_name=>'CANTIDAD_MAXIMA'
,p_display_order=>350
,p_column_identifier=>'BK'
,p_column_label=>'Cantidad maxima'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010074953240566)
,p_db_column_name=>'PEDIDO_MINIMO'
,p_display_order=>360
,p_column_identifier=>'BL'
,p_column_label=>'Pedido minimo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010203510240567)
,p_db_column_name=>'FLAG_TOMA_FISICA'
,p_display_order=>370
,p_column_identifier=>'BM'
,p_column_label=>'Flag toma fisica'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010282818240568)
,p_db_column_name=>'AJUSTA_INFLACION'
,p_display_order=>380
,p_column_identifier=>'BN'
,p_column_label=>'Ajusta inflacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010428221240569)
,p_db_column_name=>'BLOQUEADO_COMPRA_POR'
,p_display_order=>390
,p_column_identifier=>'BO'
,p_column_label=>'Bloqueado compra por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010477621240570)
,p_db_column_name=>'FECHA_BLOQUEO_COMPRA'
,p_display_order=>400
,p_column_identifier=>'BP'
,p_column_label=>'Fecha bloqueo compra'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010576073240571)
,p_db_column_name=>'BLOQUEADO_VENTA_POR'
,p_display_order=>410
,p_column_identifier=>'BQ'
,p_column_label=>'Bloqueado venta por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010702868240572)
,p_db_column_name=>'FECHA_BLOQUEO_VENTA'
,p_display_order=>420
,p_column_identifier=>'BR'
,p_column_label=>'Fecha bloqueo venta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010818086240573)
,p_db_column_name=>'MESES_INVENTARIO'
,p_display_order=>430
,p_column_identifier=>'BS'
,p_column_label=>'Meses inventario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065010906869240574)
,p_db_column_name=>'ROTACION_SIMPLE'
,p_display_order=>440
,p_column_identifier=>'BT'
,p_column_label=>'Rotacion simple'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011019090240575)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>450
,p_column_identifier=>'BU'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011082714240576)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>460
,p_column_identifier=>'BV'
,p_column_label=>'Fecha creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011134590240577)
,p_db_column_name=>'MODIFICADO_POR'
,p_display_order=>470
,p_column_identifier=>'BW'
,p_column_label=>'Modificado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011244393240578)
,p_db_column_name=>'REG_SANITARIO'
,p_display_order=>480
,p_column_identifier=>'BX'
,p_column_label=>'Reg sanitario'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011343798240579)
,p_db_column_name=>'VEN_REG_SANITARIO'
,p_display_order=>490
,p_column_identifier=>'BY'
,p_column_label=>'Ven reg sanitario'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011467747240580)
,p_db_column_name=>'FECHA_DESCONTINUADO'
,p_display_order=>500
,p_column_identifier=>'BZ'
,p_column_label=>'Fecha descontinuado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011611402240581)
,p_db_column_name=>'NUMERO_DIAS_INVENTARIO'
,p_display_order=>510
,p_column_identifier=>'CA'
,p_column_label=>'Numero dias inventario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011692872240582)
,p_db_column_name=>'TAMANO'
,p_display_order=>520
,p_column_identifier=>'CB'
,p_column_label=>'Tamano'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011796542240583)
,p_db_column_name=>'COLOR'
,p_display_order=>530
,p_column_identifier=>'CC'
,p_column_label=>'Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011858402240584)
,p_db_column_name=>'CLASIFICACION_ABC'
,p_display_order=>540
,p_column_identifier=>'CD'
,p_column_label=>'Clasificacion abc'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065011976242240585)
,p_db_column_name=>'LOCAL_EXTERNO'
,p_display_order=>550
,p_column_identifier=>'CE'
,p_column_label=>'Local externo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012122985240586)
,p_db_column_name=>'TIPO_COMBUSTIBLE'
,p_display_order=>560
,p_column_identifier=>'CF'
,p_column_label=>'Tipo combustible'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012216767240587)
,p_db_column_name=>'CILINDRAJE'
,p_display_order=>570
,p_column_identifier=>'CG'
,p_column_label=>'Cilindraje'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012276281240588)
,p_db_column_name=>'NUMERO_CILINDROS'
,p_display_order=>580
,p_column_identifier=>'CH'
,p_column_label=>'Numero cilindros'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012410678240589)
,p_db_column_name=>'TIPO_TRACCION'
,p_display_order=>590
,p_column_identifier=>'CI'
,p_column_label=>'Tipo traccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012434546240590)
,p_db_column_name=>'TIPO_CARROCERIA'
,p_display_order=>600
,p_column_identifier=>'CJ'
,p_column_label=>'Tipo carroceria'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012584176240591)
,p_db_column_name=>'TIPO_ESTILO'
,p_display_order=>610
,p_column_identifier=>'CK'
,p_column_label=>'Tipo estilo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012725480240592)
,p_db_column_name=>'CATEGORIA_CAR'
,p_display_order=>620
,p_column_identifier=>'CL'
,p_column_label=>'Categoria car'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012766259240593)
,p_db_column_name=>'TIPO_SERVICIO'
,p_display_order=>630
,p_column_identifier=>'CM'
,p_column_label=>'Tipo servicio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012872849240594)
,p_db_column_name=>'BASE_MENSUAL'
,p_display_order=>640
,p_column_identifier=>'CN'
,p_column_label=>'Base mensual'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065012954592240595)
,p_db_column_name=>'PAIS_ORIGEN'
,p_display_order=>650
,p_column_identifier=>'CO'
,p_column_label=>'Pais origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013057572240596)
,p_db_column_name=>'INDICA_COMBO'
,p_display_order=>660
,p_column_identifier=>'CP'
,p_column_label=>'Indica combo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013196375240597)
,p_db_column_name=>'IND_DESPIECE'
,p_display_order=>670
,p_column_identifier=>'CQ'
,p_column_label=>'Ind despiece'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013268666240598)
,p_db_column_name=>'IND_OBSERVACIONES'
,p_display_order=>680
,p_column_identifier=>'CR'
,p_column_label=>'Ind observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013363381240599)
,p_db_column_name=>'FRACCIONABLE'
,p_display_order=>690
,p_column_identifier=>'CS'
,p_column_label=>'Fraccionable'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013471167240600)
,p_db_column_name=>'SIN_GESTION_ESTUDIANTE'
,p_display_order=>700
,p_column_identifier=>'CT'
,p_column_label=>'Sin gestion estudiante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14065013616454240601)
,p_db_column_name=>'PERMITE_DESCUENTO'
,p_display_order=>710
,p_column_identifier=>'CU'
,p_column_label=>'Permite descuento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13925964710649215867)
,p_db_column_name=>'ESTADOCABYS'
,p_display_order=>720
,p_column_identifier=>'CW'
,p_column_label=>'Estado Cabys'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14178143116563227910)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'104047'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:ARTICULO:FAMILIA:DESCRIPCION:CODIGO_CABYS:ESTADOCABYS:OBSERVACIONES:MODELO:MARCA:CODIGO_BARRAS:COSTO_FOB:COSTO_ESTANDAR:BLOQUEADO_COMPRA:BLOQUEADO_VENTA:REEMPLAZA:REEMPLAZO:MAXIMO_DESCUENTO:MODIFICAR_PRECIO:GRAVADO:MODIFICA_DESCRIPCION:BAJO_M'
||'ARGEN:DESCONTINUADO:CATEGORIA:CLAVE:ITEMIZADO:TIEMPO_ENTREGA:FECHA_INGRESO:DESC_FAMILIA:DESCRIPCION_ALTERNA:CANTIDAD_MAQUINA:PARTE_FABRICANTE:PARTIDA:CANTIDAD_MINIMA:CANTIDAD_MAXIMA:PEDIDO_MINIMO:FLAG_TOMA_FISICA:AJUSTA_INFLACION:BLOQUEADO_COMPRA_POR'
||':FECHA_BLOQUEO_COMPRA:BLOQUEADO_VENTA_POR:FECHA_BLOQUEO_VENTA:MESES_INVENTARIO:ROTACION_SIMPLE:CREADO_POR:FECHA_CREACION:MODIFICADO_POR:REG_SANITARIO:VEN_REG_SANITARIO:FECHA_DESCONTINUADO:NUMERO_DIAS_INVENTARIO:TAMANO:COLOR:CLASIFICACION_ABC:LOCAL_EX'
||'TERNO:TIPO_COMBUSTIBLE:CILINDRAJE:NUMERO_CILINDROS:TIPO_TRACCION:TIPO_CARROCERIA:TIPO_ESTILO:CATEGORIA_CAR:TIPO_SERVICIO:BASE_MENSUAL:PAIS_ORIGEN:INDICA_COMBO:IND_DESPIECE:IND_OBSERVACIONES:FRACCIONABLE:SIN_GESTION_ESTUDIANTE:PERMITE_DESCUENTO:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096884223491821893)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14096883920031821892)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096884949922821894)
,p_name=>'P33_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096883920031821892)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098494101367203714)
,p_name=>'P33_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14096883920031821892)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE       use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
