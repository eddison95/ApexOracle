prompt --application/pages/page_00138
begin
--   Manifest
--     PAGE: 00138
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>138
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'RRHH-Acciones de Personal'
,p_step_title=>'RRHH-Acciones de Personal'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201125104305'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14295989366950593620)
,p_plug_name=>'Acciones de personal '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14295992667657630289)
,p_plug_name=>'Acciones de personal '
,p_parent_plug_id=>wwv_flow_api.id(14295989366950593620)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   DISTINCT ACP_ID AS Accion_personal,',
'                    ACP_TAP_ID AS Tipo_accion,',
'                    TAP_DESCRIPCION AS descripcion,',
'                    ACP_ESTADO AS Estado,',
'                    ACP_PER_PERSONA AS Empleado,',
'                    RAZON_SOCIAL AS Nombre_Empleado,',
'                    ACP_TEM_ID AS Tipo_Empleado,',
'                    PUE_DESCRIPCION AS Descripcion_Empleado,',
'                    ACP_DEP_DEPARTAMENTO AS Departamento,',
'                    DEP_DESCRIPCION AS Desc_Departamento,',
'                    ACP_FECHA_INGRESO AS Fecha_Ini,',
'                    ACP_FECHA_EMISION AS Fecha_Emision,',
'                    ACP_DETALLE AS Detalle,',
'                    ACP_HORAS AS HORAS,',
'                    ACP_EMP_EMPRESA AS EMPRESA,',
'                    ACP_FECHA_EGRESO AS FECHA_EGRESO,',
'                    ACP_HORARIO_FUERA AS HORARIO_FUERA,',
'                    ACP_DIAS_HABILES AS DIAS_HABILES,',
'                    ACP_DIAS_CALCULADO_VAC AS DIAS_CALC_VAC,',
'                    ACP_DIAS_FERIADOS_VAC AS DIAS_FERIADOS_VAC,',
'                    ACP_FECHA_HASTA AS FECHA_HASTA,',
'                    ACP_FECHA_INICIO AS FECHA_INICIO,',
'                    ACP_HORA_INICIO AS HORA_INICIO,',
'                    ACP_HORA_FIN AS HORA_FIN,',
'                    ACP_PER_PERSONA_SOL AS PERSONA_SOLIC,',
'                    ACP_PER_PERSONA_APR AS PERSONA_APR,',
'                    ACP_FECHA_APROBAR AS FECHA_APROBACION,',
'                    PUE_DESCRIPCION AS PUESTO,',
'                    ACP_NIVEL_ANT AS NIVEL_ANTERIOR,',
'                    ACP_SUBNIVEL_ANT AS SUBNIVEL_ANTERIOR,',
'                    ACP_NIVEL_NUE AS NIVEL_NUEVO,',
'                    ACP_SUBNIVEL_NUE AS SUBNIVEL_NUEVO,',
'                    ACP_SALARIO_ANT AS SALARIO_ANTERIOR,',
'                    ACP_SALARIO_NUE AS SALARIO_NUEVO,',
'                    ACP_CREADO_POR AS CREADO_POR,',
'                    ACP_FECHA_CREACION AS FECHA_CREACION,',
'                    ACP_FECHA_MODIFICACION AS FECHA_MODIFICACION,',
'                    ACP_DEP_DEPARTAMENTO_NUE AS DEPARTAMENTO_NUEVO,',
'                    ACP_SALARIO_HORA_ANT AS SALARIO_HORA_ANTERIOR,',
'                    ACP_SALARIO_HORA_NUE AS SALARIO_HORA_NUEVO,',
'                    ACP_SALARIO_DIA_ANT AS SALARIO_DIA_ANTERIOR,',
'                    ACP_SALARIO_DIA_NUE AS SALARIO_DIA_NUEVO,',
'                    ACP_MONEDA_ANT AS MONEDA_ANTERIOR,',
'                    ACP_MONEDA_NUE AS MONEDA_NUEVO,',
'                    ACP_OBSERVACION_ANULACION AS OBSERVACION_ANULACION',
'    FROM   RHU_ACCION_PERSONAL_TB_NX,',
'           RHU_TIPO_ACCION_TB_NX,',
'           GNL_PERSONA_TR_NX,',
'           RHU_EMPLEADO_TB_NX,',
'           RHU_PUESTOS_TB_NX,',
'           FAC_DEPARTAMENTO_TB_NX,',
'           PLA_TIPO_EMPLEADO_TB_NX',
'   WHERE   INSTR ('':'' || :p138_empresa || '':'', '':'' || ACP_EMP_EMPRESA || '':'') >',
'              0',
'           AND ACP_FECHA_EMISION BETWEEN :p138_inicio',
'                                     AND  TO_DATE (:p138_fin || '' 23:59'',',
'                                                   ''dd/mm/rrrr hh24:mi'')',
'           AND ACP_TAP_ID = TAP_ID',
'           AND ACP_EMP_EMPRESA = TAP_EMP_EMPRESA',
'           AND ACP_PER_PERSONA = PERSONA',
'           AND ACP_EMP_EMPRESA = EPL_EMP_EMPRESA',
'           AND ACP_PER_PERSONA = EPL_PER_PERSONA',
'           AND EPL_EMP_EMPRESA = PUE_EMP_EMPRESA',
'           AND EPL_PUE_ID = PUE_ID',
'           AND ACP_DEP_DEPARTAMENTO= DEP_DEPARTAMENTO',
'           AND ACP_EMP_EMPRESA = DEP_EMP_EMPRESA',
'           AND ACP_TEM_ID = TEM_ID',
'ORDER BY   ACP_ID DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_required_role=>wwv_flow_api.id(14193430675880859352)
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P138_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14295992761126630290)
,p_name=>'Compras'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>232973030686414031
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084045070276050713)
,p_db_column_name=>'ACCION_PERSONAL'
,p_display_order=>10
,p_column_identifier=>'V'
,p_column_label=>unistr('Acci\00F3n Personal')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084045821539050729)
,p_db_column_name=>'TIPO_ACCION'
,p_display_order=>20
,p_column_identifier=>'W'
,p_column_label=>unistr('Tipo Acci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084046229343050730)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>30
,p_column_identifier=>'X'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084046544069050731)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'Y'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084046950833050731)
,p_db_column_name=>'EMPLEADO'
,p_display_order=>50
,p_column_identifier=>'Z'
,p_column_label=>'Empleado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084047427306050732)
,p_db_column_name=>'NOMBRE_EMPLEADO'
,p_display_order=>60
,p_column_identifier=>'AA'
,p_column_label=>'Nombre Empleado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084047768459050736)
,p_db_column_name=>'TIPO_EMPLEADO'
,p_display_order=>70
,p_column_identifier=>'AB'
,p_column_label=>'Tipo Empleado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084048178800050737)
,p_db_column_name=>'DESCRIPCION_EMPLEADO'
,p_display_order=>80
,p_column_identifier=>'AC'
,p_column_label=>unistr('Descripci\00F3n Empleado')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084048580116050738)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>90
,p_column_identifier=>'AD'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084048965940050738)
,p_db_column_name=>'DESC_DEPARTAMENTO'
,p_display_order=>100
,p_column_identifier=>'AE'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084049416718050739)
,p_db_column_name=>'FECHA_INI'
,p_display_order=>110
,p_column_identifier=>'AF'
,p_column_label=>'Fecha Inicial'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084049805821050740)
,p_db_column_name=>'FECHA_EMISION'
,p_display_order=>120
,p_column_identifier=>'AG'
,p_column_label=>unistr('Fecha Emisi\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084050168785050741)
,p_db_column_name=>'DETALLE'
,p_display_order=>130
,p_column_identifier=>'AH'
,p_column_label=>'Detalle'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13962366178348129104)
,p_db_column_name=>'HORAS'
,p_display_order=>140
,p_column_identifier=>'AI'
,p_column_label=>'Horas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951913389031568323)
,p_db_column_name=>'EMPRESA'
,p_display_order=>150
,p_column_identifier=>'AJ'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951913629205568326)
,p_db_column_name=>'FECHA_EGRESO'
,p_display_order=>180
,p_column_identifier=>'AM'
,p_column_label=>'Fecha Egreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951913740246568327)
,p_db_column_name=>'HORARIO_FUERA'
,p_display_order=>190
,p_column_identifier=>'AN'
,p_column_label=>'Horario Fuera'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951913883494568328)
,p_db_column_name=>'DIAS_HABILES'
,p_display_order=>200
,p_column_identifier=>'AO'
,p_column_label=>'Dias Habiles'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951913920134568329)
,p_db_column_name=>'DIAS_CALC_VAC'
,p_display_order=>210
,p_column_identifier=>'AP'
,p_column_label=>'Dias Calc Vac'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914113275568330)
,p_db_column_name=>'DIAS_FERIADOS_VAC'
,p_display_order=>220
,p_column_identifier=>'AQ'
,p_column_label=>'Dias Feriados Vac'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914188013568331)
,p_db_column_name=>'FECHA_HASTA'
,p_display_order=>230
,p_column_identifier=>'AR'
,p_column_label=>'Fecha Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914253108568332)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>240
,p_column_identifier=>'AS'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914372872568333)
,p_db_column_name=>'HORA_INICIO'
,p_display_order=>250
,p_column_identifier=>'AT'
,p_column_label=>'Hora Inicio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914498372568334)
,p_db_column_name=>'HORA_FIN'
,p_display_order=>260
,p_column_identifier=>'AU'
,p_column_label=>'Hora Fin'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914613310568335)
,p_db_column_name=>'PERSONA_SOLIC'
,p_display_order=>270
,p_column_identifier=>'AV'
,p_column_label=>'Persona Solic'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914634966568336)
,p_db_column_name=>'PERSONA_APR'
,p_display_order=>280
,p_column_identifier=>'AW'
,p_column_label=>'Persona Apr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914761605568337)
,p_db_column_name=>'FECHA_APROBACION'
,p_display_order=>290
,p_column_identifier=>'AX'
,p_column_label=>'Fecha Aprobacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951914841818568338)
,p_db_column_name=>'PUESTO'
,p_display_order=>300
,p_column_identifier=>'AY'
,p_column_label=>'Puesto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915012853568339)
,p_db_column_name=>'NIVEL_ANTERIOR'
,p_display_order=>310
,p_column_identifier=>'AZ'
,p_column_label=>'Nivel Anterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915042366568340)
,p_db_column_name=>'SUBNIVEL_ANTERIOR'
,p_display_order=>320
,p_column_identifier=>'BA'
,p_column_label=>'Subnivel Anterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915131254568341)
,p_db_column_name=>'NIVEL_NUEVO'
,p_display_order=>330
,p_column_identifier=>'BB'
,p_column_label=>'Nivel Nuevo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915299403568342)
,p_db_column_name=>'SUBNIVEL_NUEVO'
,p_display_order=>340
,p_column_identifier=>'BC'
,p_column_label=>'Subnivel Nuevo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915359632568343)
,p_db_column_name=>'SALARIO_ANTERIOR'
,p_display_order=>350
,p_column_identifier=>'BD'
,p_column_label=>'Salario Anterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915504277568344)
,p_db_column_name=>'SALARIO_NUEVO'
,p_display_order=>360
,p_column_identifier=>'BE'
,p_column_label=>'Salario Nuevo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915596381568345)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>370
,p_column_identifier=>'BF'
,p_column_label=>'Creado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915706072568346)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>380
,p_column_identifier=>'BG'
,p_column_label=>'Fecha Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915779826568347)
,p_db_column_name=>'FECHA_MODIFICACION'
,p_display_order=>390
,p_column_identifier=>'BH'
,p_column_label=>'Fecha Modificacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915844774568348)
,p_db_column_name=>'DEPARTAMENTO_NUEVO'
,p_display_order=>400
,p_column_identifier=>'BI'
,p_column_label=>'Departamento Nuevo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951915918997568349)
,p_db_column_name=>'SALARIO_HORA_ANTERIOR'
,p_display_order=>410
,p_column_identifier=>'BJ'
,p_column_label=>'Salario Hora Anterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951916086039568350)
,p_db_column_name=>'SALARIO_HORA_NUEVO'
,p_display_order=>420
,p_column_identifier=>'BK'
,p_column_label=>'Salario Hora Nuevo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951916147003568351)
,p_db_column_name=>'SALARIO_DIA_ANTERIOR'
,p_display_order=>430
,p_column_identifier=>'BL'
,p_column_label=>'Salario Dia Anterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951916299278568352)
,p_db_column_name=>'SALARIO_DIA_NUEVO'
,p_display_order=>440
,p_column_identifier=>'BM'
,p_column_label=>'Salario Dia Nuevo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951916411967568353)
,p_db_column_name=>'MONEDA_ANTERIOR'
,p_display_order=>450
,p_column_identifier=>'BN'
,p_column_label=>'Moneda Anterior'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951987404036507404)
,p_db_column_name=>'MONEDA_NUEVO'
,p_display_order=>460
,p_column_identifier=>'BO'
,p_column_label=>'Moneda Nuevo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951987415305507405)
,p_db_column_name=>'OBSERVACION_ANULACION'
,p_display_order=>470
,p_column_identifier=>'BP'
,p_column_label=>'Observacion Anulacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14295994168696630594)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'210308'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TTM_LOC_ID::ACCION_PERSONAL:TIPO_ACCION:DESCRIPCION:ESTADO:EMPLEADO:NOMBRE_EMPLEADO:TIPO_EMPLEADO:DESCRIPCION_EMPLEADO:DEPARTAMENTO:DESC_DEPARTAMENTO:FECHA_INI:FECHA_EMISION:DETALLE:HORAS:EMPRESA:FECHA_EGRESO:HORARIO_FUERA:DIAS_HABILES:DIAS_CALC_VAC:'
||'DIAS_FERIADOS_VAC:FECHA_HASTA:FECHA_INICIO:HORA_INICIO:HORA_FIN:PERSONA_SOLIC:PERSONA_APR:FECHA_APROBACION:PUESTO:NIVEL_ANTERIOR:SUBNIVEL_ANTERIOR:NIVEL_NUEVO:SUBNIVEL_NUEVO:SALARIO_ANTERIOR:SALARIO_NUEVO:CREADO_POR:FECHA_CREACION:FECHA_MODIFICACION:'
||'DEPARTAMENTO_NUEVO:SALARIO_HORA_ANTERIOR:SALARIO_HORA_NUEVO:SALARIO_DIA_ANTERIOR:SALARIO_DIA_NUEVO:MONEDA_ANTERIOR:MONEDA_NUEVO:OBSERVACION_ANULACION'
,p_sum_columns_on_break=>'CED_SUBTOTAL:CED_DESCUENTO:CED_IMPUESTO:CED_OTROS_IMPUESTOS:CED_TOTAL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14084043144818050654)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14295989366950593620)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084043597103050667)
,p_name=>'P138_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14295989366950593620)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084043967389050691)
,p_name=>'P138_INICIO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14295989366950593620)
,p_prompt=>'Inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'RETURN TRUNC (SYSDATE, ''MM'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084044386591050692)
,p_name=>'P138_FIN'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14295989366950593620)
,p_prompt=>'Fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'SYSDATE'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
