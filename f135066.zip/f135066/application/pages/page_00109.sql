prompt --application/pages/page_00109
begin
--   Manifest
--     PAGE: 00109
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>109
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'TAL - Detalle de Casos'
,p_step_title=>'Detalle de Casos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165035'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095993236989759187)
,p_plug_name=>'Detalle de Casos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095987849903759169)
,p_plug_name=>'Detalle de Casos'
,p_parent_plug_id=>wwv_flow_api.id(14095993236989759187)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ord_orden,',
'    CASE ord_estado_caso',
'        WHEN ''R''  THEN',
'            ''Registrado''',
'        WHEN ''V''  THEN',
'            ''Valorado''',
'        WHEN ''C''  THEN',
'            ''Cotizado''',
'        WHEN ''A''  THEN',
'            ''Aceptado''',
'        WHEN ''D''  THEN',
'            ''Declinado''',
'        WHEN ''E''  THEN',
'            ''Desestimado''',
'        ELSE',
'            ''Otro''',
'    END estado,',
'    trunc(ord_fecha)     fecha,',
'    ord_emp_empresa,',
'    ord_lcn_localizacion,',
'    NULL                 correo',
'FROM',
'    tal_orden_servicio_tb_nx o',
'WHERE',
'        ord_emp_empresa = :p109_empresa',
'    AND ord_lcn_localizacion = nvl(',
'        :p109_localizacion, ord_lcn_localizacion',
'    )',
'    AND ord_estado_caso = :p109_casos',
'    AND ord_fecha BETWEEN :p109_inicio AND to_date(',
'        :p109_fin || '' 23:59'', ''dd/mm/rrrr hh24:mi''',
'    )'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P109_FIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095988272931759170)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>8244548159870076
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096105748950408008)
,p_db_column_name=>'ORD_ORDEN'
,p_display_order=>10
,p_column_identifier=>'AE'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096105868193408009)
,p_db_column_name=>'ESTADO'
,p_display_order=>20
,p_column_identifier=>'AF'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096105962363408010)
,p_db_column_name=>'FECHA'
,p_display_order=>30
,p_column_identifier=>'AG'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096106049506408011)
,p_db_column_name=>'ORD_EMP_EMPRESA'
,p_display_order=>40
,p_column_identifier=>'AH'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096106154802408012)
,p_db_column_name=>'ORD_LCN_LOCALIZACION'
,p_display_order=>50
,p_column_identifier=>'AI'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14096106225539408013)
,p_db_column_name=>'CORREO'
,p_display_order=>60
,p_column_identifier=>'AJ'
,p_column_label=>'Correo'
,p_column_link=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.:RP:P109_BODY: #ORD_ORDEN# #ORD_EMP_EMPRESA# #ORD_LCN_LOCALIZACION# #FECHA# #ESTADO#'
,p_column_linktext=>'<button type="button">@</button> '
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095992754697759186)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'82491'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>':ORD_ORDEN:ESTADO:FECHA:ORD_EMP_EMPRESA:ORD_LCN_LOCALIZACION:CORREO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14095993678230759188)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14095993236989759187)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095994104947759190)
,p_name=>'P109_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14095993236989759187)
,p_item_default=>'return :P99_EMPRESA'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Empresa'
,p_source=>'return :P99_EMPRESA'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095994482624759191)
,p_name=>'P109_INICIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14095993236989759187)
,p_item_default=>'RETURN :P99_INICIO'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Inicio'
,p_source=>'RETURN :P99_INICIO'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095994829710759192)
,p_name=>'P109_FIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14095993236989759187)
,p_item_default=>'RETURN :P99_FIN'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fin'
,p_source=>'RETURN :P99_FIN'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095995275396759193)
,p_name=>'P109_CASOS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14095993236989759187)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096153225303594730)
,p_name=>'P109_LOCALIZACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14095993236989759187)
,p_item_default=>'return :P99_LOCALIZACION'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Sucursal'
,p_source=>'return :P99_LOCALIZACION'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (inv_descrip_loca_v_nx(ord_emp_empresa, ord_lcn_localizacion)||'' - ''||ord_lcn_localizacion) as d,',
'       ord_lcn_localizacion as r',
'FROM   tal_orden_servicio_vw_nx',
'WHERE  ord_emp_empresa = :P109_EMPRESA',
'GROUP  BY ord_emp_empresa, ord_lcn_localizacion',
'ORDER  BY ord_lcn_localizacion  '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_lov_cascade_parent_items=>'P109_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
