prompt --application/pages/page_00126
begin
--   Manifest
--     PAGE: 00126
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>126
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CRM - Oportunidades Detallado'
,p_step_title=>'CRM - Oportunidades Detallado'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165243'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098091840899567209)
,p_plug_name=>'Oportunidades Detallado'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14083992978224031909)
,p_plug_name=>'Oportunidades'
,p_parent_plug_id=>wwv_flow_api.id(14098091840899567209)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT org.name cta_nombre,',
'      first_name cta_apellido1,',
'      last_name cta_apellido2,',
'      CASE marital_status',
'         WHEN ''C1'' THEN ''CASADO UNA VEZ''',
'         WHEN ''C2'' THEN ''CASADO DOS VECES''',
'         WHEN ''C3'' THEN ''CASADO TRES VECES''',
'         WHEN ''C4'' THEN ''CASADO CUATRO VECES''',
'         WHEN ''C5'' THEN ''CASADO CINCO VECES''',
'         WHEN ''D1'' THEN ''DIVORCIADO UNA VEZ''',
'         WHEN ''D2'' THEN ''DIVORCIADO DOS VECES''',
'         WHEN ''D3'' THEN ''DIVORCIADO TRES VECES''',
'         WHEN ''SO'' THEN ''SOLTERO''',
'         WHEN ''VI'' THEN ''VIUDO''',
'         WHEN ''NA'' THEN ''NO APLICA''',
'         WHEN ''SE'' THEN ''SEPARADO''',
'         WHEN ''UL'' THEN ''UNION LIBRE''',
'         WHEN ''D4'' THEN ''DIVORCIADO CUATRO VECES''',
'         WHEN ''D5'' THEN ''DIVORCIADO CINCO VECES''',
'         WHEN ''N/A'' THEN ''NO APLICA''',
'         ELSE ''OTRO''',
'      END',
'         cta_estado_civil,',
'      CASE document_type',
'         WHEN ''F'' THEN ''FISICA''',
'         WHEN ''J'' THEN ''JURIDICA''',
'         WHEN ''P'' THEN ''PASAPORTE''',
'         WHEN ''R'' THEN ''RESIDENCIA''',
'         ELSE ''OTRO''',
'      END',
'         cta_tipo_documento,',
'      identification cta_documento,',
'      celular cta_celular,',
'      email cta_correo_electronico,',
'      address1 cta_direccion,',
'      (SELECT description',
'       FROM province a',
'       WHERE a.id = org.province)',
'         cta_provincia,',
'      (SELECT description',
'       FROM canton a',
'       WHERE a.id = org.canton)',
'         cta_canton,',
'      (SELECT description',
'       FROM district a',
'       WHERE a.id = org.district)',
'         cta_distrito,',
'      (SELECT name',
'       FROM profession a',
'       WHERE a.id = org.profession)',
'         cta_profesion,',
'      birth_date cta_fecha_nacimiento,',
'      CASE has_vehicle',
'         WHEN ''S'' THEN ''Si''',
'         WHEN ''N'' THEN ''No''',
'         ELSE ''SD''',
'      END',
'         cta_tiene_vehiculo,',
'      (SELECT name',
'       FROM territories a',
'       WHERE a.id = org.territory)',
'         cta_territorio,',
'      (SELECT name',
'       FROM economic_sector a',
'       WHERE a.id = org.economic_sector)',
'         cta_sector,',
'      org.phone cta_telefono,',
'      url cta_sitio_web,',
'      CASE org.TYPE',
'         WHEN ''P'' THEN ''PROSPECTO''',
'         WHEN ''O'' THEN ''OPORTUNIDAD''',
'         ELSE ''OTRO''',
'      END',
'         cta_tipo,',
'      CASE gender',
'         WHEN ''M'' THEN ''MASCULINO''',
'         WHEN ''F'' THEN ''FEMENINO''',
'         ELSE ''OTRO''',
'      END',
'         cta_genero,',
'      opp.company opo_empresa,',
'      opp.name opo_nombre,',
'      TO_CHAR (opp.description) opo_descripcion,',
'      (SELECT name',
'       FROM salesman a',
'       WHERE a.id = opp.assigned_to)',
'         opo_representante,',
'      opp.estimated_close_date opo_cierre_estimado,',
'      CASE opp.status',
'         WHEN ''1'' THEN ''EN PROCESO''',
'         WHEN ''2'' THEN ''GANADA''',
'         WHEN ''3'' THEN ''PERDIDA''',
'         WHEN ''4'' THEN ''DESIERTA''',
'         WHEN ''5'' THEN ''EN ESTUDIO''',
'WHEN ''6'' THEN ''CREDITO CONDICIONADO''',
'         WHEN ''7'' THEN ''CREDITO RECHAZADO''',
'         WHEN ''8'' THEN ''CREDITO APROBADO''',
'         ELSE ''OTRO''',
'      END',
'         opo_estado,',
'      (SELECT name',
'       FROM referrals a',
'       WHERE a.id = opp.referral)',
'         opo_origen,',
'      (SELECT name',
'       FROM advertising_origin a',
'       WHERE a.id = opp.advertising_origin)',
'         opo_medio,',
'      (SELECT name || '' '' || description',
'       FROM price_books a',
'       WHERE a.id = opp.price_book)',
'         opo_lista_precios,',
'      (SELECT name || '' '' || code',
'       FROM products a',
'       WHERE a.id = pop.product)',
'         opo_articulo,',
'      pop.sale_price opo_precio_venta,',
'      opp.total_discount opo_descuento,',
'      pop.total_price opo_precio_total,',
'      opo_ultima_etapa_fn (opp.id) opo_etapa,',
'      (SELECT max (percent1)',
'     FROM follow_ups a , followups_detail b',
'     WHERE     a.opportunity = opp.id',
'           AND status = 1',
'           AND b.template = opp.template',
'           AND a.secuence = b.secuence) opo_avance,',
'      por.chassis itm_chasis,',
'      por.mark itm_marca,',
'      por.model itm_modelo,',
'      por.serial itm_serial,',
'      por.motor itm_motor,',
'      por.ano itm_ano,',
'      por.color itm_color,',
'      por.veh_value itm_valor,',
'      por.discount itm_descuento,',
'      (SELECT count(fil.id) FROM files fil',
'       WHERE opp.id = fil.topic ) cantidad_archivos,',
'opp.fecha_cre fecha_creacion,',
'LAST_CAUSE,',
'opp.id, ',
'opp.template',
'FROM organizations org,',
'    opportunities opp,',
'    products_by_opportunity pop,',
'    orders ord,',
'    products_by_order por',
'WHERE     org.id = opp.organization(+)',
'     AND opp.id = pop.opportunity(+)',
'     AND opp.id = ord.opportunities(+)',
'     AND ord.id = por.p_order(+)',
'     AND INSTR ('':'' || :P126_EMPRESA || '':'',',
'                     '':'' || opp.company || '':'') > 0',
'     AND fecha_cre BETWEEN TO_DATE(:P126_INICIO, ''DD/MM/RRRR'') AND TO_DATE (:P126_FIN || '' 23:59'', ''DD/MM/RRRR HH24:MI'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14083993095903031910)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>14151585425193705
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993145537031911)
,p_db_column_name=>'CTA_NOMBRE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993249228031912)
,p_db_column_name=>'CTA_APELLIDO1'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Apellido1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993351856031913)
,p_db_column_name=>'CTA_APELLIDO2'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Apellido2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993447833031914)
,p_db_column_name=>'CTA_ESTADO_CIVIL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado Civil'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993597062031915)
,p_db_column_name=>'CTA_TIPO_DOCUMENTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993689188031916)
,p_db_column_name=>'CTA_DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993710622031917)
,p_db_column_name=>'CTA_CELULAR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Celular'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993851451031918)
,p_db_column_name=>'CTA_CORREO_ELECTRONICO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Correo Electronico'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083993964541031919)
,p_db_column_name=>'CTA_DIRECCION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Direccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994100921031920)
,p_db_column_name=>'CTA_PROVINCIA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Provincia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994150890031921)
,p_db_column_name=>'CTA_CANTON'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Canton'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994247591031922)
,p_db_column_name=>'CTA_DISTRITO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Distrito'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994326115031923)
,p_db_column_name=>'CTA_PROFESION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Profesion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994416313031924)
,p_db_column_name=>'CTA_FECHA_NACIMIENTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'F. Nacimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994567620031925)
,p_db_column_name=>'CTA_TIENE_VEHICULO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Tiene Vehiculo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994677435031926)
,p_db_column_name=>'CTA_TERRITORIO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Territorio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994768821031927)
,p_db_column_name=>'CTA_SECTOR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Sector'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994844414031928)
,p_db_column_name=>'CTA_TELEFONO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083994918648031929)
,p_db_column_name=>'CTA_SITIO_WEB'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Sitio Web'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995100681031930)
,p_db_column_name=>'CTA_TIPO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995146643031931)
,p_db_column_name=>'CTA_GENERO'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Genero'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995308758031932)
,p_db_column_name=>'OPO_EMPRESA'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995377335031933)
,p_db_column_name=>'OPO_NOMBRE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Oportunidad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995532480031935)
,p_db_column_name=>'OPO_REPRESENTANTE'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Representante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995630932031936)
,p_db_column_name=>'OPO_CIERRE_ESTIMADO'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'F. Estimada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995764363031937)
,p_db_column_name=>'OPO_ESTADO'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995853900031938)
,p_db_column_name=>'OPO_ORIGEN'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083995946189031939)
,p_db_column_name=>'OPO_MEDIO'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Medio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996031773031940)
,p_db_column_name=>'OPO_LISTA_PRECIOS'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Lista Precios'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996197777031941)
,p_db_column_name=>'OPO_ARTICULO'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996273807031942)
,p_db_column_name=>'OPO_PRECIO_VENTA'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Precio Venta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996353759031943)
,p_db_column_name=>'OPO_DESCUENTO'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996501081031944)
,p_db_column_name=>'OPO_PRECIO_TOTAL'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Precio Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996522683031945)
,p_db_column_name=>'OPO_ETAPA'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996776530031947)
,p_db_column_name=>'ITM_CHASIS'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Chasis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996814135031948)
,p_db_column_name=>'ITM_MARCA'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083996949436031949)
,p_db_column_name=>'ITM_MODELO'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083997057836031950)
,p_db_column_name=>'ITM_SERIAL'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Serial'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083997114601031951)
,p_db_column_name=>'ITM_MOTOR'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Motor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083997241080031952)
,p_db_column_name=>'ITM_ANO'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083997349460031953)
,p_db_column_name=>'ITM_COLOR'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083997509160031954)
,p_db_column_name=>'ITM_VALOR'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083997516505031955)
,p_db_column_name=>'ITM_DESCUENTO'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086274804519786975)
,p_db_column_name=>'CANTIDAD_ARCHIVOS'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Cantidad archivos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087234805928160895)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fecha creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14063222487464713805)
,p_db_column_name=>'LAST_CAUSE'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Cambio de estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049586633397902059)
,p_db_column_name=>'OPO_DESCRIPCION'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Opo descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049586760171902060)
,p_db_column_name=>'OPO_AVANCE'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Opo avance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049586810961902061)
,p_db_column_name=>'ID'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049586910081902062)
,p_db_column_name=>'TEMPLATE'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Template'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14072962729327988274)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'31213'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CTA_NOMBRE:CTA_APELLIDO1:CTA_APELLIDO2:CTA_ESTADO_CIVIL:CTA_TIPO_DOCUMENTO:CTA_DOCUMENTO:CTA_CELULAR:CTA_CORREO_ELECTRONICO:CTA_DIRECCION:CTA_PROVINCIA:CTA_CANTON:CTA_DISTRITO:CTA_PROFESION:CTA_FECHA_NACIMIENTO:CTA_TIENE_VEHICULO:CTA_TERRITORIO:CTA_S'
||'ECTOR:CTA_TELEFONO:CTA_SITIO_WEB:CTA_TIPO:CTA_GENERO:OPO_EMPRESA:OPO_NOMBRE:OPO_REPRESENTANTE:OPO_CIERRE_ESTIMADO:OPO_ESTADO:OPO_ORIGEN:OPO_MEDIO:OPO_LISTA_PRECIOS:OPO_ARTICULO:OPO_PRECIO_VENTA:OPO_DESCUENTO:OPO_PRECIO_TOTAL:OPO_ETAPA:ITM_CHASIS:ITM_'
||'MARCA:ITM_MODELO:ITM_SERIAL:ITM_MOTOR:ITM_ANO:ITM_COLOR:ITM_VALOR:ITM_DESCUENTO:CANTIDAD_ARCHIVOS:FECHA_CREACION:LAST_CAUSE::ID:TEMPLATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14072925849525828831)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14098091840899567209)
,p_button_name=>'CONSULTAR'
,p_button_static_id=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14072926300350828835)
,p_name=>'P126_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14098091840899567209)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14072926676423828841)
,p_name=>'P126_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14098091840899567209)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14072927102129828842)
,p_name=>'P126_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14098091840899567209)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
