prompt --application/pages/page_00056
begin
--   Manifest
--     PAGE: 00056
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>56
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GNL - Personas'
,p_step_title=>'Personas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ESALAS'
,p_last_upd_yyyymmddhh24miss=>'20210218091923'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14096917179098465116)
,p_plug_name=>'Personas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14112626163558530113)
,p_plug_name=>'Personas'
,p_region_name=>'Personas'
,p_parent_plug_id=>wwv_flow_api.id(14096917179098465116)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   a.per_emp_empresa,',
'         a.persona persona,',
'         a.nombre || '' '' || a.apellidos nombre_completo,',
'         a.documento cedula,',
'         CASE a.sexo',
'            WHEN ''F'' THEN',
'            ''FEMENINO''',
'            WHEN ''M'' THEN',
'            ''MASCULINO''',
'            ELSE',
'            ''NA''',
'            END sexo,',
'         (SELECT   b.pfe_descripcion',
'            FROM   gnl_profesion_tb_nx b',
'           WHERE   b.pfe_profesion = a.pfe_profesion)',
'            profesion,',
'         a.nacionalidad,',
'         (SELECT   c.gec_descripcion',
'            FROM   gnl_estado_civil_tb_nx c',
'           WHERE   c.gec_tipo = a.estado_civil)',
'            estado_civil,',
'         a.direccion,',
'         a.email,',
'         CASE',
'            WHEN (    a.telefono1 IS NOT NULL',
'                  AND a.telefono2 IS NULL',
'                  AND a.telefono3 IS NULL)',
'            THEN',
'               a.telefono1',
'            WHEN (    a.telefono1 IS NOT NULL',
'                  AND a.telefono2 IS NOT NULL',
'                  AND a.telefono3 IS NULL)',
'            THEN',
'               a.telefono1 || '' / '' || a.telefono2',
'            WHEN (    a.telefono1 IS NOT NULL',
'                  AND a.telefono2 IS NOT NULL',
'                  AND a.telefono3 IS NOT NULL)',
'            THEN',
'               a.telefono1 || '' / '' || a.telefono2 || '' / '' || a.telefono3',
'            ELSE',
'               ''''',
'         END',
'            telefonos,',
'         a.fax,',
'         a.apartado,',
'         DECODE (a.proveedor, 1, ''Si'', ''No'') proveedor,',
'         DECODE (a.cliente, 1, ''Si'', ''No'') cliente,',
'         DECODE (a.banco, 1, ''Si'', ''No'') banco,',
'         DECODE (a.empleado, 1, ''Si'', ''No'') empleado,',
'         DECODE (a.servicios, 1, ''Si'', ''No'') servicios,',
'         DECODE (a.otro, 1, ''Si'', ''No'') otro,',
'         (SELECT   d.atv_descripcion',
'            FROM   gnl_actividad_tb_nx d',
'           WHERE   d.atv_actividad = a.act_actividad)',
'            actividad,',
'         a.representante_legal,',
'         a.cedula_representante,',
'         DECODE (a.regimen_iva,',
'                 ''C'', ''Comun'',',
'                 ''S'', ''Simplificado'',',
'                 ''No Aplica'')',
'            regimen_iva,',
'         DECODE (a.gran_contribuyente, ''N'', ''No'', ''Si'') gran_contribuyente,',
'         DECODE (a.autoretenedor, ''N'', ''No'', ''Si'') autoretenedor,',
'         DECODE (a.per_afiliado_diamante, ''N'', ''No'', ''Si'') afiliado_diamante,',
'         a.contacto1,',
'         a.cargo_contacto1,',
'         a.relacion_contacto1,',
'         a.contacto2,',
'         a.cargo_contacto2,',
'         a.relacion_contacto2,',
'         a.contacto3,',
'         a.cargo_contacto3,',
'         a.relacion_contacto3,',
'         FECHA_NACIMIENTO,',
'         (SELECT pai_nombre || '' (''||pai_pais||'')''',
'         FROM gnl_pais_tb_nx b',
'         WHERE b.pai_pais = a.pai_pais) per_pais,',
'         (SELECT pro_nombre || '' (''||pro_numero||'')''',
'         FROM gnl_provincia_tb_nx b',
'         WHERE b.pro_id = a.per_pro_provincia) per_provincia,         ',
'         (SELECT ciu_nombre || '' (''||ciu_ciudad||'')''',
'         FROM gnl_ciudad_tb_nx b',
'         WHERE b.ciu_ciudad = a.ciu_ciudad) per_ciudad,',
'         (SELECT descripcion || '' (''||zona||'')''',
'         FROM gnl_zona_tr_nx b',
'         WHERE b.zona = a.zon_zona) per_zona   ,',
'         a.observaciones observaciones,',
'         a.per_tcu_cuenta condicion,',
'         CASE ',
'             WHEN tipo_documento = 1 THEN ''Numero Identificacion Tributario''',
'             WHEN tipo_documento = 2 THEN ''Cedula de Ciudadania''',
'             WHEN tipo_documento = 3 THEN ''Cedula de Residencia''',
'             WHEN tipo_documento = 4 THEN ''Documento de Identidad Migratoria para Extranjeros''',
'             WHEN tipo_documento = 5 THEN ''Cedula Juridica''',
'             WHEN tipo_documento = 6 THEN ''Pasaporte''',
'             WHEN tipo_documento = 7 THEN ''Cedula de Identidad''',
'             WHEN tipo_documento = 8 THEN ''Registro Federal de Causantes''',
'             ELSE ''NA''',
'          END tipo,',
'          razon_social,',
'         DECODE (a.per_estudiante, 1, ''Si'', ''No'') estudiante,',
'         DECODE (a.per_profesor, 1, ''Si'', ''No'') profesor,',
'         exp_otro explica_otro,',
'         correspondencia,',
'         creado_por,',
'         fecha_creacion,',
'         modificado_por,',
'         fecha_modificacion,',
'         cita_registral,',
'         cr_tomo,',
'         cr_folio,',
'         cr_asiento,',
'         digito_verificacion,',
'         documento_nit,',
'         dom_fiscal dominio_fiscal,',
'         per_grd_grado_academico grado_academico,',
'         per_apellido_soltera_casada,',
'         per_clase_sec_economico clase_sector_economico,',
'         per_consecutivo consecutivo,',
'         cr_tomo_2 tomo2,',
'         cr_folio_2 folio2,',
'         cr_asiento_2 asiento2,',
'        (select        tpa_descripcion',
'  from GCM_TIPO_PACIENTE_TB_NX',
'  WHERE tpa_emp_empresa = per_emp_Empresa',
'  AND tpa_id = per_tipo_paciente) tipo_paciente,',
'         DECODE (a.per_medico, 1, ''Si'', ''No'') medico,',
'         (SELECT dis_nombre || '' (''||dis_numero||'')''',
'         FROM gnl_distrito_tb_nx b',
'         WHERE b.dis_id = a.per_dis_id) distrito,',
'         per_usu_user_id id_usuario ',
'  FROM   gnl_persona_tr_nx a',
'  WHERE   (CASE',
'             WHEN :G_INS_COMPARTIDA = ''S''',
'             THEN',
'                INSTR ('':'' || :P56_EMPRESA || '':'',',
'                       '':'' || PER_EMP_EMPRESA || '':'')',
'             ELSE',
'                1',
'          END) > 0;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P56_EMPRESA IS NOT NULL OR :G_INS_COMPARTIDA = ''N'' THEN ',
'RETURN TRUE;',
'ELSE ',
'RETURN FALSE ;',
'END IF ;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14112626378194530118)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>11835127502741507
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112626473262530130)
,p_db_column_name=>'CEDULA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
,p_static_id=>'CEDULA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112631568760547157)
,p_db_column_name=>'NOMBRE_COMPLETO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Nombre Completo'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE_COMPLETO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112631672755547167)
,p_db_column_name=>'SEXO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Sexo'
,p_column_type=>'STRING'
,p_static_id=>'SEXO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112631783382547168)
,p_db_column_name=>'PROFESION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Profesion'
,p_column_type=>'STRING'
,p_static_id=>'PROFESION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112631876489547168)
,p_db_column_name=>'NACIONALIDAD'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Nacionalidad'
,p_column_type=>'STRING'
,p_static_id=>'NACIONALIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112631973812547168)
,p_db_column_name=>'ESTADO_CIVIL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Estado Civil'
,p_column_type=>'STRING'
,p_static_id=>'ESTADO_CIVIL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632072095547169)
,p_db_column_name=>'DIRECCION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Direccion'
,p_column_type=>'STRING'
,p_static_id=>'DIRECCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632166919547169)
,p_db_column_name=>'EMAIL'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_static_id=>'EMAIL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632282428547169)
,p_db_column_name=>'TELEFONOS'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Telefonos'
,p_column_type=>'STRING'
,p_static_id=>'TELEFONOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632368860547169)
,p_db_column_name=>'FAX'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fax'
,p_column_type=>'STRING'
,p_static_id=>'FAX'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632468734547170)
,p_db_column_name=>'APARTADO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Apartado'
,p_column_type=>'STRING'
,p_static_id=>'APARTADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632552056547170)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PROVEEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632680772547171)
,p_db_column_name=>'CLIENTE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632776134547171)
,p_db_column_name=>'BANCO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_static_id=>'BANCO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632877054547171)
,p_db_column_name=>'EMPLEADO'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Empleado'
,p_column_type=>'STRING'
,p_static_id=>'EMPLEADO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112632976987547172)
,p_db_column_name=>'SERVICIOS'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Servicios'
,p_column_type=>'STRING'
,p_static_id=>'SERVICIOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633058183547172)
,p_db_column_name=>'OTRO'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Otro'
,p_column_type=>'STRING'
,p_static_id=>'OTRO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633163907547172)
,p_db_column_name=>'ACTIVIDAD'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Actividad'
,p_column_type=>'STRING'
,p_static_id=>'ACTIVIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633253210547172)
,p_db_column_name=>'REPRESENTANTE_LEGAL'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Representante Legal'
,p_column_type=>'STRING'
,p_static_id=>'REPRESENTANTE_LEGAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633352716547173)
,p_db_column_name=>'CEDULA_REPRESENTANTE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Cedula Representante'
,p_column_type=>'STRING'
,p_static_id=>'CEDULA_REPRESENTANTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633460414547173)
,p_db_column_name=>'REGIMEN_IVA'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Regimen IVA'
,p_column_type=>'STRING'
,p_static_id=>'REGIMEN_IVA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633583308547174)
,p_db_column_name=>'GRAN_CONTRIBUYENTE'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Gran Contribuyente'
,p_column_type=>'STRING'
,p_static_id=>'GRAN_CONTRIBUYENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633662139547174)
,p_db_column_name=>'AUTORETENEDOR'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Autoretenedor'
,p_column_type=>'STRING'
,p_static_id=>'AUTORETENEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633763865547174)
,p_db_column_name=>'AFILIADO_DIAMANTE'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Afiliado Diamante'
,p_column_type=>'STRING'
,p_static_id=>'AFILIADO_DIAMANTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633856504547175)
,p_db_column_name=>'CONTACTO1'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Contacto 1'
,p_column_type=>'STRING'
,p_static_id=>'CONTACTO1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112633968297547175)
,p_db_column_name=>'CARGO_CONTACTO1'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Cargo Contacto 1'
,p_column_type=>'STRING'
,p_static_id=>'CARGO_CONTACTO1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112634057809547175)
,p_db_column_name=>'RELACION_CONTACTO1'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Relacion Contacto 1'
,p_column_type=>'STRING'
,p_static_id=>'RELACION_CONTACTO1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112634161809547176)
,p_db_column_name=>'CONTACTO2'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Contacto 2'
,p_column_type=>'STRING'
,p_static_id=>'CONTACTO2'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112634269004547176)
,p_db_column_name=>'CARGO_CONTACTO2'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Cargo Contacto 2'
,p_column_type=>'STRING'
,p_static_id=>'CARGO_CONTACTO2'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112634371939547176)
,p_db_column_name=>'RELACION_CONTACTO2'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Relacion Contacto 2'
,p_column_type=>'STRING'
,p_static_id=>'RELACION_CONTACTO2'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112634478510547176)
,p_db_column_name=>'CONTACTO3'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Contacto 3'
,p_column_type=>'STRING'
,p_static_id=>'CONTACTO3'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112634559122547178)
,p_db_column_name=>'CARGO_CONTACTO3'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Cargo Contacto 3'
,p_column_type=>'STRING'
,p_static_id=>'CARGO_CONTACTO3'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112634669533547178)
,p_db_column_name=>'RELACION_CONTACTO3'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Relacion Contacto 3'
,p_column_type=>'STRING'
,p_static_id=>'RELACION_CONTACTO3'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112883556622766299)
,p_db_column_name=>'PERSONA'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PERSONA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098671404941192135)
,p_db_column_name=>'PER_EMP_EMPRESA'
,p_display_order=>44
,p_column_identifier=>'AI'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_display_condition_type=>'FUNCTION_BODY'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :G_INS_COMPARTIDA = ''S''',
'THEN',
'RETURN true;',
'ELSE',
'RETURN false;',
'END IF;',
'END;'))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049846340513900147)
,p_db_column_name=>'FECHA_NACIMIENTO'
,p_display_order=>54
,p_column_identifier=>'AJ'
,p_column_label=>'Fecha nacimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD-MM-YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000673379218697961)
,p_db_column_name=>'PER_PAIS'
,p_display_order=>64
,p_column_identifier=>'AK'
,p_column_label=>'Pais'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000673493449697962)
,p_db_column_name=>'PER_PROVINCIA'
,p_display_order=>74
,p_column_identifier=>'AL'
,p_column_label=>'Provincia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000673512327697963)
,p_db_column_name=>'PER_CIUDAD'
,p_display_order=>84
,p_column_identifier=>'AM'
,p_column_label=>'Ciudad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000673620460697964)
,p_db_column_name=>'PER_ZONA'
,p_display_order=>94
,p_column_identifier=>'AN'
,p_column_label=>'Zona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13995908281227191162)
,p_db_column_name=>'CONDICION'
,p_display_order=>104
,p_column_identifier=>'AO'
,p_column_label=>'Condicion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001922549216738675)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>114
,p_column_identifier=>'AP'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956957692298175114)
,p_db_column_name=>'TIPO'
,p_display_order=>124
,p_column_identifier=>'AQ'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956957838503175115)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>134
,p_column_identifier=>'AR'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956957880261175116)
,p_db_column_name=>'ESTUDIANTE'
,p_display_order=>144
,p_column_identifier=>'AS'
,p_column_label=>'Estudiante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958009796175117)
,p_db_column_name=>'PROFESOR'
,p_display_order=>154
,p_column_identifier=>'AT'
,p_column_label=>'Profesor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958134973175118)
,p_db_column_name=>'EXPLICA_OTRO'
,p_display_order=>164
,p_column_identifier=>'AU'
,p_column_label=>'Explica Otro'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958184850175119)
,p_db_column_name=>'CORRESPONDENCIA'
,p_display_order=>174
,p_column_identifier=>'AV'
,p_column_label=>'Correspondencia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958353178175120)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>184
,p_column_identifier=>'AW'
,p_column_label=>'Creado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958374690175121)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>194
,p_column_identifier=>'AX'
,p_column_label=>'Fecha Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958518818175122)
,p_db_column_name=>'MODIFICADO_POR'
,p_display_order=>204
,p_column_identifier=>'AY'
,p_column_label=>'Modificado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958566845175123)
,p_db_column_name=>'FECHA_MODIFICACION'
,p_display_order=>214
,p_column_identifier=>'AZ'
,p_column_label=>'Fecha Modificacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958732970175124)
,p_db_column_name=>'CITA_REGISTRAL'
,p_display_order=>224
,p_column_identifier=>'BA'
,p_column_label=>'Cita Registral'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13956958773584175125)
,p_db_column_name=>'CR_TOMO'
,p_display_order=>234
,p_column_identifier=>'BB'
,p_column_label=>'Tomo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958102821898942776)
,p_db_column_name=>'CR_FOLIO'
,p_display_order=>244
,p_column_identifier=>'BC'
,p_column_label=>'Folio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958102931464942777)
,p_db_column_name=>'CR_ASIENTO'
,p_display_order=>254
,p_column_identifier=>'BD'
,p_column_label=>'Asiento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958102999780942778)
,p_db_column_name=>'DIGITO_VERIFICACION'
,p_display_order=>264
,p_column_identifier=>'BE'
,p_column_label=>'Digito Verificacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103146203942779)
,p_db_column_name=>'DOCUMENTO_NIT'
,p_display_order=>274
,p_column_identifier=>'BF'
,p_column_label=>'Documento Nit'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103212298942780)
,p_db_column_name=>'DOMINIO_FISCAL'
,p_display_order=>284
,p_column_identifier=>'BG'
,p_column_label=>'Dominio Fiscal'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103339123942781)
,p_db_column_name=>'GRADO_ACADEMICO'
,p_display_order=>294
,p_column_identifier=>'BH'
,p_column_label=>'Grado Academico'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103431387942782)
,p_db_column_name=>'PER_APELLIDO_SOLTERA_CASADA'
,p_display_order=>304
,p_column_identifier=>'BI'
,p_column_label=>'Apellido Soltera'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103531724942783)
,p_db_column_name=>'CLASE_SECTOR_ECONOMICO'
,p_display_order=>314
,p_column_identifier=>'BJ'
,p_column_label=>'Clase Sector Economico'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103648720942784)
,p_db_column_name=>'CONSECUTIVO'
,p_display_order=>324
,p_column_identifier=>'BK'
,p_column_label=>'Consecutivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103742263942785)
,p_db_column_name=>'TOMO2'
,p_display_order=>334
,p_column_identifier=>'BL'
,p_column_label=>'Tomo2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103829200942786)
,p_db_column_name=>'FOLIO2'
,p_display_order=>344
,p_column_identifier=>'BM'
,p_column_label=>'Folio2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103937295942787)
,p_db_column_name=>'ASIENTO2'
,p_display_order=>354
,p_column_identifier=>'BN'
,p_column_label=>'Asiento2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958103983463942788)
,p_db_column_name=>'TIPO_PACIENTE'
,p_display_order=>364
,p_column_identifier=>'BO'
,p_column_label=>'Tipo Paciente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958104165675942789)
,p_db_column_name=>'MEDICO'
,p_display_order=>374
,p_column_identifier=>'BP'
,p_column_label=>'Medico'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958104209430942790)
,p_db_column_name=>'DISTRITO'
,p_display_order=>384
,p_column_identifier=>'BQ'
,p_column_label=>'Distrito'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958104283688942791)
,p_db_column_name=>'ID_USUARIO'
,p_display_order=>394
,p_column_identifier=>'BR'
,p_column_label=>'Id Usuario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14112626859077530143)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118357'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'PERSONA:NOMBRE_COMPLETO:PROFESION:EMAIL:ACTIVIDAD:AFILIADO_DIAMANTE:APARTADO:AUTORETENEDOR:BANCO:CARGO_CONTACTO1:CARGO_CONTACTO2:CARGO_CONTACTO3:CEDULA:CEDULA_REPRESENTANTE:CLIENTE:CONTACTO1:CONTACTO2:CONTACTO3:DIRECCION:EMPLEADO:ESTADO_CIVIL:FAX:GRA'
||'N_CONTRIBUYENTE:NACIONALIDAD:OTRO:PROVEEDOR:REGIMEN_IVA:RELACION_CONTACTO1:RELACION_CONTACTO2:RELACION_CONTACTO3:REPRESENTANTE_LEGAL:SERVICIOS:SEXO:TELEFONOS::FECHA_NACIMIENTO:PER_PAIS:PER_PROVINCIA:PER_CIUDAD:PER_ZONA:CONDICION:OBSERVACIONES:TIPO:RA'
||'ZON_SOCIAL:ESTUDIANTE:PROFESOR:EXPLICA_OTRO:CORRESPONDENCIA:CREADO_POR:FECHA_CREACION:MODIFICADO_POR:FECHA_MODIFICACION:CITA_REGISTRAL:CR_TOMO:CR_FOLIO:CR_ASIENTO:DIGITO_VERIFICACION:DOCUMENTO_NIT:DOMINIO_FISCAL:GRADO_ACADEMICO:PER_APELLIDO_SOLTERA_C'
||'ASADA:CLASE_SECTOR_ECONOMICO:CONSECUTIVO:TOMO2:FOLIO2:ASIENTO2:TIPO_PACIENTE:MEDICO:DISTRITO:ID_USUARIO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14096917480895465117)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14096917179098465116)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096917922220465118)
,p_name=>'P56_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14096917179098465116)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_grid_column=>1
,p_display_when=>'G_INS_COMPARTIDA'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
