prompt --application/pages/page_00078
begin
--   Manifest
--     PAGE: 00078
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>78
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'INV - Ventas Perdidas'
,p_step_title=>'Ventas Perdidas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164510'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094529164806117173)
,p_plug_name=>'Ventas Perdidas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094509191550780220)
,p_plug_name=>'Ventas Perdidas'
,p_parent_plug_id=>wwv_flow_api.id(14094529164806117173)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 19/01/2017 01:14:13 p.m. (QP5 v5.115.810.9015) */',
'SELECT   VPE_ID,',
'         VPE_EMP_EMPRESA,',
'         VPE_ENC_CONSULTA,',
'         VPE_ENC_PEDIDO,',
'         TRUNC (VPE_FECHA) VPE_FECHA,',
'         VPE_LCN_LOCALIZACION,',
'         VPE_CLI_CLIENTE,',
'         ENC_LPO_LISTA,',
'         INV_DESCRIP_LISTA_V_NX (VPE_EMP_EMPRESA, ENC_LPO_LISTA) DESC_LISTA,',
'         VPE_CLI_MON_MONEDA,',
'         VPE_VEN_VENDEDOR,',
'         VPE_ATO_ARTICULO,',
'         (inv_precio_art_n_nx (VPE_EMP_EMPRESA,',
'                               ENC_LPO_LISTA,',
'                               VPE_ATO_ARTICULO,',
'                               NULL)',
'          * VPE_CANTIDAD_PEDIDA)',
'            PRECIO_TOTAL,',
'         VPE_CANTIDAD_PEDIDA, ',
'         VPE_CANTIDAD_DISPONIBLE,',
'         VPE_CANTIDAD_TOTAL,',
'         inv_costo_prom_art_n_nx (VPE_EMP_EMPRESA, VPE_ATO_ARTICULO)',
'            COSTO_UNITARIO,',
'         VPE_CANTIDAD_PERDIDA,',
'         (inv_costo_prom_art_n_nx (VPE_EMP_EMPRESA, VPE_ATO_ARTICULO)',
'          * VPE_CANTIDAD_PERDIDA)',
'            COSTO_TOTAL,',
'         VPE_CREADO_POR,',
'         TRUNC (VPE_FECHA_CREACION) VPE_FECHA_CREACION,',
'         VPE_MODIFICADO_POR,',
'         TRUNC (VPE_FECHA_MODIFICACION) VPE_FECHA_MODIFICACION         ',
'  FROM   inv_venta_perdida_tb_nx, fac_consulta_tb_nx',
' WHERE       INSTR ('':'' || :P78_EMPRESA || '':'',',
'                    '':'' || VPE_EMP_EMPRESA || '':'') > 0',
'         AND VPE_ENC_CONSULTA = ENC_CONSULTA',
'         AND VPE_EMP_EMPRESA = ENC_EMP_EMPRESA',
'         AND VPE_FECHA BETWEEN :P78_INICIO',
'                           AND  TO_DATE (:P78_FIN || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P78_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14094509287943780221)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>6765563171891127
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509397562780222)
,p_db_column_name=>'VPE_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509456963780223)
,p_db_column_name=>'VPE_EMP_EMPRESA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509580897780224)
,p_db_column_name=>'VPE_ENC_CONSULTA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Consulta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509700430780225)
,p_db_column_name=>'VPE_ENC_PEDIDO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509798720780226)
,p_db_column_name=>'VPE_FECHA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509920971780227)
,p_db_column_name=>'VPE_LCN_LOCALIZACION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094509965556780228)
,p_db_column_name=>'VPE_CLI_CLIENTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510036325780229)
,p_db_column_name=>'VPE_CLI_MON_MONEDA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510134553780230)
,p_db_column_name=>'VPE_VEN_VENDEDOR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510246991780231)
,p_db_column_name=>'VPE_ATO_ARTICULO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510366748780232)
,p_db_column_name=>'VPE_CANTIDAD_PEDIDA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Cantidad Pedida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510519148780233)
,p_db_column_name=>'VPE_CANTIDAD_DISPONIBLE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Cantidad Disponible'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510572594780234)
,p_db_column_name=>'VPE_CANTIDAD_PERDIDA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Cantidad Perdida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510685278780235)
,p_db_column_name=>'VPE_CREADO_POR'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Creado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510786297780236)
,p_db_column_name=>'VPE_FECHA_CREACION'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fecha Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510843878780237)
,p_db_column_name=>'VPE_MODIFICADO_POR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Modificado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094510989361780238)
,p_db_column_name=>'VPE_FECHA_MODIFICACION'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fecha Modificacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900326673642711)
,p_db_column_name=>'ENC_LPO_LISTA'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900515777642712)
,p_db_column_name=>'DESC_LISTA'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Desc. Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900588300642713)
,p_db_column_name=>'COSTO_UNITARIO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Costo unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P78_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900649356642714)
,p_db_column_name=>'COSTO_TOTAL'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Costo total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P78_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900727958642715)
,p_db_column_name=>'PRECIO_TOTAL'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Precio total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082456083369111860)
,p_db_column_name=>'VPE_CANTIDAD_TOTAL'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Cantidad Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14094544857254134053)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'68012'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VPE_ID:VPE_EMP_EMPRESA:VPE_ENC_CONSULTA:VPE_ENC_PEDIDO:VPE_FECHA:VPE_LCN_LOCALIZACION:VPE_CLI_CLIENTE:VPE_CLI_MON_MONEDA:VPE_VEN_VENDEDOR:VPE_ATO_ARTICULO:ENC_LPO_LISTA:DESC_LISTA:VPE_CANTIDAD_PEDIDA:VPE_CANTIDAD_DISPONIBLE:VPE_CANTIDAD_PERDIDA:VPE_C'
||'ANTIDAD_TOTAL:COSTO_UNITARIO:COSTO_TOTAL:PRECIO_TOTAL:VPE_CREADO_POR:VPE_FECHA_CREACION:VPE_MODIFICADO_POR:VPE_FECHA_MODIFICACION:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14094529550593117174)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14094529164806117173)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094529963419117181)
,p_name=>'P78_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14094529164806117173)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098021122044823200)
,p_name=>'P78_INICIO'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14094529164806117173)
,p_prompt=>'Inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'RETURN TRUNC (SYSDATE, ''MM'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098021410902824815)
,p_name=>'P78_FIN'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14094529164806117173)
,p_prompt=>'Fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'SYSDATE'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098472607609088184)
,p_name=>'P78_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14094529164806117173)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE       use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14094535285432117194)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'genera_reporte_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 19/07/2016 03:32:10 p.m. (QP5 v5.115.810.9015) */',
'DECLARE',
'   CURSOR hoj',
'   IS',
'      SELECT hcj_emp_empresa hcj_empresa,',
'             hcj_hoja_caja hcj_hoja,',
'             hcj_fecha_hoja hcj_fecha,',
'             hcj_dep_departamento hcj_departamento,',
'             hcj_caj_caja hcj_caja,',
'             DECODE (hcj_status,',
'                ''C'', ''Creado'',',
'                ''A'', ''Aprobada'',',
'                ''L'', ''Liquidada'',',
'                ''Sin Definir'')',
'                hcj_estado,',
'             HCJ_UCJ_USER_ID hcj_cajero,',
'             GNL_USERNAME_V_NX(HCJ_UCJ_USER_ID) hcj_nombre',
'      FROM kje_hoja_caja_tb_nx',
'      WHERE     hcj_emp_empresa = :P78_EMPRESA',
'            AND hcj_status NOT IN (''C'', ''L'');',
'',
'   CURSOR liquidacion (empresa_c IN varchar2, hoja_c IN number',
'   )',
'   IS',
'      SELECT kcl_mon_moneda moneda,',
'             SUM (kcl_monto) efectivo,',
'             SUM (kcl_traslados) traslados',
'      FROM kje_calculo_liquidacion_tb_nx',
'      WHERE     kcl_emp_empresa = empresa_c',
'            AND kcl_hcj_hoja_caja = hoja_c',
'            AND kcl_mpg_modo IN (''E'', ''G'')',
'      GROUP BY kcl_mon_moneda;',
'',
'   cierre_alt_v   kje_transaccion_tb_nx.trk_monto%TYPE;',
'   total_alt_v    kje_traslados_tb_nx.tkj_monto%TYPE;',
'   cierre_crc_v   kje_transaccion_tb_nx.trk_monto%TYPE;',
'   total_crc_v    kje_traslados_tb_nx.tkj_monto%TYPE;',
'   mon_base_v     gnl_moneda_tr_nx.moneda%TYPE;',
'   mon_alt_v      gnl_moneda_tr_nx.moneda%TYPE;',
'BEGIN',
'   mon_base_v   := gnl_parametro_emp_v_nx (:P78_EMPRESA, ''CGL'', ''MONEDA'');',
'   mon_alt_v    :=',
'      gnl_parametro_emp_v_nx (:P78_EMPRESA, ''GNL'', ''MONEDA CONVERSION'');',
'   apex_collection.create_or_truncate_collection (''HOJA_CAJA'');',
'',
'   FOR h IN hoj',
'   LOOP',
'      kje_calculo_liquidacion_pr_nx (h.hcj_empresa, h.hcj_hoja);',
'      cierre_alt_v   := 0;',
'      total_alt_v    := 0;',
'      cierre_crc_v   := 0;',
'      total_crc_v    := 0;',
'',
'      FOR liq IN liquidacion (h.hcj_empresa, h.hcj_hoja)',
'      LOOP',
'         IF liq.moneda = mon_base_v',
'         THEN',
'            cierre_crc_v   :=',
'               kje_monto_hoja_n_nx (h.hcj_empresa,',
'                                    h.hcj_hoja,',
'                                    liq.moneda,',
'                                    ''C''',
'               );',
'            total_crc_v   :=',
'               (liq.efectivo + liq.traslados) - NVL (cierre_crc_v, 0);',
'         ELSIF liq.moneda = mon_alt_v',
'         THEN',
'            cierre_alt_v   :=',
'               kje_monto_hoja_n_nx (h.hcj_empresa,',
'                                    h.hcj_hoja,',
'                                    liq.moneda,',
'                                    ''C''',
'               );',
'            total_alt_v   :=',
'               (liq.efectivo + liq.traslados) - NVL (cierre_alt_v, 0);',
'         END IF;',
'      END LOOP;',
'',
'      apex_collection.add_member (''HOJA_CAJA'',',
'                                  h.hcj_hoja,',
'                                  h.hcj_fecha,',
'                                  h.hcj_departamento,',
'                                  h.hcj_caja,',
'                                  h.hcj_estado,',
'                                  h.hcj_cajero,',
'                                  h.hcj_nombre,',
'                                  to_char(total_crc_v, ''999G999G999G990D99''),',
'                                  to_char(total_alt_v, ''999G999G999G990D99'')',
'      );',
'   END LOOP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
