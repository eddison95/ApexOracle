prompt --application/pages/page_00035
begin
--   Manifest
--     PAGE: 00035
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>35
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('FAC \2013 Notas de Credito')
,p_step_title=>'Notas de Credito'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201210093146'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167861019273791521)
,p_plug_name=>'Notas de Credito'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167858918670728457)
,p_plug_name=>'Notas de Credito'
,p_parent_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 11/03/2018 12:03:24 a.m. (QP5 v5.115.810.9015) */',
'/* Formatted on 10/03/2018 11:46:08 p.m. (QP5 v5.115.810.9015) */',
'SELECT   ncd_emp_empresa empresa,',
'         ncd_transaccion transaccion,',
'         ncd_nota nota,',
'         tra_factura factura,',
'         DECODE (ncd_status,',
'                 ''C'',',
'                 ''CREADA'',',
'                 ''R'',',
'                 ''RECHAZADA'',',
'                 ''A'',',
'                 ''AUTORIZADA'',',
'                 ''P'',',
'                 ''PROCESADA'')',
'            estado,',
'         tra_ord_orden orden_taller,',
'         TRUNC (ncd_fecha) fecha,',
'         ncd_dep_departamento depto,',
'         cgl_nombre_depto_v_nx (ncd_emp_empresa, ncd_dep_departamento)',
'            departamento,',
'         ncd_lcn_localizacion localizacion,',
'         inv_descrip_loca_v_nx (tra_emp_empresa, tra_lcn_localizacion)',
'            desc_localizacion,',
'         ncd_mon_moneda cod_moneda,',
'         ncd_valor_cambio t_cambio,',
'         tra_lpo_lista lista,',
'         tra_ven_vendedor cod_vendedor,',
'         gnl_nombre_vendedor_vi (ncd_emp_empresa, tra_ven_vendedor) vendedor,',
'         tra_cli_cliente cliente,',
'         tra_cedula cedula,',
'         tra_nombre nombre,',
'         DECODE (ncd_tipo,',
'                 ''1'',',
'                 ''TOTAL'',',
'                 ''2'',',
'                 ''PARCIAL B.E'',',
'                 ''3'',',
'                 ''PARCIAL M.E'',',
'                 ''4'',',
'                 ''DIFERENCIA DESC'',',
'                 ''5'',',
'                 ''DIFERENCIA PREC'',',
'                 ''6'',',
'                 ''NOTA ESP'')',
'            tipo_nota,',
'         DECODE (tra_tipo,',
'                 ''CON'',',
'                 ''CONTADO'',',
'                 ''CRE'',',
'                 ''CREDITO'',',
'                 ''FIN'',',
'                 ''FINANCIAMIENTO'',',
'                 ''NIT'',',
'                 ''NOTA INTERNA'')',
'            tipo_fact,',
'         tra_ttr_tipo tipo_tra_fac,',
'         ncd_ttr_tipo tipo_tra_nc,',
'         tra_doc_documento documento,',
'         CASE',
'            WHEN (:p35_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (dnc_descuento)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (dnc_descuento)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (dnc_descuento)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (dnc_descuento)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'               / ncd_valor_cambio',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (dnc_descuento)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'               * ncd_valor_cambio',
'         END',
'            descuento,',
'         CASE',
'            WHEN (:p35_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (dnc_impuesto_ventas)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (dnc_impuesto_ventas)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (dnc_impuesto_ventas)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (dnc_impuesto_ventas)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'               / ncd_valor_cambio',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (dnc_impuesto_ventas)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'               * ncd_valor_cambio',
'         END',
'            impto,',
'         CASE',
'            WHEN (:p35_moneda = ''ND'')',
'            THEN',
'               a.ncd_monto',
'            WHEN (a.ncd_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda = ''L'')',
'            THEN',
'               a.ncd_monto',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda = ''A'')',
'            THEN',
'               a.ncd_monto',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda <> ''L'')',
'            THEN',
'               a.ncd_monto / a.ncd_valor_cambio',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda <> ''A'')',
'            THEN',
'               a.ncd_monto * a.ncd_valor_cambio',
'         END',
'            total,',
'         CASE',
'            WHEN (:p35_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (dnc_costo_local_fiscal)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (dnc_costo_local_fiscal)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (dnc_costo_alterno_fiscal)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (dnc_costo_alterno_fiscal)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (dnc_costo_local_fiscal)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   dnc_ncd_transaccion = a.ncd_transaccion)',
'         END',
'            costo_total,',
'         AUTORIZADO_POR,',
'         NCD_ANULACION,',
'         CASE NCD_TIPO',
'            WHEN 1 THEN ''Total''',
'            WHEN 2 THEN ''Parcial Buen Estado''',
'            WHEN 3 THEN ''Parcial Mal Estado''',
'            WHEN 4 THEN ''Diferencia Descuento''',
'            WHEN 5 THEN ''Diferencia Precio''',
'            WHEN 6 THEN ''Nota Especial''',
'            ELSE ''Sin Definir''',
'         END',
'            NCD_TIPO,',
'         NCD_COMPROBANTE_ELECTRONICO comp_elect,',
'         TRA_COMPROBANTE_ELECTRONICO comp_elect_fac,',
'         CASE',
'            WHEN (:p35_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (dnc_monto - dnc_descuento)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   (DNC_IMPUESTO_VENTAS = 0 AND DNC_OTROS_IMPUESTOS = 0)',
'                         AND DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'            WHEN (a.ncd_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (dnc_monto - dnc_descuento)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   (DNC_IMPUESTO_VENTAS = 0 AND DNC_OTROS_IMPUESTOS = 0)',
'                         AND DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (dnc_monto - dnc_descuento)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   (DNC_IMPUESTO_VENTAS = 0 AND DNC_OTROS_IMPUESTOS = 0)',
'                         AND DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (dnc_monto - dnc_descuento) / ncd_valor_cambio',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   (DNC_IMPUESTO_VENTAS = 0 AND DNC_OTROS_IMPUESTOS = 0)',
'                         AND DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (dnc_monto - dnc_descuento) * a.ncd_valor_cambio',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   (DNC_IMPUESTO_VENTAS = 0 AND DNC_OTROS_IMPUESTOS = 0)',
'                         AND DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'         END',
'            exento,',
'         (SELECT   Z.DESCRIPCION',
'            FROM   GNL_PERSONA_TR_NX P, GNL_ZONA_TR_NX Z, CXC_CLIENTE_TB_NX',
'           WHERE       P.ZON_ZONA = Z.ZONA',
'                   AND CLI_PER_PERSONA = PERSONA',
'                   AND CLI_CLIENTE = NCD_CLI_CLIENTE',
'                   AND CLI_MON_MONEDA = NCD_CLI_MON_MONEDA',
'                   AND CLI_EMP_EMPRESA = NCD_CLI_EMP_EMPRESA)',
'            ZONA,',
'         CASE',
'            WHEN (:p35_moneda = ''ND'')',
'            THEN',
'               (SELECT   SUM (DNC_MONTO)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'            WHEN (a.ncd_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda = ''L'')',
'            THEN',
'               (SELECT   SUM (DNC_MONTO)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda = ''A'')',
'            THEN',
'               (SELECT   SUM (DNC_MONTO)',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'            WHEN (ncd_mon_moneda = :P35_LOCAL AND :p35_moneda <> ''L'')',
'            THEN',
'               (SELECT   SUM (DNC_MONTO) / ncd_valor_cambio',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'            WHEN (ncd_mon_moneda = :P35_ALTERNA AND :p35_moneda <> ''A'')',
'            THEN',
'               (SELECT   SUM (DNC_MONTO) * a.ncd_valor_cambio',
'                  FROM   fac_detalle_nota_cr_db_tb_nx',
'                 WHERE   DNC_EMP_EMPRESA = NCD_EMP_EMPRESA',
'                         AND DNC_NCD_TRANSACCION = NCD_TRANSACCION)',
'         END',
'            SUBTOTAL,',
'            ncd_observaciones observaciones',
'  FROM   fac_notas_cr_db_tb_nx a,',
'         fac_factura_nota_tb_nx b,',
'         fac_factura_tb_nx c',
' WHERE       ncd_status NOT IN (''C'', ''R'')',
'         AND a.ncd_transaccion = b.fnt_ncd_transaccion',
'         AND b.fnt_tra_transaccion = c.tra_transaccion',
'         AND INSTR ('':'' || :p35_empresa || '':'',',
'                    '':'' || a.ncd_emp_empresa || '':'') > 0',
'         AND ncd_transaccion = NVL(:P35_TRANSACCION, ncd_transaccion)',
'         AND ncd_fecha BETWEEN :p35_inicio',
'                           AND  TO_DATE (:p35_fin || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P35_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14167859011050728457)
,p_name=>unistr('Reporte de Notas de Cr\00E9dito')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:RP:P35_TRANSACCION:#TRANSACCION#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10745117639229157
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167859203470728468)
,p_db_column_name=>'TRANSACCION'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167859318639728473)
,p_db_column_name=>'COD_MONEDA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'COD_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167859719958728474)
,p_db_column_name=>'DEPTO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_static_id=>'DEPTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167859817555728475)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
,p_static_id=>'DEPARTAMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167859901324728475)
,p_db_column_name=>'COD_VENDEDOR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'COD_VENDEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167860025806728476)
,p_db_column_name=>'VENDEDOR'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'VENDEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167860114971728476)
,p_db_column_name=>'NOTA'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'NOTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167860203922728477)
,p_db_column_name=>'FACTURA'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'FACTURA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167860424745728477)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
,p_static_id=>'LOCALIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167860621990728478)
,p_db_column_name=>'FECHA'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167860797637728479)
,p_db_column_name=>'IMPTO'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'IMPTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168014407658105898)
,p_db_column_name=>'COSTO_TOTAL'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'COSTO_TOTAL'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P35_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14113167683459558696)
,p_db_column_name=>'ORDEN_TALLER'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Orden Taller'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ORDEN_TALLER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098103434924802525)
,p_db_column_name=>'EMPRESA'
,p_display_order=>30
,p_column_identifier=>'U'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098103622486802526)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'V'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098103641574802527)
,p_db_column_name=>'DESC_LOCALIZACION'
,p_display_order=>50
,p_column_identifier=>'W'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098103783425802528)
,p_db_column_name=>'T_CAMBIO'
,p_display_order=>60
,p_column_identifier=>'X'
,p_column_label=>'T. Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098103899493802529)
,p_db_column_name=>'LISTA'
,p_display_order=>70
,p_column_identifier=>'Y'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098103965002802530)
,p_db_column_name=>'CLIENTE'
,p_display_order=>80
,p_column_identifier=>'Z'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098104105447802531)
,p_db_column_name=>'CEDULA'
,p_display_order=>90
,p_column_identifier=>'AA'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098104136065802532)
,p_db_column_name=>'NOMBRE'
,p_display_order=>100
,p_column_identifier=>'AB'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098104328454802534)
,p_db_column_name=>'TIPO_FACT'
,p_display_order=>120
,p_column_identifier=>'AD'
,p_column_label=>'T. Factura'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098104618163802536)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>140
,p_column_identifier=>'AF'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098104642182802537)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>150
,p_column_identifier=>'AG'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098104751417802538)
,p_db_column_name=>'TOTAL'
,p_display_order=>160
,p_column_identifier=>'AH'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098104899122802539)
,p_db_column_name=>'TIPO_NOTA'
,p_display_order=>170
,p_column_identifier=>'AI'
,p_column_label=>'T. Nota'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099851459381974207)
,p_db_column_name=>'AUTORIZADO_POR'
,p_display_order=>180
,p_column_identifier=>'AJ'
,p_column_label=>'Autorizado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099851576327974208)
,p_db_column_name=>'NCD_ANULACION'
,p_display_order=>190
,p_column_identifier=>'AK'
,p_column_label=>'Anulacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099851661936974209)
,p_db_column_name=>'NCD_TIPO'
,p_display_order=>200
,p_column_identifier=>'AL'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082965638464390306)
,p_db_column_name=>'TIPO_TRA_FAC'
,p_display_order=>210
,p_column_identifier=>'AM'
,p_column_label=>'Tipo Tra FAC'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082965776079390307)
,p_db_column_name=>'TIPO_TRA_NC'
,p_display_order=>220
,p_column_identifier=>'AN'
,p_column_label=>'Tipo Tra NC'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084691545821360968)
,p_db_column_name=>'COMP_ELECT'
,p_display_order=>230
,p_column_identifier=>'AO'
,p_column_label=>unistr('Comprobante electr\00F3nico ')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084691917732360971)
,p_db_column_name=>'COMP_ELECT_FAC'
,p_display_order=>240
,p_column_identifier=>'AP'
,p_column_label=>'Comp elect fac'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084692493327360977)
,p_db_column_name=>'EXENTO'
,p_display_order=>250
,p_column_identifier=>'AQ'
,p_column_label=>'Exento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084692538512360978)
,p_db_column_name=>'ZONA'
,p_display_order=>260
,p_column_identifier=>'AR'
,p_column_label=>'Zona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084692776280360980)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>270
,p_column_identifier=>'AS'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14023995568840493049)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>280
,p_column_identifier=>'AT'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14167862314340809002)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'107485'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:TRANSACCION:NOTA:FACTURA:COMP_ELECT:ESTADO:ORDEN_TALLER:FECHA:DEPTO:DEPARTAMENTO:LOCALIZACION:DESC_LOCALIZACION:COD_MONEDA:T_CAMBIO:LISTA:COD_VENDEDOR:VENDEDOR:CLIENTE:CEDULA:NOMBRE:ZONA:TIPO_NOTA:TIPO_FACT:DOCUMENTO:SUBTOTAL:EXENTO:DESCUENTO'
||':IMPTO:TOTAL:AUTORIZADO_POR:NCD_ANULACION:NCD_TIPO:TIPO_TRA_FAC:TIPO_TRA_NC:COMP_ELECT_FAC::OBSERVACIONES'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(14167862993880926074)
,p_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_api.id(14167858918670728457)
,p_template=>wwv_flow_api.id(13960797068045591914)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 20/01/2017 10:31:40 a.m. (QP5 v5.115.810.9015) */',
'SELECT   ncd_lcn_localizacion localizacion,',
'         inv_descrip_loca_v_nx (ncd_emp_empresa, ncd_lcn_localizacion)',
'            desc_localizacion,',
'         dnc_ato_articulo articulo,',
'         inv_descrip_art_v_nx (dnc_emp_empresa, dnc_ato_articulo) descripcion,',
'         inv_familia_art_v_nx (dnc_emp_empresa, dnc_ato_articulo)',
'            codigo_familia,',
'         inv_desc_fam_art_v_nx (dnc_emp_empresa, dnc_ato_articulo) familia,',
'         inv_obt_clasif_prin_art_v_nx (dnc_emp_empresa, dnc_ato_articulo)',
'            tipoarticulo,',
'         DNC_CANTIDAD,',
'         DNC_PRECIO_LOCAL precio_unitario,',
'         DNC_PRECIO_LOCAL * DNC_CANTIDAD subtotal,',
'         DNC_DESCUENTO descuento,',
'         (DNC_PRECIO_LOCAL * DNC_CANTIDAD) * (DNC_IMPUESTO_VENTAS / 100)',
'            impuesto,',
'         (DNC_PRECIO_LOCAL * DNC_CANTIDAD) * (DNC_OTROS_IMPUESTOS / 100)',
'            otros_impuestos,',
'         --DES_TOTAL,',
'         DNC_COSTO_LOCAL_FISCAL,',
'         DNC_COSTO_ALTERNO_FISCAL',
'  FROM   fac_notas_cr_db_tb_nx a,',
'         fac_factura_nota_tb_nx b,',
'         fac_factura_tb_nx c,',
'         fac_detalle_nota_cr_db_tb_nx d',
' WHERE       ncd_status NOT IN (''C'', ''R'')',
'         AND a.ncd_transaccion = b.fnt_ncd_transaccion',
'         AND b.fnt_tra_transaccion = c.tra_transaccion',
'         AND a.ncd_transaccion = d.dnc_ncd_transaccion',
'         AND a.ncd_transaccion = :p35_transaccion',
'UNION ALL',
'SELECT   ncd_lcn_localizacion localizacion,',
'         inv_descrip_loca_v_nx (ncd_emp_empresa, ncd_lcn_localizacion)',
'            desc_localizacion,',
'         TO_CHAR (dns_ser_consecutivo) articulo,',
'         tal_desc_servicio_v_nx (dns_emp_empresa, dns_ser_consecutivo)',
'            descripcion,',
'         tal_familia_servicio_v_nx (dns_emp_empresa, dns_ser_consecutivo)',
'            codigo_familia,',
'         inv_descrip_fam_v_nx (',
'            dns_emp_empresa,',
'            tal_familia_servicio_v_nx (dns_emp_empresa, dns_ser_consecutivo)',
'         )',
'            familia,',
'         NULL tipoarticulo,',
'         dns_cantidad cantidad,',
'         DNS_PRECIO_LOCAL precio_unitario,',
'         DNS_PRECIO_LOCAL * DNS_CANTIDAD subtotal,',
'         DNS_DESCUENTO descuento,',
'         (DNS_PRECIO_LOCAL * DNS_CANTIDAD) * (DNS_IMPUESTO_VENTAS / 100) impuesto,',
'         (DNS_PRECIO_LOCAL * DNS_CANTIDAD) * (DNS_OTROS_IMPUESTOS / 100)',
'            otros_impuestos,',
'         --DES_TOTAL,',
'         DNS_COSTO_LOCAL_FISCAL,',
'         DNS_COSTO_ALTERNO_FISCAL',
'  FROM   fac_notas_cr_db_tb_nx a,',
'         fac_factura_nota_tb_nx b,',
'         fac_factura_tb_nx c,',
'         fac_detalle_nota_serv_tb_nx d',
' WHERE       ncd_status NOT IN (''C'', ''R'')',
'         AND a.ncd_transaccion = b.fnt_ncd_transaccion',
'         AND b.fnt_tra_transaccion = c.tra_transaccion',
'         AND a.ncd_transaccion = d.dns_ncd_transaccion',
'         AND a.ncd_transaccion = :p35_transaccion'))
,p_display_when_condition=>'P35_TRANSACCION'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_footer=>'</div>'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(13960822795309591924)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167864618808926090)
,p_query_column_id=>1
,p_column_alias=>'LOCALIZACION'
,p_column_display_sequence=>1
,p_column_heading=>'Localizacion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14098105221457802542)
,p_query_column_id=>2
,p_column_alias=>'DESC_LOCALIZACION'
,p_column_display_sequence=>2
,p_column_heading=>'Desc. Localizacion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167864904516926090)
,p_query_column_id=>3
,p_column_alias=>'ARTICULO'
,p_column_display_sequence=>3
,p_column_heading=>'Articulo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167865022951926091)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>4
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167865108074926091)
,p_query_column_id=>5
,p_column_alias=>'CODIGO_FAMILIA'
,p_column_display_sequence=>5
,p_column_heading=>'Familia'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167865225049926091)
,p_query_column_id=>6
,p_column_alias=>'FAMILIA'
,p_column_display_sequence=>6
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167865326027926091)
,p_query_column_id=>7
,p_column_alias=>'TIPOARTICULO'
,p_column_display_sequence=>7
,p_column_heading=>'T. ARTICULO'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14098105312469802543)
,p_query_column_id=>8
,p_column_alias=>'DNC_CANTIDAD'
,p_column_display_sequence=>8
,p_column_heading=>'Cantidad'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14098105357949802544)
,p_query_column_id=>9
,p_column_alias=>'PRECIO_UNITARIO'
,p_column_display_sequence=>9
,p_column_heading=>'Precio Unitario'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14098165245558480995)
,p_query_column_id=>10
,p_column_alias=>'SUBTOTAL'
,p_column_display_sequence=>10
,p_column_heading=>'Subtotal'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167865721240926091)
,p_query_column_id=>11
,p_column_alias=>'DESCUENTO'
,p_column_display_sequence=>11
,p_column_heading=>'Descuento'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14167865905720926091)
,p_query_column_id=>12
,p_column_alias=>'IMPUESTO'
,p_column_display_sequence=>12
,p_column_heading=>'Impuestos'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14098165415894480996)
,p_query_column_id=>13
,p_column_alias=>'OTROS_IMPUESTOS'
,p_column_display_sequence=>13
,p_column_heading=>'Otros Impuestos'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14098165426555480997)
,p_query_column_id=>14
,p_column_alias=>'DNC_COSTO_LOCAL_FISCAL'
,p_column_display_sequence=>14
,p_column_heading=>'Costo Local'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_when_condition=>'P35_AUTO_CCA'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(14098165536007480998)
,p_query_column_id=>15
,p_column_alias=>'DNC_COSTO_ALTERNO_FISCAL'
,p_column_display_sequence=>15
,p_column_heading=>'Costo Alterno'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_when_condition=>'P35_AUTO_CCA'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168164095610596511)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14112853462405502980)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14167858918670728457)
,p_button_name=>'RESTABLECER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Restablecer'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:RP,35::'
,p_button_condition=>'P35_TRANSACCION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966309872106995417)
,p_name=>'P35_LOCAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P35_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   FROM DUAL',
'connect by regexp_substr(:P35_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966309929087995418)
,p_name=>'P35_ALTERNA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P35_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )   FROM DUAL',
'connect by regexp_substr(:P35_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098455722260602091)
,p_name=>'P35_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE       use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167861216046791564)
,p_name=>'P35_TRANSACCION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167861426170791585)
,p_name=>'P35_INICIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167861595913791585)
,p_name=>'P35_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167861816893791586)
,p_name=>'P35_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168118896467493163)
,p_name=>'P35_MONEDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14167861019273791521)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MONEDA'
,p_lov=>'.'||wwv_flow_api.id(13966336081955007059)||'.'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966307512306995394)
,p_validation_name=>'MONEDA_EMPRESAS'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P35_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P35_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P35_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P35_EMPRESA,''[^:]+'', 1, level) is not null;',
'     ',
'        ',
'IF (cantidad_local_v > 1 AND :P35_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
' ',
'IF (cantidad_alt_v > 1 AND :P35_MONEDA = ''A'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_api.id(14168164095610596511)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
