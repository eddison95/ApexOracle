prompt --application/pages/page_00130
begin
--   Manifest
--     PAGE: 00130
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>130
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GAC-Informe de Asistencia de Estudiantes'
,p_step_title=>'Informe de Asistencia de Estudiantes'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165313'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14127678053824625675)
,p_plug_name=>'Informe de asistencia de estudiantes por curso del profesor'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14127676073342625578)
,p_plug_name=>'Informe asistencia de estudiantes por curso del profesor'
,p_region_name=>'Informe de Asistencia'
,p_parent_plug_id=>wwv_flow_api.id(14127678053824625675)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 24/04/2018 05:52:14 p.m. (QP5 v5.115.810.9015) */',
'SELECT   DAP_OAC_ULA_ANTIGUEDAD AS Generacion,',
'         DAP_ESTADO AS Condicion,',
'         APA_ATO_ARTICULO AS Codigo,',
'         ATO_DESCRIPCION AS Descripcion,',
'         RAZON_SOCIAL AS Estudiante,',
'         DPA_SEMANA1 AS Semana1,',
'         DPA_SEMANA2 AS Semana2,',
'         DPA_SEMANA3 AS Semana3,',
'         DPA_SEMANA4 AS Semana4,',
'         DPA_SEMANA5 AS Semana5,',
'         DPA_SEMANA6 AS Semana6,',
'         DPA_SEMANA7 AS Semana7,',
'         DPA_SEMANA8 AS Semana8,',
'         DPA_SEMANA9 AS Semana9,',
'         DPA_SEMANA10 AS Semana10,',
'         DPA_SEMANA11 AS Semana11,',
'         DPA_SEMANA12 AS Semana12,',
'         DPA_SEMANA13 AS Semana13,',
'         DPA_SEMANA14 AS Semana14,',
'         DPA_SEMANA15 AS Semana15,',
'         DPA_SEMANA16 AS Semana16,',
'         DPA_SEMANA17 AS Semana17,',
'         DPA_SEMANA18 AS Semana18,',
'         DPA_SEMANA19 AS Semana19,',
'         DPA_SEMANA20 AS Semana20,',
'         persona,',
'         (SELECT   pai_nombre',
'            FROM   gnl_pais_tb_nx',
'           WHERE   PAI_PAIS = per.PAI_PAIS)',
'            pais,',
'         EMAIL,',
'         TELEFONO1 || '' '' || TELEFONO2 telefono,',
'         (SELECT   PFE_DESCRIPCION',
'            FROM   GNL_PROFESION_TB_NX',
'           WHERE   pfe_profesion = per.PFE_PROFESION) profesion',
'  FROM   INV_ARTICULO_TB_NX,',
'         GAC_ADMI_PROFESORES_TB_NX,',
'         GAC_DET_ADMI_PROFESORES_TB_NX,',
'         GAC_ADMI_PROFE_ASIS_TB_NX,',
'         GAC_ADMI_PROFE_DET_ASIS_TB_NX,',
'         GNL_PERSONA_TR_NX per',
' WHERE       INSTR ('':'' || :P130_EMPRESA || '':'',',
'                    '':'' || DAP_EMP_EMPRESA || '':'') > 0',
'         AND INSTR ('':'' || :P130_PROFESORES || '':'', '':'' || GAP_ID || '':'') > 0',
'         AND DAP_GAP_ID = GAP_ID',
'         AND APA_DAP_ID = DAP_ID',
'         AND DPA_APA_ID = APA_ID',
'         AND DPA_PERSONA = persona',
'         AND DAP_DOA_ATO_ARTICULO = APA_ATO_ARTICULO',
'         AND APA_ATO_ARTICULO = ATO_ARTICULO'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P130_EMPRESA'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14127676273862625586)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>64656543422409327
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066850086880369372)
,p_db_column_name=>'GENERACION'
,p_display_order=>130
,p_column_identifier=>'DQ'
,p_column_label=>'Generacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066850484448369373)
,p_db_column_name=>'CONDICION'
,p_display_order=>150
,p_column_identifier=>'DS'
,p_column_label=>'Condicion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066847230683369360)
,p_db_column_name=>'CODIGO'
,p_display_order=>160
,p_column_identifier=>'DT'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066847632921369365)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>170
,p_column_identifier=>'DU'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812086143758177)
,p_db_column_name=>'ESTUDIANTE'
,p_display_order=>180
,p_column_identifier=>'EA'
,p_column_label=>'Estudiante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812221662758178)
,p_db_column_name=>'SEMANA1'
,p_display_order=>190
,p_column_identifier=>'EB'
,p_column_label=>'Semana1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812237120758179)
,p_db_column_name=>'SEMANA2'
,p_display_order=>200
,p_column_identifier=>'EC'
,p_column_label=>'Semana2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812356864758180)
,p_db_column_name=>'SEMANA3'
,p_display_order=>210
,p_column_identifier=>'ED'
,p_column_label=>'Semana3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812451029758181)
,p_db_column_name=>'SEMANA4'
,p_display_order=>220
,p_column_identifier=>'EE'
,p_column_label=>'Semana4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812556264758182)
,p_db_column_name=>'SEMANA5'
,p_display_order=>230
,p_column_identifier=>'EF'
,p_column_label=>'Semana5'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812635724758183)
,p_db_column_name=>'SEMANA6'
,p_display_order=>240
,p_column_identifier=>'EG'
,p_column_label=>'Semana6'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812792850758184)
,p_db_column_name=>'SEMANA7'
,p_display_order=>250
,p_column_identifier=>'EH'
,p_column_label=>'Semana7'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812839257758185)
,p_db_column_name=>'SEMANA8'
,p_display_order=>260
,p_column_identifier=>'EI'
,p_column_label=>'Semana8'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066812964795758186)
,p_db_column_name=>'SEMANA9'
,p_display_order=>270
,p_column_identifier=>'EJ'
,p_column_label=>'Semana9'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813074175758187)
,p_db_column_name=>'SEMANA10'
,p_display_order=>280
,p_column_identifier=>'EK'
,p_column_label=>'Semana10'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813203865758188)
,p_db_column_name=>'SEMANA11'
,p_display_order=>290
,p_column_identifier=>'EL'
,p_column_label=>'Semana11'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813325794758189)
,p_db_column_name=>'SEMANA12'
,p_display_order=>300
,p_column_identifier=>'EM'
,p_column_label=>'Semana12'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813368682758190)
,p_db_column_name=>'SEMANA13'
,p_display_order=>310
,p_column_identifier=>'EN'
,p_column_label=>'Semana13'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813512264758191)
,p_db_column_name=>'SEMANA14'
,p_display_order=>320
,p_column_identifier=>'EO'
,p_column_label=>'Semana14'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813600564758192)
,p_db_column_name=>'SEMANA15'
,p_display_order=>330
,p_column_identifier=>'EP'
,p_column_label=>'Semana15'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813700218758193)
,p_db_column_name=>'SEMANA16'
,p_display_order=>340
,p_column_identifier=>'EQ'
,p_column_label=>'Semana16'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813814571758194)
,p_db_column_name=>'SEMANA17'
,p_display_order=>350
,p_column_identifier=>'ER'
,p_column_label=>'Semana17'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813872288758195)
,p_db_column_name=>'SEMANA18'
,p_display_order=>360
,p_column_identifier=>'ES'
,p_column_label=>'Semana18'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066813997355758196)
,p_db_column_name=>'SEMANA19'
,p_display_order=>370
,p_column_identifier=>'ET'
,p_column_label=>'Semana19'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066814041101758197)
,p_db_column_name=>'SEMANA20'
,p_display_order=>380
,p_column_identifier=>'EU'
,p_column_label=>'Semana20'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084695235731361005)
,p_db_column_name=>'PERSONA'
,p_display_order=>390
,p_column_identifier=>'EV'
,p_column_label=>'Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086908295471238869)
,p_db_column_name=>'PAIS'
,p_display_order=>400
,p_column_identifier=>'EW'
,p_column_label=>'Pais'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086908375440238870)
,p_db_column_name=>'EMAIL'
,p_display_order=>410
,p_column_identifier=>'EX'
,p_column_label=>'Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086908491881238871)
,p_db_column_name=>'TELEFONO'
,p_display_order=>420
,p_column_identifier=>'EY'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086908545354238872)
,p_db_column_name=>'PROFESION'
,p_display_order=>430
,p_column_identifier=>'EZ'
,p_column_label=>'Profesion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14127677849618625659)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'38311'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ESTUDIANTE:PAIS:EMAIL:TELEFONO:PROFESION:GENERACION:CODIGO:DESCRIPCION:CONDICION:SEMANA1:SEMANA2:SEMANA3:SEMANA4:SEMANA5:SEMANA6:SEMANA7:SEMANA8:SEMANA9:SEMANA10:SEMANA11:SEMANA12:SEMANA13:SEMANA14:SEMANA15:SEMANA16:SEMANA17:SEMANA18:SEMANA19:SEMANA2'
||'0:PERSONA:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14066851614601369390)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14127678053824625675)
,p_button_name=>'P130_CONSULTAR'
,p_button_static_id=>'65_CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066851950555369410)
,p_name=>'P130_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14127678053824625675)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'   order by EMPRESA',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066852250719369478)
,p_name=>'P130_PROFESORES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14127678053824625675)
,p_prompt=>'PROFESORES'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   DISTINCT (GAP_ID || '' '' || razon_social) razon_social, GAP_ID',
'    FROM   GAC_ADMI_PROFESORES_TB_NX, GNL_PERSONA_TR_NX',
'   WHERE   GAP_PERSONA = PERSONA ',
'   ORDER BY   GAP_ID'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.component_end;
end;
/
