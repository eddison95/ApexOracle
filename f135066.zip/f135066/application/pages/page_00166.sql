prompt --application/pages/page_00166
begin
--   Manifest
--     PAGE: 00166
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>166
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'Monitor de login'
,p_step_title=>'Monitor de login'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170010'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13997465380799654571)
,p_plug_name=>'Sesiones'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13997467130974654589)
,p_plug_name=>'Login bd'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    os_username,',
'    username,',
'    userhost,',
'    terminal,',
'    timestamp,',
'    (',
'        SELECT',
'            1',
'        FROM',
'            gnl_usuarios_tb_nx usu',
'        WHERE',
'            usu.username = das.username',
'    ) mbacase',
'FROM',
'    dba_audit_session das',
'WHERE',
'    action_name = ''LOGON''',
'    AND trunc(timestamp) BETWEEN to_date(:P166_INI,''dd/mm/rrrr'') AND to_date(:P166_FIN,''dd/mm/rrrr'')',
'UNION ALL',
'SELECT os_username,',
'       dbusername,',
'       userhost,',
'       terminal,',
'       event_timestamp,',
'       (',
'        SELECT',
'            1',
'        FROM',
'            gnl_usuarios_tb_nx usu',
'        WHERE',
'            usu.username = das.dbusername',
'       ) mbacase',
'FROM unified_audit_trail das',
'WHERE INSTR(action_name, ''LOGOFF'') > 0 ',
'AND trunc(event_timestamp) BETWEEN to_date(:P166_INI,''dd/mm/rrrr'') AND to_date(:P166_FIN,''dd/mm/rrrr'');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P166_TIPO'
,p_plug_display_when_cond2=>'orcl'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13997467212278654590)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RVALVERDE'
,p_internal_uid=>32357506702110545
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997467307147654591)
,p_db_column_name=>'OS_USERNAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Os username'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997467491055654592)
,p_db_column_name=>'USERNAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Username'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997467524269654593)
,p_db_column_name=>'USERHOST'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Userhost'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997467672550654594)
,p_db_column_name=>'TERMINAL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Terminal'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997467734894654595)
,p_db_column_name=>'TIMESTAMP'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Timestamp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997515585646961646)
,p_db_column_name=>'MBACASE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Mbacase'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13997522828734961993)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'324132'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OS_USERNAME:USERNAME:USERHOST:TERMINAL:TIMESTAMP:MBACASE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13997515766540961648)
,p_plug_name=>'Login apex'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    time_stamp,',
'    userid,',
'    ip_address,',
'    flow_id,',
'    (',
'        SELECT',
'            1',
'        FROM',
'            gnl_usuarios_tb_nx',
'        WHERE',
'            username = userid',
'    ) mbacase',
'FROM',
'    apex_activity_log',
'WHERE',
'    trunc(time_stamp) BETWEEN to_date(:P166_INI,''dd/mm/rrrr'') AND to_date(:P166_FIN,''dd/mm/rrrr'')',
'GROUP BY',
'    time_stamp,',
'    userid,',
'    ip_address,',
'    flow_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P166_TIPO'
,p_plug_display_when_cond2=>'apx'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13997515847895961649)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RVALVERDE'
,p_internal_uid=>32406142319417604
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997515908774961650)
,p_db_column_name=>'TIME_STAMP'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Time stamp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997516079476961651)
,p_db_column_name=>'USERID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Userid'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997516178998961652)
,p_db_column_name=>'IP_ADDRESS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ip address'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997516258730961653)
,p_db_column_name=>'FLOW_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Flow id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13997516348138961654)
,p_db_column_name=>'MBACASE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Mbacase'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13997528585061067427)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'324189'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIME_STAMP:USERID:IP_ADDRESS:FLOW_ID:MBACASE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13997515647544961647)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(13997465380799654571)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13997466222633654580)
,p_name=>'P166_INI'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(13997465380799654571)
,p_prompt=>'Fecha de inicio'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13997516550768961656)
,p_name=>'P166_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13997465380799654571)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:ORACLE;orcl,Apex;apx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000849355986807379)
,p_name=>'P166_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(13997465380799654571)
,p_prompt=>'Fecha Final'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
