prompt --application/pages/page_00169
begin
--   Manifest
--     PAGE: 00169
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>169
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CGL - Carga Asiento'
,p_step_title=>'CGL - Carga Asiento'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104170052'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14102406684663281497)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14000674035636697968)
,p_plug_name=>'Plantilla Departamentos'
,p_parent_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'cgl_carga_nx.pla_det_depto_pr;'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P169_TIPO = 2 AND :P169_PLANTILLA = ''S'''
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14000674224259697970)
,p_plug_name=>'Departamentos'
,p_parent_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT seq_id, ',
'       c001, c002, c003, c004, c005, c006, c007',
'FROM APEX_COLLECTIONS',
'WHERE COLLECTION_NAME = ''P169_DET_ASIENTO'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P169_TIPO'
,p_plug_display_when_cond2=>'2'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14000674470811697972)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>35564765235153927
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000674514513697973)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Linea'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000674723494697975)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000674861939697976)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000674938080697977)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Debe'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000675097454697978)
,p_db_column_name=>'C005'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Haber'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000675133969697979)
,p_db_column_name=>'C006'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Debe Alterno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000675295097697980)
,p_db_column_name=>'C007'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Haber alterno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000674648018697974)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>90
,p_column_identifier=>'B'
,p_column_label=>'Fila'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14000832025384273186)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'357224'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C001:SEQ_ID:C002:C003:C004:C005:C006:C007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14092217776570340085)
,p_plug_name=>'Archivo'
,p_parent_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14092217983502340088)
,p_plug_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT seq_id, ',
'       c001, c002, c003, c004, c005, c006, c007, c008, c009, c010, c011',
'FROM APEX_COLLECTIONS',
'WHERE COLLECTION_NAME = ''P169_DET_ASIENTO'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P169_TIPO'
,p_plug_display_when_cond2=>'1'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14092218115696340089)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>127108410119796044
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000756689007193985)
,p_db_column_name=>'C001'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Linea'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000757064707193994)
,p_db_column_name=>'C002'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000757479461193995)
,p_db_column_name=>'C003'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000757831761193996)
,p_db_column_name=>'C004'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000758211531193996)
,p_db_column_name=>'C005'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Debe'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000758702280193997)
,p_db_column_name=>'C006'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Haber'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000759032066193997)
,p_db_column_name=>'C007'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Debe Alterno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000759424305193997)
,p_db_column_name=>'C008'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Haber Alterno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000759817059193998)
,p_db_column_name=>'C009'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000760285913193999)
,p_db_column_name=>'C010'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Numero'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000760611417194000)
,p_db_column_name=>'C011'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14000776572941194035)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fila'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14092821384658227700)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'356672'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004:C005:C006:C007:C008:C009:C010:C011'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14092803189625184592)
,p_plug_name=>'Plantilla Detalle'
,p_parent_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'cgl_carga_nx.pla_det_asiento_pr;'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P169_TIPO = 1 AND :P169_PLANTILLA = ''S'''
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14000755601524193963)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14092217776570340085)
,p_button_name=>'CARGAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cargar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14000674306717697971)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14000674224259697970)
,p_button_name=>'PROCESAR2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Procesar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14000777342084194048)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14092217983502340088)
,p_button_name=>'PROCESAR1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Procesar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000673883914697966)
,p_name=>'P169_ASIENTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_prompt=>'Asiento'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (asiento||'' ''||fecha||'' ''||descripcion) as d, asiento as r ',
'FROM cgl_asiento_tr_nx',
'WHERE emp_empresa = :P169_EMPRESA',
'AND status = 2',
'AND sub_subsistema = ''CGL'''))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P169_EMPRESA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000673972818697967)
,p_name=>'P169_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Detalle;1,Departamentos;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000754477834193934)
,p_name=>'P169_EMPRESA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000754824988193956)
,p_name=>'P169_PLANTILLA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14102406684663281497)
,p_item_default=>'N'
,p_prompt=>'Plantilla'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:SI;S,NO;N'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14000755983999193973)
,p_name=>'P169_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14092217776570340085)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14000778053406194072)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'PLUGIN_NL.AMIS.SCHEFFER.PROCESS.EXCEL2COLLECTION'
,p_process_name=>'cargar_pr'
,p_attribute_01=>'P169_ARCHIVO'
,p_attribute_02=>'P169_DET_ASIENTO'
,p_attribute_04=>';'
,p_attribute_05=>'"'
,p_attribute_07=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14000755601524193963)
,p_process_success_message=>'Carga Completa'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14000778431810194077)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'procesar_det_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    det_asiento_v   cgl_detalle_asiento_tr_nx%rowtype;',
'BEGIN',
'    DELETE cgl_detalle_depto_tb_nx',
'    WHERE ddp_emp_empresa = :p169_empresa',
'    AND ddp_asto_asiento = :p169_asiento;',
'    DELETE cgl_detalle_asiento_tr_nx',
'    WHERE asto_emp_empresa = :p169_empresa',
'    AND asto_asiento = :p169_asiento;    ',
'    FOR a IN (',
'        SELECT',
'            seq_id,',
'            c001, SUBSTR(c002,1,10) c002, c003, c004, c005,',
'            c006, c007, c008, c009, c010,',
'            c011',
'        FROM',
'            apex_collections',
'        WHERE',
'            collection_name = ''P169_DET_ASIENTO''',
'        ORDER BY',
'            seq_id',
'    ) LOOP',
'    BEGIN',
'        det_asiento_v.asto_emp_empresa := :p169_empresa;',
'        det_asiento_v.asto_asiento := :p169_asiento;',
'        det_asiento_v.consecutivo := a.c001;',
'        det_asiento_v.fecha_documento := TO_DATE(a.c002);               ',
'        det_asiento_v.cta_emp_empresa := a.c003;',
'        det_asiento_v.cta_cuenta := a.c004;',
'        det_asiento_v.debe := a.c005;',
'        det_asiento_v.haber := a.c006;',
'        det_asiento_v.debe_alterno := a.c007;',
'        det_asiento_v.haber_alterno := a.c008;',
'        det_asiento_v.doc_documento := a.c009;',
'        det_asiento_v.documento := a.c010;',
'        det_asiento_v.observaciones := a.c011;',
'        cgl_carga_nx.det_asiento_pr(det_asiento_v);',
'        COMMIT;',
'        EXCEPTION',
'        WHEN OTHERS THEN',
'        raise_application_error(-20000, a.seq_id);',
'    END;    ',
'    END LOOP;',
'    ',
'    apex_collection.truncate_collection(''P169_DET_ASIENTO'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14000777342084194048)
,p_process_success_message=>'Proceso Terminado'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14000675766385697985)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'procesar_depto_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    det_asiento_v   cgl_detalle_depto_tb_nx%rowtype;',
'BEGIN',
'    DELETE cgl_detalle_depto_tb_nx',
'    WHERE ddp_emp_empresa = :p169_empresa',
'    AND ddp_asto_asiento = :p169_asiento;',
'    FOR a IN (',
'        SELECT',
'            seq_id,',
'            c001, c002, c003, c004, c005,',
'            c006, c007',
'        FROM',
'            apex_collections',
'        WHERE',
'            collection_name = ''P169_DET_ASIENTO''',
'        ORDER BY',
'            seq_id',
'    ) LOOP',
'        det_asiento_v.ddp_emp_empresa := :p169_empresa;',
'        det_asiento_v.ddp_asto_asiento := :p169_asiento;',
'        det_asiento_v.ddp_det_consecutivo := a.c001;',
'        det_asiento_v.ddp_dep_emp_empresa := a.c002;',
'        det_asiento_v.ddp_dep_departamento := a.c003;',
'        det_asiento_v.ddp_debe := a.c004;',
'        det_asiento_v.ddp_haber := a.c005;',
'        det_asiento_v.ddp_debe_alterno := a.c006;',
'        det_asiento_v.ddp_haber_alterno := a.c007;',
'        cgl_carga_nx.det_depto_pr(det_asiento_v);',
'        COMMIT;',
'    END LOOP;',
'    ',
'    apex_collection.truncate_collection(''P169_DET_ASIENTO'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14000674306717697971)
,p_process_success_message=>'Proceso Terminado'
);
wwv_flow_api.component_end;
end;
/
