prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>101
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('P\00E1gina de Conexi\00F3n')
,p_alias=>'LOGIN_DESKTOP'
,p_step_title=>'REPORTES DINAMICOS - Log In'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(13960753491289591898)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201216092313'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14092513735717915303)
,p_plug_name=>'REPORTES DINAMICOS'
,p_region_template_options=>'#DEFAULT#:margin-top-none'
,p_plug_template=>wwv_flow_api.id(13960796665867591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13966395753459430576)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14092513735717915303)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ingresar'
,p_button_position=>'BODY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13966396171800430577)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14092513735717915303)
,p_button_name=>'RECUPERAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Recuperar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13958104898845942797)
,p_name=>'P101_LINEA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14092513735717915303)
,p_prompt=>'Nuevo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(13960851787690591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13958105000048942798)
,p_name=>'P101_LOGO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14092513735717915303)
,p_source=>'#APP_IMAGES#Daytona.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_attributes=>'style="width: 80% ;  display: block;   margin-left: auto;   margin-right: auto"'
,p_field_template=>wwv_flow_api.id(13960852129143591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966396936964430582)
,p_name=>'P101_USERNAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14092513735717915303)
,p_prompt=>'usuario'
,p_placeholder=>'usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_api.id(13960851787690591935)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966397361292430582)
,p_name=>'P101_PASSWORD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14092513735717915303)
,p_prompt=>unistr('contrase\00F1a')
,p_placeholder=>unistr('contrase\00F1a')
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_api.id(13960851787690591935)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966397731121430582)
,p_name=>'P101_CORREO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14092513735717915303)
,p_prompt=>'Correo'
,p_placeholder=>'correo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851787690591935)
,p_item_icon_css_classes=>'fa-envelope'
,p_item_template_options=>'#DEFAULT#:margin-top-none'
,p_inline_help_text=>unistr('Solo requerido para recuperar contrase\00F1a')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966398270318430587)
,p_validation_name=>'usuario'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   id_v     NUMBER;',
'   usuario_v gnl_usuarios_tb_nx.username%TYPE;',
'   estado_v VARCHAR2(1);   ',
'BEGIN',
'   usuario_v := UPPER(:P101_USERNAME);',
'   --Valida que el usuario exista en la tabla de usuarios del MBACASE',
'   id_v := gnl_id_usuario_n_nx(usuario_v);',
'   IF id_v IS NULL THEN',
'      RETURN ''Usuario no existe'';',
'   END IF;  ',
'',
'   --Valida el password en la tabla de usuarios del MBACASE',
'   IF gnl_val_pw_n_nx(usuario_v,:P101_PASSWORD) <> 1 THEN',
'      RETURN ''Credenciales invalidos'';',
'   END IF;   ',
'   ',
'   --Valida el estado del usuario en la tabla de usuarios del MBACASE',
'   estado_v := gnl_valida_usuario_v_nx(usuario_v);',
'   IF estado_v = ''I'' THEN',
'      RETURN ''Usuario inactivo'';',
'   ELSIF estado_v = ''E'' THEN',
'      RETURN ''Usuario expirado'';',
'   END IF;   ',
'   ',
'   RETURN NULL;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(13966400184179430591)
,p_name=>'Recuperar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(13966396171800430577)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(13966400663938430592)
,p_event_id=>wwv_flow_api.id(13966400184179430591)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   nss_user_nx.reset_user_pr(UPPER(:P101_USERNAME),UPPER(:P101_CORREO));',
'   COMMIT;',
'END;    '))
,p_attribute_02=>'P101_USERNAME,P101_CORREO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(13966401151921430592)
,p_event_id=>wwv_flow_api.id(13966400184179430591)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Recuperacion Finalizada, verifique correo'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13966398942938430588)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Definir Cookie de Nombre de Usuario'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.send_login_username_cookie (',
'    p_username => lower(:P101_USERNAME) );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13966398534218430588)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Login'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.login(',
'    p_username => :P101_USERNAME,',
'    p_password => :P101_PASSWORD );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13966399735003430590)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>unistr('Borrar Cach\00E9 de P\00E1ginas')
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13966399398804430590)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Obtener Cookie de Nombre de Usuario'
,p_process_sql_clob=>':P101_USERNAME := apex_authentication.get_login_username_cookie;'
,p_process_clob_language=>'PLSQL'
);
wwv_flow_api.component_end;
end;
/
