prompt --application/pages/page_00134
begin
--   Manifest
--     PAGE: 00134
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>134
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'GAC-Informe de Asistencia de cursos por Estudiante'
,p_step_title=>'Informe de Asistencia de cursos por Estudiante'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165347'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14106648058148796526)
,p_plug_name=>'Informe de Asistencia de cursos por estudiante'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14106642605044796128)
,p_plug_name=>'Informe de Asistencia de cursos por estudiante'
,p_region_name=>'Informe de asistencia de cursos por estudiante'
,p_parent_plug_id=>wwv_flow_api.id(14106648058148796526)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 26/09/2017 08:28:49 a.m. (QP5 v5.115.810.9015) */',
'SELECT   GAE_PERSONA ID_Persona,',
'         RAZON_SOCIAL AS Nombre,',
'         GAE_CLI_CLIENTE AS Cliente,',
'         GAE_CLI_MON_MONEDA AS Moneda,',
'         DECODE (TIPO_DOCUMENTO,',
'                 1,',
'                 ''Identificacion Tributaria'',',
'                 2,',
'                 ''Cedula de Cuidadania'',',
'                 3,',
'                 ''Cedula de Residencia'',',
'                 4,',
'                 ''Tarjeta de Identidad'',',
'                 5,',
'                 ''Registro Unico Contribuyentes'',',
'                 6,',
'                 ''Pasaporte'',',
'                 7,',
'                 ''Cedula de Identidad'',',
'                 8,',
'                 ''Registro Federal de Causantes'')',
'            AS Tipo_Documento,',
'         per.DOCUMENTO AS Documento,',
'         DECODE (PER_GRD_GRADO_ACADEMICO,',
'                 1,',
'                 ''PRIMARIA'',',
'                 2,',
'                 ''SECUNDARIA'',',
'                 3,',
'                 ''DIPLOMADO'',',
'                 4,',
'                 ''BACHILLERATO'',',
'                 5,',
'                 ''BACHILLERATO INCOMPLETO'',',
'                 6,',
'                 ''LICENCIATURA'',',
'                 7,',
'                 ''LICENCIATURA INCOMPLETA'',',
'                 8,',
'                 ''MAESTRIA'',',
'                 9,',
'                 ''MAESTRIA INCOMPLETA'',',
'                 10,',
'                 ''DOCTORADO'',',
'                 11,',
'                 ''DOCTORADO INCOMPLETO'',',
'                 12,',
'                 ''ESPECIALIDAD'',',
'                 NULL,',
'                 ''N/A'')',
'            AS Grado_Academico,',
'         DAE_DOA_ATO_ARTICULO AS Materia,',
'         DAE_OAC_ULA_ANTIGUEDAD AS Generacion,',
'         DAE_DOA_ATO_ARTICULO AS Codigo,',
'         ATO_DESCRIPCION AS Descripcion,',
'         DPA_SEMANA1 AS Semana1,',
'         DPA_SEMANA2 AS Semana2,',
'         DPA_SEMANA3 AS Semana3,',
'         DPA_SEMANA4 AS Semana4,',
'         DPA_SEMANA5 AS Semana5,',
'         DPA_SEMANA6 AS Semana6,',
'         DPA_SEMANA7 AS Semana7,',
'         DPA_SEMANA8 AS Semana8,',
'         DPA_SEMANA9 AS Semana9,',
'         DPA_SEMANA10 AS Semana10,',
'         DPA_SEMANA11 AS Semana11,',
'         DPA_SEMANA12 AS Semana12,',
'         DPA_SEMANA13 AS Semana13,',
'         DPA_SEMANA14 AS Semana14,',
'         DPA_SEMANA15 AS Semana15,',
'         (SELECT   pai_nombre',
'            FROM   gnl_pais_tb_nx',
'           WHERE   PAI_PAIS = per.PAI_PAIS)',
'            pais,',
'         EMAIL,',
'         TELEFONO1 || '' '' || TELEFONO2 telefono,',
'         (SELECT   PFE_DESCRIPCION',
'            FROM   GNL_PROFESION_TB_NX',
'           WHERE   pfe_profesion = per.PFE_PROFESION)',
'            profesion,',
'         (SELECT   TCU_CUENTA',
'            FROM   CXC_TIPO_CUENTA_TB_NX',
'           WHERE   TCU_EMP_EMPRESA = per_emp_empresa',
'                   AND TCU_CUENTA = PER_TCU_CUENTA)',
'            condicion',
'  FROM   GAC_ADMI_PROFE_ASIS_TB_NX,',
'         GAC_ADMI_ESTUDIANTES_TB_NX,',
'         GNL_PERSONA_TR_NX per,',
'         GAC_DET_ADMI_ESTUDIANTES_TB_NX,',
'         INV_ARTICULO_TB_NX,',
'         GAC_ADMI_PROFE_DET_ASIS_TB_NX',
' WHERE   INSTR ('':'' || :P134_EMPRESA || '':'',',
'                '':'' || GAE_CLI_EMP_EMPRESA || '':'') > 0',
'         AND GAE_FECHA_CREACION BETWEEN :P134_INICIO',
'                                    AND  TO_DATE (:P134_FIN || '' 23:59'',',
'                                                  ''dd/mm/rrrr hh24:mi'')',
'         AND GAE_PERSONA = PERSONA',
'         AND GAE_ID = DAE_GAE_ID',
'         AND DAE_DOA_ATO_ARTICULO = ATO_ARTICULO',
'         AND GAE_PERSONA = DPA_PERSONA',
'         AND APA_ID = DPA_APA_ID',
'         AND APA_ATO_ARTICULO = ATO_ARTICULO'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P134_EMPRESA'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14106642846555796175)
,p_name=>'Reporte D151'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'MMORALES'
,p_internal_uid=>43623116115579916
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066930015176189016)
,p_db_column_name=>'MONEDA'
,p_display_order=>100
,p_column_identifier=>'Z'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066926347847189002)
,p_db_column_name=>'ID_PERSONA'
,p_display_order=>110
,p_column_identifier=>'AK'
,p_column_label=>'Id Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066926744787189006)
,p_db_column_name=>'NOMBRE'
,p_display_order=>120
,p_column_identifier=>'AL'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066927199517189007)
,p_db_column_name=>'CLIENTE'
,p_display_order=>130
,p_column_identifier=>'AM'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066927933577189009)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>150
,p_column_identifier=>'AO'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066928414660189010)
,p_db_column_name=>'GRADO_ACADEMICO'
,p_display_order=>160
,p_column_identifier=>'AP'
,p_column_label=>'Grado Academico'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066930389093189017)
,p_db_column_name=>'GENERACION'
,p_display_order=>200
,p_column_identifier=>'AT'
,p_column_label=>'Generacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066930819664189018)
,p_db_column_name=>'MATERIA'
,p_display_order=>210
,p_column_identifier=>'AU'
,p_column_label=>'Materia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905131364490964)
,p_db_column_name=>'CODIGO'
,p_display_order=>220
,p_column_identifier=>'AX'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905323149490965)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>230
,p_column_identifier=>'AY'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905420635490966)
,p_db_column_name=>'SEMANA1'
,p_display_order=>240
,p_column_identifier=>'AZ'
,p_column_label=>'Semana1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905492884490967)
,p_db_column_name=>'SEMANA2'
,p_display_order=>250
,p_column_identifier=>'BA'
,p_column_label=>'Semana2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905625560490968)
,p_db_column_name=>'SEMANA3'
,p_display_order=>260
,p_column_identifier=>'BB'
,p_column_label=>'Semana3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905681412490969)
,p_db_column_name=>'SEMANA4'
,p_display_order=>270
,p_column_identifier=>'BC'
,p_column_label=>'Semana4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905752425490970)
,p_db_column_name=>'SEMANA5'
,p_display_order=>280
,p_column_identifier=>'BD'
,p_column_label=>'Semana5'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905856254490971)
,p_db_column_name=>'SEMANA6'
,p_display_order=>290
,p_column_identifier=>'BE'
,p_column_label=>'Semana6'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066905965272490972)
,p_db_column_name=>'SEMANA7'
,p_display_order=>300
,p_column_identifier=>'BF'
,p_column_label=>'Semana7'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066906117003490973)
,p_db_column_name=>'SEMANA8'
,p_display_order=>310
,p_column_identifier=>'BG'
,p_column_label=>'Semana8'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066906143245490974)
,p_db_column_name=>'SEMANA9'
,p_display_order=>320
,p_column_identifier=>'BH'
,p_column_label=>'Semana9'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066906285910490975)
,p_db_column_name=>'SEMANA10'
,p_display_order=>330
,p_column_identifier=>'BI'
,p_column_label=>'Semana10'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066906429694490976)
,p_db_column_name=>'SEMANA11'
,p_display_order=>340
,p_column_identifier=>'BJ'
,p_column_label=>'Semana11'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066906495173490977)
,p_db_column_name=>'SEMANA12'
,p_display_order=>350
,p_column_identifier=>'BK'
,p_column_label=>'Semana12'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066906552687490978)
,p_db_column_name=>'SEMANA13'
,p_display_order=>360
,p_column_identifier=>'BL'
,p_column_label=>'Semana13'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066906682557490979)
,p_db_column_name=>'SEMANA14'
,p_display_order=>370
,p_column_identifier=>'BM'
,p_column_label=>'Semana14'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14066906739350490980)
,p_db_column_name=>'SEMANA15'
,p_display_order=>380
,p_column_identifier=>'BN'
,p_column_label=>'Semana15'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14067158988949098290)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>390
,p_column_identifier=>'BO'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086908819183238874)
,p_db_column_name=>'PAIS'
,p_display_order=>400
,p_column_identifier=>'BP'
,p_column_label=>'Pais'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086908860696238875)
,p_db_column_name=>'EMAIL'
,p_display_order=>410
,p_column_identifier=>'BQ'
,p_column_label=>'Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086909027788238876)
,p_db_column_name=>'TELEFONO'
,p_display_order=>420
,p_column_identifier=>'BR'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086909057385238877)
,p_db_column_name=>'PROFESION'
,p_display_order=>430
,p_column_identifier=>'BS'
,p_column_label=>'Profesion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086909137548238878)
,p_db_column_name=>'CONDICION'
,p_display_order=>440
,p_column_identifier=>'BT'
,p_column_label=>'Condicion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14106647626563796450)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'39122'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID_PERSONA:NOMBRE:PAIS:EMAIL:TELEFONO:PROFESION:CONDICION:CLIENTE:MONEDA:TIPO_DOCUMENTO:DOCUMENTO:GRADO_ACADEMICO:MATERIA:GENERACION:CODIGO:DESCRIPCION:SEMANA1:SEMANA2:SEMANA3:SEMANA4:SEMANA5:SEMANA6:SEMANA7:SEMANA8:SEMANA9:SEMANA10:SEMANA11:SEMANA12'
||':SEMANA13:SEMANA14:SEMANA15:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14066932716657189032)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14106648058148796526)
,p_button_name=>'CONSULTAR'
,p_button_static_id=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066933034394189034)
,p_name=>'P134_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14106648058148796526)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066933435787189036)
,p_name=>'P134_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14106648058148796526)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14066933845167189038)
,p_name=>'P134_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14106648058148796526)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
