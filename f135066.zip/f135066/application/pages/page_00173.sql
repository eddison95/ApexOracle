prompt --application/pages/page_00173
begin
--   Manifest
--     PAGE: 00173
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>173
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'Pronostico'
,p_step_title=>'Pronostico'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14003697521012907952)
,p_plug_name=>unistr('Pron\00F3stico Sugerido')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14003693867853898173)
,p_plug_name=>'Pronostico'
,p_parent_plug_id=>wwv_flow_api.id(14003697521012907952)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT c001,',
'       c002,',
'       c003,',
'       c004,',
'       c005,',
'       c006,',
'       c007,',
'       to_number (c008)',
'FROM   apex_collections',
'WHERE  collection_name = ''FAC-PRONOSTICO'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P173_EMPRESA'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14003693914096898173)
,p_name=>'Pronostico'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RVALVERDE'
,p_internal_uid=>38584208520354128
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003694389382898179)
,p_db_column_name=>'C001'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003694718169898187)
,p_db_column_name=>'C002'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003695126098898187)
,p_db_column_name=>'C003'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003695538860898188)
,p_db_column_name=>'C004'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3digo relacionado ')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003695934777898188)
,p_db_column_name=>'C005'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('Descripci\00F3n relacionada ')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003697771719907954)
,p_db_column_name=>'C006'
,p_display_order=>15
,p_column_identifier=>'H'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003697869504907955)
,p_db_column_name=>'C007'
,p_display_order=>25
,p_column_identifier=>'I'
,p_column_label=>'Familia relacionada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14003698573105907962)
,p_db_column_name=>'TO_NUMBER(C008)'
,p_display_order=>35
,p_column_identifier=>'P'
,p_column_label=>unistr('Iteraci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14003703230693961264)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'385936'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C001:C002:C003:C004:C005:C006:C007:TO_NUMBER(C008)'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14003697256842907949)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14003697521012907952)
,p_button_name=>'Consultar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003696965515907946)
,p_name=>'P173_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14003697521012907952)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003697064278907947)
,p_name=>'P173_FECHA_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14003697521012907952)
,p_prompt=>'Fecha inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14003697182492907948)
,p_name=>'P173_FECHA_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14003697521012907952)
,p_prompt=>'Fecha fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14003697490059907951)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'consutar_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' DECLARE',
'    empresa_p gnl_empresa_tr_nx.empresa%TYPE := :P173_EMPRESA;',
'    l_query   VARCHAR2(32767) := ''SELECT tra_emp_empresa,''',
'                               || ''det1.det_ato_articulo articulo1,''',
'                               || ''det1.det_descripcion descripcion1,''',
'                               || ''det2.det_ato_articulo articulo2,''',
'                               || ''det2.det_descripcion descripcion2,''',
'                               || ''inv_familia_art_v_nx(tra_emp_empresa,det1.det_ato_articulo ) familia1,''',
'                               || ''inv_familia_art_v_nx( tra_emp_empresa,det2.det_ato_articulo ) familia2,''        ',
'                               || ''Count(*) repeticiones''',
'                               || '' FROM fac_factura_tb_nx,''',
'                               || '' fac_detalle_factura_tb_nx det1,''',
'                               || '' fac_detalle_factura_tb_nx det2''',
'                               || '' WHERE  tra_emp_empresa = ''',
'                               ||''''''''',
'                               ||empresa_p',
'                               ||''''''''',
'                               ||'' AND tra_status <> ''''C''''''',
'                               ||'' AND tra_fecha BETWEEN  to_date('''''' || :P173_FECHA_INICIO || '''''', ''''DD/MM/RRRR'''') ',
'                                   AND to_date ('''''' || :P173_FECHA_FIN || '' 23:59'' ||'''''',  ''''DD/MM/RRRR hh24:mi'''')''',
'                               ||'' AND tra_transaccion = det1.det_tra_transaccion''',
'                               ||'' AND tra_transaccion = det2.det_tra_transaccion''',
'                               ||'' AND det1.det_ato_articulo <> det2.det_ato_articulo''',
'                               ||'' HAVING COUNT(*) > 1''',
'                               ||'' GROUP BY tra_emp_empresa, det1.det_ato_articulo, det1.det_descripcion,''',
'                               ||'' det2.det_ato_articulo,det2.det_descripcion'';',
'BEGIN',
'    IF apex_collection.Collection_exists(''FAC-PRONOSTICO'') THEN',
'      apex_collection.Delete_collection(''FAC-PRONOSTICO'');',
'    END IF;',
'',
'    apex_collection.Create_collection_from_query(''FAC-PRONOSTICO'', l_query);',
'END;   ',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
