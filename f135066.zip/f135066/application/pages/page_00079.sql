prompt --application/pages/page_00079
begin
--   Manifest
--     PAGE: 00079
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>79
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'TAL - Visitas'
,p_step_title=>'Visitas Taller'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164519'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094565222443598377)
,p_plug_name=>'Visitas Taller'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14094511093235780239)
,p_plug_name=>'Visitas Taller'
,p_parent_plug_id=>wwv_flow_api.id(14094565222443598377)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 23/02/2017 06:37:33 p.m. (QP5 v5.115.810.9015) */',
'SELECT   VIS_CONSECUTIVO,',
'         DECODE (VIS_ESTADO,',
'                 ''C'',',
'                 ''Creado'',',
'                 ''P'',',
'                 ''Procesado'')',
'            VIS_ESTADO,',
'         DECODE (VIS_TIPO,',
'                 ''A'',',
'                 ''Aseguradora'',',
'                 ''P'',',
'                 ''Particular'')',
'            VIS_TIPO,',
'         VIS_EMP_EMPRESA,',
'         VIS_CLI_CLIENTE,',
'         VIS_CLI_MON_MONEDA,',
'         VIS_CLI_NOMBRE,',
'         VIS_VEH_CONSECUTIVO,',
'         VIS_VEH_MOM_CONSECUTIVO,',
'         VIS_MAR_MARCA,',
'         VIS_MOD_MODELO,',
'         VIS_VEH_PLACA,',
'         VIS_TELEFONO,',
'         VIS_EMAIL,',
'         TRUNC (VIS_FECHA_CREACION) VIS_FECHA_CREACION,',
'         VIS_USUARIO_CREACION,',
'         TRUNC (VIS_FECHA_PROCESADO) VIS_FECHA_PROCESADO,',
'         VIS_USUARIO_PROCESADO',
'  FROM   TAL_VISITA_TB_NX',
' WHERE   INSTR ('':'' || :P79_EMPRESA || '':'', '':'' || VIS_EMP_EMPRESA || '':'') >',
'            0',
'         AND VIS_FECHA_CREACION BETWEEN :P79_INICIO',
'                                    AND  TO_DATE (:P79_FIN || '' 23:59'',',
'                                                  ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P79_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14094511175029780240)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>6767450257891146
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094511230136780241)
,p_db_column_name=>'VIS_CONSECUTIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Consecutivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094511324821780242)
,p_db_column_name=>'VIS_ESTADO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094511475675780243)
,p_db_column_name=>'VIS_TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094511598243780244)
,p_db_column_name=>'VIS_EMP_EMPRESA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094567863413602495)
,p_db_column_name=>'VIS_CLI_CLIENTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094567995600602496)
,p_db_column_name=>'VIS_CLI_MON_MONEDA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568052276602497)
,p_db_column_name=>'VIS_CLI_NOMBRE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568206798602498)
,p_db_column_name=>'VIS_VEH_CONSECUTIVO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Veh Consecutivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568241583602499)
,p_db_column_name=>'VIS_VEH_MOM_CONSECUTIVO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Veh Mom Consecutivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568343245602500)
,p_db_column_name=>'VIS_MAR_MARCA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568458876602501)
,p_db_column_name=>'VIS_MOD_MODELO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Modelo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568614591602502)
,p_db_column_name=>'VIS_VEH_PLACA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Placa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568691253602503)
,p_db_column_name=>'VIS_TELEFONO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568793474602504)
,p_db_column_name=>'VIS_EMAIL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094568839009602505)
,p_db_column_name=>'VIS_FECHA_CREACION'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'F. Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569012351602506)
,p_db_column_name=>'VIS_USUARIO_CREACION'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Usuario Creacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569117781602507)
,p_db_column_name=>'VIS_FECHA_PROCESADO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'F. Procesado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094569127424602508)
,p_db_column_name=>'VIS_USUARIO_PROCESADO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Usuario Procesado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14094589866278615403)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'68462'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VIS_CONSECUTIVO:VIS_ESTADO:VIS_TIPO:VIS_EMP_EMPRESA:VIS_CLI_CLIENTE:VIS_CLI_MON_MONEDA:VIS_CLI_NOMBRE:VIS_VEH_CONSECUTIVO:VIS_VEH_MOM_CONSECUTIVO:VIS_MAR_MARCA:VIS_MOD_MODELO:VIS_VEH_PLACA:VIS_TELEFONO:VIS_EMAIL:VIS_FECHA_CREACION:VIS_USUARIO_CREACIO'
||'N:VIS_FECHA_PROCESADO:VIS_USUARIO_PROCESADO:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14094565607801598378)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14094565222443598377)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094566020898598381)
,p_name=>'P79_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14094565222443598377)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094566401832598382)
,p_name=>'P79_INICIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14094565222443598377)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14094566819352598383)
,p_name=>'P79_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14094565222443598377)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
