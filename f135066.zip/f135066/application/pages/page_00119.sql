prompt --application/pages/page_00119
begin
--   Manifest
--     PAGE: 00119
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>119
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('FAC \2013 Estad\00EDsticas de Facturacion')
,p_step_title=>unistr('Estad\00EDsticas de Facturacion')
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165148'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098220709810887957)
,p_plug_name=>unistr('Estad\00EDsticas de Facturacion')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098210592208887869)
,p_plug_name=>unistr('Estad\00EDsticas de Facturaci\00F3n')
,p_parent_plug_id=>wwv_flow_api.id(14098220709810887957)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 09/03/2017 01:59:55 p.m. (QP5 v5.115.810.9015) */',
'  SELECT   A.FES_EMPRESA,',
'           A.FES_ARTICULO,',
'           inv_descrip_art_v_nx (A.FES_EMPRESA, A.FES_ARTICULO) descripcion,',
'           inv_familia_art_v_nx (A.FES_EMPRESA, A.FES_ARTICULO) codigo_familia,',
'           inv_desc_fam_art_v_nx (A.FES_EMPRESA, A.FES_ARTICULO) familia,',
'           NVL (',
'              (  SELECT   COUNT (C.FES_ARTICULO)',
'                   FROM   FAC_ESTADISTICA_VW_NX C',
'                  WHERE       C.FES_CANTIDAD_VENDIDA > 0',
'                          AND C.FES_ARTICULO = A.FES_ARTICULO',
'                          AND INSTR ('':'' || :P119_EMPRESA || '':'',',
'                                     '':'' || C.FES_EMPRESA || '':'') > 0',
'                          AND C.FES_FECHA BETWEEN :p119_inicio',
'                                              AND  TO_DATE (',
'                                                      :p119_fin || '' 23:59'',',
'                                                      ''dd/mm/rrrr hh24:mi''',
'                                                   )',
'               GROUP BY   C.FES_ARTICULO),',
'              0',
'           )',
'              movimientos_ventas,',
'           NVL (SUM (FES_CANTIDAD_VENDIDA), 0) unidades_vendidas,',
'           NVL (',
'              (  SELECT   COUNT (C.FES_ARTICULO)',
'                   FROM   FAC_ESTADISTICA_VW_NX C',
'                  WHERE       C.FES_CANTIDAD_PERDIDA > 0',
'                          AND C.FES_ARTICULO = A.FES_ARTICULO',
'                          AND INSTR ('':'' || :P119_EMPRESA || '':'',',
'                                     '':'' || C.FES_EMPRESA || '':'') > 0',
'                          AND C.FES_FECHA BETWEEN :p119_inicio',
'                                              AND  TO_DATE (',
'                                                      :p119_fin || '' 23:59'',',
'                                                      ''dd/mm/rrrr hh24:mi''',
'                                                   )',
'               GROUP BY   C.FES_ARTICULO),',
'              0',
'           )',
'              movimientos_ventas_perdidas,',
'           NVL (SUM (FES_CANTIDAD_PERDIDA), 0) unidades_perdidas,',
'           NVL (',
'              (  SELECT   COUNT (C.FES_ARTICULO)',
'                   FROM   FAC_ESTADISTICA_VW_NX C',
'                  WHERE       C.FES_CANTIDAD_DEVUELTA > 0',
'                          AND C.FES_ARTICULO = A.FES_ARTICULO',
'                          AND INSTR ('':'' || :P119_EMPRESA || '':'',',
'                                     '':'' || C.FES_EMPRESA || '':'') > 0',
'                          AND C.FES_FECHA BETWEEN :p119_inicio',
'                                              AND  TO_DATE (',
'                                                      :p119_fin || '' 23:59'',',
'                                                      ''dd/mm/rrrr hh24:mi''',
'                                                   )',
'               GROUP BY   C.FES_ARTICULO),',
'              0',
'           )',
'              movimientos_devoluciones,',
'           NVL (SUM (FES_CANTIDAD_DEVUELTA), 0) unidades_devueltas,',
'           A.FES_LOCALIZACION,',
'           A.FES_DESC_LOCALIZACION',
'    FROM   FAC_ESTADISTICA_VW_NX A',
'   WHERE   INSTR ('':'' || :P119_EMPRESA || '':'', '':'' || FES_EMPRESA || '':'') > 0',
'           AND FES_FECHA BETWEEN :p119_inicio',
'                             AND  TO_DATE (:p119_fin || '' 23:59'',',
'                                           ''dd/mm/rrrr hh24:mi'')',
'GROUP BY   FES_EMPRESA,',
'           FES_ARTICULO,',
'           FES_LOCALIZACION,',
'           FES_DESC_LOCALIZACION;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P119_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14098211011566887880)
,p_name=>'Detalle de Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10467286794998786
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098168966146481032)
,p_db_column_name=>'UNIDADES_VENDIDAS'
,p_display_order=>20
,p_column_identifier=>'CN'
,p_column_label=>'Unidades Vendidas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098169223284481034)
,p_db_column_name=>'UNIDADES_PERDIDAS'
,p_display_order=>40
,p_column_identifier=>'CP'
,p_column_label=>'Unidades Perdidas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098169362411481036)
,p_db_column_name=>'UNIDADES_DEVUELTAS'
,p_display_order=>60
,p_column_identifier=>'CR'
,p_column_label=>'Unidades Devueltas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098169501439481037)
,p_db_column_name=>'FES_ARTICULO'
,p_display_order=>70
,p_column_identifier=>'CS'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098169679018481039)
,p_db_column_name=>'MOVIMIENTOS_VENTAS'
,p_display_order=>90
,p_column_identifier=>'CU'
,p_column_label=>'Mov. Ventas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098169792902481040)
,p_db_column_name=>'MOVIMIENTOS_VENTAS_PERDIDAS'
,p_display_order=>100
,p_column_identifier=>'CV'
,p_column_label=>'Mov. Ventas Perdidas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098169878213481041)
,p_db_column_name=>'MOVIMIENTOS_DEVOLUCIONES'
,p_display_order=>110
,p_column_identifier=>'CW'
,p_column_label=>'Mov. Devoluciones'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098315841743873814)
,p_db_column_name=>'FES_EMPRESA'
,p_display_order=>120
,p_column_identifier=>'CX'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098315951871873815)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>130
,p_column_identifier=>'CY'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098316078853873816)
,p_db_column_name=>'CODIGO_FAMILIA'
,p_display_order=>140
,p_column_identifier=>'CZ'
,p_column_label=>'Cod. Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098316201908873817)
,p_db_column_name=>'FAMILIA'
,p_display_order=>150
,p_column_identifier=>'DA'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099125418275152619)
,p_db_column_name=>'FES_LOCALIZACION'
,p_display_order=>160
,p_column_identifier=>'DB'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099125431191152620)
,p_db_column_name=>'FES_DESC_LOCALIZACION'
,p_display_order=>170
,p_column_identifier=>'DC'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14098220133593887919)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'104765'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'FES_EMPRESA:FES_ARTICULO:DESCRIPCION:CODIGO_FAMILIA:FAMILIA:FES_LOCALIZACION:FES_DESC_LOCALIZACION:MOVIMIENTOS_VENTAS:UNIDADES_VENDIDAS:MOVIMIENTOS_VENTAS_PERDIDAS:UNIDADES_PERDIDAS:MOVIMIENTOS_DEVOLUCIONES:UNIDADES_DEVUELTAS:'
,p_sort_column_1=>'MOVIMIENTOS_DEVOLUCIONES'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'MOVIMIENTOS_VENTAS_PERDIDAS'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'MOVIMIENTOS_VENTAS'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'UNIDADES_VENDIDAS'
,p_sort_direction_4=>'DESC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14098221065699887958)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14098220709810887957)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098221465301887975)
,p_name=>'P119_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14098220709810887957)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098221810514887998)
,p_name=>'P119_INICIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14098220709810887957)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098222134521887999)
,p_name=>'P119_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14098220709810887957)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
