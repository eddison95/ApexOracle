prompt --application/pages/page_00091
begin
--   Manifest
--     PAGE: 00091
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>91
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CRM - Etapas'
,p_step_title=>'Etapas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201016153901'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14082848587381475406)
,p_plug_name=>'Etapas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY_1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095600934398593781)
,p_plug_name=>'Etapas'
,p_parent_plug_id=>wwv_flow_api.id(14082848587381475406)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 17/02/2017 08:00:26 a.m. (QP5 v5.115.810.9015) */',
'SELECT   FOLLOWUPS_DETAIL.ID AS ID,',
'         FOLLOWUPS_DETAIL.TEMPLATE AS TEMPLATE,',
'         FOLLOWUPS_TEMPLATES.NAME AS NAME_TAMPLATE,',
'         FOLLOWUPS_DETAIL.SECUENCE AS SECUENCE,',
'         FOLLOWUPS_DETAIL.NAME AS NAME,',
'         FOLLOWUPS_DETAIL.DESCRIPTION AS DESCRIPTION,',
'         FOLLOWUPS_DETAIL.COMMENTS AS COMMENTS,',
'         FOLLOWUPS_DETAIL.PREDECESSOR AS PREDECESSOR,',
'         FOLLOWUPS_DETAIL.PREDECESSOR_REQUIRED AS PREDECESSOR_REQUIRED,',
'         FOLLOWUPS_DETAIL.PERCENT1 AS PERCENT1,',
'         DECODE (FOLLOWUPS_DETAIL.TYPE,',
'                 ''P'',',
'                 ''Pipeline'',',
'                 ''F'',',
'                 ''Forecast'',',
'                 ''O'',',
'                 ''Outlook'')',
'            AS TYPE,',
'         FOLLOWUPS_DETAIL.NOTIFY_TO AS NOTIFY_TO,',
'         FOLLOWUPS_DETAIL.MAX_DAYS_TO_DO AS MAX_DAYS_TO_DO,',
'         FOLLOWUPS_DETAIL.ORDERS AS ORDERS,',
'         FOLLOWUPS_DETAIL.OBLIGATORIO AS OBLIGATORIO',
'  FROM   FOLLOWUPS_DETAIL FOLLOWUPS_DETAIL,',
'         FOLLOWUPS_TEMPLATES FOLLOWUPS_TEMPLATES',
' WHERE   FOLLOWUPS_DETAIL.TEMPLATE = FOLLOWUPS_TEMPLATES.ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095601294975593819)
,p_name=>'Ventas Diarias'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>7857570203704725
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095603645985593857)
,p_db_column_name=>'NAME'
,p_display_order=>10
,p_column_identifier=>'CI'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095497323244481424)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'CJ'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095497396972481425)
,p_db_column_name=>'TEMPLATE'
,p_display_order=>30
,p_column_identifier=>'CK'
,p_column_label=>'Cod. Plantilla'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095497451152481426)
,p_db_column_name=>'SECUENCE'
,p_display_order=>40
,p_column_identifier=>'CL'
,p_column_label=>'Secuencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095497668035481428)
,p_db_column_name=>'COMMENTS'
,p_display_order=>60
,p_column_identifier=>'CN'
,p_column_label=>'Comentarios'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095497730020481429)
,p_db_column_name=>'PREDECESSOR'
,p_display_order=>70
,p_column_identifier=>'CO'
,p_column_label=>'Predecesor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095497856467481430)
,p_db_column_name=>'PREDECESSOR_REQUIRED'
,p_display_order=>80
,p_column_identifier=>'CP'
,p_column_label=>'Predecesor Requerido'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095497959208481431)
,p_db_column_name=>'PERCENT1'
,p_display_order=>90
,p_column_identifier=>'CQ'
,p_column_label=>'Porcentaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498042747481432)
,p_db_column_name=>'TYPE'
,p_display_order=>100
,p_column_identifier=>'CR'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498156118481433)
,p_db_column_name=>'NOTIFY_TO'
,p_display_order=>110
,p_column_identifier=>'CS'
,p_column_label=>'Notificar a'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498265748481434)
,p_db_column_name=>'MAX_DAYS_TO_DO'
,p_display_order=>120
,p_column_identifier=>'CT'
,p_column_label=>'Max Dias Etapa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498365633481435)
,p_db_column_name=>'ORDERS'
,p_display_order=>130
,p_column_identifier=>'CU'
,p_column_label=>'Ordenes'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095498448502481436)
,p_db_column_name=>'OBLIGATORIO'
,p_display_order=>140
,p_column_identifier=>'CV'
,p_column_label=>'Obligatorio'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669519974192116)
,p_db_column_name=>'NAME_TAMPLATE'
,p_display_order=>150
,p_column_identifier=>'CW'
,p_column_label=>'Plantilla'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098669539170192117)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>160
,p_column_identifier=>'CX'
,p_column_label=>'Description'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095604067849593859)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'78604'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:TEMPLATE:SECUENCE:TYPE:NAME:COMMENTS:PREDECESSOR:PREDECESSOR_REQUIRED:PERCENT1:NOTIFY_TO:MAX_DAYS_TO_DO:ORDERS:OBLIGATORIO::NAME_TAMPLATE'
);
wwv_flow_api.component_end;
end;
/
