prompt --application/pages/page_00118
begin
--   Manifest
--     PAGE: 00118
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>118
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('FAC \2013 Detalle de Reservas')
,p_step_title=>'Detalle de Reservas'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104165138'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098045949540487244)
,p_plug_name=>'Detalle de Reservas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14098026741825487061)
,p_plug_name=>'Detalle de Reservas'
,p_parent_plug_id=>wwv_flow_api.id(14098045949540487244)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 19/01/2017 06:10:56 p.m. (QP5 v5.115.810.9015) */',
'SELECT   r.FRS_EMP_EMPRESA,',
'         r.FRS_RESERVA,',
'         r.FRS_DEP_DEPARTAMENTO,',
'         cgl_nombre_depto_v_nx (r.FRS_EMP_EMPRESA, r.FRS_DEP_DEPARTAMENTO)',
'            desc_departamento,',
'         r.FRS_VEN_VENDEDOR vendedor,',
'         gnl_nombre_vendedor_vi (r.FRS_EMP_EMPRESA, r.FRS_VEN_VENDEDOR)',
'            nombre_vend,',
'         r.FRS_CLI_CLIENTE,',
'         r.FRS_CLI_MON_MONEDA,',
'         r.FRS_NOMBRE,',
'         r.CREADO_POR,',
'         r.FRS_MON_MONEDA MONEDA_RESERVA,',
'         DECODE (r.FRS_STATUS,',
'                 ''A'',',
'                 ''ASIGNADA'',',
'                 ''F'',',
'                 ''FINALIZADA'',',
'                 ''E'',',
'                 ''ELIMINADA'')',
'            ESTADO,',
'         r.FRS_DOCUMENTO,',
'         r.FRS_REC_NUMERO_RECIBO,',
'         TRUNC (r.FRS_FECHA) FECHA,',
'         dr.FDR_ATO_ARTICULO,',
'         dr.FDR_CANTIDAD,',
'         dr.FDR_CANTIDAD_FACTURA,',
'         dr.FDR_IPA_PLAN,',
'         dr.FDR_LCN_LOCALIZACION,',
'         dr.FDR_ORD_ORDEN_INTERNA,',
'         dr.FDR_PRECIO,',
'         inv_descrip_loca_v_nx (r.FRS_EMP_EMPRESA, dr.FDR_LCN_LOCALIZACION)',
'            desc_localizacion',
'  FROM   fac_reserva_tb_nx r, fac_detalle_reserva_tb_nx dr',
' WHERE   INSTR ('':'' || :P118_EMPRESA || '':'', '':'' || r.FRS_EMP_EMPRESA || '':'') >',
'            0',
'         AND r.FRS_RESERVA = dr.FDR_FRS_RESERVA',
'         AND r.FRS_FECHA BETWEEN :p118_inicio',
'                             AND  TO_DATE (:p118_fin || '' 23:59'',',
'                                           ''dd/mm/rrrr hh24:mi'');'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P118_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14098027111417487083)
,p_name=>'Detalle de Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10283386645597989
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098043477891487174)
,p_db_column_name=>'NOMBRE_VEND'
,p_display_order=>23
,p_column_identifier=>'U'
,p_column_label=>'Nom. Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE_VEND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098044682994487178)
,p_db_column_name=>'FECHA'
,p_display_order=>26
,p_column_identifier=>'X'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098036358118487139)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>247
,p_column_identifier=>'AW'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097901342985642721)
,p_db_column_name=>'FRS_EMP_EMPRESA'
,p_display_order=>257
,p_column_identifier=>'AX'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097901466297642722)
,p_db_column_name=>'FRS_RESERVA'
,p_display_order=>267
,p_column_identifier=>'AY'
,p_column_label=>'Reserva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097901596957642723)
,p_db_column_name=>'FRS_DEP_DEPARTAMENTO'
,p_display_order=>277
,p_column_identifier=>'AZ'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097901712926642724)
,p_db_column_name=>'VENDEDOR'
,p_display_order=>287
,p_column_identifier=>'BA'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097901740471642725)
,p_db_column_name=>'FRS_CLI_CLIENTE'
,p_display_order=>297
,p_column_identifier=>'BB'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097901900626642726)
,p_db_column_name=>'FRS_CLI_MON_MONEDA'
,p_display_order=>307
,p_column_identifier=>'BC'
,p_column_label=>'Moneda Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902022421642727)
,p_db_column_name=>'FRS_NOMBRE'
,p_display_order=>317
,p_column_identifier=>'BD'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902064294642728)
,p_db_column_name=>'ESTADO'
,p_display_order=>327
,p_column_identifier=>'BE'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902305256642730)
,p_db_column_name=>'FRS_DOCUMENTO'
,p_display_order=>347
,p_column_identifier=>'BG'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902383761642731)
,p_db_column_name=>'FDR_ATO_ARTICULO'
,p_display_order=>357
,p_column_identifier=>'BH'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902430688642732)
,p_db_column_name=>'FDR_CANTIDAD'
,p_display_order=>367
,p_column_identifier=>'BI'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902557020642733)
,p_db_column_name=>'FDR_CANTIDAD_FACTURA'
,p_display_order=>377
,p_column_identifier=>'BJ'
,p_column_label=>'Cantidad Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902639215642734)
,p_db_column_name=>'FDR_IPA_PLAN'
,p_display_order=>387
,p_column_identifier=>'BK'
,p_column_label=>'Plan'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902751450642735)
,p_db_column_name=>'FDR_LCN_LOCALIZACION'
,p_display_order=>397
,p_column_identifier=>'BL'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902874891642736)
,p_db_column_name=>'FDR_ORD_ORDEN_INTERNA'
,p_display_order=>407
,p_column_identifier=>'BM'
,p_column_label=>'Orden interna'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097902969101642737)
,p_db_column_name=>'FDR_PRECIO'
,p_display_order=>417
,p_column_identifier=>'BN'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097903074764642738)
,p_db_column_name=>'DESC_LOCALIZACION'
,p_display_order=>427
,p_column_identifier=>'BO'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097903178432642739)
,p_db_column_name=>'DESC_DEPARTAMENTO'
,p_display_order=>437
,p_column_identifier=>'BP'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097903225049642740)
,p_db_column_name=>'FRS_REC_NUMERO_RECIBO'
,p_display_order=>447
,p_column_identifier=>'BQ'
,p_column_label=>'Num. Recibo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097903344988642741)
,p_db_column_name=>'MONEDA_RESERVA'
,p_display_order=>457
,p_column_identifier=>'BR'
,p_column_label=>'Moneda reserva'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14098045435412487181)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'103018'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'FRS_EMP_EMPRESA:FRS_RESERVA:CREADO_POR:FRS_DOCUMENTO:FDR_ATO_ARTICULO:FDR_CANTIDAD:FDR_CANTIDAD_FACTURA:FDR_LCN_LOCALIZACION:DESC_LOCALIZACION:FDR_ORD_ORDEN_INTERNA:ESTADO:FDR_PRECIO:FECHA:FRS_DEP_DEPARTAMENTO:DESC_DEPARTAMENTO:VENDEDOR:NOMBRE_VEND:F'
||'RS_CLI_CLIENTE:FRS_NOMBRE:FRS_CLI_MON_MONEDA:FDR_IPA_PLAN::FRS_REC_NUMERO_RECIBO:MONEDA_RESERVA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14098046414239487245)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14098045949540487244)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098046765255487254)
,p_name=>'P118_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14098045949540487244)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098047793736487273)
,p_name=>'P118_INICIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14098045949540487244)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098048151639487274)
,p_name=>'P118_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14098045949540487244)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
