prompt --application/pages/page_00039
begin
--   Manifest
--     PAGE: 00039
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>39
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('BCO \2013 Saldos por Cuenta Bancaria')
,p_step_title=>'Saldos por Cuenta Bancaria'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163849'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167778316454658189)
,p_plug_name=>'Saldos por Cuenta Bancaria'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167776424811639186)
,p_plug_name=>'Saldos por Cuenta Bancaria'
,p_parent_plug_id=>wwv_flow_api.id(14167778316454658189)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT	a.mov_ctb_bco_emp_empresa empresa,',
'			a.mov_ctb_bco_banco banco,',
'			a.mov_ctb_cuenta cuenta,',
'			DECODE (a.mov_tipo_movimiento,',
'					  ''CHK'', ''Cheque'',',
'					  ''TEF'', ''Transferencia'',',
unistr('					  ''DEP'', ''Dep\00F3sito'','),
unistr('					  ''NC'', ''Nota de Cr\00E9dito'','),
unistr('					  ''ND'', ''Nota D\00E9bito'','),
unistr('					  ''OC'', ''Otros Cr\00E9ditos'','),
unistr('					  ''OD'', ''Otros D\00E9bitos'','),
'					  ''OTR'', ''Otros Movimientos'',',
'					  ''Inexsistente''',
'					 )',
'				tipo_mov,',
'			a.mov_monto monto,',
'			DECODE (bct_efecto, ''D'', a.mov_monto, 0) debitos,',
'			DECODE (bct_efecto, ''A'', a.mov_monto, 0) creditos,',
'			a.mov_bct_tipo,',
'			TRUNC(a.mov_fecha) mov_fecha,',
'			(SELECT	 SUM (DECODE (b.bct_efecto, ''A'', a.mov_monto, 0))',
'						 - SUM (DECODE (b.bct_efecto, ''D'', a.mov_monto, 0))',
'				FROM	 bco_movimiento_tr_nx c, bco_tipo_transaccion_tb_nx d',
'			  WHERE		  c.mov_ctb_bco_emp_empresa = :p39_empresa',
'						 AND c.mov_ctb_bco_banco = mov_ctb_bco_banco',
'						 AND c.mov_ctb_cuenta = a.mov_ctb_cuenta',
'						 AND c.mov_fecha < a.mov_fecha',
'						 AND d.bct_emp_empresa = c.mov_ctb_bco_emp_empresa',
'						 AND d.bct_tipo = c.mov_bct_tipo)',
'				saldo_inicial',
'  FROM	bco_movimiento_tr_nx a, bco_tipo_transaccion_tb_nx b',
' WHERE		 mov_status <> ''C''',
'			AND mov_ctb_bco_emp_empresa = :p39_empresa',
'			AND mov_fecha BETWEEN :p39_inicio AND to_date(:p39_fin||'' 23:59'', ''dd/mm/rrrr hh24:mi'')',
'			AND bct_emp_empresa = mov_ctb_bco_emp_empresa',
'			AND bct_tipo = mov_bct_tipo'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P39_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14167776499613639186)
,p_name=>'Saldo por Cuenta Contable'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10662606202139886
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167776709324639333)
,p_db_column_name=>'EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167776814349639346)
,p_db_column_name=>'BANCO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Banco'
,p_column_type=>'STRING'
,p_static_id=>'BANCO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167776896801639346)
,p_db_column_name=>'CUENTA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167777002734639347)
,p_db_column_name=>'TIPO_MOV'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Tipo Mov'
,p_column_type=>'STRING'
,p_static_id=>'TIPO_MOV'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167777095678639347)
,p_db_column_name=>'MONTO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'MONTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167777200928639347)
,p_db_column_name=>'DEBITOS'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Debitos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'DEBITOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167777306377639348)
,p_db_column_name=>'CREDITOS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Creditos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CREDITOS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167777397508639348)
,p_db_column_name=>'MOV_BCT_TIPO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Mov Bct Tipo'
,p_column_type=>'STRING'
,p_static_id=>'MOV_BCT_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167777497279639349)
,p_db_column_name=>'MOV_FECHA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Mov Fecha'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'MOV_FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167780421773545449)
,p_db_column_name=>'SALDO_INICIAL'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Saldo Inicial'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'SALDO_INICIAL'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14167777623118641174)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'106638'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:BANCO:CUENTA:TIPO_MOV:MONTO:DEBITOS:CREDITOS:MOV_BCT_TIPO:MOV_FECHA:APXWS_CC_001:'
,p_sum_columns_on_break=>'DEBITOS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168170420756696807)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14167778316454658189)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167778494582658225)
,p_name=>'P39_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14167778316454658189)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167778708268658274)
,p_name=>'P39_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14167778316454658189)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167778901284658276)
,p_name=>'P39_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14167778316454658189)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
