prompt --application/pages/page_00139
begin
--   Manifest
--     PAGE: 00139
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>139
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'RRHH-Tiempo de Servicio'
,p_step_title=>'RRHH-Tiempo de Servicio'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ESALAS'
,p_last_upd_yyyymmddhh24miss=>'20210507151029'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14316953712185535802)
,p_plug_name=>'Tiempo de servicio'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14316957012892572471)
,p_plug_name=>'Tiempo de servicio'
,p_parent_plug_id=>wwv_flow_api.id(14316953712185535802)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 09/11/2017 02:11:23 p.m. (QP5 v5.115.810.9015) */',
'  SELECT   EPL_PER_PERSONA AS Persona,',
'           GNL_PERSONA_TR_NX.NOMBRE AS Nombre,',
'           APELLIDOS AS Apellidos,',
'           fecha_nacimiento AS fercha_nacimiento,',
'           EPL_FECHA_INGRESO AS Fecha_ingreso,',
'           TRUNC(MONTHS_BETWEEN (TO_DATE (SYSDATE, ''DD/MM/YYYY''),',
'                                 TO_DATE (EPL_FECHA_INGRESO, ''DD/MM/YYYY''))',
'                 / 12)',
'              AS anios,',
'           TRUNC(MOD (',
'                    MONTHS_BETWEEN (TO_DATE (SYSDATE, ''DD/MM/YYYY''),',
'                                    TO_DATE (EPL_FECHA_INGRESO, ''DD/MM/YYYY'')),',
'                    12',
'                 ))',
'              AS meses,',
'           TO_DATE (SYSDATE, ''DD/MM/YYYY'')',
'           - ADD_MONTHS (',
'                EPL_FECHA_INGRESO,',
'                TRUNC(MONTHS_BETWEEN (',
'                         TO_DATE (SYSDATE, ''DD/MM/YYYY''),',
'                         TO_DATE (EPL_FECHA_INGRESO, ''DD/MM/YYYY'')',
'                      ))',
'             )',
'              AS dias,',
'               DECODE (epl_estado,',
'                 ''A'',',
'                 ''ACTIVO'',',
'                 ''I'',',
'                 ''INACTIVO''',
'                )',
'            ESTADO,',
'           rhu_saldo_vacaciones_n_nx (EPL_PER_PERSONA) AS Saldo',
'    FROM   RHU_EMPLEADO_TB_NX, GNL_PERSONA_TR_NX, DUAL',
'   WHERE   INSTR ('':'' || :p139_empresa || '':'', '':'' || EPL_EMP_EMPRESA || '':'') >',
'              0',
'           AND EPL_FECHA_INGRESO BETWEEN :p139_inicio',
'                                     AND  TO_DATE (:p139_fin || '' 23:59'',',
'                                                   ''dd/mm/rrrr hh24:mi'')',
'           AND EPL_PER_PERSONA = PERSONA',
'ORDER BY   EPL_PER_PERSONA'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_required_role=>wwv_flow_api.id(14193430675880859352)
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P139_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14316957106361572472)
,p_name=>'Compras'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'RMORALES'
,p_internal_uid=>253937375921356213
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084057584995071374)
,p_db_column_name=>'PERSONA'
,p_display_order=>10
,p_column_identifier=>'AI'
,p_column_label=>'Persona'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084058421192071381)
,p_db_column_name=>'APELLIDOS'
,p_display_order=>30
,p_column_identifier=>'AK'
,p_column_label=>'Apellidos'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084058792096071382)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>40
,p_column_identifier=>'AL'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084059185005071383)
,p_db_column_name=>'ANIOS'
,p_display_order=>50
,p_column_identifier=>'AM'
,p_column_label=>unistr('A\00F1os')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084059567684071383)
,p_db_column_name=>'MESES'
,p_display_order=>60
,p_column_identifier=>'AN'
,p_column_label=>'Meses'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084059938832071384)
,p_db_column_name=>'DIAS'
,p_display_order=>70
,p_column_identifier=>'AO'
,p_column_label=>unistr('D\00EDas')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084060333304071385)
,p_db_column_name=>'SALDO'
,p_display_order=>80
,p_column_identifier=>'AP'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083999161106291964)
,p_db_column_name=>'NOMBRE'
,p_display_order=>90
,p_column_identifier=>'AQ'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217117234664847)
,p_db_column_name=>'FERCHA_NACIMIENTO'
,p_display_order=>100
,p_column_identifier=>'AR'
,p_column_label=>'Fercha Nacimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13885217261431664849)
,p_db_column_name=>'ESTADO'
,p_display_order=>110
,p_column_identifier=>'AS'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14316958513931572776)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'210410'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TTM_LOC_ID::EMPLEADO_EMPLEADO:PERSONA:APELLIDOS:FECHA_INGRESO:ANIOS:MESES:DIAS:SALDO:FERCHA_NACIMIENTO:ESTADO'
,p_sum_columns_on_break=>'CED_SUBTOTAL:CED_DESCUENTO:CED_IMPUESTO:CED_OTROS_IMPUESTOS:CED_TOTAL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14084055644279071367)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14316953712185535802)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084056062035071369)
,p_name=>'P139_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14316953712185535802)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084056479147071372)
,p_name=>'P139_INICIO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14316953712185535802)
,p_prompt=>'Inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'RETURN TRUNC (SYSDATE, ''MM'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084056846326071372)
,p_name=>'P139_FIN'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14316953712185535802)
,p_prompt=>'Fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'SYSDATE'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
