prompt --application/pages/page_00082
begin
--   Manifest
--     PAGE: 00082
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>82
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'COM - Costos de Importacion Articulos'
,p_step_title=>'Costos de Importacion Articulos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104164549'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095032515247647435)
,p_plug_name=>'Costos de Importacion Articulos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14095034778558647442)
,p_plug_name=>'Costos de Importacion Articulos'
,p_parent_plug_id=>wwv_flow_api.id(14095032515247647435)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 18/01/2017 10:21:25 a.m. (QP5 v5.115.810.9015) */',
'SELECT   DED_ID,',
'         DED_EMP_EMPRESA,',
'         DED_ORDEN,',
'         DED_PROVEEDOR,',
'         DED_MONEDA_PROVEEDOR,',
'         cxp_nombre_prov_v_nx(',
'          ded_emp_empresa',
'         ,ded_proveedor',
'         ,ded_moneda_proveedor',
'        ) nombre_proveedor,',
'        ato_descripcion descripcion_art,',
'        inv_descrip_fam_v_nx (',
'            ato_emp_empresa,',
'            ato_fma_familia',
'        ) descripcion_familia,',
'         DED_DPC_DESPACHO,',
'         DED_DDF_LINEA,',
'         DED_CEC_ESQUEMA,',
'         COM_DESCRIP_ESQ_V_NX (DED_EMP_EMPRESA, DED_CEC_ESQUEMA) DESC_ESQUEMA,',
'         DED_TET_TIPO,',
'         TET_DESCRIPCION TIPO_ETAPA,',
'         CASE TET_ACCION',
'         WHEN ''S'' THEN',
'         ''Seguimiento''',
'         WHEN ''F'' THEN',
'         ''Factura''',
'         WHEN ''O'' THEN',
'         ''Gestion Operativa''',
'         WHEN ''I'' THEN',
'         ''Gestion Informativa''',
'         ELSE',
'         ''S/D''',
'         END TET_ACCION,',
'         CASE TET_MANEJO_ETAPA',
'         WHEN ''M'' THEN',
'         ''Modificacion''',
'         WHEN ''B'' THEN',
'         ''Base''',
'         WHEN ''P'' THEN',
'         ''Preliquidacion''',
'         WHEN ''E'' THEN',
'         ''Entrega''',
'         WHEN ''U'' THEN',
'         ''Ultima''',
'         WHEN ''N'' THEN',
'         ''Normal''',
'         ELSE',
'         ''S/D''',
'         END TET_MANEJO,',
'         DED_CODIGO,',
'         DED_CANTIDAD_ORIGINAL,',
'         DED_CANTIDAD_ETAPA,',
'         DED_DOC_DOCUMENTO,',
'         DED_DOCUMENTO,',
'         DED_TIEMPO_ESTIMADO,',
'         DED_UNIDAD_TIEMPO,',
'         TRUNC (DED_FECHA_INICIAL) DED_FECHA_INICIAL,',
'         TRUNC (DED_FECHA_FIN) DED_FECHA_FIN,',
'         DED_COSTO_UNITARIO,',
'         DED_PRECIO,',
'         DED_DESCUENTO,',
'         DED_CED_ETAPA,',
'         DED_IMPORTACION_TERMINADA,',
'         DED_NO_DEPENDIENTE,',
'         DED_ETAPA_TERMINADA,',
'         DED_DED_ID,',
'         DED_PARTICION,',
'         DED_IND_LIQUIDAR,',
'         DED_CREADO_POR,',
'         TRUNC (DED_FECHA_CREACION) DED_FECHA_CREACION,',
'         DED_MODIFICADO_POR,',
'         TRUNC (DED_FECHA_MODIFICACION) DED_FECHA_MODIFICACION,',
'         DED_IND_MULTIPLE,',
'         DED_REEMPLAZO,',
'         DED_ARCHIVO_EMBARQUE,',
'         DED_NUMERO_DECLARACION,',
'         DED_NUMERO_LEVANTE,',
'         TRUNC (DED_FECHA_LEVANTE) DED_FECHA_LEVANTE,',
'         DED_INTERMEDIARIO_ADUANERO,',
'         DED_ADUANA_DE,',
'         DED_CANCELACION_DERECHOS,',
'         DED_NUM_ACEPTACION,',
'         TRUNC (DED_FECHA_ACEPTACION) DED_FECHA_ACEPTACION,',
'         TRUNC (DED_FECHA_CANCELACION) DED_FECHA_CANCELACION,',
'         DED_PUERTO_ENTRADA,',
'         DED_PAIS_ORIGEN,',
'         DED_NUMERO_CERTIFICADO_CPNI,',
'         TRUNC (DED_FECHA_EMISION_CPNI) DED_FECHA_EMISION_CPNI,',
'         TRUNC (DED_FECHA_APROBACION_CPNI) DED_FECHA_APROBACION_CPNI,',
'         DED_NUMERO_SOLICITUD_AD,',
'         TRUNC (DED_FECHA_EMISION_SAD) DED_FECHA_EMISION_SAD,',
'         TRUNC (DED_FECHA_RECIBO_BCO_SAD) DED_FECHA_RECIBO_BCO_SAD,',
'         DED_CODIGO_AAD,',
'         TRUNC (DED_FECHA_EMISION_CODIGO_AAD) DED_FECHA_EMISION_CODIGO_AAD,',
'         DED_CODIGO_ALD,',
'         TRUNC (DED_FECHA_EMISION_ALD) DED_FECHA_EMISION_ALD,',
'         DED_NUMERO_CARTA_CREDITO,',
'         DED_INDICADOR_CONTROL_DIVISAS,',
'         DED_FOB_UNIT,',
'         DED_FREIGHT_UNIT,',
'         DED_INSURANCE_UNIT,',
'         DED_INTEREST_UNIT,',
'         DED_NUMERO_PLANILLA_LIQ_GRAV,',
'         TRUNC (DED_FECHA_PLANILLA_LIQ_GRAV) DED_FECHA_PLANILLA_LIQ_GRAV,',
'         DED_NUMERO_FACT_ADQUISICION,',
'         TRUNC (DED_FECHA_FACT_ADQUISICION) DED_FECHA_FACT_ADQUISICION,',
'         CED_NUM_DOC NRO_DOCUMENTO,',
'         CED_REFERENCIA,',
'         CED_TTM_TIPO,',
'         CED_TSP_TRANSACCION,',
'         Gnl_Valor_Cambio_N_Nx (ced_fecha, ced_pro_mon_moneda, ',
'                                gnl_parametro_emp_v_nx(ced_emp_empresa,''INV'',''TIPO CAMBIO CONVERSION MONEDA BASE DESDE ''|| ced_pro_mon_moneda)',
'                                ) ced_tipo_cambio,',
'   (SELECT deg_fecha_Creacion',
'          FROM COM_DET_ENTREGA_TB_NX',
'         WHERE     DEG_DDF_DPC_DESPACHO = DED_DPC_DESPACHO',
'               AND DEG_DDF_LINEA = DED_DDF_LINEA',
'                AND rownum = 1) fecha_entrega    ',
'  FROM   COM_DET_ETAPA_DESPACHO_TB_NX, COM_TIPO_ETAPA_TB_NX, COM_ETAPA_DESPACHO_TB_NX, INV_ARTICULO_TB_NX',
' WHERE   INSTR ('':'' || :P82_EMPRESA || '':'','':'' || DED_EMP_EMPRESA || '':'') > 0 ',
'         AND DED_EMP_EMPRESA = TET_EMP_EMPRESA',
'         AND DED_TET_TIPO = TET_TIPO',
'         AND DED_CED_ETAPA = CED_ETAPA',
'         AND DED_EMP_EMPRESA = ATO_EMP_EMPRESA',
'         AND DED_CODIGO = ATO_ARTICULO',
'         AND ATO_ITEMIZADO = ''N''',
'         AND CED_FECHA BETWEEN :P82_INICIO',
'                                    AND  TO_DATE (:P82_FIN || '' 23:59'',',
'                                                  ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P82_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14095035199263647443)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'WJIMENEZ'
,p_internal_uid=>7291474491758349
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986095911497026)
,p_db_column_name=>'DED_ID'
,p_display_order=>10
,p_column_identifier=>'BF'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986130035497027)
,p_db_column_name=>'DED_EMP_EMPRESA'
,p_display_order=>20
,p_column_identifier=>'BG'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986278812497028)
,p_db_column_name=>'DED_ORDEN'
,p_display_order=>30
,p_column_identifier=>'BH'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986361038497029)
,p_db_column_name=>'DED_PROVEEDOR'
,p_display_order=>40
,p_column_identifier=>'BI'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986480057497030)
,p_db_column_name=>'DED_MONEDA_PROVEEDOR'
,p_display_order=>50
,p_column_identifier=>'BJ'
,p_column_label=>'Moneda Proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986622476497031)
,p_db_column_name=>'DED_DPC_DESPACHO'
,p_display_order=>60
,p_column_identifier=>'BK'
,p_column_label=>'Despacho'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986695407497032)
,p_db_column_name=>'DED_DDF_LINEA'
,p_display_order=>70
,p_column_identifier=>'BL'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986741147497033)
,p_db_column_name=>'DED_CEC_ESQUEMA'
,p_display_order=>80
,p_column_identifier=>'BM'
,p_column_label=>'Esquema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986891070497034)
,p_db_column_name=>'DED_TET_TIPO'
,p_display_order=>90
,p_column_identifier=>'BN'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094986987318497035)
,p_db_column_name=>'DED_CODIGO'
,p_display_order=>100
,p_column_identifier=>'BO'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094987107652497036)
,p_db_column_name=>'DED_CANTIDAD_ORIGINAL'
,p_display_order=>110
,p_column_identifier=>'BP'
,p_column_label=>'Cantidad Original'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094987211126497037)
,p_db_column_name=>'DED_CANTIDAD_ETAPA'
,p_display_order=>120
,p_column_identifier=>'BQ'
,p_column_label=>'Cantidad Etapa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094987247430497038)
,p_db_column_name=>'DED_DOC_DOCUMENTO'
,p_display_order=>130
,p_column_identifier=>'BR'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094987483141497040)
,p_db_column_name=>'DED_TIEMPO_ESTIMADO'
,p_display_order=>150
,p_column_identifier=>'BT'
,p_column_label=>'Tiempo Estimado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094987595494497041)
,p_db_column_name=>'DED_UNIDAD_TIEMPO'
,p_display_order=>160
,p_column_identifier=>'BU'
,p_column_label=>'Unidad Tiempo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094987707125497042)
,p_db_column_name=>'DED_FECHA_INICIAL'
,p_display_order=>170
,p_column_identifier=>'BV'
,p_column_label=>'Fecha Inicial'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094987808974497043)
,p_db_column_name=>'DED_FECHA_FIN'
,p_display_order=>180
,p_column_identifier=>'BW'
,p_column_label=>'Fecha Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14094987914698497044)
,p_db_column_name=>'DED_COSTO_UNITARIO'
,p_display_order=>190
,p_column_identifier=>'BX'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095059721857679295)
,p_db_column_name=>'DED_PRECIO'
,p_display_order=>200
,p_column_identifier=>'BY'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095059761319679296)
,p_db_column_name=>'DED_DESCUENTO'
,p_display_order=>210
,p_column_identifier=>'BZ'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095059875301679297)
,p_db_column_name=>'DED_CED_ETAPA'
,p_display_order=>220
,p_column_identifier=>'CA'
,p_column_label=>'Etapa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095059965482679298)
,p_db_column_name=>'DED_IMPORTACION_TERMINADA'
,p_display_order=>230
,p_column_identifier=>'CB'
,p_column_label=>'Importacion Terminada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060073962679299)
,p_db_column_name=>'DED_NO_DEPENDIENTE'
,p_display_order=>240
,p_column_identifier=>'CC'
,p_column_label=>'Dependiente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060155590679300)
,p_db_column_name=>'DED_ETAPA_TERMINADA'
,p_display_order=>250
,p_column_identifier=>'CD'
,p_column_label=>'Etapa Terminada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060236983679301)
,p_db_column_name=>'DED_DED_ID'
,p_display_order=>260
,p_column_identifier=>'CE'
,p_column_label=>'Ded Ded Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060402437679302)
,p_db_column_name=>'DED_PARTICION'
,p_display_order=>270
,p_column_identifier=>'CF'
,p_column_label=>'Particion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060458974679303)
,p_db_column_name=>'DED_IND_LIQUIDAR'
,p_display_order=>280
,p_column_identifier=>'CG'
,p_column_label=>'Liquidar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060622127679304)
,p_db_column_name=>'DED_CREADO_POR'
,p_display_order=>290
,p_column_identifier=>'CH'
,p_column_label=>'Creado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060712674679305)
,p_db_column_name=>'DED_FECHA_CREACION'
,p_display_order=>300
,p_column_identifier=>'CI'
,p_column_label=>'Fecha Creacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060736077679306)
,p_db_column_name=>'DED_MODIFICADO_POR'
,p_display_order=>310
,p_column_identifier=>'CJ'
,p_column_label=>'Modificado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060911263679307)
,p_db_column_name=>'DED_FECHA_MODIFICACION'
,p_display_order=>320
,p_column_identifier=>'CK'
,p_column_label=>'Fecha Modificacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095060997943679308)
,p_db_column_name=>'DED_IND_MULTIPLE'
,p_display_order=>330
,p_column_identifier=>'CL'
,p_column_label=>'Multiple'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061046187679309)
,p_db_column_name=>'DED_REEMPLAZO'
,p_display_order=>340
,p_column_identifier=>'CM'
,p_column_label=>'Reemplazo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061152763679310)
,p_db_column_name=>'DED_ARCHIVO_EMBARQUE'
,p_display_order=>350
,p_column_identifier=>'CN'
,p_column_label=>'Archivo Embarque'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061250372679311)
,p_db_column_name=>'DED_NUMERO_DECLARACION'
,p_display_order=>360
,p_column_identifier=>'CO'
,p_column_label=>'Numero Declaracion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061409752679312)
,p_db_column_name=>'DED_NUMERO_LEVANTE'
,p_display_order=>370
,p_column_identifier=>'CP'
,p_column_label=>'Numero Levante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061460775679313)
,p_db_column_name=>'DED_FECHA_LEVANTE'
,p_display_order=>380
,p_column_identifier=>'CQ'
,p_column_label=>'Fecha Levante'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061532387679314)
,p_db_column_name=>'DED_INTERMEDIARIO_ADUANERO'
,p_display_order=>390
,p_column_identifier=>'CR'
,p_column_label=>'Intermediario Aduanero'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061626094679315)
,p_db_column_name=>'DED_ADUANA_DE'
,p_display_order=>400
,p_column_identifier=>'CS'
,p_column_label=>'Aduana De'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061750847679316)
,p_db_column_name=>'DED_CANCELACION_DERECHOS'
,p_display_order=>410
,p_column_identifier=>'CT'
,p_column_label=>'Cancelacion Derechos'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061876634679317)
,p_db_column_name=>'DED_NUM_ACEPTACION'
,p_display_order=>420
,p_column_identifier=>'CU'
,p_column_label=>'Num Aceptacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095061997841679318)
,p_db_column_name=>'DED_FECHA_ACEPTACION'
,p_display_order=>430
,p_column_identifier=>'CV'
,p_column_label=>'Fecha Aceptacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062039565679319)
,p_db_column_name=>'DED_FECHA_CANCELACION'
,p_display_order=>440
,p_column_identifier=>'CW'
,p_column_label=>'Fecha Cancelacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062206927679320)
,p_db_column_name=>'DED_PUERTO_ENTRADA'
,p_display_order=>450
,p_column_identifier=>'CX'
,p_column_label=>'Puerto Entrada'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062259409679321)
,p_db_column_name=>'DED_PAIS_ORIGEN'
,p_display_order=>460
,p_column_identifier=>'CY'
,p_column_label=>'Pais Origen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062328782679322)
,p_db_column_name=>'DED_NUMERO_CERTIFICADO_CPNI'
,p_display_order=>470
,p_column_identifier=>'CZ'
,p_column_label=>'Numero Certificado Cpni'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062464584679323)
,p_db_column_name=>'DED_FECHA_EMISION_CPNI'
,p_display_order=>480
,p_column_identifier=>'DA'
,p_column_label=>'Fecha Emision Cpni'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062579325679324)
,p_db_column_name=>'DED_FECHA_APROBACION_CPNI'
,p_display_order=>490
,p_column_identifier=>'DB'
,p_column_label=>'Fecha Aprobacion Cpni'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062707667679325)
,p_db_column_name=>'DED_NUMERO_SOLICITUD_AD'
,p_display_order=>500
,p_column_identifier=>'DC'
,p_column_label=>'Numero Solicitud Ad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062794638679326)
,p_db_column_name=>'DED_FECHA_EMISION_SAD'
,p_display_order=>510
,p_column_identifier=>'DD'
,p_column_label=>'Fecha Emision Sad'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062916553679327)
,p_db_column_name=>'DED_FECHA_RECIBO_BCO_SAD'
,p_display_order=>520
,p_column_identifier=>'DE'
,p_column_label=>'Fecha Recibo Bco Sad'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095062984670679328)
,p_db_column_name=>'DED_CODIGO_AAD'
,p_display_order=>530
,p_column_identifier=>'DF'
,p_column_label=>'Codigo Aad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063059345679329)
,p_db_column_name=>'DED_FECHA_EMISION_CODIGO_AAD'
,p_display_order=>540
,p_column_identifier=>'DG'
,p_column_label=>'Fecha Emision Codigo Aad'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063150148679330)
,p_db_column_name=>'DED_CODIGO_ALD'
,p_display_order=>550
,p_column_identifier=>'DH'
,p_column_label=>'Codigo Ald'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063279188679331)
,p_db_column_name=>'DED_FECHA_EMISION_ALD'
,p_display_order=>560
,p_column_identifier=>'DI'
,p_column_label=>'Fecha Emision Ald'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063417269679332)
,p_db_column_name=>'DED_NUMERO_CARTA_CREDITO'
,p_display_order=>570
,p_column_identifier=>'DJ'
,p_column_label=>'Numero Carta Credito'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063474695679333)
,p_db_column_name=>'DED_INDICADOR_CONTROL_DIVISAS'
,p_display_order=>580
,p_column_identifier=>'DK'
,p_column_label=>'Indicador Control Divisas'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063561557679334)
,p_db_column_name=>'DED_FOB_UNIT'
,p_display_order=>590
,p_column_identifier=>'DL'
,p_column_label=>'Fob Unit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063689122679335)
,p_db_column_name=>'DED_FREIGHT_UNIT'
,p_display_order=>600
,p_column_identifier=>'DM'
,p_column_label=>'Freight Unit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063746079679336)
,p_db_column_name=>'DED_INSURANCE_UNIT'
,p_display_order=>610
,p_column_identifier=>'DN'
,p_column_label=>'Insurance Unit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095063867070679337)
,p_db_column_name=>'DED_INTEREST_UNIT'
,p_display_order=>620
,p_column_identifier=>'DO'
,p_column_label=>'Interest Unit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095064007091679338)
,p_db_column_name=>'DED_NUMERO_PLANILLA_LIQ_GRAV'
,p_display_order=>630
,p_column_identifier=>'DP'
,p_column_label=>'Numero Planilla Liq Grav'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095064110739679339)
,p_db_column_name=>'DED_FECHA_PLANILLA_LIQ_GRAV'
,p_display_order=>640
,p_column_identifier=>'DQ'
,p_column_label=>'Fecha Planilla Liq Grav'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095064213260679340)
,p_db_column_name=>'DED_NUMERO_FACT_ADQUISICION'
,p_display_order=>650
,p_column_identifier=>'DR'
,p_column_label=>'Numero Fact Adquisicion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095064255031679341)
,p_db_column_name=>'DED_FECHA_FACT_ADQUISICION'
,p_display_order=>660
,p_column_identifier=>'DS'
,p_column_label=>'Fecha Fact Adquisicion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900842283642716)
,p_db_column_name=>'DESC_ESQUEMA'
,p_display_order=>670
,p_column_identifier=>'DT'
,p_column_label=>'Desc. Esquema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097900967695642717)
,p_db_column_name=>'TIPO_ETAPA'
,p_display_order=>680
,p_column_identifier=>'DU'
,p_column_label=>'Desc. Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082672580613943307)
,p_db_column_name=>'TET_ACCION'
,p_display_order=>690
,p_column_identifier=>'DV'
,p_column_label=>'Accion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082672704404943308)
,p_db_column_name=>'TET_MANEJO'
,p_display_order=>700
,p_column_identifier=>'DW'
,p_column_label=>'Manejo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084102557173032663)
,p_db_column_name=>'CED_REFERENCIA'
,p_display_order=>720
,p_column_identifier=>'DY'
,p_column_label=>'Referencia'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084102666131032664)
,p_db_column_name=>'CED_TTM_TIPO'
,p_display_order=>730
,p_column_identifier=>'DZ'
,p_column_label=>'Tipo Trn.'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084102811080032665)
,p_db_column_name=>'CED_TSP_TRANSACCION'
,p_display_order=>740
,p_column_identifier=>'EA'
,p_column_label=>'Transaccion CxP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084103330588032671)
,p_db_column_name=>'CED_TIPO_CAMBIO'
,p_display_order=>750
,p_column_identifier=>'EB'
,p_column_label=>'Tipo Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086978550614568379)
,p_db_column_name=>'NRO_DOCUMENTO'
,p_display_order=>760
,p_column_identifier=>'EC'
,p_column_label=>'Nro documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14086978706103568380)
,p_db_column_name=>'FECHA_ENTREGA'
,p_display_order=>770
,p_column_identifier=>'ED'
,p_column_label=>'Fecha entrega'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058209109203913588)
,p_db_column_name=>'DED_DOCUMENTO'
,p_display_order=>780
,p_column_identifier=>'EE'
,p_column_label=>'Ded documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958105513248942803)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>790
,p_column_identifier=>'EF'
,p_column_label=>'Nombre Proveedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958105628734942804)
,p_db_column_name=>'DESCRIPCION_ART'
,p_display_order=>800
,p_column_identifier=>'EG'
,p_column_label=>unistr('Descripci\00F3n Art\00EDculo')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13958105727361942805)
,p_db_column_name=>'DESCRIPCION_FAMILIA'
,p_display_order=>810
,p_column_identifier=>'EH'
,p_column_label=>unistr('Descripci\00F3n Familia')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14095258678111088931)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75150'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DED_ID:DED_EMP_EMPRESA:DED_ORDEN:DED_PROVEEDOR:DED_MONEDA_PROVEEDOR:DED_DPC_DESPACHO:DED_DDF_LINEA:DED_CEC_ESQUEMA:DESC_ESQUEMA:DED_TET_TIPO:TIPO_ETAPA:TET_ACCION:TET_MANEJO:DED_CODIGO:DED_CANTIDAD_ORIGINAL:DED_CANTIDAD_ETAPA:DED_DOC_DOCUMENTO:DED_TI'
||'EMPO_ESTIMADO:DED_UNIDAD_TIEMPO:DED_FECHA_INICIAL:DED_FECHA_FIN:DED_COSTO_UNITARIO:DED_PRECIO:DED_DESCUENTO:DED_CED_ETAPA:DED_IMPORTACION_TERMINADA:DED_NO_DEPENDIENTE:DED_ETAPA_TERMINADA:DED_DED_ID:DED_PARTICION:DED_IND_LIQUIDAR:DED_CREADO_POR:DED_FE'
||'CHA_CREACION:DED_MODIFICADO_POR:DED_FECHA_MODIFICACION:DED_IND_MULTIPLE:DED_REEMPLAZO:DED_ARCHIVO_EMBARQUE:DED_NUMERO_DECLARACION:DED_NUMERO_LEVANTE:DED_FECHA_LEVANTE:DED_INTERMEDIARIO_ADUANERO:DED_ADUANA_DE:DED_CANCELACION_DERECHOS:DED_NUM_ACEPTACIO'
||'N:DED_FECHA_ACEPTACION:DED_FECHA_CANCELACION:DED_PUERTO_ENTRADA:DED_PAIS_ORIGEN:DED_NUMERO_CERTIFICADO_CPNI:DED_FECHA_EMISION_CPNI:DED_FECHA_APROBACION_CPNI:DED_NUMERO_SOLICITUD_AD:DED_FECHA_EMISION_SAD:DED_FECHA_RECIBO_BCO_SAD:DED_CODIGO_AAD:DED_FEC'
||'HA_EMISION_CODIGO_AAD:DED_CODIGO_ALD:DED_FECHA_EMISION_ALD:DED_NUMERO_CARTA_CREDITO:DED_INDICADOR_CONTROL_DIVISAS:DED_FOB_UNIT:DED_FREIGHT_UNIT:DED_INSURANCE_UNIT:DED_INTEREST_UNIT:DED_NUMERO_PLANILLA_LIQ_GRAV:DED_FECHA_PLANILLA_LIQ_GRAV:DED_NUMERO_F'
||'ACT_ADQUISICION:DED_FECHA_FACT_ADQUISICION::CED_REFERENCIA:CED_TTM_TIPO:CED_TSP_TRANSACCION:CED_TIPO_CAMBIO:FECHA_ENTREGA:NOMBRE_PROVEEDOR:DESCRIPCION_ART:DESCRIPCION_FAMILIA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14095032879101647436)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14095032515247647435)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095033234554647437)
,p_name=>'P82_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14095032515247647435)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095033640884647438)
,p_name=>'P82_INICIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14095032515247647435)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14095034096738647440)
,p_name=>'P82_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14095032515247647435)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
