prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('KJE \2013 Detalle Modos de Pago')
,p_step_title=>'Detalle Modos de Pago'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>unistr('No hay ayuda disponible para esta p\00E1gina.')
,p_last_updated_by=>'MBACASE'
,p_last_upd_yyyymmddhh24miss=>'20210311102550'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14192758961123809459)
,p_plug_name=>'Detalle Modos de Pago'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14192888652294946309)
,p_plug_name=>'Detalle Modos de Pago'
,p_parent_plug_id=>wwv_flow_api.id(14192758961123809459)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Formatted on 06/02/2017 03:51:58 p.m. (QP5 v5.115.810.9015) */',
'SELECT   KMP_EMPRESA AS KMP_EMPRESA,',
'         KMP_DEPARTAMENTO AS KMP_DEPARTAMENTO,',
'         cgl_nombre_depto_v_nx (KMP_EMPRESA,',
'                                KMP_DEPARTAMENTO)',
'            DESC_DEPARTAMENTO,',
'         KMP_CAJA AS KMP_CAJA,',
'         KMP_TIPO_PAGO AS KMP_TIPO_PAGO,',
'         KMP_NOMBRE_PAGO AS KMP_NOMBRE_PAGO,',
'         KMP_ORIGEN AS KMP_ORIGEN,',
'         KMP_TRANSACCION AS KMP_TRANSACCION,',
'         KMP_NUMERO_FACTURA AS KMP_NUMERO_FACTURA,',
'         TRUNC (KMP_FECHA) AS KMP_FECHA,',
'         KMP_MONEDA AS KMP_MONEDA,',
'         KMP_MONTO AS KMP_MONTO,',
'         KMP_MONTO_TRANSACCION',
'            AS KMP_MONTO_TRANSACCION,',
'         KMP_CUENTA AS KMP_CUENTA,',
'         KMP_NUMERO AS KMP_NUMERO,',
'         KMP_AUTORIZACION AS KMP_AUTORIZACION,',
'         KMP_IND_DEPOSITO AS KMP_IND_DEPOSITO,',
'         KMP_HOJA AS KMP_HOJA,',
'         KMP_CREADO_POR AS KMP_CREADO_POR,',
'         KMP_CLIENTE,',
'         KMP_NOMBRE,',
'         KMP_ANULADO,',
'         KMP_FECHA_LIQUIDACION,',
'         KMP_USUARIO_LIQUIDA,',
'         KMP_STATUS,',
'         KMP_TIPO_TRANSACCION,',
'         KMP_DESCRIPCION,',
'         KMP_CHKBOL,',
'         KMP_COD_REMISION,',
'         KMP_COBRADOR,',
'         KMP_GRUPO_CTA,',
'         KMP_GRUPO_CTA_DESC,',
'         KMP_GRUPO_CTA_PADRE',
'  FROM   KJE_MODOS_DE_PAGO_VW_NX ',
' WHERE   INSTR ('':'' || :P5_EMPRESA || '':'', '':'' || KMP_EMPRESA || '':'') > 0',
'         AND KMP_FECHA BETWEEN :P5_FECHA_INICIO',
'                           AND  TO_DATE (:P5_FECHA_FIN || '' 23:59'',',
'                                         ''dd/mm/rrrr hh24:mi'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P5_EMPRESA'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14192888777431946310)
,p_name=>'Detalle Modos de Pago'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'EPICADO'
,p_internal_uid=>6889425312760633
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192888960419946318)
,p_db_column_name=>'KMP_EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'KMP_EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889071160946318)
,p_db_column_name=>'KMP_DEPARTAMENTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_static_id=>'KMP_DEPARTAMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889159524946319)
,p_db_column_name=>'KMP_CAJA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Caja'
,p_column_type=>'STRING'
,p_static_id=>'KMP_CAJA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889259849946319)
,p_db_column_name=>'KMP_TIPO_PAGO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Tipo Pago'
,p_column_type=>'STRING'
,p_static_id=>'KMP_TIPO_PAGO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889370318946319)
,p_db_column_name=>'KMP_NOMBRE_PAGO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Nombre Pago'
,p_column_type=>'STRING'
,p_static_id=>'KMP_NOMBRE_PAGO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889472424946320)
,p_db_column_name=>'KMP_ORIGEN'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_static_id=>'KMP_ORIGEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889559996946320)
,p_db_column_name=>'KMP_TRANSACCION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>unistr('Transacci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'KMP_TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889659124946320)
,p_db_column_name=>'KMP_NUMERO_FACTURA'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Numero Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'KMP_NUMERO_FACTURA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889758515946321)
,p_db_column_name=>'KMP_FECHA'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'KMP_FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889866170946321)
,p_db_column_name=>'KMP_MONEDA'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'KMP_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192889976174946321)
,p_db_column_name=>'KMP_MONTO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KMP_MONTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192890053156946322)
,p_db_column_name=>'KMP_MONTO_TRANSACCION'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>unistr('Monto Transacci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'KMP_MONTO_TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192890160301946322)
,p_db_column_name=>'KMP_CUENTA'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_static_id=>'KMP_CUENTA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192890266281946322)
,p_db_column_name=>'KMP_NUMERO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>unistr('N\00FAmero')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'KMP_NUMERO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192890375604946323)
,p_db_column_name=>'KMP_AUTORIZACION'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>unistr('Autorizaci\00F3n')
,p_column_type=>'STRING'
,p_static_id=>'KMP_AUTORIZACION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192890467841946323)
,p_db_column_name=>'KMP_HOJA'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Hoja'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'KMP_HOJA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097481936072436441)
,p_db_column_name=>'KMP_IND_DEPOSITO'
,p_display_order=>26
,p_column_identifier=>'R'
,p_column_label=>'Liquidado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098316270053873818)
,p_db_column_name=>'DESC_DEPARTAMENTO'
,p_display_order=>36
,p_column_identifier=>'S'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098316330740873819)
,p_db_column_name=>'KMP_CREADO_POR'
,p_display_order=>46
,p_column_identifier=>'T'
,p_column_label=>'Creado Por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082581838822100307)
,p_db_column_name=>'KMP_CLIENTE'
,p_display_order=>56
,p_column_identifier=>'U'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14082581932365100308)
,p_db_column_name=>'KMP_NOMBRE'
,p_display_order=>66
,p_column_identifier=>'V'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083901006369692906)
,p_db_column_name=>'KMP_ANULADO'
,p_display_order=>76
,p_column_identifier=>'W'
,p_column_label=>'Anulado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087231329013160760)
,p_db_column_name=>'KMP_FECHA_LIQUIDACION'
,p_display_order=>86
,p_column_identifier=>'X'
,p_column_label=>'Fecha Liquidacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14087234490592160892)
,p_db_column_name=>'KMP_STATUS'
,p_display_order=>106
,p_column_identifier=>'Z'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14048920739873972849)
,p_db_column_name=>'KMP_USUARIO_LIQUIDA'
,p_display_order=>116
,p_column_identifier=>'AA'
,p_column_label=>'Kmp usuario liquida'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14048920769790972850)
,p_db_column_name=>'KMP_TIPO_TRANSACCION'
,p_display_order=>126
,p_column_identifier=>'AB'
,p_column_label=>'Tipo Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14048920876314972851)
,p_db_column_name=>'KMP_DESCRIPCION'
,p_display_order=>136
,p_column_identifier=>'AC'
,p_column_label=>'Descripcion Tipo Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001217001776589483)
,p_db_column_name=>'KMP_CHKBOL'
,p_display_order=>146
,p_column_identifier=>'AD'
,p_column_label=>'Cheque/Boleta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001217019941589484)
,p_db_column_name=>'KMP_COD_REMISION'
,p_display_order=>156
,p_column_identifier=>'AE'
,p_column_label=>'Cod. Remision'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14001217117970589485)
,p_db_column_name=>'KMP_COBRADOR'
,p_display_order=>166
,p_column_identifier=>'AF'
,p_column_label=>'Cobrador'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13901954796106818602)
,p_db_column_name=>'KMP_GRUPO_CTA'
,p_display_order=>176
,p_column_identifier=>'AG'
,p_column_label=>'Grupo Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13901954814030818603)
,p_db_column_name=>'KMP_GRUPO_CTA_DESC'
,p_display_order=>186
,p_column_identifier=>'AH'
,p_column_label=>unistr('Grupo Cuenta Descripci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13901954965627818604)
,p_db_column_name=>'KMP_GRUPO_CTA_PADRE'
,p_display_order=>196
,p_column_identifier=>'AI'
,p_column_label=>'Grupo de Cuenta Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14192890575150952892)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'68913'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'KMP_EMPRESA:KMP_DEPARTAMENTO:DESC_DEPARTAMENTO:KMP_CAJA:KMP_ORIGEN:KMP_TRANSACCION:KMP_NUMERO_FACTURA:KMP_FECHA:KMP_MONEDA:KMP_MONTO:KMP_MONTO_TRANSACCION:KMP_CUENTA:KMP_NUMERO:KMP_AUTORIZACION:KMP_HOJA:KMP_CREADO_POR:KMP_IND_DEPOSITO:KMP_CLIENTE:KMP'
||'_NOMBRE:KMP_ANULADO:KMP_FECHA_LIQUIDACION:KMP_STATUS:KMP_TIPO_TRANSACCION:KMP_DESCRIPCION:KMP_CHKBOL:KMP_COD_REMISION:KMP_COBRADOR:KMP_GRUPO_CTA:KMP_GRUPO_CTA_DESC:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168172796781753524)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14192758961123809459)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14096848277093516260)
,p_name=>'P5_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14192758961123809459)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14192795682321774416)
,p_name=>'P5_FECHA_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14192758961123809459)
,p_prompt=>'Fecha Inicio'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14192796067428796531)
,p_name=>'P5_FECHA_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14192758961123809459)
,p_prompt=>'Fecha Fin'
,p_format_mask=>'DD/MM/RRRR'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
