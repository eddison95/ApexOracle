prompt --application/pages/page_00048
begin
--   Manifest
--     PAGE: 00048
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>48
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('FAC \2013 Detalle de Facturas')
,p_step_title=>'Detalle de Facturas'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ESALAS'
,p_last_upd_yyyymmddhh24miss=>'20201229132911'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167873019610065941)
,p_plug_name=>'Detalle de Facturas'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14167868811549055100)
,p_plug_name=>'Detalle de Facturas'
,p_parent_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT c001 empresa,',
'       n001 factura,',
'       c002 tra_estado,',
'       n002 orden_taller,',
'       c003 padre_departamento,',
'       c004 desc_departamento_padre,',
'       c005 departamento,',
'       c006 desc_departamento,',
'       c007 localizacion,',
'       c008 desc_localizacion,',
'       c009 tipo_fact,',
'       TRUNC (d001) fecha_vencimiento,',
'       c010 tipo_transaccion,',
'       c011 documento,',
'       n003 t_cambio,',
'       c012 cod_vend,',
'       c013 nombre_vend,',
'       c014 cliente,',
'       c015 cedula,',
'       c016 moneda,',
'       c017 nombre,',
'       n004 transaccion,',
'       c018 tra_lpo_lista,',
'       c019 articulo,',
'       c020 descripcion,',
'       c021 codigo_familia,',
'       c022 familia,',
'       c023 familia_padre,',
'       c024 tipoarticulo,',
'       c025 clase,',
'       c026 moneda_lista,',
'       TO_NUMBER (c027) costo_unit,',
'       TO_NUMBER (c028) costo_total,',
'       TO_NUMBER (c029) cantidad,',
'       TO_NUMBER (c030) preciounitario,',
'       TO_NUMBER (c031) preciototal,',
'       TO_NUMBER (c032) descuento,',
'       TO_NUMBER (c033) impuesto,',
'       TO_NUMBER (c034) total,',
'       TRUNC (d002) fecha,',
'       c035 tipo_compra,',
'       TO_NUMBER (c036) total_notas,',
'       c037 itm_clr_color,',
'       c038 itm_serial,',
'       c039 itm_motor,',
'       c040 itm_chasis,',
'       c041 itm_ano,',
'       c042 creado_por,',
'       c043 cliente_reser,',
'       c044 cedula_reser,',
'       c045 cli_nombre_reser,',
'       TRUNC (d003) fecha_nota,',
'       TO_NUMBER (c046) monto_nota,',
'       TO_NUMBER (c047) descuento_nota,',
'       TO_NUMBER (c048) iva_nota,',
'       c049 nota,',
'       c050 comp_elect,',
'       tra_orden_compra orden_compra,',
'       tra_enc_consulta',
'FROM apex_collections,',
'     FAC_FACTURA_TB_NX ',
'WHERE collection_name = ''DETFAC'' AND n004 = tra_transaccion'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P48_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14167868924833055100)
,p_name=>'Detalle de Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>10755031421555800
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167869125101055104)
,p_db_column_name=>'EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_static_id=>'EMPRESA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167869196384055108)
,p_db_column_name=>'FACTURA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'FACTURA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167869403924055109)
,p_db_column_name=>'CLIENTE'
,p_display_order=>5
,p_column_identifier=>'D'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_static_id=>'CLIENTE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167869501067055109)
,p_db_column_name=>'MONEDA'
,p_display_order=>6
,p_column_identifier=>'E'
,p_column_label=>'Moneda Cliente'
,p_column_type=>'STRING'
,p_static_id=>'MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167869612293055109)
,p_db_column_name=>'NOMBRE'
,p_display_order=>7
,p_column_identifier=>'F'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167869702622055110)
,p_db_column_name=>'TRANSACCION'
,p_display_order=>8
,p_column_identifier=>'G'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167869803387055110)
,p_db_column_name=>'ARTICULO'
,p_display_order=>9
,p_column_identifier=>'H'
,p_column_label=>'Articulo'
,p_column_type=>'STRING'
,p_static_id=>'ARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167869911868055111)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870013886055111)
,p_db_column_name=>'CODIGO_FAMILIA'
,p_display_order=>11
,p_column_identifier=>'J'
,p_column_label=>'Familia'
,p_column_type=>'STRING'
,p_static_id=>'CODIGO_FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870102666055111)
,p_db_column_name=>'FAMILIA'
,p_display_order=>12
,p_column_identifier=>'K'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'FAMILIA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14112557581868214720)
,p_db_column_name=>'FAMILIA_PADRE'
,p_display_order=>13
,p_column_identifier=>'Z'
,p_column_label=>'Familia Padre'
,p_column_type=>'STRING'
,p_static_id=>'FAMILIA_PADRE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870216373055112)
,p_db_column_name=>'TIPOARTICULO'
,p_display_order=>14
,p_column_identifier=>'L'
,p_column_label=>'Tipo Articulo'
,p_column_type=>'STRING'
,p_static_id=>'TIPOARTICULO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870307892055112)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>15
,p_column_identifier=>'M'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'CANTIDAD'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870395465055113)
,p_db_column_name=>'PRECIOUNITARIO'
,p_display_order=>16
,p_column_identifier=>'N'
,p_column_label=>'Precio Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PRECIOUNITARIO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870509259055113)
,p_db_column_name=>'PRECIOTOTAL'
,p_display_order=>17
,p_column_identifier=>'O'
,p_column_label=>'Precio Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PRECIOTOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870613300055121)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>18
,p_column_identifier=>'P'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'DESCUENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870810379055122)
,p_db_column_name=>'IMPUESTO'
,p_display_order=>20
,p_column_identifier=>'R'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'IMPUESTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14167870895068055122)
,p_db_column_name=>'TOTAL'
,p_display_order=>21
,p_column_identifier=>'S'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'TOTAL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168014795797111374)
,p_db_column_name=>'COD_VEND'
,p_display_order=>22
,p_column_identifier=>'T'
,p_column_label=>'Codigo Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'COD_VEND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168014902492111375)
,p_db_column_name=>'NOMBRE_VEND'
,p_display_order=>23
,p_column_identifier=>'U'
,p_column_label=>'Nombre Vendedor'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE_VEND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168015024397111375)
,p_db_column_name=>'COSTO_UNIT'
,p_display_order=>24
,p_column_identifier=>'V'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'COSTO_UNIT'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P48_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168015113752111376)
,p_db_column_name=>'COSTO_TOTAL'
,p_display_order=>25
,p_column_identifier=>'W'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'COSTO_TOTAL'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_display_condition=>'P48_AUTO_CCA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14168063307991267155)
,p_db_column_name=>'FECHA'
,p_display_order=>26
,p_column_identifier=>'X'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'FECHA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14113195550974740844)
,p_db_column_name=>'ORDEN_TALLER'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Orden Taller'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ORDEN_TALLER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095028846637628815)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>37
,p_column_identifier=>'AB'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095028950834628816)
,p_db_column_name=>'TIPO_COMPRA'
,p_display_order=>47
,p_column_identifier=>'AC'
,p_column_label=>'Tipo Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14095131001777798828)
,p_db_column_name=>'TOTAL_NOTAS'
,p_display_order=>57
,p_column_identifier=>'AD'
,p_column_label=>'Total Notas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097326337125671337)
,p_db_column_name=>'ITM_CLR_COLOR'
,p_display_order=>67
,p_column_identifier=>'AE'
,p_column_label=>'Color'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097326504724671338)
,p_db_column_name=>'ITM_SERIAL'
,p_display_order=>77
,p_column_identifier=>'AF'
,p_column_label=>'Serial'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097326544560671339)
,p_db_column_name=>'ITM_MOTOR'
,p_display_order=>87
,p_column_identifier=>'AG'
,p_column_label=>'Motor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097326641487671340)
,p_db_column_name=>'ITM_CHASIS'
,p_display_order=>97
,p_column_identifier=>'AH'
,p_column_label=>'Chasis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097326913839671342)
,p_db_column_name=>'DESC_DEPARTAMENTO'
,p_display_order=>117
,p_column_identifier=>'AJ'
,p_column_label=>'Desc. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097327013673671343)
,p_db_column_name=>'LOCALIZACION'
,p_display_order=>127
,p_column_identifier=>'AK'
,p_column_label=>'Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097327105036671344)
,p_db_column_name=>'DESC_LOCALIZACION'
,p_display_order=>137
,p_column_identifier=>'AL'
,p_column_label=>'Desc. Localizacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097414353579365595)
,p_db_column_name=>'TRA_ESTADO'
,p_display_order=>147
,p_column_identifier=>'AM'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097414521585365596)
,p_db_column_name=>'TRA_LPO_LISTA'
,p_display_order=>157
,p_column_identifier=>'AN'
,p_column_label=>'Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097414581423365597)
,p_db_column_name=>'CEDULA'
,p_display_order=>167
,p_column_identifier=>'AO'
,p_column_label=>'Cedula'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097414636866365598)
,p_db_column_name=>'TIPO_FACT'
,p_display_order=>177
,p_column_identifier=>'AP'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097414754611365599)
,p_db_column_name=>'FECHA_VENCIMIENTO'
,p_display_order=>187
,p_column_identifier=>'AQ'
,p_column_label=>'F. Vencimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097414892509365600)
,p_db_column_name=>'TIPO_TRANSACCION'
,p_display_order=>197
,p_column_identifier=>'AR'
,p_column_label=>'T. Transaccion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097414980159365601)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>207
,p_column_identifier=>'AS'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097415315101365604)
,p_db_column_name=>'CLASE'
,p_display_order=>217
,p_column_identifier=>'AT'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097415371718365605)
,p_db_column_name=>'MONEDA_LISTA'
,p_display_order=>227
,p_column_identifier=>'AU'
,p_column_label=>'Moneda Lista'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097732836347647142)
,p_db_column_name=>'T_CAMBIO'
,p_display_order=>237
,p_column_identifier=>'AV'
,p_column_label=>'T. Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14097901313393642720)
,p_db_column_name=>'CREADO_POR'
,p_display_order=>247
,p_column_identifier=>'AW'
,p_column_label=>'Creado por'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314549456873801)
,p_db_column_name=>'CLIENTE_RESER'
,p_display_order=>257
,p_column_identifier=>'AX'
,p_column_label=>'Cliente Reserva'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314702274873802)
,p_db_column_name=>'CEDULA_RESER'
,p_display_order=>267
,p_column_identifier=>'AY'
,p_column_label=>unistr('C\00E9dula Cliente Reserva')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098314815224873803)
,p_db_column_name=>'CLI_NOMBRE_RESER'
,p_display_order=>277
,p_column_identifier=>'AZ'
,p_column_label=>'Nombre Cliente Reserva'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098317031862873826)
,p_db_column_name=>'FECHA_NOTA'
,p_display_order=>287
,p_column_identifier=>'BA'
,p_column_label=>'Fecha Nota'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098317182195873827)
,p_db_column_name=>'PADRE_DEPARTAMENTO'
,p_display_order=>297
,p_column_identifier=>'BB'
,p_column_label=>'Departamento Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098317228795873828)
,p_db_column_name=>'DESC_DEPARTAMENTO_PADRE'
,p_display_order=>307
,p_column_identifier=>'BC'
,p_column_label=>'Desc. Departamento Padre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098317327113873829)
,p_db_column_name=>'MONTO_NOTA'
,p_display_order=>317
,p_column_identifier=>'BD'
,p_column_label=>'Monto Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098317512653873830)
,p_db_column_name=>'DESCUENTO_NOTA'
,p_display_order=>327
,p_column_identifier=>'BE'
,p_column_label=>'Descuento Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14098317563086873831)
,p_db_column_name=>'IVA_NOTA'
,p_display_order=>337
,p_column_identifier=>'BF'
,p_column_label=>'Impuesto Nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14099124360428152609)
,p_db_column_name=>'ITM_ANO'
,p_display_order=>347
,p_column_identifier=>'BI'
,p_column_label=>'Itm ano'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14083388405086714370)
,p_db_column_name=>'NOTA'
,p_display_order=>357
,p_column_identifier=>'BQ'
,p_column_label=>'Nota'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084692060638360973)
,p_db_column_name=>'COMP_ELECT'
,p_display_order=>367
,p_column_identifier=>'BR'
,p_column_label=>unistr('Comprobante electr\00F3nico ')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14057907672908533674)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>377
,p_column_identifier=>'BS'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13927620050795715626)
,p_db_column_name=>'TRA_ENC_CONSULTA'
,p_display_order=>387
,p_column_identifier=>'BT'
,p_column_label=>'Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14167872107143062337)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'107583'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EMPRESA:TRANSACCION:FACTURA:COMP_ELECT:TRA_ESTADO:ORDEN_TALLER:FECHA:PADRE_DEPARTAMENTO:DESC_DEPARTAMENTO_PADRE:DEPARTAMENTO:DESC_DEPARTAMENTO:LOCALIZACION:DESC_LOCALIZACION:MONEDA:T_CAMBIO:TRA_LPO_LISTA:MONEDA_LISTA:COD_VEND:NOMBRE_VEND:CLIENTE:CEDU'
||'LA:NOMBRE:CLIENTE_RESER:CEDULA_RESER:CLI_NOMBRE_RESER:TIPO_FACT:FECHA_VENCIMIENTO:TIPO_TRANSACCION:DOCUMENTO:ARTICULO:DESCRIPCION:CODIGO_FAMILIA:FAMILIA:FAMILIA_PADRE:TIPOARTICULO:CANTIDAD:PRECIOUNITARIO:CLASE:ITM_CLR_COLOR:ITM_SERIAL:ITM_MOTOR:ITM_C'
||'HASIS:DESCUENTO:IMPUESTO:TOTAL:PRECIOTOTAL:TOTAL_NOTAS:TIPO_COMPRA:CREADO_POR::ORDEN_COMPRA:TRA_ENC_CONSULTA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168165014657601985)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966310101227995419)
,p_name=>'P48_LOCAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   FROM DUAL',
'connect by regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13966310130912995420)
,p_name=>'P48_ALTERNA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )   FROM DUAL',
'connect by regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level) is not null;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14098453536217593683)
,p_name=>'P48_AUTO_CCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE   use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167873218327065942)
,p_name=>'P48_TRANSACCION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167873396858065943)
,p_name=>'P48_INICIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167873620316065943)
,p_name=>'P48_FIN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14167873817447065943)
,p_name=>'P48_EMPRESA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14168117012802288070)
,p_name=>'P48_MONEDA'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14167873019610065941)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MONEDA'
,p_lov=>'.'||wwv_flow_api.id(13966336081955007059)||'.'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14098722683934306635)
,p_computation_sequence=>10
,p_computation_item=>'P48_AUTO_CCA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   COUNT ( * )',
'  FROM   nss_autorizacion_usuario_tb_nx nss, gnl_usuario_empresa_tb_nx gnl',
' WHERE   use_usu_user_id = gnl_id_usuario_n_nx (:APP_USER)',
'         AND subsistema = ''INV''',
'         AND autorizacion = ''CCA''',
'         AND nss.use_id = gnl.use_id;'))
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966308141660995400)
,p_validation_name=>'MONEDA_EMPRESAS'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level) is not null;',
'             ',
'IF (cantidad_local_v > 1 AND :P48_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
'',
'IF (cantidad_alt_v > 1 AND :P48_MONEDA = ''A'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
'',
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') )   INTO :P48_LOCAL FROM DUAL',
'connect by regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA CONVERSION'') )  INTO :P48_ALTERNA   FROM DUAL',
'connect by regexp_substr(:P48_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_api.id(14168165014657601985)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14098722532842306634)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'llena_reporte_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'fac_det_factura_pr_nx (',
':P48_EMPRESA,                              (CASE WHEN :P48_MONEDA = ''L'' THEN :P48_LOCAL WHEN :P48_MONEDA = ''A'' THEN :P48_ALTERNA ELSE ''ND'' END ),                                                            :P48_INICIO,                                 '
||'                :P48_FIN,',
':APP_USER',
');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14168165014657601985)
);
wwv_flow_api.component_end;
end;
/
