prompt --application/pages/page_00142
begin
--   Manifest
--     PAGE: 00142
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>142
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'CXC - Analisis Antiguedad Financiamientos'
,p_step_title=>'CXC - Analisis Antiguedad Financiamientos'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'MBACASE'
,p_last_upd_yyyymmddhh24miss=>'20201221125752'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14222435008249620032)
,p_plug_name=>'Analisis Antiguedad Financiamientos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13932073901547672424)
,p_plug_name=>'Detalle Recibos'
,p_parent_plug_id=>wwv_flow_api.id(14222435008249620032)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select solicitud,padre,num_doc,documento,fecha,cuota,TO_NUMBER(monto_total) monto_total, mora_cobrada, STATUS, ',
'TO_NUMBER(DECODE (STATUS, ''P'', monto_total, 0)) MONTO_PENDIENTES ',
'from CXC_ESTADO_CUENTA_FIN_VW_NX',
'where padre <> 0',
'and cuota is null',
'and status in (''P'',''L'')',
'AND solicitud= :P142_SOLICITUD',
'ORDER BY padre'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'<div style="margin-top: 20px;">',
unistr('    <p style="font-weight:bold;">Detalle Cancelaci\00F3n Cuotas </p>'),
'        ',
'    </div>'))
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13932073970510672425)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>4484043665801721
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074077838672426)
,p_db_column_name=>'SOLICITUD'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Solicitud'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074184143672427)
,p_db_column_name=>'PADRE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Padre'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074259833672428)
,p_db_column_name=>'NUM_DOC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Num Doc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074364887672429)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074456711672430)
,p_db_column_name=>'FECHA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074603384672431)
,p_db_column_name=>'CUOTA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cuota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074761375672433)
,p_db_column_name=>'MORA_COBRADA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Mora Cobrada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074841532672434)
,p_db_column_name=>'STATUS'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932074952384672435)
,p_db_column_name=>'MONTO_PENDIENTES'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Monto Pendientes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13932075297226672438)
,p_db_column_name=>'MONTO_TOTAL'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Monto Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13932100605891938687)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'45107'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SOLICITUD:PADRE:NUM_DOC:DOCUMENTO:FECHA:CUOTA:MORA_COBRADA:STATUS:MONTO_PENDIENTES:MONTO_TOTAL'
,p_sum_columns_on_break=>'MONTO_PENDIENTES:MONTO_TOTAL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14222430800188609191)
,p_plug_name=>'Analisis Antiguedad Financiamientos'
,p_parent_plug_id=>wwv_flow_api.id(14222435008249620032)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'''consulta'' consultar,',
'c001 trx_empresa,',
'c002 trx_moneda,',
'c003 trx_dsp_moneda,',
'c004 trx_grupo_cta,',
'c005 trx_departamento,',
'c006 trx_dsp_departamento,',
'c007 trx_clase,',
'c008 trx_dsp_clase,',
'c009 trx_cobrador,',
'c010 trx_dsp_cobrador,',
'c011 trx_vendedor,',
'c012 trx_dsp_vendedor,',
'c013 trx_cliente,',
'c014 trx_dsp_cliente,',
'c015 trx_persona,',
'c016 trx_telefonos,',
'c017 trx_ciudad,',
'c018 trx_zona,',
'c019 trx_operacion,',
'c020 trx_solicitud,',
'TO_NUMBER(c021) trx_monto_aprobado,',
'TO_DATE(c022, ''DD/MM/RRRR'') trx_fecha_apertura,',
'TO_NUMBER(c023) trx_plazo,',
'TO_NUMBER(c024) trx_plazo_restante,',
'TO_NUMBER(c025) trx_tasa_interes,',
'TO_NUMBER(c026) vencidas_v,',
'TO_NUMBER(c027) cuota_v,',
'TO_NUMBER(c028) saldo_v,',
'TO_NUMBER(c029) trx_nvencido,',
'TO_NUMBER(c030) trx_vencido30,',
'TO_NUMBER(c031) trx_vencido60,',
'TO_NUMBER(c032) trx_vencido90,',
'TO_NUMBER(c033) trx_vencido120,',
'TO_NUMBER(c034) trx_vencido,',
'TO_NUMBER(c035) trx_abono,',
'TO_DATE(c036, ''DD/MM/RRRR'') trx_fult_pag,',
'TO_NUMBER(c037) trx_mult_pag,',
'TO_NUMBER(c038) trx_dsin_pag,',
'c039 trx_status,',
'c040 estado_financiamiento,',
'TO_NUMBER(c041) por_aplicar',
'FROM apex_collections',
'WHERE collection_name = ''CXCANT'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P142_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="margin-top: 20px;">',
'    <p style="font-weight:bold;">Transacciones de Financiamiento </span>',
''))
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14222430913472609191)
,p_name=>'Detalle de Facturas'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'ACAMPOS'
,p_internal_uid=>159411183032392932
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13938438749517286748)
,p_db_column_name=>'CONSULTAR'
,p_display_order=>10
,p_column_identifier=>'GP'
,p_column_label=>'Consultar'
,p_column_link=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.:RP:P142_SOLICITUD:#TRX_SOLICITUD#'
,p_column_linktext=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_column_link_attr=>'class="orderReportButton            t-Button            t-Button--simple            t-Button--hot            t-Button--stretch" data-order-id="#TRX_SOLICITUD#" type="button"'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084161866392272340)
,p_db_column_name=>'TRX_EMPRESA'
,p_display_order=>20
,p_column_identifier=>'EF'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084162154265272347)
,p_db_column_name=>'TRX_MONEDA'
,p_display_order=>30
,p_column_identifier=>'EG'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084162573058272347)
,p_db_column_name=>'TRX_DSP_MONEDA'
,p_display_order=>40
,p_column_identifier=>'EH'
,p_column_label=>'D. Moneda'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084163017463272348)
,p_db_column_name=>'TRX_GRUPO_CTA'
,p_display_order=>50
,p_column_identifier=>'EI'
,p_column_label=>'G. Cuenta'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084163397735272349)
,p_db_column_name=>'TRX_DEPARTAMENTO'
,p_display_order=>60
,p_column_identifier=>'EJ'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084163766738272350)
,p_db_column_name=>'TRX_DSP_DEPARTAMENTO'
,p_display_order=>70
,p_column_identifier=>'EK'
,p_column_label=>'D. Departamento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084164194767272350)
,p_db_column_name=>'TRX_CLASE'
,p_display_order=>80
,p_column_identifier=>'EL'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084164579956272351)
,p_db_column_name=>'TRX_DSP_CLASE'
,p_display_order=>90
,p_column_identifier=>'EM'
,p_column_label=>'D. Clase'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084164932499272352)
,p_db_column_name=>'TRX_COBRADOR'
,p_display_order=>100
,p_column_identifier=>'EN'
,p_column_label=>'Cobrador'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084165398752272352)
,p_db_column_name=>'TRX_DSP_COBRADOR'
,p_display_order=>110
,p_column_identifier=>'EO'
,p_column_label=>'D. Cobrador'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084165755585272353)
,p_db_column_name=>'TRX_VENDEDOR'
,p_display_order=>120
,p_column_identifier=>'EP'
,p_column_label=>'Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084166193303272354)
,p_db_column_name=>'TRX_DSP_VENDEDOR'
,p_display_order=>130
,p_column_identifier=>'EQ'
,p_column_label=>'D. Vendedor'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084166551760272354)
,p_db_column_name=>'TRX_CLIENTE'
,p_display_order=>140
,p_column_identifier=>'ER'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084167009976272355)
,p_db_column_name=>'TRX_DSP_CLIENTE'
,p_display_order=>150
,p_column_identifier=>'ES'
,p_column_label=>'D. Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084167411313272356)
,p_db_column_name=>'TRX_PERSONA'
,p_display_order=>160
,p_column_identifier=>'ET'
,p_column_label=>'Persona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084167802948272356)
,p_db_column_name=>'TRX_TELEFONOS'
,p_display_order=>170
,p_column_identifier=>'EU'
,p_column_label=>'Telefonos'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084168218458272357)
,p_db_column_name=>'TRX_CIUDAD'
,p_display_order=>180
,p_column_identifier=>'EV'
,p_column_label=>'Ciudad'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084168559308272358)
,p_db_column_name=>'TRX_ZONA'
,p_display_order=>190
,p_column_identifier=>'EW'
,p_column_label=>'Zona'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084169023573272359)
,p_db_column_name=>'TRX_OPERACION'
,p_display_order=>200
,p_column_identifier=>'EX'
,p_column_label=>'Operacion'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084169339859272359)
,p_db_column_name=>'TRX_SOLICITUD'
,p_display_order=>210
,p_column_identifier=>'FD'
,p_column_label=>'Solicitud'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084169738763272360)
,p_db_column_name=>'TRX_MONTO_APROBADO'
,p_display_order=>220
,p_column_identifier=>'FS'
,p_column_label=>'Monto Aprobado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084170184526272361)
,p_db_column_name=>'TRX_PLAZO'
,p_display_order=>230
,p_column_identifier=>'FT'
,p_column_label=>'Plazo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084170622268272362)
,p_db_column_name=>'TRX_PLAZO_RESTANTE'
,p_display_order=>240
,p_column_identifier=>'FU'
,p_column_label=>'Plazo Restante'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084170940520272362)
,p_db_column_name=>'TRX_TASA_INTERES'
,p_display_order=>250
,p_column_identifier=>'FV'
,p_column_label=>'Tasa Int.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084171397464272363)
,p_db_column_name=>'VENCIDAS_V'
,p_display_order=>260
,p_column_identifier=>'FW'
,p_column_label=>'C. Vencidas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084171760524272364)
,p_db_column_name=>'CUOTA_V'
,p_display_order=>270
,p_column_identifier=>'FY'
,p_column_label=>'M. Cuota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084172147074272364)
,p_db_column_name=>'SALDO_V'
,p_display_order=>280
,p_column_identifier=>'FZ'
,p_column_label=>'Saldo Act.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084172541129272370)
,p_db_column_name=>'TRX_NVENCIDO'
,p_display_order=>290
,p_column_identifier=>'GA'
,p_column_label=>'No Vencido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084173030409272371)
,p_db_column_name=>'TRX_VENCIDO30'
,p_display_order=>300
,p_column_identifier=>'GB'
,p_column_label=>'Vencido 1 a 30'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084173394667272372)
,p_db_column_name=>'TRX_VENCIDO60'
,p_display_order=>310
,p_column_identifier=>'GC'
,p_column_label=>'Vencido 31 a 60'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084173816599272373)
,p_db_column_name=>'TRX_VENCIDO90'
,p_display_order=>320
,p_column_identifier=>'GD'
,p_column_label=>'Vencido 61 a 90'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084174213251272374)
,p_db_column_name=>'TRX_VENCIDO120'
,p_display_order=>330
,p_column_identifier=>'GE'
,p_column_label=>'Vencido 91 a 120'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084174613670272374)
,p_db_column_name=>'TRX_VENCIDO'
,p_display_order=>340
,p_column_identifier=>'GF'
,p_column_label=>'Vencido > 120'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084174962105272375)
,p_db_column_name=>'TRX_ABONO'
,p_display_order=>350
,p_column_identifier=>'GG'
,p_column_label=>'Abono'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084175375096272376)
,p_db_column_name=>'TRX_MULT_PAG'
,p_display_order=>360
,p_column_identifier=>'GH'
,p_column_label=>'M. Ult. Pago'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084175818059272376)
,p_db_column_name=>'TRX_DSIN_PAG'
,p_display_order=>370
,p_column_identifier=>'GI'
,p_column_label=>'D. Sin Pago'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084176130772272377)
,p_db_column_name=>'TRX_FECHA_APERTURA'
,p_display_order=>380
,p_column_identifier=>'GJ'
,p_column_label=>'F. Apertura'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14084176611938272378)
,p_db_column_name=>'TRX_FULT_PAG'
,p_display_order=>390
,p_column_identifier=>'GK'
,p_column_label=>'F. Ult. Pago'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14058209459227913591)
,p_db_column_name=>'TRX_STATUS'
,p_display_order=>400
,p_column_identifier=>'GL'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13938437303901286733)
,p_db_column_name=>'ESTADO_FINANCIAMIENTO'
,p_display_order=>410
,p_column_identifier=>'GN'
,p_column_label=>'Estado Financiamiento'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13938437408595286734)
,p_db_column_name=>'POR_APLICAR'
,p_display_order=>420
,p_column_identifier=>'GO'
,p_column_label=>'Saldo Por Aplicar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14222434095782616428)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'211572'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TRX_EMPRESA:TRX_MONEDA:TRX_DSP_MONEDA:TRX_CLIENTE:TRX_DSP_CLIENTE:TRX_SOLICITUD:TRX_MONTO_APROBADO:CUOTA_V:SALDO_V:TRX_ABONO:POR_APLICAR:CONSULTAR:TRX_NVENCIDO:TRX_VENCIDO30:TRX_VENCIDO60:TRX_VENCIDO90:TRX_VENCIDO120:TRX_VENCIDO:TRX_STATUS:ESTADO_FIN'
||'ANCIAMIENTO:TRX_OPERACION:TRX_FECHA_APERTURA:TRX_PLAZO_RESTANTE:TRX_TASA_INTERES:VENCIDAS_V:TRX_PLAZO:TRX_FULT_PAG:TRX_MULT_PAG:TRX_DSIN_PAG:TRX_GRUPO_CTA:TRX_DEPARTAMENTO:TRX_DSP_DEPARTAMENTO:TRX_CLASE:TRX_DSP_CLASE:TRX_COBRADOR:TRX_DSP_COBRADOR:TRX'
||'_VENDEDOR:TRX_DSP_VENDEDOR:TRX_PERSONA:TRX_TELEFONOS:TRX_CIUDAD:TRX_ZONA:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14084177981303272436)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14222435008249620032)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13938438670830286747)
,p_name=>'P142_SOLICITUD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14222435008249620032)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084178422688272441)
,p_name=>'P142_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14222435008249620032)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084178760909272445)
,p_name=>'P142_TIPO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14222435008249620032)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Principal+Intereses;1,Principal;2,Intereses;3'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084179208703272446)
,p_name=>'P142_INICIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14222435008249620032)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14084179597735272447)
,p_name=>'P142_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14222435008249620032)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(13932071977944672405)
,p_name=>'Nuevo'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.orderReportButton'
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(13932072068099672406)
,p_event_id=>wwv_flow_api.id(13932071977944672405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P142_SOLICITUD'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.getAttribute(''data-order-id'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(13932075053724672436)
,p_event_id=>wwv_flow_api.id(13932071977944672405)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(13932073901547672424)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14084180015012272454)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'llena_reporte_pr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'cxc_analisis_antiguedad_pr_nx (:P142_EMPRESA, :P142_TIPO, :P142_INICIO, :P142_FIN);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14084177981303272436)
);
wwv_flow_api.component_end;
end;
/
