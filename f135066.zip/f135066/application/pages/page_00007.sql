prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>unistr('CXP \2013 Resumen por Tipo')
,p_step_title=>'Resumen por Tipo'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201104163215'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193483163185001772)
,p_plug_name=>'Resumen por Tipo'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14193484360178001777)
,p_plug_name=>'Resumen por Tipo'
,p_parent_plug_id=>wwv_flow_api.id(14193483163185001772)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT cxp_tran.TSP_TRANSACCION,',
'       cxp_tran.TSP_PRO_MON_MONEDA,',
'       cxp_tran.TSP_TTP_TIPO,',
'       cxp_tran.TSP_DOCUMENTO,',
'       cxp_tran.TSP_DETALLE_DOCUMENTO,',
'       TRUNC(cxp_tran.TSP_FECHA_DOCUMENTO) TSP_FECHA_DOCUMENTO,',
'       TRUNC(cxp_tran.TSP_FECHA_TRANSACCION) TSP_FECHA_TRANSACCION,',
'       cxp_tran.TSP_MONTO,',
'       cxp_tran.TSP_SALDO,',
'       cxp_prov.PRO_PROVEEDOR,',
'       cxp_prov.PRO_TIA_TIPO,',
'       cxp_tipo.TIA_DESCRIPCION,',
'       gnl_pers.NOMBRE_COMPLETO       ',
'FROM cxp_transaccion_tb_nx cxp_tran,',
'     cxp_proveedor_tb_nx cxp_prov,',
'     cxp_tipo_transaccion_tb_nx cxp_ttra,',
'     cxp_tipo_proveedor_tb_nx cxp_tipo,',
'     gnl_persona_vw_nx gnl_pers',
'WHERE     cxp_tran.TSP_EMP_EMPRESA = cxp_prov.PRO_EMP_EMPRESA',
'      AND cxp_tran.TSP_PRO_PROVEEDOR = cxp_prov.PRO_PROVEEDOR',
'      AND cxp_tran.TSP_PRO_MON_MONEDA = cxp_prov.PRO_MON_MONEDA',
'      AND cxp_tran.TSP_EMP_EMPRESA = cxp_ttra.TTP_EMP_EMPRESA',
'      AND cxp_tran.TSP_TTP_TIPO = cxp_ttra.TTP_TIPO',
'      AND cxp_prov.PRO_TIA_TIPO = cxp_tipo.TIA_TIPO',
'      AND cxp_prov.PRO_PER_PERSONA = gnl_pers.PERSONA',
'      AND tsp_emp_empresa = :P7_EMPRESA',
'      and TSP_FECHA_DOCUMENTO BETWEEN :P7_INICIO and to_date(:P7_FIN||'' 23:59'', ''dd/mm/rrrr hh24:mi'')',
'ORDER BY gnl_pers.NOMBRE_COMPLETO,',
'         cxp_prov.PRO_MON_MONEDA DESC,',
'         cxp_prov.PRO_TIA_TIPO,',
'         cxp_prov.PRO_PROVEEDOR,',
'         cxp_tran.TSP_TTP_TIPO'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P7_EMPRESA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_header=>'<div style="overflow:auto;border:solid 0px;">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14193484579215001777)
,p_name=>'Reporte Cuentas por Pagar por Tipo'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'HCARVAJAL'
,p_internal_uid=>7485227095816100
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193484663559001778)
,p_db_column_name=>'TSP_TRANSACCION'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TSP_TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193484780735001780)
,p_db_column_name=>'TSP_PRO_MON_MONEDA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_static_id=>'TSP_PRO_MON_MONEDA'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193484884853001780)
,p_db_column_name=>'TSP_TTP_TIPO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_static_id=>'TSP_TTP_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193484981346001780)
,p_db_column_name=>'TSP_DOCUMENTO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'TSP_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485079979001780)
,p_db_column_name=>'TSP_DETALLE_DOCUMENTO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Detalle Documento'
,p_column_type=>'STRING'
,p_static_id=>'TSP_DETALLE_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485180390001781)
,p_db_column_name=>'TSP_FECHA_DOCUMENTO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fecha Documento'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'TSP_FECHA_DOCUMENTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485252601001781)
,p_db_column_name=>'TSP_FECHA_TRANSACCION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Fecha Transaccion'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/RRRR'
,p_tz_dependent=>'N'
,p_static_id=>'TSP_FECHA_TRANSACCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485373454001781)
,p_db_column_name=>'TSP_MONTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'TSP_MONTO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485465799001782)
,p_db_column_name=>'TSP_SALDO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Saldos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'TSP_SALDO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485558607001782)
,p_db_column_name=>'PRO_PROVEEDOR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PRO_PROVEEDOR'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485670563001782)
,p_db_column_name=>'PRO_TIA_TIPO'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Pro Tia Tipo'
,p_column_type=>'STRING'
,p_static_id=>'PRO_TIA_TIPO'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485765560001783)
,p_db_column_name=>'TIA_DESCRIPCION'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_static_id=>'TIA_DESCRIPCION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193485869347001783)
,p_db_column_name=>'NOMBRE_COMPLETO'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Nombre Completo'
,p_column_type=>'STRING'
,p_static_id=>'NOMBRE_COMPLETO'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14193485955937001783)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'74867'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TSP_TRANSACCION:TSP_PRO_MON_MONEDA:TSP_TTP_TIPO:TSP_DOCUMENTO:TSP_DETALLE_DOCUMENTO:TSP_FECHA_DOCUMENTO:TSP_FECHA_TRANSACCION:TSP_MONTO:TSP_SALDO:PRO_PROVEEDOR:PRO_MON_MONEDA:PRO_TIA_TIPO:TIA_DESCRIPCION:NOMBRE_COMPLETO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14168176293952785220)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14193483163185001772)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193483362906001773)
,p_name=>'P7_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14193483163185001772)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'--Seleccione--'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193483570953001774)
,p_name=>'P7_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14193483163185001772)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14193483955798001775)
,p_name=>'P7_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14193483163185001772)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
