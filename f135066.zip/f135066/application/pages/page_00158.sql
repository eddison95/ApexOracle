prompt --application/pages/page_00158
begin
--   Manifest
--     PAGE: 00158
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>46486915229993164861
,p_default_application_id=>135066
,p_default_id_offset=>13885192501097591701
,p_default_owner=>'WKSP_CERTIFICACION'
);
wwv_flow_api.create_page(
 p_id=>158
,p_user_interface_id=>wwv_flow_api.id(14192753077894589648)
,p_name=>'FAC - Comision por Pagos'
,p_step_title=>'Comision por Pagos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(14193430675880859352)
,p_last_updated_by=>'ACAMPOS'
,p_last_upd_yyyymmddhh24miss=>'20201210093329'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14049834088431851611)
,p_plug_name=>'Comision por Pagos'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(13960796002249591914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_1'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT A.TRX_EMP_EMPRESA EMPRESA,',
'        A.TRX_TRANSACCION TRX_TRANSACCION,',
'        E.TRA_TRANSACCION TRA_TRANSACCION,',
'        A.TRX_FECHA_TRANSACCION FECHA_TRANSACCION,',
'        E.TRA_FACTURA FACTURA,',
'              DECODE (E.tra_tipo,',
'                 ''CRE'',',
'                 ''CREDITO'',',
'                 ''CON'',',
'                 ''CONTADO'',',
'                 ''FIN'',',
'                 ''FINANCIAMIENTO'',',
'                 ''NIT'',',
'                 ''NOTA INTERNA'')',
'            tipo, ',
'        A.TRX_SUB_SUBSISTEMA SUBSISTEMA,',
'        TRA_TTR_TIPO TIPO_FACTURA,',
'        A.TRX_DOC_DOCUMENTO DOCUMENTO,',
'        A.TRX_REC_NUMERO_RECIBO NUMERO_RECIBO,',
'        E.tra_ven_vendedor codigo_vendedor,',
'        gnl_nombre_vendedor_vi (E.tra_emp_empresa, E.tra_ven_vendedor)',
'            nombre_vendedor,',
'        A.TRX_CLI_CLIENTE CLIENTE,',
'        E.TRA_NOMBRE NOMBRE_CLIENTE,',
'        A.TRX_CLI_MON_MONEDA MONEDA,',
'        CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               D.REF_MONTO',
'            WHEN (E.tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (E.tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               D.REF_MONTO',
'            WHEN (E.tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               D.REF_MONTO',
'            WHEN (E.tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               D.REF_MONTO / tra_valor_cambio',
'            WHEN (E.tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               D.REF_MONTO  * tra_valor_cambio',
'         END',
'            MONTO_RECIBO,',
'        CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               E.tra_subtotal',
'            WHEN (E.tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (E.tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               E.tra_subtotal',
'            WHEN (E.tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               E.tra_subtotal',
'            WHEN (E.tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               E.tra_subtotal / tra_valor_cambio',
'            WHEN (E.tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               E.tra_subtotal * tra_valor_cambio',
'         END',
'            subtotal,',
'        CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               E.TRA_IMPUESTO_VENTAS ',
'            WHEN (E.tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (E.tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'              E.TRA_IMPUESTO_VENTAS ',
'            WHEN (E.tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               E.TRA_IMPUESTO_VENTAS ',
'            WHEN (E.tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               E.TRA_IMPUESTO_VENTAS / tra_valor_cambio',
'            WHEN (E.tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               E.TRA_IMPUESTO_VENTAS * tra_valor_cambio',
'         END',
'            IMPUESTO,',
'          CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               E.tra_descuento',
'            WHEN (E.tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (E.tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               E.tra_descuento',
'            WHEN (E.tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               E.tra_descuento',
'            WHEN (E.tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               E.tra_descuento / tra_valor_cambio',
'            WHEN (E.tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               E.tra_descuento * tra_valor_cambio',
'         END',
'            descuento,',
'            CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               E.TRA_TOTAL',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               E.TRA_TOTAL',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               E.TRA_TOTAL',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               E.TRA_TOTAL / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               E.TRA_TOTAL * tra_valor_cambio',
'         END Total_Factura,',
'           CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               ROUND(D.REF_MONTO-(D.REF_MONTO* (TRA_IMPUESTO_VENTAS/E.TRA_TOTAL)))',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               ROUND(D.REF_MONTO-(D.REF_MONTO* (TRA_IMPUESTO_VENTAS/E.TRA_TOTAL)))',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               ROUND(D.REF_MONTO-(D.REF_MONTO* (TRA_IMPUESTO_VENTAS/E.TRA_TOTAL)))',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               ROUND(D.REF_MONTO-(D.REF_MONTO* (TRA_IMPUESTO_VENTAS/E.TRA_TOTAL))) / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               ROUND(D.REF_MONTO-(D.REF_MONTO* (TRA_IMPUESTO_VENTAS/E.TRA_TOTAL))) * tra_valor_cambio',
'         END COMISION,',
'            CASE C.REC_STATUS',
'             WHEN ''X'' THEN ''Anulado''',
'             WHEN ''C'' THEN ''Creado''',
'             WHEN ''A'' THEN ''Aplicado''',
'             WHEN ''F'' THEN ''Finalizado''',
'          END',
'             ESTADO,',
'          B.trx_monto MONTO_PADRE,',
'          B.trx_saldo SALDO,',
'          B.trx_fecha_vencimiento FECHA_VENCIMIENTO,',
'           CASE',
'             WHEN (SYSDATE - B.trx_fecha_vencimiento) < 0 THEN 0',
'             ELSE TRUNC (SYSDATE - B.trx_fecha_vencimiento)',
'          END DIAS_VENCIDOS,',
'          B.TRX_DIAS_GRACIA dias_gracia,',
'          G.NCD_TRANSACCION,',
'          CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               G.NCD_MONTO',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               G.NCD_MONTO',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               G.NCD_MONTO',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               G.NCD_MONTO / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               G.NCD_MONTO * tra_valor_cambio',
'         END MONTO_NOTA',
'FROM CXC_TRANSACCION_TB_NX A,',
'     CXC_TRANSACCION_TB_NX B,',
'     CXC_RECIBO_CAJA_TB_NX C, ',
'     CXC_REFERENCIA_TB_NX  D,',
'     FAC_FACTURA_TB_NX E,',
'     FAC_FACTURA_NOTA_TB_NX F,',
'     FAC_NOTAS_CR_DB_TB_NX G',
'WHERE  INSTR ('':'' || :p158_empresa || '':'', '':'' || A.TRX_EMP_EMPRESA || '':'') > 0',
'AND A.TRX_FECHA_TRANSACCION BETWEEN :P158_INICIO AND to_date(:P158_FIN||'' 23:59'', ''dd/mm/rrrr hh24:mi'')',
'AND A.TRX_REC_EMP_EMPRESA = C.REC_EMP_EMPRESA ',
'AND A.TRX_REC_NUMERO_RECIBO = C.REC_NUMERO_RECIBO',
'AND A.TRX_TRANSACCION = D.REF_TRX_TRANSACCION_HIJAS ',
'AND B.TRX_TRANSACCION = D.REF_TRX_TRANSACCION',
'AND B.TRX_TRA_TRANSACCION = E.TRA_TRANSACCION',
'AND E.TRA_TRANSACCION = F.FNT_TRA_TRANSACCION(+)',
'AND F.FNT_NCD_TRANSACCION = NCD_TRANSACCION(+) ',
'UNION ALL',
'SELECT TRA_EMP_EMPRESA,',
'        NULL TRX_TRANSACCION,',
'        TRA_TRANSACCION TRA_TRANSACCION,',
'        TRA_FECHA,',
'        TRA_FACTURA,',
'                      DECODE (tra_tipo,',
'                 ''CRE'',',
'                 ''CREDITO'',',
'                 ''CON'',',
'                 ''CONTADO'',',
'                 ''FIN'',',
'                 ''FINANCIAMIENTO'',',
'                 ''NIT'',',
'                 ''NOTA INTERNA'')',
'            tipo, ',
'        TRA_SUB_SUBSISTEMA,',
'        TRA_TTR_TIPO,',
'        TRA_DOC_DOCUMENTO,',
'        NULL NUMERO_RECIBO,',
'        tra_ven_vendedor codigo_vendedor,',
'        gnl_nombre_vendedor_vi (tra_emp_empresa,tra_ven_vendedor)',
'            nombre_vendedor,',
'        TRA_CLI_CLIENTE,',
'        TRA_NOMBRE,',
'        TRA_MON_MONEDA ,',
'        NULL ,',
'        CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               tra_subtotal / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               tra_subtotal * tra_valor_cambio',
'         END',
'            subtotal,',
'        TRA_IMPUESTO_VENTAS,',
'          CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               tra_descuento',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               tra_descuento / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               tra_descuento * tra_valor_cambio',
'         END',
'            descuento,',
'            CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               tra_total',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               tra_total',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               tra_total',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               tra_total / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               tra_total * tra_valor_cambio',
'         END Total_Factura,',
'          CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               tra_subtotal ',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               tra_subtotal',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               tra_subtotal / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               tra_subtotal * tra_valor_cambio',
'         END',
'            COMISION,',
'          NULL Estado,',
'          NULL MONTO_PADRE,',
'          NULL Saldo,',
'          NULL FECHA_VENCIMIENTO,',
'          NULL DIAS_VENCIDOS,',
'          NULL dias_gracia,',
'          NCD_TRANSACCION ,',
'          CASE',
'            WHEN (:p158_moneda = ''ND'')',
'            THEN',
'               NCD_MONTO ',
'            WHEN (tra_valor_cambio = 0)',
'            THEN',
'               0',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               NCD_MONTO',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               NCD_MONTO',
'            WHEN (tra_mon_moneda = :P158_MON_LOCAL AND :p158_moneda = ''EX'')',
'            THEN',
'               NCD_MONTO / tra_valor_cambio',
'            WHEN (tra_mon_moneda <> :P158_MON_LOCAL AND :p158_moneda = ''LO'')',
'            THEN',
'               NCD_MONTO * tra_valor_cambio',
'         END MONTO_NOTA',
'FROM FAC_FACTURA_TB_NX,',
'     FAC_FACTURA_NOTA_TB_NX,',
'     FAC_NOTAS_CR_DB_TB_NX',
'WHERE  INSTR ('':'' || :p158_empresa || '':'', '':'' || TRA_EMP_EMPRESA || '':'') > 0',
'AND TRA_FECHA BETWEEN :P158_INICIO AND to_date(:P158_FIN||'' 23:59'', ''dd/mm/rrrr hh24:mi'')',
'AND TRA_TIPO =''CON''',
'AND TRA_TRANSACCION = FNT_TRA_TRANSACCION(+)',
'AND FNT_NCD_TRANSACCION = NCD_TRANSACCION(+)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P158_EMPRESA'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14049834193791851611)
,p_name=>'FAC - COMISION POR PAGOS'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(14000867207679915099)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'JJIMENEZ'
,p_internal_uid=>3242343663377699
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049834591597851626)
,p_db_column_name=>'EMPRESA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049834968645851632)
,p_db_column_name=>'TRX_TRANSACCION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Trx Transaccion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049835422652851633)
,p_db_column_name=>'TRA_TRANSACCION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Tra Transaccion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049835768609851633)
,p_db_column_name=>'FECHA_TRANSACCION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fecha Transaccion'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MM-YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049836192817851634)
,p_db_column_name=>'FACTURA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049836584488851635)
,p_db_column_name=>'TIPO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049837000944851636)
,p_db_column_name=>'SUBSISTEMA'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Subsistema'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049837420511851638)
,p_db_column_name=>'TIPO_FACTURA'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Tipo Factura'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049837800145851638)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049838229080851641)
,p_db_column_name=>'CODIGO_VENDEDOR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Codigo Vendedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049838595507851643)
,p_db_column_name=>'NOMBRE_VENDEDOR'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Nombre Vendedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049838988616851644)
,p_db_column_name=>'CLIENTE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049839386769851646)
,p_db_column_name=>'NOMBRE_CLIENTE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Nombre Cliente'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049839775808851648)
,p_db_column_name=>'MONEDA'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049840629087851650)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049841006980851655)
,p_db_column_name=>'IMPUESTO'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Impuesto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049841446154851656)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049841807480851656)
,p_db_column_name=>'TOTAL_FACTURA'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Total Factura'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049842249140851658)
,p_db_column_name=>'COMISION'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Comision'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049843933106900123)
,p_db_column_name=>'MONTO_RECIBO'
,p_display_order=>30
,p_column_identifier=>'V'
,p_column_label=>'Monto recibo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049844284520900127)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'W'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049844427377900128)
,p_db_column_name=>'MONTO_PADRE'
,p_display_order=>50
,p_column_identifier=>'X'
,p_column_label=>'Monto padre'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049844511309900129)
,p_db_column_name=>'SALDO'
,p_display_order=>60
,p_column_identifier=>'Y'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14049846609623900150)
,p_db_column_name=>'NUMERO_RECIBO'
,p_display_order=>70
,p_column_identifier=>'Z'
,p_column_label=>'Numero recibo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14037178110282435595)
,p_db_column_name=>'FECHA_VENCIMIENTO'
,p_display_order=>80
,p_column_identifier=>'AA'
,p_column_label=>'Fecha vencimiento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14037178128513435596)
,p_db_column_name=>'DIAS_VENCIDOS'
,p_display_order=>90
,p_column_identifier=>'AB'
,p_column_label=>'Dias vencidos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14037007384246286592)
,p_db_column_name=>'DIAS_GRACIA'
,p_display_order=>100
,p_column_identifier=>'AC'
,p_column_label=>'Dias gracia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14024166656662642056)
,p_db_column_name=>'NCD_TRANSACCION'
,p_display_order=>110
,p_column_identifier=>'AD'
,p_column_label=>'Ncd transaccion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14024166700997642057)
,p_db_column_name=>'MONTO_NOTA'
,p_display_order=>120
,p_column_identifier=>'AE'
,p_column_label=>'Monto nota'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14049851518147971487)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'32597'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMPRESA:TRX_TRANSACCION:TRA_TRANSACCION:FECHA_TRANSACCION:FACTURA:TIPO:SUBSISTEMA:TIPO_FACTURA:DOCUMENTO:CODIGO_VENDEDOR:NOMBRE_VENDEDOR:CLIENTE:NOMBRE_CLIENTE:MONEDA:SUBTOTAL:IMPUESTO:DESCUENTO:TOTAL_FACTURA:COMISION:MONTO_RECIBO:ESTADO:MONTO_PADRE:'
||'SALDO:NUMERO_RECIBO:FECHA_VENCIMIENTO:DIAS_VENCIDOS:DIAS_GRACIA:NCD_TRANSACCION:MONTO_NOTA'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14049842978685900114)
,p_plug_name=>'Comision por Pagos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(13960797068045591914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY_1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14049843740120900121)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(14049842978685900114)
,p_button_name=>'CONSULTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Consultar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14049843644458900120)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14049834088431851611)
,p_button_name=>'RESTABLECER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(13960853193765591935)
,p_button_image_alt=>'Restablecer'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:158:&SESSION.::&DEBUG.:RP,158::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14049843076300900115)
,p_name=>'P158_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14049842978685900114)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT   (EMPRESA || '' - '' || NOMBRE) NOMBRE, EMPRESA',
'    FROM   NSS_USUARIO_EMPRESA_VW_NX',
'   WHERE   USERNAME = :APP_USER',
'ORDER BY   EMPRESA;'))
,p_lov_display_null=>'YES'
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14049843242913900116)
,p_name=>'P158_MONEDA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14049842978685900114)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:No Definida;ND, Local;LO,Alterna;EX'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960852250431591935)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14049843429072900118)
,p_name=>'P158_INICIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14049842978685900114)
,p_prompt=>'Inicio'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14049843512320900119)
,p_name=>'P158_FIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14049842978685900114)
,p_prompt=>'Fin'
,p_source=>'select sysdate from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(13960851924117591935)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14049844080018900125)
,p_name=>'P158_MON_LOCAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14049842978685900114)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(14058125594857120056)
,p_computation_sequence=>10
,p_computation_item=>'P158_MON_LOCAL'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VALOR',
'FROM GNL_PARAMETRO_EMPRESA_TB_NX',
'WHERE INSTR ('':'' || :p151_empresa || '':'', '':'' || EMPRESA || '':'') > 0',
'AND PARAMETRO = ''MONEDA''',
'AND SUBSISTEMA= ''CGL''',
'GROUP BY VALOR'))
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13966308942401995408)
,p_validation_name=>'MONEDA_EMPRESA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'cantidad_local_v NUMBER(10);',
'cantidad_alt_v NUMBER(10);',
'BEGIN',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P158_EMPRESA,''[^:]+'', 1, level), ''CGL'',''MONEDA'') ) ) INTO cantidad_local_v FROM DUAL',
'connect by regexp_substr(:P158_EMPRESA,''[^:]+'', 1, level) is not null;',
'',
'SELECT count(DISTINCT ( GNL_PARAMETRO_EMP_V_NX(',
'regexp_substr(:P158_EMPRESA,''[^:]+'', 1, level), ''GNL'',''MONEDA_CONVERSION'') ) ) INTO cantidad_alt_v FROM DUAL',
'connect by regexp_substr(:P158_EMPRESA,''[^:]+'', 1, level) is not null;',
'             ',
'IF (cantidad_local_v > 1 AND :P158_MONEDA = ''L'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Local configurada.'');',
'END IF;',
'',
'IF (cantidad_alt_v > 1 AND :P158_MONEDA = ''A'') THEN',
'    return (''No es posible consultar empresas con mas de una Moneda Alterna configurada.'');',
'END IF;',
'',
'',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_api.id(14049843740120900121)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
